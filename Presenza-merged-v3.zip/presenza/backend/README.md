# Shared Backend Packages Guide

This guide explains how to use Presenza's shared backend packages.

``` text
com.presenza.backend
├── common
│   ├── exception
│   ├── health
│   └── response
├── config
└── security
```

## 1. `common`

Use `common` for code genuinely reused by multiple feature modules.

Current structure:

``` text
common/
├── exception/
│   ├── BadRequestException.java
│   ├── GlobalExceptionHandler.java
│   └── ResourceNotFoundException.java
├── health/
│   └── HealthController.java
└── response/
    ├── ApiError.java
    └── ValidationError.java
```

Do not use `common` as a dumping ground for feature-specific code.

## 2. `ResourceNotFoundException`

Use when a requested resource does not exist, such as an employee,
shift, ticket, geofence, or attendance request.

``` java
Employee employee = employeeRepository
        .findById(employeeId)
        .orElseThrow(() ->
                new ResourceNotFoundException(
                        "Employee not found with id: " + employeeId
                )
        );
```

Flow:

``` text
Service
  ↓
Resource missing
  ↓
throw ResourceNotFoundException
  ↓
GlobalExceptionHandler
  ↓
HTTP 404
```

Do not repeat controller-level `try/catch` blocks just to format 404
responses.

## 3. `BadRequestException`

Use when a request violates a business rule.

Examples:

-   employee already checked in
-   end date is before start date
-   shift is inactive
-   invalid status transition

``` java
if (endDate.isBefore(startDate)) {
    throw new BadRequestException(
            "End date cannot be before start date"
    );
}
```

The global handler converts this to HTTP 400.

## 4. `GlobalExceptionHandler`

This is the central exception-to-HTTP-response mapper.

It uses:

``` java
@RestControllerAdvice
```

Current behavior:

``` text
ResourceNotFoundException
        ↓
404 Not Found

BadRequestException
        ↓
400 Bad Request

MethodArgumentNotValidException
        ↓
400 Bad Request + field errors
```

Never manually call the handler:

``` java
globalExceptionHandler.handleBadRequest(...);
```

Instead throw the appropriate exception:

``` java
throw new BadRequestException("Shift is inactive");
```

Spring routes it to the handler.

## 5. `ApiError`

`ApiError` defines the normal API error shape:

``` java
public record ApiError(
        int status,
        String error,
        String message,
        String path,
        Instant timestamp
) {
}
```

Example:

``` json
{
  "status": 404,
  "error": "Not Found",
  "message": "Ticket not found",
  "path": "/api/tickets/99",
  "timestamp": "2026-07-05T08:00:00Z"
}
```

Feature modules normally should not construct this manually. Throw the
correct exception and let the global handler create it.

## 6. Validation with `@Valid`

Use Jakarta Validation annotations on request DTOs.

``` java
public record CreateUserRequest(

        @NotBlank(message = "Username is required")
        String username,

        @NotBlank(message = "Email is required")
        @Email(message = "Email must be valid")
        String email
) {
}
```

Controller:

``` java
@PostMapping
public ResponseEntity<?> createUser(
        @Valid @RequestBody CreateUserRequest request
) {
    return ResponseEntity.ok().build();
}
```

Important import:

``` java
import jakarta.validation.Valid;
```

If validation fails, Spring throws `MethodArgumentNotValidException`,
which the global handler converts to `ValidationError`.

## 7. `ValidationError`

Use this response shape for field-level DTO validation failures:

``` java
public record ValidationError(
        int status,
        String error,
        String message,
        String path,
        Map<String, String> fieldErrors,
        Instant timestamp
) {
}
```

Example:

``` json
{
  "status": 400,
  "error": "Bad Request",
  "message": "Validation failed",
  "path": "/api/users",
  "fieldErrors": {
    "username": "Username is required",
    "email": "Email must be valid"
  },
  "timestamp": "2026-07-05T08:00:00Z"
}
```

Use validation annotations for request-shape constraints:

``` text
blank username
invalid email format
missing required field
invalid field size
```

Use service-layer exceptions for business rules:

``` text
employee already checked in
shift is inactive
request already reviewed
resource does not exist
```

## 8. `health`

Current structure:

``` text
common/
└── health/
    └── HealthController.java
```

Endpoint:

``` text
GET /api/health
```

Example response:

``` json
{
  "status": "UP",
  "service": "presenza-backend"
}
```

Use it for local startup checks, teammate setup checks, basic deployment
checks, and confirming Spring MVC routing works.

The current endpoint proves the HTTP application responds. It does not
necessarily prove Neon connectivity or full dependency health.

## 9. `config`

Use `config` for application-wide Spring configuration.

Possible future examples:

``` text
config/
├── CorsConfig.java
├── JacksonConfig.java
└── AppConfig.java
```

Add configuration only when actually needed, such as:

-   CORS policy
-   custom JSON serialization
-   application-wide Spring beans
-   special framework configuration

Do not create empty `JpaConfig.java` or similar classes just because a
technology exists. Spring Boot already auto-configures many components.

## 10. `security`

Use `security` for authentication and authorization infrastructure.

Possible future structure:

``` text
security/
├── config/
├── filter/
├── service/
└── permission/
```

Potential responsibilities:

-   resolving the authenticated user
-   authentication filters
-   access-control configuration
-   permission checks
-   protected endpoint rules

Typical authorization flow:

``` text
Is user authenticated?
        ↓
Which user?
        ↓
Which organization?
        ↓
Can they access this resource?
        ↓
Are they the correct team manager?
```

Do not build security filters until the authentication/session strategy
is agreed upon.

## 11. How Feature Modules Use `common`

Employee lookup:

``` text
EmployeeController
        ↓
EmployeeService
        ↓
EmployeeRepository
        ↓
No employee found
        ↓
ResourceNotFoundException
        ↓
GlobalExceptionHandler
        ↓
ApiError
        ↓
HTTP 404
```

Attendance request:

``` text
AttendanceController
        ↓
@Valid request DTO
        ↓
Invalid field?
   Yes → ValidationError
   No
        ↓
AttendanceService
        ↓
Business rule fails?
   Yes → BadRequestException
   No  → continue
```

## 12. Quick Decision Guide

Situation                             Use
  ------------------------------------- --------------------------------------
Requested resource does not exist     `ResourceNotFoundException`
Business rule makes request invalid   `BadRequestException`
DTO field is blank/invalid            Jakarta Validation annotation
Multiple DTO fields fail              `ValidationError` via global handler
Need consistent HTTP error JSON       `GlobalExceptionHandler`
Need genuinely shared reusable code   `common`
Need Spring-wide configuration        `config`
Need auth/access infrastructure       `security`
Need logic for one feature            Keep it inside that feature module

## 13. Team Rules

1.  Keep business logic inside feature services.
2.  Do not put feature-specific logic into `common`.
3.  Do not manually call `GlobalExceptionHandler`.
4.  Throw meaningful exceptions from services.
5.  Use `@Valid` on controller request DTOs when validation is required.
6.  Do not manually construct validation responses in every controller.
7.  Do not create configuration classes without a real need.
8.  Do not implement security filters until the auth strategy is
    confirmed.
9.  Do not expose secrets, password hashes, or stack traces in API
    errors.
10. Extend shared infrastructure only when a real repeated need appears.

## Summary

``` text
common
= reusable shared code

common.exception
= shared exceptions + global exception handling

common.response
= consistent error response shapes

common.health
= lightweight backend availability endpoint

config
= application-wide Spring configuration

security
= authentication and authorization infrastructure
```

Current stage:

``` text
common      → active and usable
config      → keep minimal until needed
security    → design with auth/session flow
```
