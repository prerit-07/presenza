package com.presenza.backend.presence.controller;

import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.common.exception.BadRequestException;
import com.presenza.backend.common.exception.GlobalExceptionHandler;
import com.presenza.backend.presence.dto.response.PresenceResponse;
import com.presenza.backend.presence.enums.PresenceEventType;
import com.presenza.backend.presence.enums.PresenceState;
import com.presenza.backend.presence.service.PresenceService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class PresenceControllerIntegrationTest {

    private PresenceService presenceService;
    private TokenService tokenService;
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        presenceService = mock(PresenceService.class);
        tokenService = mock(TokenService.class);
        mockMvc = MockMvcBuilders
                .standaloneSetup(new PresenceController(
                        presenceService,
                        tokenService
                ))
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();

        when(tokenService.getAuthenticatedUser("valid-token"))
                .thenReturn(new AuthenticatedUser(1, 20, "EMPLOYEE"));
    }

    @Test
    void postPresenceUpdateReturnsOkAndExitEvent() throws Exception {
        when(presenceService.processPresenceUpdate(eq(1), eq(20), any()))
                .thenReturn(new PresenceResponse(
                        true,
                        PresenceEventType.EXIT,
                        PresenceState.OUTSIDE,
                        null
                ));

        mockMvc.perform(post("/presence/updates")
                        .header("Authorization", "Bearer valid-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(validPayload()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.eventGenerated").value(true))
                .andExpect(jsonPath("$.eventType").value("EXIT"))
                .andExpect(jsonPath("$.currentState").value("OUTSIDE"));
    }

    @Test
    void postPresenceUpdateRejectsMissingAuthentication() throws Exception {
        mockMvc.perform(post("/presence/updates")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(validPayload()))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void postPresenceUpdateRejectsInvalidUser() throws Exception {
        when(tokenService.getAuthenticatedUser("invalid-token"))
                .thenThrow(new InvalidCredentialsException());

        mockMvc.perform(post("/presence/updates")
                        .header("Authorization", "Bearer invalid-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(validPayload()))
                .andExpect(status().isUnauthorized());

        verifyNoInteractions(presenceService);
    }

    @Test
    void postPresenceUpdateRejectsInvalidCoordinates() throws Exception {
        mockMvc.perform(post("/presence/updates")
                        .header("Authorization", "Bearer valid-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"latitude\":91,\"longitude\":0}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.latitude")
                        .value("Latitude must not exceed 90"));

        verifyNoInteractions(presenceService);
    }

    @Test
    void postPresenceUpdateReturnsBadRequestWhenNoActiveCheckIn()
            throws Exception {
        when(presenceService.processPresenceUpdate(eq(1), eq(20), any()))
                .thenThrow(new BadRequestException(
                        "No active check-in found for today"
                ));

        mockMvc.perform(post("/presence/updates")
                        .header("Authorization", "Bearer valid-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(validPayload()))
                .andExpect(status().isBadRequest());
    }

    private String validPayload() {
        return """
                {
                  "connectedSsid": "Office WiFi",
                  "connectedBssid": "AA:BB",
                  "latitude": 0,
                  "longitude": 0,
                  "accuracy": 5
                }
                """;
    }
}
