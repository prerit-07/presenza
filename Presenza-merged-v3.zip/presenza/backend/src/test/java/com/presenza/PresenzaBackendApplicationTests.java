package com.presenza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PresenzaBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
