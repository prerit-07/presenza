package com.presenza.backend.presence.service;

import com.presenza.backend.checkin.entity.CheckIn;
import com.presenza.backend.checkin.repository.CheckInRepository;
import com.presenza.backend.employee.repository.EmployeeRepository;
import com.presenza.backend.geofence.entity.Geofence;
import com.presenza.backend.geofence.entity.WifiNetwork;
import com.presenza.backend.geofence.repository.WifiNetworkRepository;
import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.organisation.repository.OrganizationRepository;
import com.presenza.backend.presence.dto.request.PresenceUpdateRequest;
import com.presenza.backend.presence.dto.response.PresenceResponse;
import com.presenza.backend.presence.entity.PresenceEvent;
import com.presenza.backend.presence.enums.PresenceEventType;
import com.presenza.backend.presence.repository.PresenceEventRepository;
import com.presenza.backend.shift.entity.Shift;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

class PresenceServiceTest {

    private CheckInRepository checkInRepository;
    private PresenceEventRepository presenceEventRepository;
    private WifiNetworkRepository wifiNetworkRepository;
    private EmployeeRepository employeeRepository;
    private OrganizationRepository organizationRepository;
    private EntityManager entityManager;
    private PresenceService presenceService;
    private CheckIn checkIn;
    private Geofence geofence;

    @BeforeEach
    void setUp() {
        checkInRepository = mock(CheckInRepository.class);
        presenceEventRepository = mock(PresenceEventRepository.class);
        wifiNetworkRepository = mock(WifiNetworkRepository.class);
        employeeRepository = mock(EmployeeRepository.class);
        organizationRepository = mock(OrganizationRepository.class);
        entityManager = mock(EntityManager.class);
        presenceService = new PresenceService(
                checkInRepository,
                presenceEventRepository,
                wifiNetworkRepository,
                employeeRepository,
                organizationRepository,
                entityManager
        );

        checkIn = mock(CheckIn.class);
        Shift shift = mock(Shift.class);
        Organization organization = mock(Organization.class);
        geofence = mock(Geofence.class);

        when(checkIn.getCheckinId()).thenReturn(10);
        when(checkIn.getShift()).thenReturn(shift);
        when(shift.getOrganization()).thenReturn(organization);
        when(organization.getOrgId()).thenReturn(20);
        when(organization.getPresenceMonitoringEnabled()).thenReturn(true);
        when(organizationRepository.findById(20)).thenReturn(Optional.of(organization));
        when(presenceEventRepository.saveAndFlush(any(PresenceEvent.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
        when(shift.getGeofence()).thenReturn(geofence);
        when(geofence.getGeofenceId()).thenReturn(30);
        when(geofence.getLatitude()).thenReturn(BigDecimal.ZERO);
        when(geofence.getLongitude()).thenReturn(BigDecimal.ZERO);
        when(geofence.getRadius()).thenReturn(100);
        when(checkInRepository
                .findFirstByUserUserIdAndCheckinTimeBetweenOrderByCheckinTimeDesc(
                        anyInt(), any(), any()
                ))
                .thenReturn(Optional.of(checkIn));
    }

    @Test
    void insideToInsideCreatesPresentHeartbeat() {
        mockTrustedWifi();
        when(presenceEventRepository
                .findFirstByCheckInCheckinIdOrderByEventTimestampDesc(10))
                .thenReturn(Optional.empty());

        PresenceResponse response = presenceService.processPresenceUpdate(
                1, 20, insideRequest()
        );

        assertThat(response.isEventGenerated()).isTrue();
        assertThat(response.getEventType()).isEqualTo(PresenceEventType.PRESENT);
        verifySavedEvent(PresenceEventType.PRESENT);
    }

    @Test
    void outsideToOutsideDoesNotCreateEvent() {
        when(presenceEventRepository
                .findFirstByCheckInCheckinIdOrderByEventTimestampDesc(10))
                .thenReturn(Optional.of(event(PresenceEventType.EXIT)));

        PresenceResponse response = presenceService.processPresenceUpdate(
                1, 20, outsideRequest()
        );

        assertThat(response.isEventGenerated()).isFalse();
        verify(presenceEventRepository, never()).saveAndFlush(any());
    }

    @Test
    void insideToOutsideCreatesExit() {
        when(presenceEventRepository
                .findFirstByCheckInCheckinIdOrderByEventTimestampDesc(10))
                .thenReturn(Optional.empty());
        when(presenceEventRepository.saveAndFlush(any(PresenceEvent.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        PresenceResponse response = presenceService.processPresenceUpdate(
                1, 20, outsideRequest()
        );

        assertThat(response.isEventGenerated()).isTrue();
        assertThat(response.getEventType()).isEqualTo(PresenceEventType.EXIT);
        verifySavedEvent(PresenceEventType.EXIT);
    }

    @Test
    void outsideToInsideCreatesReturn() {
        mockTrustedWifi();
        when(presenceEventRepository
                .findFirstByCheckInCheckinIdOrderByEventTimestampDesc(10))
                .thenReturn(Optional.of(event(PresenceEventType.EXIT)));
        when(presenceEventRepository.saveAndFlush(any(PresenceEvent.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        PresenceResponse response = presenceService.processPresenceUpdate(
                1, 20, insideRequest()
        );

        assertThat(response.isEventGenerated()).isTrue();
        assertThat(response.getEventType()).isEqualTo(PresenceEventType.RETURN);
        verifySavedEvent(PresenceEventType.RETURN);
    }

    @Test
    void duplicateOutsideUpdatesCreateOnlyOneExit() {
        when(presenceEventRepository
                .findFirstByCheckInCheckinIdOrderByEventTimestampDesc(10))
                .thenReturn(
                        Optional.empty(),
                        Optional.of(event(PresenceEventType.EXIT))
                );
        when(presenceEventRepository.saveAndFlush(any(PresenceEvent.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        presenceService.processPresenceUpdate(1, 20, outsideRequest());
        PresenceResponse duplicate = presenceService.processPresenceUpdate(
                1, 20, outsideRequest()
        );

        assertThat(duplicate.isEventGenerated()).isFalse();
        verify(presenceEventRepository, times(1)).saveAndFlush(any());
    }

    @Test
    void gpsOutsideGeofenceCreatesExit() {
        when(presenceEventRepository
                .findFirstByCheckInCheckinIdOrderByEventTimestampDesc(10))
                .thenReturn(Optional.empty());
        when(presenceEventRepository.saveAndFlush(any(PresenceEvent.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        presenceService.processPresenceUpdate(1, 20, outsideRequest());

        verifySavedEvent(PresenceEventType.EXIT);
        verify(wifiNetworkRepository, never()).findByBssidAndIsActiveTrue(any());
    }

    @Test
    void trustedWifiVerificationAllowsInsideState() {
        mockTrustedWifi();
        when(presenceEventRepository
                .findFirstByCheckInCheckinIdOrderByEventTimestampDesc(10))
                .thenReturn(Optional.empty());

        PresenceResponse response = presenceService.processPresenceUpdate(
                1, 20, insideRequest()
        );

        assertThat(response.getCurrentState().name()).isEqualTo("INSIDE");
    }

    @Test
    void failedWifiVerificationCreatesExit() {
        when(checkIn.getShift().getOrganization().getRequireTrustedWifi())
                .thenReturn(true);
        when(presenceEventRepository
                .findFirstByCheckInCheckinIdOrderByEventTimestampDesc(10))
                .thenReturn(Optional.empty());
        when(presenceEventRepository.saveAndFlush(any(PresenceEvent.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        presenceService.processPresenceUpdate(1, 20, insideRequest());

        verifySavedEvent(PresenceEventType.EXIT);
    }

    private void mockTrustedWifi() {
        WifiNetwork wifiNetwork = mock(WifiNetwork.class);
        when(wifiNetwork.getGeofence()).thenReturn(geofence);
        when(wifiNetwork.getSsid()).thenReturn("Office WiFi");
        when(wifiNetworkRepository.findByBssidAndIsActiveTrue("AA:BB"))
                .thenReturn(Optional.of(wifiNetwork));
    }

    private PresenceEvent event(PresenceEventType eventType) {
        PresenceEvent event = new PresenceEvent(checkIn, eventType);
        ReflectionTestUtils.setField(
                event,
                "eventTimestamp",
                OffsetDateTime.now()
        );
        return event;
    }

    private PresenceUpdateRequest insideRequest() {
        return request("0", "0", "Office WiFi", "AA:BB");
    }

    private PresenceUpdateRequest outsideRequest() {
        return request("1", "1", null, null);
    }

    private PresenceUpdateRequest request(
            String latitude,
            String longitude,
            String ssid,
            String bssid
    ) {
        PresenceUpdateRequest request = new PresenceUpdateRequest();
        ReflectionTestUtils.setField(
                request, "latitude", new BigDecimal(latitude)
        );
        ReflectionTestUtils.setField(
                request, "longitude", new BigDecimal(longitude)
        );
        ReflectionTestUtils.setField(request, "connectedSsid", ssid);
        ReflectionTestUtils.setField(request, "connectedBssid", bssid);
        return request;
    }

    private void verifySavedEvent(PresenceEventType expectedType) {
        ArgumentCaptor<PresenceEvent> captor =
                ArgumentCaptor.forClass(PresenceEvent.class);
        verify(presenceEventRepository).saveAndFlush(captor.capture());
        assertThat(captor.getValue().getEventType()).isEqualTo(expectedType);
    }
}
