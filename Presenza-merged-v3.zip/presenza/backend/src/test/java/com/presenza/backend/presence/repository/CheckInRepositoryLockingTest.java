package com.presenza.backend.presence.repository;

import com.presenza.backend.checkin.repository.CheckInRepository;
import jakarta.persistence.LockModeType;
import org.junit.jupiter.api.Test;
import org.springframework.data.jpa.repository.Lock;

import java.lang.reflect.Method;

import static org.assertj.core.api.Assertions.assertThat;

class CheckInRepositoryLockingTest {

    @Test
    void activeCheckInLookupUsesPessimisticWriteLock() throws Exception {
        Method method = CheckInRepository.class.getMethod(
                "findFirstByUserUserIdAndCheckinTimeBetweenOrderByCheckinTimeDesc",
                Integer.class,
                java.time.OffsetDateTime.class,
                java.time.OffsetDateTime.class
        );

        Lock lock = method.getAnnotation(Lock.class);

        assertThat(lock).isNotNull();
        assertThat(lock.value()).isEqualTo(LockModeType.PESSIMISTIC_WRITE);
    }
}
