package com.presenza.backend.presence.dto.request;

import jakarta.validation.Validation;
import jakarta.validation.Validator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

class PresenceUpdateRequestValidationTest {

    private Validator validator;

    @BeforeEach
    void setUp() {
        validator = Validation.buildDefaultValidatorFactory()
                .getValidator();
    }

    @Test
    void rejectsInvalidGpsCoordinates() {
        PresenceUpdateRequest request = new PresenceUpdateRequest();
        ReflectionTestUtils.setField(
                request, "latitude", new BigDecimal("90.1")
        );
        ReflectionTestUtils.setField(
                request, "longitude", new BigDecimal("180.1")
        );

        assertThat(validator.validate(request))
                .extracting(violation -> violation.getPropertyPath().toString())
                .contains("latitude", "longitude");
    }

    @Test
    void rejectsNegativeAccuracyAndOverlongWifiIdentifiers() {
        PresenceUpdateRequest request = new PresenceUpdateRequest();
        ReflectionTestUtils.setField(
                request, "accuracy", new BigDecimal("-0.1")
        );
        ReflectionTestUtils.setField(
                request, "connectedSsid", "x".repeat(151)
        );
        ReflectionTestUtils.setField(
                request, "connectedBssid", "x".repeat(51)
        );

        assertThat(validator.validate(request))
                .extracting(violation -> violation.getPropertyPath().toString())
                .contains("accuracy", "connectedSsid", "connectedBssid");
    }
}
