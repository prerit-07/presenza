-- Supports two bug fixes from the backend logic audit:
-- 1. OTP brute-force guard (VerificationService.verifyOtp caps attempts).
-- 2. Check-in race-condition guard (CheckInService catches the DB-level
--    unique violation as a fallback to the application-level check).

ALTER TABLE email_verification
    ADD COLUMN attempt_count integer NOT NULL DEFAULT 0;

CREATE UNIQUE INDEX check_in_user_shift_day_uidx
    ON check_in (user_id, shift_id, (checkin_time::date))
    WHERE shift_id IS NOT NULL;
