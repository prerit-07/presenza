-- Baseline schema for Presenza, reverse-engineered from the JPA @Entity
-- classes (this repo shipped with only 4 incremental ALTER-TABLE patches
-- in docs/migrations/, assuming a baseline schema that was never actually
-- included). This file recreates that missing baseline so a brand-new
-- PostgreSQL database can be bootstrapped from scratch via Flyway.
--
-- V2-V5 (the original docs/migrations/*.sql files, renamed into proper
-- Flyway version order) apply the incremental changes on top of this.

-- ============================================================
-- Subscription plans (no FK dependencies)
-- ============================================================
CREATE TABLE plan (
    plan_id       serial PRIMARY KEY,
    plan_name     varchar(100) NOT NULL,
    max_employees integer NOT NULL,
    price         numeric(10, 2) NOT NULL
);

-- ============================================================
-- Organization
-- ============================================================
CREATE TABLE organization (
    org_id               serial PRIMARY KEY,
    org_name             varchar(150) NOT NULL,
    plan_id              integer REFERENCES plan(plan_id),
    org_type             varchar(50) NOT NULL,
    max_allowed_employee integer,
    created_at           timestamptz NOT NULL DEFAULT now()
);

-- ============================================================
-- Roles / permissions (roles are seeded per-organization by the app
-- itself on registration, e.g. AuthService.register() creates the
-- ORG_ADMIN role — these tables just need to exist empty)
-- ============================================================
CREATE TABLE role (
    role_id   serial PRIMARY KEY,
    org_id    integer NOT NULL REFERENCES organization(org_id),
    role_name varchar(100) NOT NULL
);

CREATE TABLE permission (
    permission_id   serial PRIMARY KEY,
    permission_name varchar(100) NOT NULL,
    description     text
);

CREATE TABLE role_permission (
    role_id       integer NOT NULL REFERENCES role(role_id),
    permission_id integer NOT NULL REFERENCES permission(permission_id),
    PRIMARY KEY (role_id, permission_id)
);

-- ============================================================
-- User
-- ============================================================
CREATE TABLE "user" (
    user_id              serial PRIMARY KEY,
    org_id               integer NOT NULL REFERENCES organization(org_id),
    username             varchar(100) NOT NULL,
    email                varchar(150) NOT NULL,
    hash_password        varchar(255) NOT NULL,
    role_id              integer REFERENCES role(role_id),
    created_at           timestamptz NOT NULL DEFAULT now(),
    is_active            boolean NOT NULL DEFAULT true,
    last_login           timestamptz,
    must_change_password boolean NOT NULL DEFAULT false,
    CONSTRAINT user_email_key UNIQUE (email),
    CONSTRAINT user_org_id_username_key UNIQUE (org_id, username)
);

-- ============================================================
-- Devices + sessions
-- ============================================================
CREATE TABLE device (
    device_id   varchar(100) PRIMARY KEY,
    user_id     integer NOT NULL REFERENCES "user"(user_id),
    platform    varchar(50),
    model       varchar(100),
    app_version varchar(50),
    bound_at    timestamptz NOT NULL DEFAULT now(),
    last_seen_at timestamptz,
    is_active   boolean NOT NULL DEFAULT true
);

CREATE TABLE session (
    session_id  serial PRIMARY KEY,
    user_id     integer NOT NULL REFERENCES "user"(user_id),
    token_hash  varchar(255) NOT NULL,
    created_at  timestamptz NOT NULL DEFAULT now(),
    expires_at  timestamptz,
    device_info varchar(255),
    revoked_at  timestamptz
);

-- ============================================================
-- Workforce structure — department, geofence, shift, team all need
-- organization; team <-> employee is a genuine circular reference
-- (a team has a manager employee, an employee belongs to a team), so
-- team is created without that FK, employee is created next, and the
-- FK is attached afterward.
-- ============================================================
CREATE TABLE department (
    department_id   serial PRIMARY KEY,
    org_id           integer NOT NULL REFERENCES organization(org_id),
    department_name varchar(255) NOT NULL
);

CREATE TABLE geofence (
    geofence_id   serial PRIMARY KEY,
    org_id        integer NOT NULL REFERENCES organization(org_id),
    latitude      numeric(9, 6) NOT NULL,
    longitude     numeric(9, 6) NOT NULL,
    radius        integer NOT NULL,
    building_name varchar(150)
);

CREATE TABLE wifi_network (
    wifi_id     serial PRIMARY KEY,
    geofence_id integer NOT NULL REFERENCES geofence(geofence_id),
    ssid        varchar(150) NOT NULL,
    bssid       varchar(50) NOT NULL,
    added_at    timestamptz NOT NULL DEFAULT now(),
    is_active   boolean NOT NULL DEFAULT true,
    CONSTRAINT wifi_network_bssid_key UNIQUE (bssid)
);

CREATE TABLE shift (
    shift_id             serial PRIMARY KEY,
    org_id               integer NOT NULL REFERENCES organization(org_id),
    shift_name           varchar(100) NOT NULL,
    start_time           time NOT NULL,
    end_time             time NOT NULL,
    allowed_late_minutes integer,
    geofence_id          integer REFERENCES geofence(geofence_id)
);

CREATE TABLE team (
    team_id             serial PRIMARY KEY,
    org_id              integer NOT NULL REFERENCES organization(org_id),
    team_name           varchar(255) NOT NULL,
    manager_employee_id integer
);

CREATE TABLE employee (
    employee_id     serial PRIMARY KEY,
    org_id          integer NOT NULL REFERENCES organization(org_id),
    user_id         integer NOT NULL REFERENCES "user"(user_id),
    employee_name   varchar(255) NOT NULL,
    date_of_joining date,
    department_id   integer REFERENCES department(department_id),
    shift_id        integer REFERENCES shift(shift_id),
    team_id         integer REFERENCES team(team_id)
);

ALTER TABLE team
    ADD CONSTRAINT team_manager_employee_id_fkey
    FOREIGN KEY (manager_employee_id) REFERENCES employee(employee_id);

-- ============================================================
-- Check-in / attendance
-- ============================================================
CREATE TABLE check_in (
    checkin_id      serial PRIMARY KEY,
    user_id         integer NOT NULL REFERENCES "user"(user_id),
    shift_id        integer REFERENCES shift(shift_id),
    slot_id         integer,
    device_id       varchar(100) REFERENCES device(device_id),
    wifi_id         integer REFERENCES wifi_network(wifi_id),
    connected_ssid  varchar(150),
    connected_bssid varchar(50),
    wifi_verified   boolean NOT NULL DEFAULT false,
    checkin_time    timestamptz NOT NULL DEFAULT now(),
    latitude        numeric(9, 6),
    longitude       numeric(9, 6),
    device_info     varchar(255),
    accuracy        numeric(6, 2)
);

-- Note: effective_checkin_time is added later by V2 (do not duplicate it here)
CREATE TABLE attendance (
    attendance_id           serial PRIMARY KEY,
    checkin_id              integer NOT NULL REFERENCES check_in(checkin_id),
    status                  varchar(30) NOT NULL,
    approved_at             timestamptz,
    remarks                 text,
    CONSTRAINT attendance_checkin_id_key UNIQUE (checkin_id)
);

CREATE TABLE attendance_request (
    request_id     serial PRIMARY KEY,
    employee_id    integer NOT NULL REFERENCES employee(employee_id),
    request_type   varchar(30) NOT NULL,
    start_date     date NOT NULL,
    end_date       date NOT NULL,
    reason         text NOT NULL,
    status         varchar(30) NOT NULL DEFAULT 'PENDING',
    reviewed_by    integer REFERENCES employee(employee_id),
    review_remarks text,
    reviewed_at    timestamptz,
    created_at     timestamptz NOT NULL DEFAULT now(),
    updated_at     timestamptz NOT NULL DEFAULT now()
);

-- ============================================================
-- Tickets
-- ============================================================
CREATE TABLE ticket (
    ticket_id             serial PRIMARY KEY,
    org_id                integer NOT NULL REFERENCES organization(org_id),
    raised_by_user_id     integer NOT NULL REFERENCES "user"(user_id),
    assigned_to_employee_id integer REFERENCES employee(employee_id),
    checkin_id            integer REFERENCES check_in(checkin_id),
    attendance_id         integer REFERENCES attendance(attendance_id),
    subject               varchar(200) NOT NULL,
    description           text,
    status                varchar(30) NOT NULL DEFAULT 'OPEN',
    created_at            timestamptz NOT NULL DEFAULT now(),
    resolved_at           timestamptz
);

CREATE TABLE ticket_comment (
    comment_id serial PRIMARY KEY,
    ticket_id  integer NOT NULL REFERENCES ticket(ticket_id),
    user_id    integer NOT NULL REFERENCES "user"(user_id),
    message    text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

-- ============================================================
-- Device change requests
-- ============================================================
CREATE TABLE device_change_request (
    request_id     serial PRIMARY KEY,
    user_id        integer NOT NULL REFERENCES "user"(user_id),
    old_device_id  varchar(100) REFERENCES device(device_id),
    new_device_id  varchar(100),
    reason         text,
    requested_at   timestamptz NOT NULL DEFAULT now(),
    status         varchar(30) NOT NULL DEFAULT 'PENDING',
    reviewed_by    integer REFERENCES employee(employee_id),
    reviewed_at    timestamptz
);

-- ============================================================
-- Notifications
-- ============================================================
CREATE TABLE notification (
    notification_id   serial PRIMARY KEY,
    org_id            integer NOT NULL REFERENCES organization(org_id),
    recipient_user_id integer NOT NULL REFERENCES "user"(user_id),
    title             varchar(150) NOT NULL,
    message           text NOT NULL,
    notification_type varchar(30) NOT NULL,
    reference_type    varchar(30),
    reference_id      integer,
    is_read           boolean NOT NULL DEFAULT false,
    created_at        timestamptz NOT NULL DEFAULT now()
);

-- ============================================================
-- Presence tracking (EXIT/RETURN transitions, see PresenceEvent's
-- own doc comment — periodic snapshots are deliberately not stored)
-- ============================================================
CREATE TABLE presence_event (
    event_id        serial PRIMARY KEY,
    checkin_id      integer NOT NULL REFERENCES check_in(checkin_id),
    event_type      varchar(10) NOT NULL,
    event_timestamp timestamptz NOT NULL DEFAULT now(),
    latitude        numeric,
    longitude       numeric,
    accuracy        numeric,
    wifi_verified   boolean,
    connected_ssid  varchar(150),
    connected_bssid varchar(50)
);

-- ============================================================
-- Email OTP verification (registration / password reset / email change)
-- ============================================================
CREATE TABLE email_verification (
    verification_id serial PRIMARY KEY,
    email           varchar(150) NOT NULL,
    otp             varchar(6) NOT NULL,
    purpose         varchar(30) NOT NULL,
    expires_at      timestamptz NOT NULL,
    verified        boolean NOT NULL DEFAULT false,
    created_at      timestamptz NOT NULL DEFAULT now(),
    verified_at     timestamptz
);

-- Useful indexes for the lookups the code actually does
CREATE INDEX employee_org_id_idx ON employee (org_id);
CREATE INDEX check_in_user_id_idx ON check_in (user_id);
CREATE INDEX attendance_request_employee_id_idx ON attendance_request (employee_id);
CREATE INDEX ticket_org_id_idx ON ticket (org_id);
CREATE INDEX notification_recipient_user_id_idx ON notification (recipient_user_id);
CREATE INDEX email_verification_email_purpose_idx ON email_verification (email, purpose);
