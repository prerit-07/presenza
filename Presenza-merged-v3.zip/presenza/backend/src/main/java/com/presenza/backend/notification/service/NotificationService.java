package com.presenza.backend.notification.service;

import com.presenza.backend.common.exception.ForbiddenException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.notification.NotificationType;
import com.presenza.backend.notification.dto.response.NotificationResponse;
import com.presenza.backend.notification.entity.Notification;
import com.presenza.backend.notification.event.NotificationCreatedEvent;
import com.presenza.backend.notification.repository.NotificationRepository;
import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.organisation.repository.OrganizationRepository;
import com.presenza.backend.user.entity.User;
import com.presenza.backend.user.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.context.ApplicationEventPublisher;

import java.util.List;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;
    private final OrganizationRepository organizationRepository;
    private final ApplicationEventPublisher eventPublisher;

    public NotificationService(
            NotificationRepository notificationRepository,
            UserRepository userRepository,
            OrganizationRepository organizationRepository,
            ApplicationEventPublisher eventPublisher
    ) {
        this.notificationRepository = notificationRepository;
        this.userRepository = userRepository;
        this.organizationRepository = organizationRepository;
        this.eventPublisher = eventPublisher;
    }

    @Transactional
    public void createNotification(
            Integer organizationId,
            Integer recipientUserId,
            NotificationType notificationType,
            String title,
            String message,
            String referenceType,
            Integer referenceId
    ) {

        Organization organization =
                organizationRepository
                        .findById(organizationId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Organization not found with id: "
                                                + organizationId
                                )
                        );

        User recipient =
                userRepository
                        .findById(recipientUserId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "User not found with id: "
                                                + recipientUserId
                                )
                        );

        Notification notification =
                new Notification(
                        organization,
                        recipient,
                        title,
                        message,
                        notificationType,
                        referenceType,
                        referenceId
                );

        Notification saved = notificationRepository.save(notification);
        eventPublisher.publishEvent(new NotificationCreatedEvent(
                saved.getNotificationId(), recipientUserId, title, message, referenceType, referenceId
        ));
    }

    @Transactional
    public void notifyOrganizationRole(
            Integer organizationId,
            String roleName,
            NotificationType notificationType,
            String title,
            String message,
            String referenceType,
            Integer referenceId
    ) {
        userRepository
                .findByOrganizationOrgIdAndRoleRoleName(organizationId, roleName)
                .forEach(user -> createNotification(
                        organizationId,
                        user.getUserId(),
                        notificationType,
                        title,
                        message,
                        referenceType,
                        referenceId
                ));
    }

    @Transactional(readOnly = true)
    public List<NotificationResponse> getMyNotifications(
            Integer userId
    ) {

        User user =
                userRepository
                        .findById(userId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "User not found with id: "
                                                + userId
                                )
                        );

        return notificationRepository
                .findByRecipientOrderByCreatedAtDesc(user)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional
    public void markAsRead(
            Integer notificationId,
            Integer userId
    ) {

        Notification notification =
                findNotificationForUser(
                        notificationId,
                        userId
                );

        notification.setIsRead(true);

        notificationRepository.save(notification);
    }

    @Transactional
    public void markAllAsRead(
            Integer userId
    ) {

        User user =
                userRepository
                        .findById(userId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "User not found with id: "
                                                + userId
                                )
                        );

        List<Notification> notifications =
                notificationRepository
                        .findByRecipientAndIsReadFalseOrderByCreatedAtDesc(
                                user
                        );

        notifications.forEach(
                notification ->
                        notification.setIsRead(true)
        );

        notificationRepository.saveAll(notifications);
    }

    private Notification findNotificationForUser(
            Integer notificationId,
            Integer userId
    ) {

        Notification notification =
                notificationRepository
                        .findById(notificationId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Notification not found with id: "
                                                + notificationId
                                )
                        );

        if (!notification
                .getRecipient()
                .getUserId()
                .equals(userId)) {

            throw new ForbiddenException(
                    "User is not allowed to access this notification"
            );
        }

        return notification;
    }

    private NotificationResponse toResponse(
            Notification notification
    ) {

        return new NotificationResponse(
                notification.getNotificationId(),
                notification.getTitle(),
                notification.getMessage(),
                notification.getNotificationType(),
                notification.getReferenceType(),
                notification.getReferenceId(),
                notification.getIsRead(),
                notification.getCreatedAt()
        );
    }
}
