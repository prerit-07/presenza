package com.presenza.backend.ticket.dto.response;

import java.time.OffsetDateTime;

public class TicketCommentResponse {

    private final Integer commentId;
    private final Integer ticketId;
    private final Integer userId;
    private final String message;
    private final OffsetDateTime createdAt;

    public TicketCommentResponse(
            Integer commentId,
            Integer ticketId,
            Integer userId,
            String message,
            OffsetDateTime createdAt
    ) {
        this.commentId = commentId;
        this.ticketId = ticketId;
        this.userId = userId;
        this.message = message;
        this.createdAt = createdAt;
    }

    public Integer getCommentId() {
        return commentId;
    }

    public Integer getTicketId() {
        return ticketId;
    }

    public Integer getUserId() {
        return userId;
    }

    public String getMessage() {
        return message;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }
}