package com.presenza.backend.workforce.dto.response;

public class DepartmentResponse {

    private Integer departmentId;
    private Integer orgId;
    private String departmentName;

    public DepartmentResponse() {
    }

    public DepartmentResponse(
            Integer departmentId,
            Integer orgId,
            String departmentName
    ) {
        this.departmentId = departmentId;
        this.orgId = orgId;
        this.departmentName = departmentName;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }
}