package com.presenza.backend.geofence.dto.response;

import java.time.OffsetDateTime;

public class WifiNetworkResponse {

    private Integer wifiId;
    private Integer geofenceId;
    private String ssid;
    private String bssid;
    private OffsetDateTime addedAt;
    private Boolean active;

    public WifiNetworkResponse() {
    }

    public WifiNetworkResponse(
            Integer wifiId,
            Integer geofenceId,
            String ssid,
            String bssid,
            OffsetDateTime addedAt,
            Boolean active
    ) {
        this.wifiId = wifiId;
        this.geofenceId = geofenceId;
        this.ssid = ssid;
        this.bssid = bssid;
        this.addedAt = addedAt;
        this.active = active;
    }

    public Integer getWifiId() {
        return wifiId;
    }

    public void setWifiId(Integer wifiId) {
        this.wifiId = wifiId;
    }

    public Integer getGeofenceId() {
        return geofenceId;
    }

    public void setGeofenceId(Integer geofenceId) {
        this.geofenceId = geofenceId;
    }

    public String getSsid() {
        return ssid;
    }

    public void setSsid(String ssid) {
        this.ssid = ssid;
    }

    public String getBssid() {
        return bssid;
    }

    public void setBssid(String bssid) {
        this.bssid = bssid;
    }

    public OffsetDateTime getAddedAt() {
        return addedAt;
    }

    public void setAddedAt(OffsetDateTime addedAt) {
        this.addedAt = addedAt;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
}