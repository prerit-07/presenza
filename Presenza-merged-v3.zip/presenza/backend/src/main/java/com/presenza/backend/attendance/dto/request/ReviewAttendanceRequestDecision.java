package com.presenza.backend.attendance.dto.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class ReviewAttendanceRequestDecision {

    @NotNull
    private Boolean approved;

    @Size(max = 2000)
    private String remarks;

    public ReviewAttendanceRequestDecision() {
    }

    public Boolean getApproved() {
        return approved;
    }

    public void setApproved(Boolean approved) {
        this.approved = approved;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}