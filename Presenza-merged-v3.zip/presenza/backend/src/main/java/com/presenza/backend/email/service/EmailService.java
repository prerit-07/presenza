package com.presenza.backend.email.service;

import com.presenza.backend.verification.VerificationPurpose;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    public EmailService(
            JavaMailSender mailSender
    ) {
        this.mailSender = mailSender;
    }

    public void sendOtp(
            String recipientEmail,
            String otp,
            VerificationPurpose purpose
    ) {

        String subject;
        String body;

        switch (purpose) {

            case REGISTRATION -> {

                subject = "Presenza - Email Verification";

                body = """
                    Hello,

                    Your verification code is:

                    %s

                    This OTP will expire in 5 minutes.

                    If you did not request this, please ignore this email.

                    Regards,
                    Presenza Team
                    """.formatted(otp);
            }

            case PASSWORD_RESET -> {

                subject = "Presenza - Password Reset";

                body = """
                    Hello,

                    We received a request to reset your password.

                    Your OTP is:

                    %s

                    This OTP will expire in 5 minutes.

                    If you did not request this request, please ignore this email.

                    Regards,
                    Presenza Team
                    """.formatted(otp);
            }

            case EMAIL_CHANGE -> {

                subject = "Presenza - Email Change Verification";

                body = """
                    Hello,

                    Your OTP for changing your email address is:

                    %s

                    This OTP will expire in 5 minutes.

                    If you did not request this change, please ignore this email.

                    Regards,
                    Presenza Team
                    """.formatted(otp);
            }

            default -> throw new IllegalArgumentException(
                    "Unsupported verification purpose."
            );
        }

        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(recipientEmail);
        message.setSubject(subject);
        message.setText(body);

        mailSender.send(message);
    }
    public void sendWelcomeEmail(
            String recipientEmail,
            String employeeName,
            String temporaryPassword
    ) {

        SimpleMailMessage message =
                new SimpleMailMessage();

        message.setTo(recipientEmail);
        message.setSubject("Welcome to Presenza");

        message.setText(
                """
                Hello %s,
    
                Welcome to Presenza!
    
                Your account has been created successfully.
    
                Login Email:
                %s
    
                Temporary Password:
                %s
    
                For security reasons, you'll be asked to change this password after your first login.
    
                Regards,
                Presenza Team
                """
                        .formatted(
                                employeeName,
                                recipientEmail,
                                temporaryPassword
                        )
        );

        mailSender.send(message);
    }
}