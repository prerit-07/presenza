package com.presenza.backend.device.dto.response;

import java.time.OffsetDateTime;

public class DeviceChangeRequestResponse {

    private final Integer requestId;
    private final Integer userId;
    private final String oldDeviceId;
    private final String newDeviceId;
    private final String reason;
    private final String status;
    private final Integer reviewedByEmployeeId;
    private final OffsetDateTime requestedAt;
    private final OffsetDateTime reviewedAt;

    public DeviceChangeRequestResponse(
            Integer requestId,
            Integer userId,
            String oldDeviceId,
            String newDeviceId,
            String reason,
            String status,
            Integer reviewedByEmployeeId,
            OffsetDateTime requestedAt,
            OffsetDateTime reviewedAt
    ) {
        this.requestId = requestId;
        this.userId = userId;
        this.oldDeviceId = oldDeviceId;
        this.newDeviceId = newDeviceId;
        this.reason = reason;
        this.status = status;
        this.reviewedByEmployeeId = reviewedByEmployeeId;
        this.requestedAt = requestedAt;
        this.reviewedAt = reviewedAt;
    }

    public Integer getRequestId() {
        return requestId;
    }

    public Integer getUserId() {
        return userId;
    }

    public String getOldDeviceId() {
        return oldDeviceId;
    }

    public String getNewDeviceId() {
        return newDeviceId;
    }

    public String getReason() {
        return reason;
    }

    public String getStatus() {
        return status;
    }

    public Integer getReviewedByEmployeeId() {
        return reviewedByEmployeeId;
    }

    public OffsetDateTime getRequestedAt() {
        return requestedAt;
    }

    public OffsetDateTime getReviewedAt() {
        return reviewedAt;
    }
}