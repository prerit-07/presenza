package com.presenza.backend.device.dto.request;

import jakarta.validation.constraints.NotNull;

public class ReviewDeviceChangeRequest {

    @NotNull
    private Boolean approved;

    public ReviewDeviceChangeRequest() {
    }

    public Boolean getApproved() {
        return approved;
    }

    public void setApproved(Boolean approved) {
        this.approved = approved;
    }
}