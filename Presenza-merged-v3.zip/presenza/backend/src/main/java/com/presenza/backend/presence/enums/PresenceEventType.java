package com.presenza.backend.presence.enums;

public enum PresenceEventType {
    EXIT,
    RETURN,
    PRESENT
}
