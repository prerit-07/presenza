package com.presenza.backend.user.repository;

import com.presenza.backend.user.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository
        extends JpaRepository<User, Integer> {
    Optional<User> findByEmail(String email);

    List<User> findByOrganizationOrgIdAndRoleRoleName(
            Integer organizationId,
            String roleName
    );
}
