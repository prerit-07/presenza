package com.presenza.backend.presence.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.presence.dto.request.PresenceUpdateRequest;
import com.presenza.backend.presence.dto.response.PresenceHistoryResponse;
import com.presenza.backend.presence.dto.response.PresenceResponse;
import com.presenza.backend.presence.service.PresenceService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * Authenticated presence update and transition-history endpoints.
 */
@RestController
@RequestMapping("/presence")
public class PresenceController {

    private static final Logger logger =
            LoggerFactory.getLogger(PresenceController.class);

    private final PresenceService presenceService;
    private final TokenService tokenService;

    public PresenceController(PresenceService presenceService,
                              TokenService tokenService) {
        this.presenceService = presenceService;
        this.tokenService = tokenService;
    }

    @PostMapping("/updates")
    public ResponseEntity<PresenceResponse> processPresenceUpdate(
            @RequestHeader(value = "Authorization", required = false)
            String authorizationHeader,
            @Valid @RequestBody PresenceUpdateRequest request
    ) {
        AuthenticatedUser authenticatedUser = authenticate(authorizationHeader);
        logger.info("Presence update received for userId={} organizationId={}",
                authenticatedUser.getUserId(),
                authenticatedUser.getOrganizationId());

        return ResponseEntity.ok(presenceService.processPresenceUpdate(
                authenticatedUser.getUserId(),
                authenticatedUser.getOrganizationId(),
                request
        ));
    }

    @GetMapping("/history/me")
    public ResponseEntity<List<PresenceHistoryResponse>> getMyHistory(
            @RequestHeader(value = "Authorization", required = false)
            String authorizationHeader,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate date
    ) {
        AuthenticatedUser authenticatedUser = authenticate(authorizationHeader);

        return ResponseEntity.ok(presenceService.getMyHistory(
                authenticatedUser.getUserId(),
                date
        ));
    }

    @GetMapping("/history/employee/{employeeId}")
    public ResponseEntity<List<PresenceHistoryResponse>> getEmployeeHistory(
            @PathVariable Integer employeeId,
            @RequestHeader(value = "Authorization", required = false)
            String authorizationHeader,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate date
    ) {
        AuthenticatedUser authenticatedUser = authenticate(authorizationHeader);

        return ResponseEntity.ok(presenceService.getEmployeeHistory(
                employeeId,
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                date
        ));
    }

    private AuthenticatedUser authenticate(String authorizationHeader) {
        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        return tokenService.getAuthenticatedUser(
                authorizationHeader.substring(7)
        );
    }
}
