package com.presenza.backend.device.entity;

public enum DeviceChangeRequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}