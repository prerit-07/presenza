package com.presenza.backend.geofence.service;

import com.presenza.backend.common.exception.ForbiddenException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.geofence.dto.request.WifiNetworkRequest;
import com.presenza.backend.geofence.dto.response.WifiNetworkResponse;
import com.presenza.backend.geofence.entity.Geofence;
import com.presenza.backend.geofence.entity.WifiNetwork;
import com.presenza.backend.geofence.repository.GeofenceRepository;
import com.presenza.backend.geofence.repository.WifiNetworkRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class WifiNetworkService {

    private final WifiNetworkRepository wifiNetworkRepository;
    private final GeofenceRepository geofenceRepository;

    public WifiNetworkService(
            WifiNetworkRepository wifiNetworkRepository,
            GeofenceRepository geofenceRepository
    ) {
        this.wifiNetworkRepository = wifiNetworkRepository;
        this.geofenceRepository = geofenceRepository;
    }

    @Transactional
    public WifiNetworkResponse createWifiNetwork(
            Integer organizationId,
            String role,
            WifiNetworkRequest request
    ) {
        validateManagementRole(role);

        Geofence geofence = findGeofenceInOrganization(
                request.getGeofenceId(),
                organizationId
        );

        WifiNetwork wifiNetwork = new WifiNetwork(
                geofence,
                request.getSsid(),
                request.getBssid()
        );

        return toResponse(
                wifiNetworkRepository.save(wifiNetwork)
        );
    }

    @Transactional(readOnly = true)
    public WifiNetworkResponse getWifiNetworkById(
            Integer id,
            Integer organizationId
    ) {
        return toResponse(
                findWifiNetworkInOrganization(
                        id,
                        organizationId
                )
        );
    }

    @Transactional(readOnly = true)
    public List<WifiNetworkResponse> getWifiNetworksByGeofence(
            Integer geofenceId,
            Integer organizationId
    ) {
        findGeofenceInOrganization(
                geofenceId,
                organizationId
        );

        return wifiNetworkRepository
                .findByGeofenceGeofenceId(geofenceId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional
    public WifiNetworkResponse updateWifiNetwork(
            Integer id,
            Integer organizationId,
            String role,
            WifiNetworkRequest request
    ) {
        validateManagementRole(role);

        WifiNetwork wifiNetwork =
                findWifiNetworkInOrganization(
                        id,
                        organizationId
                );

        Geofence geofence =
                findGeofenceInOrganization(
                        request.getGeofenceId(),
                        organizationId
                );

        wifiNetwork.setGeofence(geofence);
        wifiNetwork.setSsid(request.getSsid());
        wifiNetwork.setBssid(request.getBssid());

        return toResponse(
                wifiNetworkRepository.save(wifiNetwork)
        );
    }

    private Geofence findGeofenceInOrganization(
            Integer geofenceId,
            Integer organizationId
    ) {
        Geofence geofence = geofenceRepository
                .findById(geofenceId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Geofence not found with id: "
                                        + geofenceId
                        )
                );

        if (!geofence.getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Geofence not found with id: "
                            + geofenceId
            );
        }

        return geofence;
    }

    private WifiNetwork findWifiNetworkInOrganization(
            Integer wifiId,
            Integer organizationId
    ) {
        WifiNetwork wifiNetwork =
                wifiNetworkRepository.findById(wifiId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "WiFi network not found with id: "
                                                + wifiId
                                )
                        );

        if (!wifiNetwork.getGeofence()
                .getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "WiFi network not found with id: "
                            + wifiId
            );
        }

        return wifiNetwork;
    }

    private void validateManagementRole(
            String role
    ) {
        if (!"ORG_ADMIN".equals(role) &&
                !"MANAGER".equals(role)) {
            throw new ForbiddenException(
                    "User is not allowed to manage WiFi networks"
            );
        }
    }

    private WifiNetworkResponse toResponse(
            WifiNetwork wifiNetwork
    ) {
        return new WifiNetworkResponse(
                wifiNetwork.getWifiId(),
                wifiNetwork.getGeofence().getGeofenceId(),
                wifiNetwork.getSsid(),
                wifiNetwork.getBssid(),
                wifiNetwork.getAddedAt(),
                wifiNetwork.getActive()
        );
    }
}