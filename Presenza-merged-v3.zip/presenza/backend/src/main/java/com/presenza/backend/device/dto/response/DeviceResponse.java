package com.presenza.backend.device.dto.response;

import java.time.OffsetDateTime;

public class DeviceResponse {

    private final String deviceId;
    private final String platform;
    private final String model;
    private final String appVersion;
    private final OffsetDateTime boundAt;
    private final OffsetDateTime lastSeenAt;
    private final Boolean active;

    public DeviceResponse(
            String deviceId,
            String platform,
            String model,
            String appVersion,
            OffsetDateTime boundAt,
            OffsetDateTime lastSeenAt,
            Boolean active
    ) {
        this.deviceId = deviceId;
        this.platform = platform;
        this.model = model;
        this.appVersion = appVersion;
        this.boundAt = boundAt;
        this.lastSeenAt = lastSeenAt;
        this.active = active;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public String getPlatform() {
        return platform;
    }

    public String getModel() {
        return model;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public OffsetDateTime getBoundAt() {
        return boundAt;
    }

    public OffsetDateTime getLastSeenAt() {
        return lastSeenAt;
    }

    public Boolean getActive() {
        return active;
    }
}