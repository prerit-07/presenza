package com.presenza.backend.attendance.dto.response;

import java.time.LocalDate;
import java.time.OffsetDateTime;

public class AttendanceRequestResponse {

    private final Integer requestId;
    private final Integer employeeId;
    private final String employeeName;
    private final String requestType;
    private final LocalDate startDate;
    private final LocalDate endDate;
    private final String reason;
    private final String status;
    private final Integer reviewedByEmployeeId;
    private final String reviewRemarks;
    private final OffsetDateTime reviewedAt;
    private final OffsetDateTime createdAt;
    private final OffsetDateTime updatedAt;

    public AttendanceRequestResponse(
            Integer requestId,
            Integer employeeId,
            String employeeName,
            String requestType,
            LocalDate startDate,
            LocalDate endDate,
            String reason,
            String status,
            Integer reviewedByEmployeeId,
            String reviewRemarks,
            OffsetDateTime reviewedAt,
            OffsetDateTime createdAt,
            OffsetDateTime updatedAt
    ) {
        this.requestId = requestId;
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.requestType = requestType;
        this.startDate = startDate;
        this.endDate = endDate;
        this.reason = reason;
        this.status = status;
        this.reviewedByEmployeeId = reviewedByEmployeeId;
        this.reviewRemarks = reviewRemarks;
        this.reviewedAt = reviewedAt;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Integer getRequestId() {
        return requestId;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public String getRequestType() {
        return requestType;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public String getReason() {
        return reason;
    }

    public String getStatus() {
        return status;
    }

    public Integer getReviewedByEmployeeId() {
        return reviewedByEmployeeId;
    }

    public String getReviewRemarks() {
        return reviewRemarks;
    }

    public OffsetDateTime getReviewedAt() {
        return reviewedAt;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public OffsetDateTime getUpdatedAt() {
        return updatedAt;
    }
}