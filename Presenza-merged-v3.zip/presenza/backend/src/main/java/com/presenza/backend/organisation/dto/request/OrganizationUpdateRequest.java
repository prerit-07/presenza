package com.presenza.backend.organisation.dto.request;

import com.presenza.backend.organisation.entity.OrganizationType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class OrganizationUpdateRequest {

    @NotBlank
    @Size(max = 150)
    private String orgName;

    @NotNull
    private OrganizationType orgType;

    public OrganizationUpdateRequest() {
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public OrganizationType getOrgType() {
        return orgType;
    }

    public void setOrgType(OrganizationType orgType) {
        this.orgType = orgType;
    }
}