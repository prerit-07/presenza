package com.presenza.backend.attendance.controller;

import com.presenza.backend.attendance.dto.request.ReviewAttendanceRequest;
import com.presenza.backend.attendance.dto.request.CreateManualAttendanceRequest;
import com.presenza.backend.attendance.dto.request.CorrectAttendanceRequest;
import com.presenza.backend.attendance.dto.response.AttendanceResponse;
import com.presenza.backend.attendance.dto.response.ManualAttendanceResponse;
import com.presenza.backend.attendance.service.AttendanceService;
import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/attendance")
public class AttendanceController {

    private final AttendanceService attendanceService;
    private final TokenService tokenService;

    public AttendanceController(
            AttendanceService attendanceService,
            TokenService tokenService
    ) {
        this.attendanceService = attendanceService;
        this.tokenService = tokenService;
    }

    @GetMapping("/pending")
    public ResponseEntity<List<AttendanceResponse>> getPendingAttendance(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        List<AttendanceResponse> response =
                attendanceService.getPendingAttendance(
                        authenticatedUser.getOrganizationId(),
                        authenticatedUser.getRole()
                );

        return ResponseEntity.ok(response);
    }

    @GetMapping("/me")
    public ResponseEntity<List<AttendanceResponse>> getMyAttendance(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        List<AttendanceResponse> response =
                attendanceService.getMyAttendance(
                        authenticatedUser.getUserId()
                );

        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<List<AttendanceResponse>>
    getOrganizationAttendance(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        List<AttendanceResponse> response =
                attendanceService.getOrganizationAttendance(
                        authenticatedUser.getOrganizationId(),
                        authenticatedUser.getRole()
                );

        return ResponseEntity.ok(response);
    }

    @PatchMapping("/{attendanceId}/review")
    public ResponseEntity<AttendanceResponse> reviewAttendance(
            @PathVariable Integer attendanceId,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody ReviewAttendanceRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        AttendanceResponse response =
                attendanceService.reviewAttendance(
                        attendanceId,
                        authenticatedUser.getOrganizationId(),
                        authenticatedUser.getRole(),
                        request
                );

        return ResponseEntity.ok(response);
    }

    @PostMapping("/manual")
    public ResponseEntity<ManualAttendanceResponse> createManualAttendance(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody CreateManualAttendanceRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        ManualAttendanceResponse response =
                attendanceService.createManualAttendance(
                        authenticatedUser.getUserId(),
                        authenticatedUser.getOrganizationId(),
                        authenticatedUser.getRole(),
                        request
                );

        return ResponseEntity.status(201).body(response);
    }

    @PatchMapping("/{attendanceId}")
    public ResponseEntity<AttendanceResponse> correctAttendance(
            @PathVariable Integer attendanceId,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody CorrectAttendanceRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return ResponseEntity.ok(attendanceService.correctAttendance(
                attendanceId,
                authenticatedUser.getUserId(),
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        ));
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {
        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        String rawToken =
                authorizationHeader.substring(7);

        return tokenService.getAuthenticatedUser(rawToken);
    }
}
