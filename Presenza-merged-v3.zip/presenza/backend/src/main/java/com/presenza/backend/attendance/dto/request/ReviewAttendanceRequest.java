package com.presenza.backend.attendance.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class ReviewAttendanceRequest {

    @NotNull(message = "Approved decision is required")
    private Boolean approved;

    @NotBlank(message = "Remarks are required")
    @Size(max = 1000, message = "Remarks must not exceed 1000 characters")
    private String remarks;

    public ReviewAttendanceRequest() {
    }

    public Boolean getApproved() {
        return approved;
    }

    public String getRemarks() {
        return remarks;
    }
}