package com.presenza.backend.device.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.device.dto.request.RegisterDeviceRequest;
import com.presenza.backend.device.dto.response.DeviceResponse;
import com.presenza.backend.device.service.DeviceService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/devices")
public class DeviceController {

    private final DeviceService deviceService;
    private final TokenService tokenService;

    public DeviceController(
            DeviceService deviceService,
            TokenService tokenService
    ) {
        this.deviceService = deviceService;
        this.tokenService = tokenService;
    }

    @PostMapping
    public ResponseEntity<DeviceResponse> registerDevice(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody RegisterDeviceRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        DeviceResponse response = deviceService.registerDevice(
                authenticatedUser.getUserId(),
                request
        );

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }

    @GetMapping
    public ResponseEntity<List<DeviceResponse>> getUserDevices(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        List<DeviceResponse> response =
                deviceService.getUserDevices(
                        authenticatedUser.getUserId()
                );

        return ResponseEntity.ok(response);
    }

    @PatchMapping("/{deviceId}/deactivate")
    public ResponseEntity<DeviceResponse> deactivateDevice(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @PathVariable String deviceId
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        DeviceResponse response =
                deviceService.deactivateDevice(
                        authenticatedUser.getUserId(),
                        deviceId
                );

        return ResponseEntity.ok(response);
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {
        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        String rawToken = authorizationHeader.substring(7);

        return tokenService.getAuthenticatedUser(rawToken);
    }
}