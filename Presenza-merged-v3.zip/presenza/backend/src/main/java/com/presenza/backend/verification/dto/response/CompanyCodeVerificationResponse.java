package com.presenza.backend.verification.dto.response;

public class CompanyCodeVerificationResponse {

    private final boolean verified;
    private final Integer organizationId;
    private final String organizationName;

    public CompanyCodeVerificationResponse(
            boolean verified,
            Integer organizationId,
            String organizationName
    ) {
        this.verified = verified;
        this.organizationId = organizationId;
        this.organizationName = organizationName;
    }

    public boolean isVerified() {
        return verified;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public String getOrganizationName() {
        return organizationName;
    }
}
