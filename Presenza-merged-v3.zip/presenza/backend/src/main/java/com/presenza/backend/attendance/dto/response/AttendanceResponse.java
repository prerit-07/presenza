package com.presenza.backend.attendance.dto.response;

import java.time.OffsetDateTime;

public class AttendanceResponse {

    private final Integer attendanceId;
    private final Integer checkinId;
    private final Integer userId;
    private final Integer shiftId;
    private final String status;
    private final OffsetDateTime approvedAt;
    private final String remarks;
    private final OffsetDateTime checkinTime;
    private final OffsetDateTime effectiveCheckinTime;
    private final Boolean wifiVerified;

    public AttendanceResponse(
            Integer attendanceId,
            Integer checkinId,
            Integer userId,
            Integer shiftId,
            String status,
            OffsetDateTime approvedAt,
            String remarks,
            OffsetDateTime checkinTime,
            Boolean wifiVerified
    ) {
        this(
                attendanceId,
                checkinId,
                userId,
                shiftId,
                status,
                approvedAt,
                remarks,
                checkinTime,
                null,
                wifiVerified
        );
    }

    public AttendanceResponse(
            Integer attendanceId,
            Integer checkinId,
            Integer userId,
            Integer shiftId,
            String status,
            OffsetDateTime approvedAt,
            String remarks,
            OffsetDateTime checkinTime,
            OffsetDateTime effectiveCheckinTime,
            Boolean wifiVerified
    ) {
        this.attendanceId = attendanceId;
        this.checkinId = checkinId;
        this.userId = userId;
        this.shiftId = shiftId;
        this.status = status;
        this.approvedAt = approvedAt;
        this.remarks = remarks;
        this.checkinTime = checkinTime;
        this.effectiveCheckinTime = effectiveCheckinTime;
        this.wifiVerified = wifiVerified;
    }

    public Integer getAttendanceId() {
        return attendanceId;
    }

    public Integer getCheckinId() {
        return checkinId;
    }

    public Integer getUserId() {
        return userId;
    }

    public Integer getShiftId() {
        return shiftId;
    }

    public String getStatus() {
        return status;
    }

    public OffsetDateTime getApprovedAt() {
        return approvedAt;
    }

    public String getRemarks() {
        return remarks;
    }

    public OffsetDateTime getCheckinTime() {
        return checkinTime;
    }

    public OffsetDateTime getEffectiveCheckinTime() {
        return effectiveCheckinTime;
    }

    public Boolean getWifiVerified() {
        return wifiVerified;
    }
}
