package com.presenza.backend.notification;

public enum NotificationType {

    GENERAL,
    ATTENDANCE,
    ATTENDANCE_REQUEST,
    DEVICE,
    DEVICE_CHANGE_REQUEST,
    TICKET,
    SYSTEM

}