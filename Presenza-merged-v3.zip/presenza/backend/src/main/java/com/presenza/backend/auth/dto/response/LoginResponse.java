package com.presenza.backend.auth.dto.response;

import java.time.OffsetDateTime;

public class LoginResponse {

    private final String token;
    private final Integer userId;
    private final String username;
    private final String email;
    private final OffsetDateTime expiresAt;
    private final Boolean mustChangePassword;

    public LoginResponse(
            String token,
            Integer userId,
            String username,
            String email,
            OffsetDateTime expiresAt,
            Boolean mustChangePassword
    ) {
        this.token = token;
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.expiresAt = expiresAt;
        this.mustChangePassword = mustChangePassword;
    }

    public String getToken() {
        return token;
    }

    public Integer getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public OffsetDateTime getExpiresAt() {
        return expiresAt;
    }

    public Boolean getMustChangePassword() {
        return mustChangePassword;
    }
}