package com.presenza.backend.geofence.entity;

import jakarta.persistence.*;

import java.time.OffsetDateTime;

@Entity
@Table(name = "wifi_network", uniqueConstraints = {
        @UniqueConstraint(
                name = "wifi_network_bssid_key",
                columnNames = "bssid"
        )
})
public class WifiNetwork {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "wifi_id")
    private Integer wifiId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "geofence_id", nullable = false)
    private Geofence geofence;

    @Column(name = "ssid", nullable = false, length = 150)
    private String ssid;

    @Column(name = "bssid", nullable = false,length = 50)
    private String bssid;

    @Column(name = "added_at", nullable = false, insertable = false, updatable = false)
    private OffsetDateTime addedAt;

    @Column(name = "is_active", nullable = false, insertable = false)
    private Boolean isActive;

    protected WifiNetwork() {
    }

    public WifiNetwork(
            Geofence geofence,
            String ssid,
            String bssid

    ) {
        this.geofence = geofence;
        this.ssid = ssid;
        this.bssid = bssid;
    }

    public Integer getWifiId() {
        return wifiId;
    }

    public Geofence getGeofence() {
        return geofence;
    }

    public String getSsid() {
        return ssid;
    }

    public String getBssid() {
        return bssid;
    }

    public OffsetDateTime getAddedAt() {
        return addedAt;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setGeofence(Geofence geofence) {
        this.geofence = geofence;
    }

    public void setSsid(String ssid) {
        this.ssid = ssid;
    }

    public void setBssid(String bssid) {
        this.bssid = bssid;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }
}
