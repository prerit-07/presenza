package com.presenza.backend.attendance.entity;

import com.presenza.backend.employee.entity.Employee;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.OffsetDateTime;

@Entity
@Table(
        name = "manual_attendance",
        uniqueConstraints = @UniqueConstraint(
                name = "manual_attendance_employee_date_key",
                columnNames = {"employee_id", "attendance_date"}
        )
)
public class ManualAttendance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "manual_attendance_id")
    private Integer manualAttendanceId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @Column(name = "attendance_date", nullable = false)
    private LocalDate attendanceDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 30)
    private AttendanceStatus status;

    @Column(name = "effective_checkin_time")
    private OffsetDateTime effectiveCheckinTime;

    @Column(name = "remarks", columnDefinition = "text")
    private String remarks;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by_employee_id", nullable = false)
    private Employee createdByEmployee;

    @Column(name = "created_at", nullable = false,
            insertable = false, updatable = false)
    private OffsetDateTime createdAt;

    protected ManualAttendance() {
    }

    public ManualAttendance(Employee employee, LocalDate attendanceDate,
                            AttendanceStatus status,
                            OffsetDateTime effectiveCheckinTime,
                            String remarks, Employee createdByEmployee) {
        this.employee = employee;
        this.attendanceDate = attendanceDate;
        this.status = status;
        this.effectiveCheckinTime = effectiveCheckinTime;
        this.remarks = remarks;
        this.createdByEmployee = createdByEmployee;
    }

    public Integer getManualAttendanceId() { return manualAttendanceId; }
    public Employee getEmployee() { return employee; }
    public LocalDate getAttendanceDate() { return attendanceDate; }
    public AttendanceStatus getStatus() { return status; }
    public OffsetDateTime getEffectiveCheckinTime() { return effectiveCheckinTime; }
    public String getRemarks() { return remarks; }
    public Employee getCreatedByEmployee() { return createdByEmployee; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
}
