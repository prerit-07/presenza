package com.presenza.backend.push.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.push.dto.request.RegisterPushTokenRequest;
import com.presenza.backend.push.service.PushTokenService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/push-tokens")
public class PushTokenController {
    private final PushTokenService pushTokenService; private final TokenService tokenService;
    public PushTokenController(PushTokenService pushTokenService, TokenService tokenService) { this.pushTokenService = pushTokenService; this.tokenService = tokenService; }
    @PostMapping public ResponseEntity<Void> register(@RequestHeader(value = "Authorization", required = false) String authorization, @Valid @RequestBody RegisterPushTokenRequest request) {
        pushTokenService.register(authenticate(authorization).getUserId(), request); return ResponseEntity.noContent().build();
    }
    @PatchMapping("/{deviceId}/deactivate") public ResponseEntity<Void> deactivate(@RequestHeader(value = "Authorization", required = false) String authorization, @PathVariable String deviceId) {
        pushTokenService.deactivate(authenticate(authorization).getUserId(), deviceId); return ResponseEntity.noContent().build();
    }
    private AuthenticatedUser authenticate(String authorization) { if (authorization == null || !authorization.startsWith("Bearer ")) throw new InvalidCredentialsException(); return tokenService.getAuthenticatedUser(authorization.substring(7)); }
}
