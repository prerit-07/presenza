package com.presenza.backend.subscription.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "plan")
public class Plan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "plan_id")
    private Integer planId;

    @Column(name = "plan_name", nullable = false, length = 100)
    private String planName;

    @Column(name = "max_employees", nullable = false)
    private Integer maxEmployees;

    @Column(name = "price", nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    protected Plan() {
    }

    public Plan(String PlanName, Integer maxEmployees, BigDecimal price) {
        this.planName = PlanName;
        this.maxEmployees = maxEmployees;
        this.price = price;
    }

    public Integer getPlanId(){
        return planId;
    }

    public String getPlanName() {
        return planName;
    }

    public Integer getMaxEmployees() {
        return maxEmployees;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public void setMaxEmployees(Integer maxEmployees) {
        this.maxEmployees = maxEmployees;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }
}
