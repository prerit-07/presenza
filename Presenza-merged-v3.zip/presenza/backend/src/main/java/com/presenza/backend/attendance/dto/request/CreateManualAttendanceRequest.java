package com.presenza.backend.attendance.dto.request;

import com.presenza.backend.attendance.entity.AttendanceStatus;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;
import java.time.OffsetDateTime;

public class CreateManualAttendanceRequest {

    @NotNull(message = "Employee ID is required")
    private Integer employeeId;

    @NotNull(message = "Attendance date is required")
    private LocalDate attendanceDate;

    @NotNull(message = "Attendance status is required")
    private AttendanceStatus status;

    private OffsetDateTime effectiveCheckinTime;

    @Size(max = 2000, message = "Remarks must not exceed 2000 characters")
    private String remarks;

    public CreateManualAttendanceRequest() {
    }

    public Integer getEmployeeId() { return employeeId; }
    public LocalDate getAttendanceDate() { return attendanceDate; }
    public AttendanceStatus getStatus() { return status; }
    public OffsetDateTime getEffectiveCheckinTime() { return effectiveCheckinTime; }
    public String getRemarks() { return remarks; }
}
