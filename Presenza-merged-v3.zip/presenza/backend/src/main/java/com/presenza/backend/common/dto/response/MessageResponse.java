package com.presenza.backend.common.dto.response;

public class MessageResponse {

    private final boolean success;
    private final String message;

    public MessageResponse(
            boolean success,
            String message
    ) {
        this.success = success;
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }
}