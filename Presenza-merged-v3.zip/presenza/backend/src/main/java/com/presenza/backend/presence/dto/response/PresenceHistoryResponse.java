package com.presenza.backend.presence.dto.response;

import com.presenza.backend.presence.enums.PresenceEventType;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

public class PresenceHistoryResponse {
    private final Integer eventId;
    private final Integer checkinId;
    private final PresenceEventType eventType;
    private final OffsetDateTime eventTimestamp;
    private final BigDecimal latitude;
    private final BigDecimal longitude;
    private final BigDecimal accuracy;
    private final Boolean wifiVerified;

    public PresenceHistoryResponse(Integer eventId, Integer checkinId,
                                   PresenceEventType eventType,
                                   OffsetDateTime eventTimestamp,
                                   BigDecimal latitude, BigDecimal longitude,
                                   BigDecimal accuracy, Boolean wifiVerified) {
        this.eventId = eventId;
        this.checkinId = checkinId;
        this.eventType = eventType;
        this.eventTimestamp = eventTimestamp;
        this.latitude = latitude;
        this.longitude = longitude;
        this.accuracy = accuracy;
        this.wifiVerified = wifiVerified;
    }

    public Integer getEventId() { return eventId; }
    public Integer getCheckinId() { return checkinId; }
    public PresenceEventType getEventType() { return eventType; }
    public OffsetDateTime getEventTimestamp() { return eventTimestamp; }
    public BigDecimal getLatitude() { return latitude; }
    public BigDecimal getLongitude() { return longitude; }
    public BigDecimal getAccuracy() { return accuracy; }
    public Boolean getWifiVerified() { return wifiVerified; }
}
