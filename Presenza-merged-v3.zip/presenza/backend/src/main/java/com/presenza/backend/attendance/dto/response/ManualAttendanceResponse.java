package com.presenza.backend.attendance.dto.response;

import java.time.LocalDate;
import java.time.OffsetDateTime;

public class ManualAttendanceResponse {

    private final Integer manualAttendanceId;
    private final Integer employeeId;
    private final LocalDate attendanceDate;
    private final String status;
    private final OffsetDateTime effectiveCheckinTime;
    private final String remarks;
    private final Integer createdByEmployeeId;
    private final OffsetDateTime createdAt;

    public ManualAttendanceResponse(Integer manualAttendanceId, Integer employeeId,
                                    LocalDate attendanceDate, String status,
                                    OffsetDateTime effectiveCheckinTime,
                                    String remarks, Integer createdByEmployeeId,
                                    OffsetDateTime createdAt) {
        this.manualAttendanceId = manualAttendanceId;
        this.employeeId = employeeId;
        this.attendanceDate = attendanceDate;
        this.status = status;
        this.effectiveCheckinTime = effectiveCheckinTime;
        this.remarks = remarks;
        this.createdByEmployeeId = createdByEmployeeId;
        this.createdAt = createdAt;
    }

    public Integer getManualAttendanceId() { return manualAttendanceId; }
    public Integer getEmployeeId() { return employeeId; }
    public LocalDate getAttendanceDate() { return attendanceDate; }
    public String getStatus() { return status; }
    public OffsetDateTime getEffectiveCheckinTime() { return effectiveCheckinTime; }
    public String getRemarks() { return remarks; }
    public Integer getCreatedByEmployeeId() { return createdByEmployeeId; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
}
