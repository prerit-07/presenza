package com.presenza.backend.verification;

public enum VerificationPurpose {
    REGISTRATION,
    PASSWORD_RESET,
    EMAIL_CHANGE
}