package com.presenza.backend.shift.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.shift.dto.request.ShiftRequest;
import com.presenza.backend.shift.dto.response.ShiftResponse;
import com.presenza.backend.shift.service.ShiftService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shifts")
public class ShiftController {

    private final ShiftService shiftService;
    private final TokenService tokenService;

    public ShiftController(
            ShiftService shiftService,
            TokenService tokenService
    ) {
        this.shiftService = shiftService;
        this.tokenService = tokenService;
    }

    @PostMapping
    public ShiftResponse createShift(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody ShiftRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return shiftService.createShift(
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        );
    }

    @GetMapping("/{id}")
    public ShiftResponse getShiftById(
            @PathVariable Integer id,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return shiftService.getShiftById(
                id,
                authenticatedUser.getOrganizationId()
        );
    }

    @GetMapping
    public List<ShiftResponse> getShiftsByOrganization(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return shiftService.getShiftsByOrganization(
                authenticatedUser.getOrganizationId()
        );
    }

    @PutMapping("/{id}")
    public ShiftResponse updateShift(
            @PathVariable Integer id,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody ShiftRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return shiftService.updateShift(
                id,
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        );
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {
        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        return tokenService.getAuthenticatedUser(
                authorizationHeader.substring(7)
        );
    }
}