package com.presenza.backend.push.service;

import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.push.dto.request.RegisterPushTokenRequest;
import com.presenza.backend.push.entity.PushToken;
import com.presenza.backend.push.repository.PushTokenRepository;
import com.presenza.backend.user.entity.User;
import com.presenza.backend.user.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PushTokenService {
    private final PushTokenRepository pushTokenRepository;
    private final UserRepository userRepository;
    public PushTokenService(PushTokenRepository pushTokenRepository, UserRepository userRepository) { this.pushTokenRepository = pushTokenRepository; this.userRepository = userRepository; }
    @Transactional public void register(Integer userId, RegisterPushTokenRequest request) {
        User user = userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User not found"));
        PushToken token = pushTokenRepository.findByExpoPushToken(request.getExpoPushToken())
                .orElseGet(() -> new PushToken(user, request.getDeviceId(), request.getExpoPushToken(), request.getPlatform()));
        token.update(user, request.getDeviceId(), request.getPlatform());
        pushTokenRepository.save(token);
    }
    @Transactional public void deactivate(Integer userId, String deviceId) {
        pushTokenRepository.findByUserUserIdAndDeviceIdAndActiveTrue(userId, deviceId).forEach(token -> token.setActive(false));
    }
}
