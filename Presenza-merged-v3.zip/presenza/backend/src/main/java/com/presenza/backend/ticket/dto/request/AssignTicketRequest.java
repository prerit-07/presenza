package com.presenza.backend.ticket.dto.request;

import jakarta.validation.constraints.NotNull;

public class AssignTicketRequest {

    @NotNull(message = "Employee id is required")
    private Integer employeeId;

    public AssignTicketRequest() {
    }

    public Integer getEmployeeId() {
        return employeeId;
    }
}