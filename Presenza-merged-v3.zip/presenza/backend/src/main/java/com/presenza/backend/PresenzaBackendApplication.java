package com.presenza.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication
@EnableAsync
public class PresenzaBackendApplication {

    @RequestMapping
    String home() {
        return "Hello World";
    }

    public static void main(String[] args) {
        SpringApplication.run(PresenzaBackendApplication.class, args);
    }

}
