package com.presenza.backend.common.response;

import java.time.Instant;
import java.util.Map;

public record ValidationError(
        int status,
        String error,
        String message,
        String path,
        Map<String,String> fieldErrors,
        Instant timestamp
) {
}
