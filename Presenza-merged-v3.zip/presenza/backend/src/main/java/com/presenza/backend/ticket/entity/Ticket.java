package com.presenza.backend.ticket.entity;

import com.presenza.backend.attendance.entity.Attendance;
import com.presenza.backend.checkin.entity.CheckIn;
import com.presenza.backend.employee.entity.Employee;
import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.user.entity.User;
import jakarta.persistence.*;

import java.time.OffsetDateTime;

@Entity
@Table(name = "ticket")
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ticket_id")
    private Integer ticketId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "org_id", nullable = false)
    private Organization organization;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "raised_by_user_id", nullable = false)
    private User raisedByUser;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_to_employee_id")
    private Employee assignedToEmployee;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "checkin_id")
    private CheckIn checkIn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "attendance_id")
    private Attendance attendance;

    @Column(name = "subject", nullable = false, length = 200)
    private String subject;

    @Column(name = "description", columnDefinition = "text")
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(
            name = "status",
            nullable = false,
            length = 30,
            insertable = false
    )
    private TicketStatus status;

    @Column(
            name = "created_at",
            nullable = false,
            insertable = false,
            updatable = false
    )
    private OffsetDateTime createdAt;

    @Column(name = "resolved_at")
    private OffsetDateTime resolvedAt;

    protected Ticket() {
    }

    public Ticket(
            Organization organization,
            User raisedByUser,
            String subject,
            String description
    ) {
        this.organization = organization;
        this.raisedByUser = raisedByUser;
        this.subject = subject;
        this.description = description;
    }

    public Integer getTicketId() {
        return ticketId;
    }

    public Organization getOrganization() {
        return organization;
    }

    public User getRaisedByUser() {
        return raisedByUser;
    }

    public Employee getAssignedToEmployee() {
        return assignedToEmployee;
    }

    public CheckIn getCheckIn() {
        return checkIn;
    }

    public Attendance getAttendance() {
        return attendance;
    }

    public String getSubject() {
        return subject;
    }

    public String getDescription() {
        return description;
    }

    public TicketStatus getStatus() {
        return status;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public OffsetDateTime getResolvedAt() {
        return resolvedAt;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public void setRaisedByUser(User raisedByUser) {
        this.raisedByUser = raisedByUser;
    }

    public void setAssignedToEmployee(Employee assignedToEmployee) {
        this.assignedToEmployee = assignedToEmployee;
    }

    public void setCheckIn(CheckIn checkIn) {
        this.checkIn = checkIn;
    }

    public void setAttendance(Attendance attendance) {
        this.attendance = attendance;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setStatus(TicketStatus status) {
        this.status = status;
    }

    public void setResolvedAt(OffsetDateTime resolvedAt) {
        this.resolvedAt = resolvedAt;
    }
}