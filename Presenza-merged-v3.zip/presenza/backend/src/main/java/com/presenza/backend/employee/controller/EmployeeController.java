package com.presenza.backend.employee.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.employee.dto.request.CreateEmployeeRequest;
import com.presenza.backend.employee.dto.request.EmployeeRequest;
import com.presenza.backend.employee.dto.response.EmployeeResponse;
import com.presenza.backend.employee.service.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final EmployeeService employeeService;
    private final TokenService tokenService;

    public EmployeeController(
            EmployeeService employeeService,
            TokenService tokenService
    ) {
        this.employeeService = employeeService;
        this.tokenService = tokenService;
    }

    @PostMapping
    public EmployeeResponse createEmployee(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid
            @RequestBody
            CreateEmployeeRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return employeeService.createEmployee(
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        );
    }

    @GetMapping("/me")
    public EmployeeResponse getMyEmployee(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return employeeService.getMyEmployee(
                authenticatedUser.getUserId(),
                authenticatedUser.getOrganizationId()
        );
    }

    @GetMapping("/{id}")
    public EmployeeResponse getEmployeeById(
            @PathVariable Integer id,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return employeeService.getEmployeeById(
                id,
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole()
        );
    }

    @GetMapping
    public List<EmployeeResponse>
    getEmployeesByOrganization(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return employeeService
                .getEmployeesByOrganization(
                        authenticatedUser
                                .getOrganizationId(),
                        authenticatedUser.getRole()
                );
    }

    @PutMapping("/{id}")
    public EmployeeResponse updateEmployee(
            @PathVariable Integer id,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid
            @RequestBody
            EmployeeRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return employeeService.updateEmployee(
                id,
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        );
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {
        if (authorizationHeader == null ||
                !authorizationHeader
                        .startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        return tokenService.getAuthenticatedUser(
                authorizationHeader.substring(7)
        );
    }
}