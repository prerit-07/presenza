package com.presenza.backend.organisation.dto.response;

public class PresenceSettingsResponse {

    private final Boolean presenceMonitoringEnabled;
    private final Integer presenceUpdateIntervalSeconds;
    private final Boolean requireTrustedWifi;

    public PresenceSettingsResponse(
            Boolean presenceMonitoringEnabled,
            Integer presenceUpdateIntervalSeconds,
            Boolean requireTrustedWifi
    ) {
        this.presenceMonitoringEnabled = presenceMonitoringEnabled;
        this.presenceUpdateIntervalSeconds = presenceUpdateIntervalSeconds;
        this.requireTrustedWifi = requireTrustedWifi;
    }

    public Boolean getPresenceMonitoringEnabled() {
        return presenceMonitoringEnabled;
    }

    public Integer getPresenceUpdateIntervalSeconds() {
        return presenceUpdateIntervalSeconds;
    }

    public Boolean getRequireTrustedWifi() {
        return requireTrustedWifi;
    }
}
