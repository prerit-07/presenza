package com.presenza.backend.workforce.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.workforce.dto.request.DepartmentRequest;
import com.presenza.backend.workforce.dto.response.DepartmentResponse;
import com.presenza.backend.workforce.service.DepartmentService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {

    private final DepartmentService departmentService;
    private final TokenService tokenService;

    public DepartmentController(
            DepartmentService departmentService,
            TokenService tokenService
    ) {
        this.departmentService = departmentService;
        this.tokenService = tokenService;
    }

    @PostMapping
    public DepartmentResponse createDepartment(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody DepartmentRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return departmentService.createDepartment(
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        );
    }

    @GetMapping("/{id}")
    public DepartmentResponse getDepartmentById(
            @PathVariable Integer id,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return departmentService.getDepartmentById(
                id,
                authenticatedUser.getOrganizationId()
        );
    }

    @GetMapping
    public List<DepartmentResponse> getDepartmentsByOrganization(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return departmentService.getDepartmentsByOrganization(
                authenticatedUser.getOrganizationId()
        );
    }

    @PutMapping("/{id}")
    public DepartmentResponse updateDepartment(
            @PathVariable Integer id,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody DepartmentRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return departmentService.updateDepartment(
                id,
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        );
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {
        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        return tokenService.getAuthenticatedUser(
                authorizationHeader.substring(7)
        );
    }
}