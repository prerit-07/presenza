package com.presenza.backend.security.entity;

import com.presenza.backend.organisation.entity.Organization;
import jakarta.persistence.*;

@Entity
@Table(name = "role")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "role_id")
    private Integer roleId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "org_id", nullable = false)
    private Organization organization;

    @Column(name = "role_name", nullable = false, length = 100)
    private String roleName;

    protected Role() {}

    public Role(Organization organization, String roleName) {
        this.organization = organization;
        this.roleName = roleName;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public Organization getOrganization() {
        return organization;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}
