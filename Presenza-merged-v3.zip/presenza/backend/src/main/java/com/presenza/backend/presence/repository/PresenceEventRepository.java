package com.presenza.backend.presence.repository;

import com.presenza.backend.presence.entity.PresenceEvent;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

public interface PresenceEventRepository
        extends JpaRepository<PresenceEvent, Integer> {

    Optional<PresenceEvent>
    findFirstByCheckInCheckinIdOrderByEventTimestampDesc(Integer checkinId);

    @EntityGraph(attributePaths = "checkIn")
    List<PresenceEvent>
    findByCheckInUserUserIdAndEventTimestampBetweenOrderByEventTimestampAsc(
            Integer userId,
            OffsetDateTime start,
            OffsetDateTime end
    );
}
