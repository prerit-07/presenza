package com.presenza.backend.attendance.entity;

import com.presenza.backend.checkin.entity.CheckIn;
import jakarta.persistence.*;

import java.time.OffsetDateTime;

@Entity
@Table(
        name = "attendance",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "attendance_checkin_id_key",
                        columnNames = "checkin_id"
                )
        }
)
public class Attendance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "attendance_id")
    private Integer attendanceId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "checkin_id", nullable = false)
    private CheckIn checkIn;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 30)
    private AttendanceStatus status;

    @Column(name = "approved_at")
    private OffsetDateTime approvedAt;

    @Column(name = "effective_checkin_time")
    private OffsetDateTime effectiveCheckinTime;

    @Column(name = "remarks", columnDefinition = "text")
    private String remarks;

    protected Attendance() {
    }

    public Attendance(
            CheckIn checkIn,
            AttendanceStatus status,
            String remarks
    ) {
        this.checkIn = checkIn;
        this.status = status;
        this.remarks = remarks;
    }

    public Integer getAttendanceId() {
        return attendanceId;
    }

    public CheckIn getCheckIn() {
        return checkIn;
    }

    public AttendanceStatus getStatus() {
        return status;
    }

    public OffsetDateTime getApprovedAt() {
        return approvedAt;
    }

    public OffsetDateTime getEffectiveCheckinTime() {
        return effectiveCheckinTime;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setCheckIn(CheckIn checkIn) {
        this.checkIn = checkIn;
    }

    public void setStatus(AttendanceStatus status) {
        this.status = status;
    }

    public void setApprovedAt(OffsetDateTime approvedAt) {
        this.approvedAt = approvedAt;
    }

    public void setEffectiveCheckinTime(
            OffsetDateTime effectiveCheckinTime
    ) {
        this.effectiveCheckinTime = effectiveCheckinTime;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
