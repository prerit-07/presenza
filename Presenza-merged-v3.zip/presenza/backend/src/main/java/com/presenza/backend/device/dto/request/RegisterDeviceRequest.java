package com.presenza.backend.device.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class RegisterDeviceRequest {

    @NotBlank(message = "Device ID is required")
    @Size(max = 100, message = "Device ID must not exceed 100 characters")
    private String deviceId;

    @Size(max = 50, message = "Platform must not exceed 50 characters")
    private String platform;

    @Size(max = 100, message = "Model must not exceed 100 characters")
    private String model;

    @Size(max = 50, message = "App version must not exceed 50 characters")
    private String appVersion;

    public RegisterDeviceRequest() {
    }

    public String getDeviceId() {
        return deviceId;
    }

    public String getPlatform() {
        return platform;
    }

    public String getModel() {
        return model;
    }

    public String getAppVersion() {
        return appVersion;
    }
}