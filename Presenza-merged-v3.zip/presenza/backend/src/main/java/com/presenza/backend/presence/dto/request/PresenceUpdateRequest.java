package com.presenza.backend.presence.dto.request;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public class PresenceUpdateRequest {

    @Size(max = 150, message = "SSID must not exceed 150 characters")
    private String connectedSsid;

    @Size(max = 50, message = "BSSID must not exceed 50 characters")
    private String connectedBssid;

    @DecimalMin(value = "-90.0", message = "Latitude must be at least -90")
    @DecimalMax(value = "90.0", message = "Latitude must not exceed 90")
    private BigDecimal latitude;

    @DecimalMin(value = "-180.0", message = "Longitude must be at least -180")
    @DecimalMax(value = "180.0", message = "Longitude must not exceed 180")
    private BigDecimal longitude;

    @DecimalMin(value = "0.0", message = "Accuracy must not be negative")
    private BigDecimal accuracy;

    public PresenceUpdateRequest() {
    }

    public String getConnectedSsid() { return connectedSsid; }
    public String getConnectedBssid() { return connectedBssid; }
    public BigDecimal getLatitude() { return latitude; }
    public BigDecimal getLongitude() { return longitude; }
    public BigDecimal getAccuracy() { return accuracy; }
}
