package com.presenza.backend.attendance.service;

import com.presenza.backend.attendance.dto.request.CreateAttendanceRequest;
import com.presenza.backend.attendance.dto.request.ReviewAttendanceRequestDecision;
import com.presenza.backend.attendance.dto.response.AttendanceRequestResponse;
import com.presenza.backend.attendance.entity.AttendanceRequest;
import com.presenza.backend.attendance.entity.AttendanceRequestStatus;
import com.presenza.backend.attendance.repository.AttendanceRequestRepository;
import com.presenza.backend.common.exception.BadRequestException;
import com.presenza.backend.common.exception.ForbiddenException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.employee.entity.Employee;
import com.presenza.backend.employee.repository.EmployeeRepository;
import com.presenza.backend.notification.NotificationType;
import com.presenza.backend.notification.service.NotificationService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

@Service
public class AttendanceRequestService {

    private final AttendanceRequestRepository attendanceRequestRepository;
    private final EmployeeRepository employeeRepository;
    private final NotificationService notificationService;

    public AttendanceRequestService(
            AttendanceRequestRepository attendanceRequestRepository,
            EmployeeRepository employeeRepository,
            NotificationService notificationService
    ) {
        this.attendanceRequestRepository =
                attendanceRequestRepository;
        this.employeeRepository =
                employeeRepository;
        this.notificationService = notificationService;
    }

    @Transactional
    public AttendanceRequestResponse createRequest(
            Integer userId,
            Integer organizationId,
            CreateAttendanceRequest request
    ) {
        if (request.getEndDate()
                .isBefore(request.getStartDate())) {
            throw new BadRequestException(
                    "End date cannot be before start date"
            );
        }

        Employee employee = employeeRepository
                .findByUserUserId(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Employee profile not found"
                        )
                );

        validateEmployeeOrganization(
                employee,
                organizationId
        );

        AttendanceRequest attendanceRequest =
                new AttendanceRequest(
                        employee,
                        request.getRequestType(),
                        request.getStartDate(),
                        request.getEndDate(),
                        request.getReason()
                );

        attendanceRequest.setStatus(
                AttendanceRequestStatus.PENDING
        );

        AttendanceRequest saved = attendanceRequestRepository.save(attendanceRequest);
        notificationService.notifyOrganizationRole(
                organizationId, "ORG_ADMIN", NotificationType.ATTENDANCE_REQUEST,
                "Attendance request pending",
                employee.getEmployeeName() + " submitted a " + request.getRequestType().name() + " request.",
                "ATTENDANCE_REQUEST", saved.getRequestId()
        );
        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<AttendanceRequestResponse> getMyRequests(
            Integer userId
    ) {
        return attendanceRequestRepository
                .findByEmployeeUserUserIdOrderByRequestIdDesc(
                        userId
                )
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<AttendanceRequestResponse>
    getOrganizationRequests(
            Integer organizationId,
            String role
    ) {
        validateAdminRole(role);

        return attendanceRequestRepository
                .findByEmployeeOrganizationOrgIdOrderByRequestIdDesc(
                        organizationId
                )
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<AttendanceRequestResponse>
    getPendingRequests(
            Integer organizationId,
            String role
    ) {
        validateAdminRole(role);

        return attendanceRequestRepository
                .findByEmployeeOrganizationOrgIdAndStatusOrderByRequestIdDesc(
                        organizationId,
                        AttendanceRequestStatus.PENDING
                )
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional
    public AttendanceRequestResponse reviewRequest(
            Integer requestId,
            Integer reviewerUserId,
            Integer organizationId,
            String role,
            ReviewAttendanceRequestDecision request
    ) {
        validateAdminRole(role);

        AttendanceRequest attendanceRequest =
                attendanceRequestRepository
                        .findById(requestId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Attendance request not found with id: "
                                                + requestId
                                )
                        );

        validateEmployeeOrganization(
                attendanceRequest.getEmployee(),
                organizationId
        );

        if (attendanceRequest.getStatus()
                != AttendanceRequestStatus.PENDING) {
            throw new BadRequestException(
                    "Only pending attendance requests can be reviewed"
            );
        }

        // Organization admins are authorized by their authenticated role and
        // do not necessarily have an Employee profile of their own.
        Employee reviewer = employeeRepository
                .findByUserUserId(reviewerUserId)
                .orElse(null);

        if (reviewer != null) {
            validateEmployeeOrganization(reviewer, organizationId);
        }

        AttendanceRequestStatus newStatus =
                Boolean.TRUE.equals(request.getApproved())
                        ? AttendanceRequestStatus.APPROVED
                        : AttendanceRequestStatus.REJECTED;

        attendanceRequest.setStatus(newStatus);
        attendanceRequest.setReviewedBy(reviewer);
        attendanceRequest.setReviewRemarks(
                request.getRemarks()
        );
        attendanceRequest.setReviewedAt(
                OffsetDateTime.now()
        );
        attendanceRequest.setUpdatedAt(
                OffsetDateTime.now()
        );

        AttendanceRequest saved = attendanceRequestRepository.save(attendanceRequest);
        notificationService.createNotification(
                organizationId,
                attendanceRequest.getEmployee().getUser().getUserId(),
                NotificationType.ATTENDANCE_REQUEST,
                "Attendance request " + newStatus.name().toLowerCase(),
                "Your " + attendanceRequest.getRequestType().name() + " request was " + newStatus.name().toLowerCase() + ".",
                "ATTENDANCE_REQUEST", saved.getRequestId()
        );
        return toResponse(saved);
    }

    private void validateAdminRole(String role) {
        if (!"ORG_ADMIN".equals(role)) {
            throw new ForbiddenException(
                    "Only organization admins can review attendance requests"
            );
        }
    }

    private void validateEmployeeOrganization(
            Employee employee,
            Integer organizationId
    ) {
        if (!employee.getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Employee not found in organization"
            );
        }
    }

    private AttendanceRequestResponse toResponse(
            AttendanceRequest request
    ) {
        return new AttendanceRequestResponse(
                request.getRequestId(),
                request.getEmployee().getEmployeeId(),
                request.getEmployee().getEmployeeName(),
                request.getRequestType().name(),
                request.getStartDate(),
                request.getEndDate(),
                request.getReason(),
                request.getStatus().name(),
                request.getReviewedBy() != null
                        ? request.getReviewedBy()
                        .getEmployeeId()
                        : null,
                request.getReviewRemarks(),
                request.getReviewedAt(),
                request.getCreatedAt(),
                request.getUpdatedAt()
        );
    }
}
