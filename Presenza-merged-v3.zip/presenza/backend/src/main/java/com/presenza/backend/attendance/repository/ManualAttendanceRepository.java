package com.presenza.backend.attendance.repository;

import com.presenza.backend.attendance.entity.ManualAttendance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface ManualAttendanceRepository
        extends JpaRepository<ManualAttendance, Integer> {

    boolean existsByEmployeeEmployeeIdAndAttendanceDate(
            Integer employeeId,
            LocalDate attendanceDate
    );

    List<ManualAttendance> findByEmployeeEmployeeIdInAndAttendanceDate(
            List<Integer> employeeIds,
            LocalDate attendanceDate
    );
}
