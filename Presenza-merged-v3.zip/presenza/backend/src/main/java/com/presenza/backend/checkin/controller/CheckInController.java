package com.presenza.backend.checkin.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.checkin.dto.request.EmployeeCheckInRequest;
import com.presenza.backend.checkin.dto.response.CheckInResponse;
import com.presenza.backend.checkin.service.CheckInService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/check-ins")
public class CheckInController {

    private final CheckInService checkInService;
    private final TokenService tokenService;

    public CheckInController(
            CheckInService checkInService,
            TokenService tokenService
    ) {
        this.checkInService = checkInService;
        this.tokenService = tokenService;
    }

    @PostMapping("/employee")
    public ResponseEntity<CheckInResponse> employeeCheckIn(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody EmployeeCheckInRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        CheckInResponse response =
                checkInService.employeeCheckIn(
                        authenticatedUser.getUserId(),
                        authenticatedUser.getOrganizationId(),
                        request
                );

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {
        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        String rawToken = authorizationHeader.substring(7);

        return tokenService.getAuthenticatedUser(rawToken);
    }
}