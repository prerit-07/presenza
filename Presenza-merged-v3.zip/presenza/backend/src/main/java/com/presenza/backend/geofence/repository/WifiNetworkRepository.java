package com.presenza.backend.geofence.repository;

import com.presenza.backend.geofence.entity.WifiNetwork;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface WifiNetworkRepository
        extends JpaRepository<WifiNetwork, Integer> {

    List<WifiNetwork> findByGeofenceGeofenceId(
            Integer geofenceId
    );

    Optional<WifiNetwork> findByBssidAndIsActiveTrue(
            String bssid
    );
}