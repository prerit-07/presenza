package com.presenza.backend.device.repository;

import com.presenza.backend.device.entity.DeviceChangeRequest;
import com.presenza.backend.device.entity.DeviceChangeRequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DeviceChangeRequestRepository
        extends JpaRepository<DeviceChangeRequest, Integer> {

    List<DeviceChangeRequest>
    findByUserUserIdOrderByRequestIdDesc(
            Integer userId
    );

    List<DeviceChangeRequest>
    findByUserOrganizationOrgIdAndStatusOrderByRequestIdDesc(
            Integer organizationId,
            DeviceChangeRequestStatus status
    );

    boolean existsByUserUserIdAndStatus(
            Integer userId,
            DeviceChangeRequestStatus status
    );
}