package com.presenza.backend.ticket.service;

import com.presenza.backend.attendance.entity.Attendance;
import com.presenza.backend.attendance.repository.AttendanceRepository;
import com.presenza.backend.checkin.entity.CheckIn;
import com.presenza.backend.checkin.repository.CheckInRepository;
import com.presenza.backend.common.exception.BadRequestException;
import com.presenza.backend.common.exception.ForbiddenException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.employee.entity.Employee;
import com.presenza.backend.employee.repository.EmployeeRepository;
import com.presenza.backend.notification.NotificationType;
import com.presenza.backend.notification.service.NotificationService;
import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.organisation.repository.OrganizationRepository;
import com.presenza.backend.ticket.dto.request.AddTicketCommentRequest;
import com.presenza.backend.ticket.dto.request.AssignTicketRequest;
import com.presenza.backend.ticket.dto.request.CreateTicketRequest;
import com.presenza.backend.ticket.dto.request.UpdateTicketStatusRequest;
import com.presenza.backend.ticket.dto.response.TicketCommentResponse;
import com.presenza.backend.ticket.dto.response.TicketResponse;
import com.presenza.backend.ticket.entity.Ticket;
import com.presenza.backend.ticket.entity.TicketComment;
import com.presenza.backend.ticket.entity.TicketStatus;
import com.presenza.backend.ticket.repository.TicketCommentRepository;
import com.presenza.backend.ticket.repository.TicketRepository;
import com.presenza.backend.user.entity.User;
import com.presenza.backend.user.repository.UserRepository;
import jakarta.persistence.EntityManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

@Service
public class TicketService {

    private final TicketRepository ticketRepository;
    private final TicketCommentRepository ticketCommentRepository;
    private final UserRepository userRepository;
    private final OrganizationRepository organizationRepository;
    private final CheckInRepository checkInRepository;
    private final AttendanceRepository attendanceRepository;
    private final EmployeeRepository employeeRepository;
    private final EntityManager entityManager;
    private final NotificationService notificationService;

    public TicketService(
            TicketRepository ticketRepository,
            TicketCommentRepository ticketCommentRepository,
            UserRepository userRepository,
            OrganizationRepository organizationRepository,
            CheckInRepository checkInRepository,
            AttendanceRepository attendanceRepository,
            EmployeeRepository employeeRepository,
            EntityManager entityManager,
            NotificationService notificationService
    ) {
        this.ticketRepository = ticketRepository;
        this.ticketCommentRepository = ticketCommentRepository;
        this.userRepository = userRepository;
        this.organizationRepository = organizationRepository;
        this.checkInRepository = checkInRepository;
        this.attendanceRepository = attendanceRepository;
        this.employeeRepository = employeeRepository;
        this.entityManager = entityManager;
        this.notificationService = notificationService;
    }

    @Transactional
    public TicketResponse createTicket(
            Integer userId,
            Integer organizationId,
            CreateTicketRequest request
    ) {
        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found with id: " + userId
                        )
                );

        Organization organization =
                organizationRepository.findById(organizationId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Organization not found with id: "
                                                + organizationId
                                )
                        );

        Ticket ticket = new Ticket(
                organization,
                user,
                request.getSubject(),
                request.getDescription()
        );

        if (request.getCheckinId() != null) {
            CheckIn checkIn = checkInRepository
                    .findById(request.getCheckinId())
                    .orElseThrow(() ->
                            new ResourceNotFoundException(
                                    "Check-in not found with id: "
                                            + request.getCheckinId()
                            )
                    );

            if (!checkIn.getUser().getUserId().equals(userId) ||
                    checkIn.getShift() == null ||
                    !checkIn.getShift()
                            .getOrganization()
                            .getOrgId()
                            .equals(organizationId)) {
                throw new ForbiddenException(
                        "User is not allowed to link this check-in"
                );
            }

            ticket.setCheckIn(checkIn);
        }

        if (request.getAttendanceId() != null) {
            Attendance attendance = attendanceRepository
                    .findById(request.getAttendanceId())
                    .orElseThrow(() ->
                            new ResourceNotFoundException(
                                    "Attendance not found with id: "
                                            + request.getAttendanceId()
                            )
                    );

            if (!attendance.getCheckIn()
                    .getUser()
                    .getUserId()
                    .equals(userId) ||
                    attendance.getCheckIn().getShift() == null ||
                    !attendance.getCheckIn()
                            .getShift()
                            .getOrganization()
                            .getOrgId()
                            .equals(organizationId)) {
                throw new ForbiddenException(
                        "User is not allowed to link this attendance"
                );
            }

            ticket.setAttendance(attendance);
        }

        Ticket savedTicket =
                ticketRepository.saveAndFlush(ticket);

        entityManager.refresh(savedTicket);

        notificationService.notifyOrganizationRole(
                organizationId, "ORG_ADMIN", NotificationType.TICKET,
                "New support ticket",
                user.getUsername() + " created ticket: " + savedTicket.getSubject(),
                "TICKET", savedTicket.getTicketId()
        );

        return toResponse(savedTicket);
    }

    @Transactional(readOnly = true)
    public List<TicketResponse> getMyTickets(Integer userId) {
        return ticketRepository
                .findByRaisedByUserUserIdOrderByTicketIdDesc(userId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<TicketResponse> getOrganizationTickets(
            Integer organizationId,
            String role
    ) {
        validateStaffRole(role);

        return ticketRepository
                .findByOrganizationOrgIdOrderByTicketIdDesc(
                        organizationId
                )
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public TicketResponse getTicket(
            Integer ticketId,
            Integer userId,
            Integer organizationId,
            String role
    ) {
        Ticket ticket = findTicketInOrganization(
                ticketId,
                organizationId
        );

        validateTicketAccess(ticket, userId, role);

        return toResponse(ticket);
    }

    @Transactional
    public TicketResponse assignTicket(
            Integer ticketId,
            Integer organizationId,
            String role,
            AssignTicketRequest request
    ) {
        validateStaffRole(role);

        Ticket ticket = findTicketInOrganization(
                ticketId,
                organizationId
        );

        Employee employee = employeeRepository
                .findById(request.getEmployeeId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Employee not found with id: "
                                        + request.getEmployeeId()
                        )
                );

        if (!employee.getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Employee not found with id: "
                            + request.getEmployeeId()
            );
        }

        ticket.setAssignedToEmployee(employee);

        if (ticket.getStatus() == TicketStatus.OPEN ||
                ticket.getStatus() == TicketStatus.REOPENED) {
            ticket.setStatus(TicketStatus.IN_PROGRESS);
        }

        Ticket saved = ticketRepository.save(ticket);
        notificationService.createNotification(
                organizationId, employee.getUser().getUserId(), NotificationType.TICKET,
                "Ticket assigned to you", "You were assigned ticket: " + saved.getSubject(),
                "TICKET", saved.getTicketId()
        );
        return toResponse(saved);
    }

    @Transactional
    public TicketResponse updateStatus(
            Integer ticketId,
            Integer organizationId,
            String role,
            UpdateTicketStatusRequest request
    ) {
        validateStaffRole(role);

        Ticket ticket = findTicketInOrganization(
                ticketId,
                organizationId
        );

        TicketStatus newStatus;

        try {
            newStatus = TicketStatus.valueOf(
                    request.getStatus()
                            .trim()
                            .toUpperCase()
            );
        } catch (IllegalArgumentException exception) {
            throw new BadRequestException(
                    "Invalid ticket status"
            );
        }

        validateStatusTransition(
                ticket.getStatus(),
                newStatus
        );

        ticket.setStatus(newStatus);

        if (newStatus == TicketStatus.RESOLVED ||
                newStatus == TicketStatus.CLOSED) {
            ticket.setResolvedAt(OffsetDateTime.now());
        } else {
            ticket.setResolvedAt(null);
        }

        Ticket saved = ticketRepository.save(ticket);
        notificationService.createNotification(
                organizationId, saved.getRaisedByUser().getUserId(), NotificationType.TICKET,
                "Ticket status updated", "Your ticket is now " + newStatus.name().toLowerCase() + ".",
                "TICKET", saved.getTicketId()
        );
        return toResponse(saved);
    }

    @Transactional
    public TicketCommentResponse addComment(
            Integer ticketId,
            Integer userId,
            Integer organizationId,
            String role,
            AddTicketCommentRequest request
    ) {
        Ticket ticket = findTicketInOrganization(
                ticketId,
                organizationId
        );

        validateTicketAccess(ticket, userId, role);

        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found with id: " + userId
                        )
                );

        TicketComment comment = new TicketComment(
                ticket,
                user,
                request.getMessage()
        );

        TicketComment savedComment =
                ticketCommentRepository.saveAndFlush(comment);

        entityManager.refresh(savedComment);

        if (!ticket.getRaisedByUser().getUserId().equals(userId)) {
            notificationService.createNotification(
                    organizationId, ticket.getRaisedByUser().getUserId(), NotificationType.TICKET,
                    "New ticket comment", "A new comment was added to: " + ticket.getSubject(),
                    "TICKET", ticket.getTicketId()
            );
        }
        if (ticket.getAssignedToEmployee() != null &&
                !ticket.getAssignedToEmployee().getUser().getUserId().equals(userId) &&
                !ticket.getAssignedToEmployee().getUser().getUserId().equals(ticket.getRaisedByUser().getUserId())) {
            notificationService.createNotification(
                    organizationId, ticket.getAssignedToEmployee().getUser().getUserId(), NotificationType.TICKET,
                    "New ticket comment", "A new comment was added to: " + ticket.getSubject(),
                    "TICKET", ticket.getTicketId()
            );
        }

        return toCommentResponse(savedComment);
    }

    @Transactional(readOnly = true)
    public List<TicketCommentResponse> getComments(
            Integer ticketId,
            Integer userId,
            Integer organizationId,
            String role
    ) {
        Ticket ticket = findTicketInOrganization(
                ticketId,
                organizationId
        );

        validateTicketAccess(ticket, userId, role);

        return ticketCommentRepository
                .findByTicketTicketIdOrderByCommentIdAsc(ticketId)
                .stream()
                .map(this::toCommentResponse)
                .toList();
    }

    private void validateStatusTransition(
            TicketStatus currentStatus,
            TicketStatus newStatus
    ) {
        if (currentStatus == newStatus) {
            throw new BadRequestException(
                    "Ticket already has status " + newStatus.name()
            );
        }

        boolean valid =
                switch (currentStatus) {
                    case OPEN ->
                            newStatus == TicketStatus.IN_PROGRESS ||
                                    newStatus == TicketStatus.RESOLVED ||
                                    newStatus == TicketStatus.CLOSED;

                    case IN_PROGRESS ->
                            newStatus == TicketStatus.RESOLVED ||
                                    newStatus == TicketStatus.CLOSED;

                    case RESOLVED ->
                            newStatus == TicketStatus.CLOSED ||
                                    newStatus == TicketStatus.REOPENED;

                    case CLOSED ->
                            newStatus == TicketStatus.REOPENED;

                    case REOPENED ->
                            newStatus == TicketStatus.IN_PROGRESS ||
                                    newStatus == TicketStatus.RESOLVED ||
                                    newStatus == TicketStatus.CLOSED;
                };

        if (!valid) {
            throw new BadRequestException(
                    "Invalid ticket status transition from "
                            + currentStatus.name()
                            + " to "
                            + newStatus.name()
            );
        }
    }

    private Ticket findTicketInOrganization(
            Integer ticketId,
            Integer organizationId
    ) {
        Ticket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Ticket not found with id: " + ticketId
                        )
                );

        if (!ticket.getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Ticket not found with id: " + ticketId
            );
        }

        return ticket;
    }

    private void validateTicketAccess(
            Ticket ticket,
            Integer userId,
            String role
    ) {
        boolean owner =
                ticket.getRaisedByUser()
                        .getUserId()
                        .equals(userId);

        boolean staff =
                "ORG_ADMIN".equals(role) ||
                        "MANAGER".equals(role);

        if (!owner && !staff) {
            throw new ForbiddenException(
                    "User is not allowed to access this ticket"
            );
        }
    }

    private void validateStaffRole(String role) {
        if (!"ORG_ADMIN".equals(role) &&
                !"MANAGER".equals(role)) {
            throw new ForbiddenException(
                    "User is not allowed to manage organization tickets"
            );
        }
    }

    private TicketResponse toResponse(Ticket ticket) {
        return new TicketResponse(
                ticket.getTicketId(),
                ticket.getOrganization().getOrgId(),
                ticket.getRaisedByUser().getUserId(),
                ticket.getAssignedToEmployee() != null
                        ? ticket.getAssignedToEmployee()
                        .getEmployeeId()
                        : null,
                ticket.getCheckIn() != null
                        ? ticket.getCheckIn().getCheckinId()
                        : null,
                ticket.getAttendance() != null
                        ? ticket.getAttendance().getAttendanceId()
                        : null,
                ticket.getSubject(),
                ticket.getDescription(),
                ticket.getStatus().name(),
                ticket.getCreatedAt(),
                ticket.getResolvedAt()
        );
    }

    private TicketCommentResponse toCommentResponse(
            TicketComment comment
    ) {
        return new TicketCommentResponse(
                comment.getCommentId(),
                comment.getTicket().getTicketId(),
                comment.getUser().getUserId(),
                comment.getMessage(),
                comment.getCreatedAt()
        );
    }
}
