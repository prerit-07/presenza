package com.presenza.backend.ticket.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.ticket.dto.request.AddTicketCommentRequest;
import com.presenza.backend.ticket.dto.request.AssignTicketRequest;
import com.presenza.backend.ticket.dto.request.CreateTicketRequest;
import com.presenza.backend.ticket.dto.request.UpdateTicketStatusRequest;
import com.presenza.backend.ticket.dto.response.TicketCommentResponse;
import com.presenza.backend.ticket.dto.response.TicketResponse;
import com.presenza.backend.ticket.service.TicketService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tickets")
public class TicketController {

    private final TicketService ticketService;
    private final TokenService tokenService;

    public TicketController(
            TicketService ticketService,
            TokenService tokenService
    ) {
        this.ticketService = ticketService;
        this.tokenService = tokenService;
    }

    @PostMapping
    public ResponseEntity<TicketResponse> createTicket(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody CreateTicketRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        TicketResponse response = ticketService.createTicket(
                authenticatedUser.getUserId(),
                authenticatedUser.getOrganizationId(),
                request
        );

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }

    @GetMapping("/me")
    public ResponseEntity<List<TicketResponse>> getMyTickets(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return ResponseEntity.ok(
                ticketService.getMyTickets(
                        authenticatedUser.getUserId()
                )
        );
    }

    @GetMapping
    public ResponseEntity<List<TicketResponse>>
    getOrganizationTickets(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return ResponseEntity.ok(
                ticketService.getOrganizationTickets(
                        authenticatedUser.getOrganizationId(),
                        authenticatedUser.getRole()
                )
        );
    }

    @GetMapping("/{ticketId}")
    public ResponseEntity<TicketResponse> getTicket(
            @PathVariable Integer ticketId,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return ResponseEntity.ok(
                ticketService.getTicket(
                        ticketId,
                        authenticatedUser.getUserId(),
                        authenticatedUser.getOrganizationId(),
                        authenticatedUser.getRole()
                )
        );
    }

    @PatchMapping("/{ticketId}/assign")
    public ResponseEntity<TicketResponse> assignTicket(
            @PathVariable Integer ticketId,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody AssignTicketRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return ResponseEntity.ok(
                ticketService.assignTicket(
                        ticketId,
                        authenticatedUser.getOrganizationId(),
                        authenticatedUser.getRole(),
                        request
                )
        );
    }

    @PatchMapping("/{ticketId}/status")
    public ResponseEntity<TicketResponse> updateStatus(
            @PathVariable Integer ticketId,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody UpdateTicketStatusRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return ResponseEntity.ok(
                ticketService.updateStatus(
                        ticketId,
                        authenticatedUser.getOrganizationId(),
                        authenticatedUser.getRole(),
                        request
                )
        );
    }

    @PostMapping("/{ticketId}/comments")
    public ResponseEntity<TicketCommentResponse> addComment(
            @PathVariable Integer ticketId,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody AddTicketCommentRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        TicketCommentResponse response =
                ticketService.addComment(
                        ticketId,
                        authenticatedUser.getUserId(),
                        authenticatedUser.getOrganizationId(),
                        authenticatedUser.getRole(),
                        request
                );

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }

    @GetMapping("/{ticketId}/comments")
    public ResponseEntity<List<TicketCommentResponse>>
    getComments(
            @PathVariable Integer ticketId,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return ResponseEntity.ok(
                ticketService.getComments(
                        ticketId,
                        authenticatedUser.getUserId(),
                        authenticatedUser.getOrganizationId(),
                        authenticatedUser.getRole()
                )
        );
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {
        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        String rawToken =
                authorizationHeader.substring(7);

        return tokenService.getAuthenticatedUser(rawToken);
    }
}