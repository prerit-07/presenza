package com.presenza.backend.organisation.dto.response;

import java.time.OffsetDateTime;

public class OrganizationResponse {

    private Integer orgId;
    private String orgName;
    private String companyCode;
    private Integer planId;
    private String planName;
    private String orgType;
    private Integer maxAllowedEmployee;
    private OffsetDateTime createdAt;

    public OrganizationResponse() {
    }

    public OrganizationResponse(
            Integer orgId,
            String orgName,
            Integer planId,
            String planName,
            String orgType,
            Integer maxAllowedEmployee,
            OffsetDateTime createdAt
    ) {
        this(
                orgId,
                orgName,
                null,
                planId,
                planName,
                orgType,
                maxAllowedEmployee,
                createdAt
        );
    }

    public OrganizationResponse(
            Integer orgId,
            String orgName,
            String companyCode,
            Integer planId,
            String planName,
            String orgType,
            Integer maxAllowedEmployee,
            OffsetDateTime createdAt
    ) {
        this.orgId = orgId;
        this.orgName = orgName;
        this.companyCode = companyCode;
        this.planId = planId;
        this.planName = planName;
        this.orgType = orgType;
        this.maxAllowedEmployee = maxAllowedEmployee;
        this.createdAt = createdAt;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public Integer getPlanId() {
        return planId;
    }

    public void setPlanId(Integer planId) {
        this.planId = planId;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public String getOrgType() {
        return orgType;
    }

    public void setOrgType(String orgType) {
        this.orgType = orgType;
    }

    public Integer getMaxAllowedEmployee() {
        return maxAllowedEmployee;
    }

    public void setMaxAllowedEmployee(Integer maxAllowedEmployee) {
        this.maxAllowedEmployee = maxAllowedEmployee;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
