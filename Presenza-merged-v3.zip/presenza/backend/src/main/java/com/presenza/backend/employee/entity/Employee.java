package com.presenza.backend.employee.entity;

import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.workforce.entity.Team;
import com.presenza.backend.shift.entity.Shift;
import com.presenza.backend.user.entity.User;
import com.presenza.backend.workforce.entity.Department;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDate;

@Entity
@Table(name = "employee")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "employee_id")
    private Integer employeeId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "org_id", nullable = false)
    private Organization organization;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "employee_name", nullable = false)
    private String employeeName;

    @Column(name = "date_of_joining")
    private LocalDate dateOfJoining;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id")
    private Department department;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shift_id")
    private Shift shift;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "team_id")
    private Team team;

    protected Employee() {
    }

    public Employee(
            Organization organization,
            User user,
            String employeeName,
            LocalDate dateOfJoining,
            Department department,
            Shift shift,
            Team team
    ) {
        this.organization = organization;
        this.user = user;
        this.employeeName = employeeName;
        this.dateOfJoining = dateOfJoining;
        this.department = department;
        this.shift = shift;
        this.team = team;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public Organization getOrganization() {
        return organization;
    }

    public User getUser() {
        return user;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public LocalDate getDateOfJoining() {
        return dateOfJoining;
    }

    public Department getDepartment() {
        return department;
    }

    public Shift getShift() {
        return shift;
    }

    public Team getTeam() {
        return team;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public void setDateOfJoining(LocalDate dateOfJoining) {
        this.dateOfJoining = dateOfJoining;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public void setShift(Shift shift) {
        this.shift = shift;
    }

    public void setTeam(Team team) {
        this.team = team;
    }
}
