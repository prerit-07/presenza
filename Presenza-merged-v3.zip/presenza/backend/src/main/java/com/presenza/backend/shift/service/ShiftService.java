package com.presenza.backend.shift.service;

import com.presenza.backend.common.exception.ForbiddenException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.geofence.entity.Geofence;
import com.presenza.backend.geofence.repository.GeofenceRepository;
import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.organisation.repository.OrganizationRepository;
import com.presenza.backend.shift.dto.request.ShiftRequest;
import com.presenza.backend.shift.dto.response.ShiftResponse;
import com.presenza.backend.shift.entity.Shift;
import com.presenza.backend.shift.repository.ShiftRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ShiftService {

    private final ShiftRepository shiftRepository;
    private final OrganizationRepository organizationRepository;
    private final GeofenceRepository geofenceRepository;

    public ShiftService(
            ShiftRepository shiftRepository,
            OrganizationRepository organizationRepository,
            GeofenceRepository geofenceRepository
    ) {
        this.shiftRepository = shiftRepository;
        this.organizationRepository = organizationRepository;
        this.geofenceRepository = geofenceRepository;
    }

    @Transactional
    public ShiftResponse createShift(
            Integer organizationId,
            String role,
            ShiftRequest request
    ) {
        validateManagementRole(role);

        Organization organization =
                findOrganization(organizationId);

        Geofence geofence = resolveGeofence(
                request.getGeofenceId(),
                organizationId
        );

        Shift shift = new Shift(
                organization,
                request.getShiftName(),
                request.getStartTime(),
                request.getEndTime(),
                request.getAllowedLateMinutes(),
                geofence
        );

        return toResponse(
                shiftRepository.save(shift)
        );
    }

    @Transactional(readOnly = true)
    public ShiftResponse getShiftById(
            Integer id,
            Integer organizationId
    ) {
        return toResponse(
                findShiftInOrganization(
                        id,
                        organizationId
                )
        );
    }

    @Transactional(readOnly = true)
    public List<ShiftResponse> getShiftsByOrganization(
            Integer organizationId
    ) {
        findOrganization(organizationId);

        return shiftRepository
                .findByOrganizationOrgId(organizationId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional
    public ShiftResponse updateShift(
            Integer id,
            Integer organizationId,
            String role,
            ShiftRequest request
    ) {
        validateManagementRole(role);

        Shift shift = findShiftInOrganization(
                id,
                organizationId
        );

        Geofence geofence = resolveGeofence(
                request.getGeofenceId(),
                organizationId
        );

        shift.setShiftName(request.getShiftName());
        shift.setStartTime(request.getStartTime());
        shift.setEndTime(request.getEndTime());
        shift.setAllowedLateMinutes(
                request.getAllowedLateMinutes()
        );
        shift.setGeofence(geofence);

        return toResponse(
                shiftRepository.save(shift)
        );
    }

    private Organization findOrganization(
            Integer organizationId
    ) {
        return organizationRepository
                .findById(organizationId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Organization not found with id: "
                                        + organizationId
                        )
                );
    }

    private Shift findShiftInOrganization(
            Integer shiftId,
            Integer organizationId
    ) {
        Shift shift = shiftRepository
                .findById(shiftId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Shift not found with id: "
                                        + shiftId
                        )
                );

        if (!shift.getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Shift not found with id: "
                            + shiftId
            );
        }

        return shift;
    }

    private Geofence resolveGeofence(
            Integer geofenceId,
            Integer organizationId
    ) {
        if (geofenceId == null) {
            return null;
        }

        Geofence geofence = geofenceRepository
                .findById(geofenceId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Geofence not found with id: "
                                        + geofenceId
                        )
                );

        if (!geofence.getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Geofence not found with id: "
                            + geofenceId
            );
        }

        return geofence;
    }

    private void validateManagementRole(
            String role
    ) {
        if (!"ORG_ADMIN".equals(role) &&
                !"MANAGER".equals(role)) {
            throw new ForbiddenException(
                    "User is not allowed to manage shifts"
            );
        }
    }

    private ShiftResponse toResponse(
            Shift shift
    ) {
        return new ShiftResponse(
                shift.getShiftId(),
                shift.getOrganization().getOrgId(),
                shift.getShiftName(),
                shift.getStartTime(),
                shift.getEndTime(),
                shift.getAllowedLateMinutes(),
                shift.getGeofence() != null
                        ? shift.getGeofence()
                        .getGeofenceId()
                        : null
        );
    }
}