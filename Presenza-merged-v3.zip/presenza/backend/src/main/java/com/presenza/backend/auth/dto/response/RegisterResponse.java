package com.presenza.backend.auth.dto.response;

public class RegisterResponse {

    private final Integer organizationId;
    private final String organizationName;
    private final Integer userId;
    private final String username;
    private final String email;
    private final String role;

    public RegisterResponse(
            Integer organizationId,
            String organizationName,
            Integer userId,
            String username,
            String email,
            String role
    ) {
        this.organizationId = organizationId;
        this.organizationName = organizationName;
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.role = role;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public Integer getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }
}