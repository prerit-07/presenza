package com.presenza.backend.attendance.entity;

public enum AttendanceStatus {
    PRESENT,
    LATE,
    ABSENT,
    PENDING,
    REJECTED
}