package com.presenza.backend.security.repository;

import com.presenza.backend.security.entity.RolePermission;
import com.presenza.backend.security.entity.RolePermissionId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RolePermissionRepository
        extends JpaRepository<RolePermission, RolePermissionId> {
}