package com.presenza.backend.attendance.dto.request;

import com.presenza.backend.attendance.entity.AttendanceRequestType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public class CreateAttendanceRequest {

    @NotNull
    private AttendanceRequestType requestType;

    @NotNull
    private LocalDate startDate;

    @NotNull
    private LocalDate endDate;

    @NotBlank
    @Size(max = 2000)
    private String reason;

    public CreateAttendanceRequest() {
    }

    public AttendanceRequestType getRequestType() {
        return requestType;
    }

    public void setRequestType(
            AttendanceRequestType requestType
    ) {
        this.requestType = requestType;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}