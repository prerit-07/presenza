package com.presenza.backend.common.util;

public final class GeofenceDistanceCalculator {

    private GeofenceDistanceCalculator() {
    }

    public static double calculateDistanceMeters(
            double userLatitude,
            double userLongitude,
            double geofenceLatitude,
            double geofenceLongitude
    ) {
        final double earthRadiusMeters = 6_371_000.0;

        double latitudeDistance = Math.toRadians(
                geofenceLatitude - userLatitude
        );
        double longitudeDistance = Math.toRadians(
                geofenceLongitude - userLongitude
        );
        double a = Math.sin(latitudeDistance / 2)
                * Math.sin(latitudeDistance / 2)
                + Math.cos(Math.toRadians(userLatitude))
                * Math.cos(Math.toRadians(geofenceLatitude))
                * Math.sin(longitudeDistance / 2)
                * Math.sin(longitudeDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return earthRadiusMeters * c;
    }
}
