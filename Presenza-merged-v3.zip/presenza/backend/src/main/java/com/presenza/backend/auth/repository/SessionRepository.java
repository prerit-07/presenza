package com.presenza.backend.auth.repository;

import com.presenza.backend.auth.entity.Session;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SessionRepository
        extends JpaRepository<Session, Integer> {

    Optional<Session> findByTokenHash(String tokenHash);
}