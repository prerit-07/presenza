package com.presenza.backend.workforce.service;

import com.presenza.backend.common.exception.ForbiddenException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.organisation.repository.OrganizationRepository;
import com.presenza.backend.workforce.dto.request.DepartmentRequest;
import com.presenza.backend.workforce.dto.response.DepartmentResponse;
import com.presenza.backend.workforce.entity.Department;
import com.presenza.backend.workforce.repository.DepartmentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final OrganizationRepository organizationRepository;

    public DepartmentService(
            DepartmentRepository departmentRepository,
            OrganizationRepository organizationRepository
    ) {
        this.departmentRepository = departmentRepository;
        this.organizationRepository = organizationRepository;
    }

    @Transactional
    public DepartmentResponse createDepartment(
            Integer organizationId,
            String role,
            DepartmentRequest request
    ) {
        validateManagementRole(role);

        Organization organization =
                findOrganization(organizationId);

        Department department = new Department(
                organization,
                request.getDepartmentName()
        );

        return toResponse(
                departmentRepository.save(department)
        );
    }

    @Transactional(readOnly = true)
    public DepartmentResponse getDepartmentById(
            Integer id,
            Integer organizationId
    ) {
        return toResponse(
                findDepartmentInOrganization(
                        id,
                        organizationId
                )
        );
    }

    @Transactional(readOnly = true)
    public List<DepartmentResponse> getDepartmentsByOrganization(
            Integer organizationId
    ) {
        findOrganization(organizationId);

        return departmentRepository
                .findByOrganizationOrgId(organizationId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional
    public DepartmentResponse updateDepartment(
            Integer departmentId,
            Integer organizationId,
            String role,
            DepartmentRequest request
    ) {
        validateManagementRole(role);

        Department department =
                findDepartmentInOrganization(
                        departmentId,
                        organizationId
                );

        department.setDepartmentName(
                request.getDepartmentName()
        );

        return toResponse(
                departmentRepository.save(department)
        );
    }

    private Organization findOrganization(
            Integer organizationId
    ) {
        return organizationRepository
                .findById(organizationId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Organization not found with id: "
                                        + organizationId
                        )
                );
    }

    private Department findDepartmentInOrganization(
            Integer departmentId,
            Integer organizationId
    ) {
        Department department = departmentRepository
                .findById(departmentId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Department not found with id: "
                                        + departmentId
                        )
                );

        if (!department.getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Department not found with id: "
                            + departmentId
            );
        }

        return department;
    }

    private void validateManagementRole(
            String role
    ) {
        if (!"ORG_ADMIN".equals(role) &&
                !"MANAGER".equals(role)) {
            throw new ForbiddenException(
                    "User is not allowed to manage departments"
            );
        }
    }

    private DepartmentResponse toResponse(
            Department department
    ) {
        return new DepartmentResponse(
                department.getDepartmentId(),
                department.getOrganization().getOrgId(),
                department.getDepartmentName()
        );
    }
}