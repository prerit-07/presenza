package com.presenza.backend.ticket.repository;

import com.presenza.backend.ticket.entity.TicketComment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TicketCommentRepository
        extends JpaRepository<TicketComment, Integer> {

    List<TicketComment> findByTicketTicketIdOrderByCommentIdAsc(
            Integer ticketId
    );
}