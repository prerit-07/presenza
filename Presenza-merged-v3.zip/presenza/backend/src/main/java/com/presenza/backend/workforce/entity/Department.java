package com.presenza.backend.workforce.entity;

import com.presenza.backend.organisation.entity.Organization;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "department")
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "department_id")
    private Integer departmentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "org_id", nullable = false)
    private Organization organization;

    @Column(name = "department_name", nullable = false)
    private String departmentName;

    protected Department() {
    }

    public Department(
            Organization organization,
            String departmentName
    ) {
        this.organization = organization;
        this.departmentName = departmentName;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public Organization getOrganization() {
        return organization;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }
}
