package com.presenza.backend.geofence.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class WifiNetworkRequest {

   private Integer geofenceId;

    @NotBlank
    private String ssid;

    @NotBlank
    private String bssid;

    public WifiNetworkRequest() {
    }

    public Integer getGeofenceId() {
        return geofenceId;
    }

    public void setGeofenceId(Integer geofenceId) {
        this.geofenceId = geofenceId;
    }

    public String getSsid() {
        return ssid;
    }

    public void setSsid(String ssid) {
        this.ssid = ssid;
    }

    public String getBssid() {
        return bssid;
    }

    public void setBssid(String bssid) {
        this.bssid = bssid;
    }
}