package com.presenza.backend.device.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class CreateDeviceChangeRequest {

    @NotBlank
    @Size(max = 100)
    private String oldDeviceId;

    @NotBlank
    @Size(max = 100)
    private String newDeviceId;

    @NotBlank
    @Size(max = 2000)
    private String reason;

    public CreateDeviceChangeRequest() {
    }

    public String getOldDeviceId() {
        return oldDeviceId;
    }

    public void setOldDeviceId(String oldDeviceId) {
        this.oldDeviceId = oldDeviceId;
    }

    public String getNewDeviceId() {
        return newDeviceId;
    }

    public void setNewDeviceId(String newDeviceId) {
        this.newDeviceId = newDeviceId;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}