
package com.presenza.backend.organisation.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import com.presenza.backend.subscription.entity.Plan;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import java.time.OffsetDateTime;

@Entity
@Table(name = "organization")
public class Organization {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "org_id")
    private Integer orgId;
    @Column(name = "org_name", nullable = false, length = 150)
    private String orgName;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "plan_id")
    private Plan plan;
    @Enumerated(EnumType.STRING)
    @Column(name = "org_type", nullable = false, length = 50)
    private OrganizationType orgType;
    @Column(name = "max_allowed_employee")
    private Integer maxAllowedEmployee;
    @Column(name = "company_code", nullable = false, unique = true, length = 20)
    private String companyCode;
    @Column(name = "presence_monitoring_enabled", nullable = false,
            insertable = false)
    private Boolean presenceMonitoringEnabled;
    @Column(name = "presence_update_interval_seconds", nullable = false,
            insertable = false)
    private Integer presenceUpdateIntervalSeconds;
    @Column(name = "require_trusted_wifi", nullable = false,
            insertable = false)
    private Boolean requireTrustedWifi;
    @Column(name = "created_at", nullable = false, insertable = false, updatable = false)
    private OffsetDateTime createdAt;

    protected Organization() {
    }
    public Organization(
            String orgName,
            OrganizationType orgType,
            Plan plan,
            Integer maxAllowedEmployee
    ) {
        this.orgName = orgName;
        this.orgType = orgType;
        this.plan = plan;
        this.maxAllowedEmployee = maxAllowedEmployee;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public Plan getPlan() {
        return plan;
    }

    public OrganizationType getOrgType() {
        return orgType;
    }

    public Integer getMaxAllowedEmployee() {
        return maxAllowedEmployee;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public Boolean getPresenceMonitoringEnabled() {
        return presenceMonitoringEnabled;
    }

    public Integer getPresenceUpdateIntervalSeconds() {
        return presenceUpdateIntervalSeconds;
    }

    public Boolean getRequireTrustedWifi() {
        return requireTrustedWifi;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public void setPlan(Plan plan) {
        this.plan = plan;
    }

    public void setOrgType(OrganizationType orgType) {
        this.orgType = orgType;
    }

    public void setMaxAllowedEmployee(Integer maxAllowedEmployee) {
        this.maxAllowedEmployee = maxAllowedEmployee;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public void setPresenceMonitoringEnabled(Boolean presenceMonitoringEnabled) {
        this.presenceMonitoringEnabled = presenceMonitoringEnabled;
    }

    public void setPresenceUpdateIntervalSeconds(
            Integer presenceUpdateIntervalSeconds
    ) {
        this.presenceUpdateIntervalSeconds = presenceUpdateIntervalSeconds;
    }

    public void setRequireTrustedWifi(Boolean requireTrustedWifi) {
        this.requireTrustedWifi = requireTrustedWifi;
    }

}


