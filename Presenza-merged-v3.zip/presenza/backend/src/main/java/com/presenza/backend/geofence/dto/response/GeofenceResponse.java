package com.presenza.backend.geofence.dto.response;

import java.math.BigDecimal;

public class GeofenceResponse {

    private Integer geofenceId;
    private Integer orgId;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private Integer radius;
    private String buildingName;

    public GeofenceResponse() {
    }

    public GeofenceResponse(
            Integer geofenceId,
            Integer orgId,
            BigDecimal latitude,
            BigDecimal longitude,
            Integer radius,
            String buildingName
    ) {
        this.geofenceId = geofenceId;
        this.orgId = orgId;
        this.latitude = latitude;
        this.longitude = longitude;
        this.radius = radius;
        this.buildingName = buildingName;
    }

    public Integer getGeofenceId() {
        return geofenceId;
    }

    public void setGeofenceId(Integer geofenceId) {
        this.geofenceId = geofenceId;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public Integer getRadius() {
        return radius;
    }

    public void setRadius(Integer radius) {
        this.radius = radius;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }
}