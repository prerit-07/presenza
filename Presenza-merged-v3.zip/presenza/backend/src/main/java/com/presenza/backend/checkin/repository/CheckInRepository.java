package com.presenza.backend.checkin.repository;

import com.presenza.backend.checkin.entity.CheckIn;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;

import java.time.OffsetDateTime;
import java.util.Optional;

public interface CheckInRepository
        extends JpaRepository<CheckIn, Integer> {

    boolean existsByUserUserIdAndShiftShiftIdAndCheckinTimeBetween(
            Integer userId,
            Integer shiftId,
            OffsetDateTime startOfDay,
            OffsetDateTime endOfDay
    );

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @EntityGraph(attributePaths = {
            "shift",
            "shift.organization",
            "shift.geofence"
    })
    Optional<CheckIn>
    findFirstByUserUserIdAndCheckinTimeBetweenOrderByCheckinTimeDesc(
            Integer userId,
            OffsetDateTime startOfDay,
            OffsetDateTime endOfDay
    );
}
