package com.presenza.backend.device.entity;

import com.presenza.backend.employee.entity.Employee;
import com.presenza.backend.user.entity.User;
import jakarta.persistence.*;

import java.time.OffsetDateTime;

@Entity
@Table(name = "device_change_request")
public class DeviceChangeRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "request_id")
    private Integer requestId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "old_device_id")
    private Device oldDevice;

    @Column(name = "new_device_id", length = 100)
    private String newDeviceId;

    @Column(name = "reason", columnDefinition = "text")
    private String reason;

    @Column(
            name = "requested_at",
            nullable = false,
            insertable = false,
            updatable = false
    )
    private OffsetDateTime requestedAt;

    @Enumerated(EnumType.STRING)
    @Column(
            name = "status",
            nullable = false,
            length = 30,
            insertable = false
    )
    private DeviceChangeRequestStatus status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "reviewed_by")
    private Employee reviewedBy;

    @Column(name = "reviewed_at")
    private OffsetDateTime reviewedAt;

    protected DeviceChangeRequest() {
    }

    public DeviceChangeRequest(
            User user,
            Device oldDevice,
            String newDeviceId,
            String reason
    ) {
        this.user = user;
        this.oldDevice = oldDevice;
        this.newDeviceId = newDeviceId;
        this.reason = reason;
    }

    public Integer getRequestId() {
        return requestId;
    }

    public User getUser() {
        return user;
    }

    public Device getOldDevice() {
        return oldDevice;
    }

    public String getNewDeviceId() {
        return newDeviceId;
    }

    public String getReason() {
        return reason;
    }

    public OffsetDateTime getRequestedAt() {
        return requestedAt;
    }

    public DeviceChangeRequestStatus getStatus() {
        return status;
    }

    public Employee getReviewedBy() {
        return reviewedBy;
    }

    public OffsetDateTime getReviewedAt() {
        return reviewedAt;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setOldDevice(Device oldDevice) {
        this.oldDevice = oldDevice;
    }

    public void setNewDeviceId(String newDeviceId) {
        this.newDeviceId = newDeviceId;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public void setStatus(DeviceChangeRequestStatus status) {
        this.status = status;
    }

    public void setReviewedBy(Employee reviewedBy) {
        this.reviewedBy = reviewedBy;
    }

    public void setReviewedAt(OffsetDateTime reviewedAt) {
        this.reviewedAt = reviewedAt;
    }
}