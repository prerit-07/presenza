package com.presenza.backend.workforce.dto.response;

public class TeamResponse {

    private Integer teamId;
    private Integer orgId;
    private String teamName;
    private Integer managerEmployeeId;

    public TeamResponse() {
    }

    public TeamResponse(
            Integer teamId,
            Integer orgId,
            String teamName,
            Integer managerEmployeeId
    ) {
        this.teamId = teamId;
        this.orgId = orgId;
        this.teamName = teamName;
        this.managerEmployeeId = managerEmployeeId;
    }

    public Integer getTeamId() {
        return teamId;
    }

    public void setTeamId(Integer teamId) {
        this.teamId = teamId;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public Integer getManagerEmployeeId() {
        return managerEmployeeId;
    }

    public void setManagerEmployeeId(Integer managerEmployeeId) {
        this.managerEmployeeId = managerEmployeeId;
    }
}