package com.presenza.backend.shift.entity;
import com.presenza.backend.geofence.entity.Geofence;
import com.presenza.backend.organisation.entity.Organization;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.LocalTime;

@Entity
@Table(name = "shift")
public class Shift {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "shift_id")
    private Integer shiftId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "org_id", nullable = false)
    private Organization organization;

    @Column(name = "shift_name", nullable = false, length = 100)
    private String shiftName;

    @Column(name = "start_time", nullable = false)
    private LocalTime startTime;

    @Column(name = "end_time", nullable = false)
    private LocalTime endTime;

    @Column(name = "allowed_late_minutes")
    private Integer allowedLateMinutes;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "geofence_id")
    private Geofence geofence;

    protected Shift() {
    }

    public Shift(
            Organization organization,
            String shiftName,
            LocalTime startTime,
            LocalTime endTime,
            Integer allowedLateMinutes,
            Geofence geofence
    ) {
        this.organization = organization;
        this.shiftName = shiftName;
        this.startTime = startTime;
        this.endTime = endTime;
        this.allowedLateMinutes = allowedLateMinutes;
        this.geofence = geofence;
    }

    public Integer getShiftId() {
        return shiftId;
    }

    public Organization getOrganization() {
        return organization;
    }

    public String getShiftName() {
        return shiftName;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public Integer getAllowedLateMinutes() {
        return allowedLateMinutes;
    }

    public Geofence getGeofence() {
        return geofence;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public void setShiftName(String shiftName) {
        this.shiftName = shiftName;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public void setAllowedLateMinutes(Integer allowedLateMinutes) {
        this.allowedLateMinutes = allowedLateMinutes;
    }

    public void setGeofence(Geofence geofence) {
        this.geofence = geofence;
    }
}
