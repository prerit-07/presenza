package com.presenza.backend.organisation.repository;

import com.presenza.backend.organisation.entity.Organization;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface OrganizationRepository
        extends JpaRepository<Organization, Integer> {

    Optional<Organization> findByCompanyCodeIgnoreCase(String companyCode);

    boolean existsByCompanyCode(String companyCode);

}
