package com.presenza.backend.attendance.entity;

public enum AttendanceRequestType {
    LEAVE,
    WFH
}