package com.presenza.backend.notification.event;

public record NotificationCreatedEvent(
        Integer notificationId,
        Integer recipientUserId,
        String title,
        String message,
        String referenceType,
        Integer referenceId
) {
}
