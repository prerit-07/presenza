
package com.presenza.backend.organisation.entity;

public enum OrganizationType {
    CORPORATE,
    EDUCATIONAL
}
