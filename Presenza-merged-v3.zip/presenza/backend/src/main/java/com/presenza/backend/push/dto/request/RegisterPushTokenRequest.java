package com.presenza.backend.push.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class RegisterPushTokenRequest {
    @NotBlank @Size(max = 100) private String deviceId;
    @NotBlank @Size(max = 255) private String expoPushToken;
    @Size(max = 20) private String platform;
    public String getDeviceId() { return deviceId; }
    public String getExpoPushToken() { return expoPushToken; }
    public String getPlatform() { return platform; }
}
