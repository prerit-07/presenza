package com.presenza.backend.ticket.repository;

import com.presenza.backend.ticket.entity.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TicketRepository
        extends JpaRepository<Ticket, Integer> {

    List<Ticket> findByRaisedByUserUserIdOrderByTicketIdDesc(
            Integer userId
    );

    List<Ticket> findByOrganizationOrgIdOrderByTicketIdDesc(
            Integer organizationId
    );
}