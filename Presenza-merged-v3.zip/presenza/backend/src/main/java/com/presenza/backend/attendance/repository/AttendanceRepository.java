package com.presenza.backend.attendance.repository;

import com.presenza.backend.attendance.entity.Attendance;
import com.presenza.backend.attendance.entity.AttendanceStatus;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.OffsetDateTime;
import java.util.List;

public interface AttendanceRepository
        extends JpaRepository<Attendance, Integer> {

    List<Attendance>
    findByStatusAndCheckInShiftOrganizationOrgIdOrderByAttendanceIdDesc(
            AttendanceStatus status,
            Integer organizationId
    );

    List<Attendance>
    findByCheckInUserUserIdOrderByAttendanceIdDesc(
            Integer userId
    );

    List<Attendance>
    findByCheckInShiftOrganizationOrgIdOrderByAttendanceIdDesc(
            Integer organizationId
    );

    @EntityGraph(attributePaths = {"checkIn", "checkIn.user"})
    List<Attendance>
    findByCheckInUserUserIdInAndCheckInCheckinTimeBetweenOrderByCheckInCheckinTimeDesc(
            List<Integer> userIds,
            OffsetDateTime start,
            OffsetDateTime end
    );
}
