package com.presenza.backend.checkin.dto.request;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public class EmployeeCheckInRequest {

    @NotNull(message = "Shift ID is required")
    private Integer shiftId;

    @NotBlank(message = "Device ID is required")
    @Size(max = 100, message = "Device ID must not exceed 100 characters")
    private String deviceId;

    @Size(max = 150, message = "SSID must not exceed 150 characters")
    private String connectedSsid;

    @Size(max = 50, message = "BSSID must not exceed 50 characters")
    private String connectedBssid;

    @DecimalMin(
            value = "-90.0",
            message = "Latitude must be at least -90"
    )
    @DecimalMax(
            value = "90.0",
            message = "Latitude must not exceed 90"
    )
    private BigDecimal latitude;

    @DecimalMin(
            value = "-180.0",
            message = "Longitude must be at least -180"
    )
    @DecimalMax(
            value = "180.0",
            message = "Longitude must not exceed 180"
    )
    private BigDecimal longitude;

    @Size(
            max = 255,
            message = "Device info must not exceed 255 characters"
    )
    private String deviceInfo;

    @DecimalMin(
            value = "0.0",
            message = "Accuracy must not be negative"
    )
    private BigDecimal accuracy;

    public EmployeeCheckInRequest() {
    }

    public Integer getShiftId() {
        return shiftId;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public String getConnectedSsid() {
        return connectedSsid;
    }

    public String getConnectedBssid() {
        return connectedBssid;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public String getDeviceInfo() {
        return deviceInfo;
    }

    public BigDecimal getAccuracy() {
        return accuracy;
    }
}