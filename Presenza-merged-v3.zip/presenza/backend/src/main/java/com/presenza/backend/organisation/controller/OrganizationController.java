package com.presenza.backend.organisation.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.organisation.dto.request.OrganizationUpdateRequest;
import com.presenza.backend.organisation.dto.request.PresenceSettingsUpdateRequest;
import com.presenza.backend.organisation.dto.response.OrganizationResponse;
import com.presenza.backend.organisation.dto.response.PresenceSettingsResponse;
import com.presenza.backend.organisation.service.OrganizationService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/organizations")
public class OrganizationController {

    private final OrganizationService organizationService;
    private final TokenService tokenService;

    public OrganizationController(
            OrganizationService organizationService,
            TokenService tokenService
    ) {
        this.organizationService = organizationService;
        this.tokenService = tokenService;
    }

    @GetMapping("/me")
    public OrganizationResponse getMyOrganization(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return organizationService.getOrganization(
                authenticatedUser.getOrganizationId()
        );
    }

    @PutMapping("/me")
    public OrganizationResponse updateMyOrganization(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody OrganizationUpdateRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return organizationService.updateOrganization(
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        );
    }

    @GetMapping("/me/presence-settings")
    public PresenceSettingsResponse getPresenceSettings(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return organizationService.getPresenceSettings(
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole()
        );
    }

    @PutMapping("/me/presence-settings")
    public PresenceSettingsResponse updatePresenceSettings(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody PresenceSettingsUpdateRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return organizationService.updatePresenceSettings(
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        );
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {
        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        return tokenService.getAuthenticatedUser(
                authorizationHeader.substring(7)
        );
    }
}
