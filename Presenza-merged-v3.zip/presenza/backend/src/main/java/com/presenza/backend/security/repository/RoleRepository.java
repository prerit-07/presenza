package com.presenza.backend.security.repository;

import com.presenza.backend.security.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RoleRepository
        extends JpaRepository<Role, Integer> {

    Optional<Role>
    findByOrganizationOrgIdAndRoleName(
            Integer organizationId,
            String roleName
    );
}