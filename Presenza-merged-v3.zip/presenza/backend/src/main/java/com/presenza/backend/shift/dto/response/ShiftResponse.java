package com.presenza.backend.shift.dto.response;

import java.time.LocalTime;

public class ShiftResponse {

    private Integer shiftId;
    private Integer orgId;
    private String shiftName;
    private LocalTime startTime;
    private LocalTime endTime;
    private Integer allowedLateMinutes;
    private Integer geofenceId;

    public ShiftResponse() {
    }

    public ShiftResponse(
            Integer shiftId,
            Integer orgId,
            String shiftName,
            LocalTime startTime,
            LocalTime endTime,
            Integer allowedLateMinutes,
            Integer geofenceId
    ) {
        this.shiftId = shiftId;
        this.orgId = orgId;
        this.shiftName = shiftName;
        this.startTime = startTime;
        this.endTime = endTime;
        this.allowedLateMinutes = allowedLateMinutes;
        this.geofenceId = geofenceId;
    }

    public Integer getShiftId() {
        return shiftId;
    }

    public void setShiftId(Integer shiftId) {
        this.shiftId = shiftId;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public String getShiftName() {
        return shiftName;
    }

    public void setShiftName(String shiftName) {
        this.shiftName = shiftName;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public Integer getAllowedLateMinutes() {
        return allowedLateMinutes;
    }

    public void setAllowedLateMinutes(Integer allowedLateMinutes) {
        this.allowedLateMinutes = allowedLateMinutes;
    }

    public Integer getGeofenceId() {
        return geofenceId;
    }

    public void setGeofenceId(Integer geofenceId) {
        this.geofenceId = geofenceId;
    }
}