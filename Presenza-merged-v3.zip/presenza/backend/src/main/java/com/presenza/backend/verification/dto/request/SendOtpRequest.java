package com.presenza.backend.verification.dto.request;

import com.presenza.backend.verification.VerificationPurpose;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class SendOtpRequest {

    @NotBlank
    @Email
    private String email;

    @NotNull
    private VerificationPurpose purpose;

    public SendOtpRequest() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(
            String email
    ) {
        this.email = email;
    }

    public VerificationPurpose getPurpose() {
        return purpose;
    }

    public void setPurpose(
            VerificationPurpose purpose
    ) {
        this.purpose = purpose;
    }
}