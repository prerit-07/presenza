package com.presenza.backend.presence.enums;

/**
 * Internal state used to derive presence transitions.
 */
public enum PresenceState {
    INSIDE,
    OUTSIDE
}
