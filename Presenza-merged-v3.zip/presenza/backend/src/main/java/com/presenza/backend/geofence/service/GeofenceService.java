package com.presenza.backend.geofence.service;

import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.common.exception.ForbiddenException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.geofence.dto.request.GeofenceRequest;
import com.presenza.backend.geofence.dto.request.WifiNetworkRequest;
import com.presenza.backend.geofence.dto.response.GeofenceResponse;
import com.presenza.backend.geofence.entity.Geofence;
import com.presenza.backend.geofence.entity.WifiNetwork;
import com.presenza.backend.geofence.repository.GeofenceRepository;
import com.presenza.backend.geofence.repository.WifiNetworkRepository;
import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.organisation.repository.OrganizationRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GeofenceService {

    private final GeofenceRepository geofenceRepository;
    private final OrganizationRepository organizationRepository;
    private final WifiNetworkRepository wifiNetworkRepository;

    public GeofenceService(
            GeofenceRepository geofenceRepository,
            OrganizationRepository organizationRepository,
            WifiNetworkRepository wifiNetworkRepository
    ) {
        this.geofenceRepository = geofenceRepository;
        this.organizationRepository = organizationRepository;
        this.wifiNetworkRepository = wifiNetworkRepository;
    }

    public GeofenceResponse createGeofence(
            AuthenticatedUser authenticatedUser,
            GeofenceRequest request
    ) {
        Integer authenticatedOrgId =
                authenticatedUser.getOrganizationId();

        validateManagementRole(authenticatedUser);

        validateOrganizationAccess(
                authenticatedUser,
                request.getOrgId()
        );

        Organization organization =
                organizationRepository.findById(authenticatedOrgId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Organization not found"
                                ));

        Geofence geofence = new Geofence(
                organization,
                request.getLatitude(),
                request.getLongitude(),
                request.getRadius(),
                request.getBuildingName()
        );

        Geofence savedGeofence = geofenceRepository.save(geofence);

        if (request.getRouters() != null && !request.getRouters().isEmpty()) {
            for (WifiNetworkRequest routerReq : request.getRouters()) {
                WifiNetwork wifi = new WifiNetwork(
                        savedGeofence,
                        routerReq.getSsid(),
                        routerReq.getBssid()
                );
                wifiNetworkRepository.save(wifi);
            }
        }

        return toResponse(savedGeofence);
    }

    public GeofenceResponse getGeofenceById(
            AuthenticatedUser authenticatedUser,
            Integer id
    ) {
        Geofence geofence = geofenceRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Geofence not found"
                        ));

        validateResourceOrganization(
                authenticatedUser,
                geofence
        );

        return toResponse(geofence);
    }

    public List<GeofenceResponse> getGeofencesByOrganization(
            AuthenticatedUser authenticatedUser,
            Integer orgId
    ) {
        validateOrganizationAccess(
                authenticatedUser,
                orgId
        );

        organizationRepository.findById(orgId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Organization not found"
                        ));

        return geofenceRepository
                .findByOrganizationOrgId(orgId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    public GeofenceResponse updateGeofence(
            AuthenticatedUser authenticatedUser,
            Integer id,
            GeofenceRequest request
    ) {
        validateManagementRole(authenticatedUser);

        Geofence geofence = geofenceRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Geofence not found"
                        ));

        validateResourceOrganization(
                authenticatedUser,
                geofence
        );

        validateOrganizationAccess(
                authenticatedUser,
                request.getOrgId()
        );

        // Do not allow moving a geofence across organizations.
        if (!geofence.getOrganization()
                .getOrgId()
                .equals(request.getOrgId())) {
            throw new ForbiddenException(
                    "Cannot move geofence to another organization"
            );
        }

        geofence.setLatitude(request.getLatitude());
        geofence.setLongitude(request.getLongitude());
        geofence.setRadius(request.getRadius());
        geofence.setBuildingName(request.getBuildingName());

        return toResponse(
                geofenceRepository.save(geofence)
        );
    }

    private void validateOrganizationAccess(
            AuthenticatedUser authenticatedUser,
            Integer requestedOrgId
    ) {
        if (authenticatedUser.getOrganizationId() == null
                || !authenticatedUser.getOrganizationId()
                .equals(requestedOrgId)) {
            throw new ForbiddenException(
                    "You cannot access another organization"
            );
        }
    }

    private void validateResourceOrganization(
            AuthenticatedUser authenticatedUser,
            Geofence geofence
    ) {
        if (authenticatedUser.getOrganizationId() == null
                || !authenticatedUser.getOrganizationId()
                .equals(
                        geofence.getOrganization().getOrgId()
                )) {
            throw new ForbiddenException(
                    "You cannot access this geofence"
            );
        }
    }

    private GeofenceResponse toResponse(
            Geofence geofence
    ) {
        return new GeofenceResponse(
                geofence.getGeofenceId(),
                geofence.getOrganization().getOrgId(),
                geofence.getLatitude(),
                geofence.getLongitude(),
                geofence.getRadius(),
                geofence.getBuildingName()
        );
    }
    public void deleteGeofence(AuthenticatedUser authenticatedUser, Integer id) {
        validateManagementRole(authenticatedUser);

        Geofence geofence = geofenceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Geofence not found"));

        validateResourceOrganization(authenticatedUser, geofence);

        geofenceRepository.delete(geofence);
    }

    private void validateManagementRole(
            AuthenticatedUser authenticatedUser
    ) {
        String role = authenticatedUser.getRole();
        if (!"ORG_ADMIN".equals(role) && !"MANAGER".equals(role)) {
            throw new ForbiddenException(
                    "User is not allowed to manage geofences"
            );
        }
    }
}