package com.presenza.backend.auth.model;

public class AuthenticatedUser {

    private final Integer userId;
    private final Integer organizationId;
    private final String role;

    public AuthenticatedUser(
            Integer userId,
            Integer organizationId,
            String role
    ) {
        this.userId = userId;
        this.organizationId = organizationId;
        this.role = role;
    }

    public Integer getUserId() {
        return userId;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public String getRole() {
        return role;
    }
}