package com.presenza.backend.auth.service;

import com.presenza.backend.auth.dto.request.*;
import com.presenza.backend.auth.dto.response.LoginResponse;
import com.presenza.backend.auth.dto.response.RegisterResponse;
import com.presenza.backend.auth.entity.Session;
import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.repository.SessionRepository;
import com.presenza.backend.common.dto.response.MessageResponse;
import com.presenza.backend.common.exception.BadRequestException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.organisation.entity.OrganizationType;
import com.presenza.backend.organisation.repository.OrganizationRepository;
import com.presenza.backend.security.entity.Role;
import com.presenza.backend.security.repository.RoleRepository;
import com.presenza.backend.subscription.entity.Plan;
import com.presenza.backend.subscription.repository.PlanRepository;
import com.presenza.backend.user.entity.User;
import com.presenza.backend.user.repository.UserRepository;
import com.presenza.backend.verification.VerificationPurpose;
import com.presenza.backend.verification.dto.response.VerificationResponse;
import com.presenza.backend.verification.repository.EmailVerificationRepository;
import com.presenza.backend.verification.service.VerificationService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.presenza.backend.employee.entity.Employee;
import com.presenza.backend.employee.repository.EmployeeRepository;
import java.time.LocalDate;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.OffsetDateTime;
import java.util.Base64;

@Service
public class AuthService {

    private static final long SESSION_DURATION_DAYS = 7;

    private final UserRepository userRepository;
    private final SessionRepository sessionRepository;
    private final PasswordEncoder passwordEncoder;
    private final OrganizationRepository organizationRepository;
    private final PlanRepository planRepository;
    private final RoleRepository roleRepository;
    private final EmailVerificationRepository emailVerificationRepository;
    private final VerificationService verificationService;
    private final EmployeeRepository employeeRepository;
    private final SecureRandom secureRandom;

    public AuthService(
            UserRepository userRepository,
            SessionRepository sessionRepository,
            PasswordEncoder passwordEncoder,
            OrganizationRepository organizationRepository,
            PlanRepository planRepository,
            RoleRepository roleRepository,
            EmailVerificationRepository emailVerificationRepository,
            VerificationService verificationService,
            EmployeeRepository employeeRepository
    ) {
        this.userRepository = userRepository;
        this.sessionRepository = sessionRepository;
        this.passwordEncoder = passwordEncoder;
        this.organizationRepository = organizationRepository;
        this.planRepository = planRepository;
        this.roleRepository = roleRepository;
        this.emailVerificationRepository = emailVerificationRepository;
        this.verificationService = verificationService;
        this.employeeRepository = employeeRepository;
        this.secureRandom = new SecureRandom();
    }

    @Transactional
    public RegisterResponse register(
            RegisterRequest request
    ) {

        String email =
                normalizeEmail(
                        request.getEmail()
                );

        if (userRepository.findByEmail(email).isPresent()) {
            throw new BadRequestException(
                    "A user with this email already exists."
            );
        }

        if (!emailVerificationRepository.existsByEmailAndPurposeAndVerifiedTrue(
                email,
                VerificationPurpose.REGISTRATION
        )) {
            throw new BadRequestException(
                    "Email has not been verified."
            );
        }

        Plan plan = planRepository
                .findFirstByOrderByPriceAscPlanIdAsc()
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "No registration plan is configured."
                        )
                );

        Organization organization =
                new Organization(
                        request.getOrganizationName(),
                        OrganizationType.CORPORATE,
                        plan,
                        plan.getMaxEmployees()
                );

        organization.setCompanyCode(generateCompanyCode());

        organizationRepository.save(
                organization
        );

        Role adminRole =
                new Role(
                        organization,
                        "ORG_ADMIN"
                );

        roleRepository.save(
                adminRole
        );

        User user =
                new User(
                        organization,
                        request.getUsername(),
                        email,
                        passwordEncoder.encode(
                                request.getPassword()
                        ),
                        adminRole
                );

        userRepository.save(
                user
        );

        Employee adminEmployee = new Employee(
                organization,
                user,
                user.getUsername(),
                LocalDate.now(),
                null,
                null,
                null
        );

        employeeRepository.save(
                adminEmployee
        );

        emailVerificationRepository.deleteByEmailAndPurpose(
                email,
                VerificationPurpose.REGISTRATION
        );

        return new RegisterResponse(
                organization.getOrgId(),
                organization.getOrgName(),
                user.getUserId(),
                user.getUsername(),
                user.getEmail(),
                adminRole.getRoleName()
        );
    }

    private String generateCompanyCode() {
        final String characters = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

        String companyCode;

        do {
            StringBuilder value = new StringBuilder("ORG-");

            for (int index = 0; index < 8; index++) {
                value.append(characters.charAt(
                        secureRandom.nextInt(characters.length())
                ));
            }

            companyCode = value.toString();
        } while (organizationRepository.existsByCompanyCode(companyCode));

        return companyCode;
    }

    @Transactional
    public LoginResponse login(
            LoginRequest request
    ) {

        String email =
                normalizeEmail(
                        request.getEmail()
                );

        User user = userRepository
                .findByEmail(email)
                .orElseThrow(
                        InvalidCredentialsException::new
                );

        if (!Boolean.TRUE.equals(
                user.getActive()
        )) {
            throw new com.presenza.backend.common.exception.ForbiddenException(
                    "User account is inactive."
            );
        }

        if (!passwordEncoder.matches(
                request.getPassword(),
                user.getHashPassword()
        )) {
            throw new InvalidCredentialsException();
        }

        String rawToken =
                generateToken();

        String tokenHash =
                hashToken(rawToken);

        OffsetDateTime expiresAt =
                OffsetDateTime.now()
                        .plusDays(
                                SESSION_DURATION_DAYS
                        );

        Session session =
                new Session(
                        user,
                        tokenHash,
                        expiresAt,
                        request.getDeviceInfo()
                );

        sessionRepository.save(
                session
        );

        user.setLastLogin(
                OffsetDateTime.now()
        );

        userRepository.save(
                user
        );

        return new LoginResponse(
                rawToken,
                user.getUserId(),
                user.getUsername(),
                user.getEmail(),
                expiresAt,
                user.getMustChangePassword()
        );
    }

    @Transactional
    public void changePassword(
            Integer userId,
            ChangePasswordRequest request
    ) {

        User user =
                userRepository.findById(userId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "User not found."
                                )
                        );

        if (!passwordEncoder.matches(
                request.getCurrentPassword(),
                user.getHashPassword()
        )) {
            throw new BadRequestException(
                    "Current password is incorrect."
            );
        }

        if (request.getCurrentPassword().equals(
                request.getNewPassword()
        )) {
            throw new BadRequestException(
                    "New password must be different from the current password."
            );
        }

        user.setHashPassword(
                passwordEncoder.encode(
                        request.getNewPassword()
                )
        );

        user.setMustChangePassword(false);

        userRepository.save(
                user
        );
    }

    @Transactional
    public VerificationResponse forgotPassword(
            ForgotPasswordRequest request
    ) {

        String email =
                normalizeEmail(
                        request.getEmail()
                );

        userRepository.findByEmail(email)
                .orElseThrow(() ->
                        new BadRequestException(
                                "No account exists with this email."
                        )
                );

        return verificationService.sendOtp(
                email,
                VerificationPurpose.PASSWORD_RESET
        );
    }

    @Transactional
    public MessageResponse resetPassword(
            ResetPasswordRequest request
    ) {

        String email =
                normalizeEmail(
                        request.getEmail()
                );

        User user =
                userRepository.findByEmail(email)
                        .orElseThrow(() ->
                                new BadRequestException(
                                        "No account exists with this email."
                                )
                        );

        if (!emailVerificationRepository
                .existsByEmailAndPurposeAndVerifiedTrue(
                        email,
                        VerificationPurpose.PASSWORD_RESET
                )) {

            throw new BadRequestException(
                    "Password reset OTP has not been verified."
            );
        }

        if (passwordEncoder.matches(
                request.getNewPassword(),
                user.getHashPassword()
        )) {

            throw new BadRequestException(
                    "New password must be different from the current password."
            );
        }

        user.setHashPassword(
                passwordEncoder.encode(
                        request.getNewPassword()
                )
        );

        user.setMustChangePassword(false);

        userRepository.save(
                user
        );

        emailVerificationRepository.deleteByEmailAndPurpose(
                email,
                VerificationPurpose.PASSWORD_RESET
        );

        return new MessageResponse(
                true,
                "Password reset successfully."
        );
    }

    private String normalizeEmail(
            String email
    ) {

        return email
                .trim()
                .toLowerCase();
    }

    private String generateToken() {

        byte[] tokenBytes = new byte[32];

        secureRandom.nextBytes(
                tokenBytes
        );

        return Base64.getUrlEncoder()
                .withoutPadding()
                .encodeToString(
                        tokenBytes
                );
    }

    private String hashToken(
            String rawToken
    ) {

        try {

            MessageDigest digest =
                    MessageDigest.getInstance(
                            "SHA-256"
                    );

            byte[] hash = digest.digest(
                    rawToken.getBytes(
                            StandardCharsets.UTF_8
                    )
            );

            return Base64.getUrlEncoder()
                    .withoutPadding()
                    .encodeToString(
                            hash
                    );

        } catch (NoSuchAlgorithmException e) {

            throw new IllegalStateException(
                    "SHA-256 algorithm is not available.",
                    e
            );
        }
    }

    @Transactional
    public void updateCurrentUser(Integer userId, java.util.Map<String, String> updates) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (updates.containsKey("username") && updates.get("username") != null) {
            user.setUsername(updates.get("username").trim());
        }

        userRepository.save(user);
    }
}
