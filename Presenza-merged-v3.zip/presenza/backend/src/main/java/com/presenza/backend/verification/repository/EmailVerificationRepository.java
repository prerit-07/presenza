package com.presenza.backend.verification.repository;

import com.presenza.backend.verification.VerificationPurpose;
import com.presenza.backend.verification.entity.EmailVerification;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EmailVerificationRepository
        extends JpaRepository<EmailVerification, Integer> {

    /**
     * Returns the latest OTP for the given email and purpose.
     */
    Optional<EmailVerification> findTopByEmailAndPurposeOrderByCreatedAtDesc(
            String email,
            VerificationPurpose purpose
    );

    /**
     * Returns the latest unverified OTP for the given email and purpose.
     */
    Optional<EmailVerification> findTopByEmailAndPurposeAndVerifiedFalseOrderByCreatedAtDesc(
            String email,
            VerificationPurpose purpose
    );

    /**
     * Returns all OTP records for an email and purpose.
     */
    List<EmailVerification> findByEmailAndPurpose(
            String email,
            VerificationPurpose purpose
    );

    /**
     * Deletes all previous OTPs for an email and purpose.
     */
    void deleteByEmailAndPurpose(
            String email,
            VerificationPurpose purpose
    );

    /**
     * Checks whether the email has already been verified
     * for the given purpose.
     */
    boolean existsByEmailAndPurposeAndVerifiedTrue(
            String email,
            VerificationPurpose purpose
    );

}