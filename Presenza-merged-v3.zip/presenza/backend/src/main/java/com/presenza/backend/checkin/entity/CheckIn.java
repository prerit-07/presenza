package com.presenza.backend.checkin.entity;

import com.presenza.backend.device.entity.Device;
import com.presenza.backend.geofence.entity.WifiNetwork;
import com.presenza.backend.shift.entity.Shift;
import com.presenza.backend.user.entity.User;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "check_in")
public class CheckIn {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "checkin_id")
    private Integer checkinId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shift_id")
    private Shift shift;

    @Column(name = "slot_id")
    private Integer slotId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "device_id")
    private Device device;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "wifi_id")
    private WifiNetwork wifiNetwork;

    @Column(name = "connected_ssid", length = 150)
    private String connectedSsid;

    @Column(name = "connected_bssid", length = 50)
    private String connectedBssid;

    @Column(
            name = "wifi_verified",
            insertable = false
    )
    private Boolean wifiVerified;

    @Column(
            name = "checkin_time",
            nullable = false,
            insertable = false,
            updatable = false
    )
    private OffsetDateTime checkinTime;

    @Column(
            name = "latitude",
            precision = 9,
            scale = 6
    )
    private BigDecimal latitude;

    @Column(
            name = "longitude",
            precision = 9,
            scale = 6
    )
    private BigDecimal longitude;

    @Column(name = "device_info", length = 255)
    private String deviceInfo;

    @Column(
            name = "accuracy",
            precision = 6,
            scale = 2
    )
    private BigDecimal accuracy;

    protected CheckIn() {
    }

    public CheckIn(
            User user,
            Shift shift,
            Device device,
            WifiNetwork wifiNetwork,
            String connectedSsid,
            String connectedBssid,
            BigDecimal latitude,
            BigDecimal longitude,
            String deviceInfo,
            BigDecimal accuracy
    ) {
        this.user = user;
        this.shift = shift;
        this.device = device;
        this.wifiNetwork = wifiNetwork;
        this.connectedSsid = connectedSsid;
        this.connectedBssid = connectedBssid;
        this.latitude = latitude;
        this.longitude = longitude;
        this.deviceInfo = deviceInfo;
        this.accuracy = accuracy;
    }

    public Integer getCheckinId() {
        return checkinId;
    }

    public User getUser() {
        return user;
    }

    public Shift getShift() {
        return shift;
    }

    public Integer getSlotId() {
        return slotId;
    }

    public Device getDevice() {
        return device;
    }

    public WifiNetwork getWifiNetwork() {
        return wifiNetwork;
    }

    public String getConnectedSsid() {
        return connectedSsid;
    }

    public String getConnectedBssid() {
        return connectedBssid;
    }

    public Boolean getWifiVerified() {
        return wifiVerified;
    }

    public OffsetDateTime getCheckinTime() {
        return checkinTime;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public String getDeviceInfo() {
        return deviceInfo;
    }

    public BigDecimal getAccuracy() {
        return accuracy;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setShift(Shift shift) {
        this.shift = shift;
    }

    public void setSlotId(Integer slotId) {
        this.slotId = slotId;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public void setWifiNetwork(WifiNetwork wifiNetwork) {
        this.wifiNetwork = wifiNetwork;
    }

    public void setConnectedSsid(String connectedSsid) {
        this.connectedSsid = connectedSsid;
    }

    public void setConnectedBssid(String connectedBssid) {
        this.connectedBssid = connectedBssid;
    }

    public void setWifiVerified(Boolean wifiVerified) {
        this.wifiVerified = wifiVerified;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public void setDeviceInfo(String deviceInfo) {
        this.deviceInfo = deviceInfo;
    }

    public void setAccuracy(BigDecimal accuracy) {
        this.accuracy = accuracy;
    }
}