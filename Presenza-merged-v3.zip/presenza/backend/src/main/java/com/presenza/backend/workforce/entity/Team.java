package com.presenza.backend.workforce.entity;

import com.presenza.backend.employee.entity.Employee;
import com.presenza.backend.organisation.entity.Organization;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "team")
public class Team {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "team_id")
    private Integer teamId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "org_id", nullable = false)
    private Organization organization;

    @Column(name = "team_name", nullable = false)
    private String teamName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "manager_employee_id")
    private Employee managerEmployee;

    protected Team() {
    }

    public Team(
            Organization organization,
            String teamName,
            Employee managerEmployee
    ) {
        this.organization = organization;
        this.teamName = teamName;
        this.managerEmployee = managerEmployee;
    }

    public Integer getTeamId() {
        return teamId;
    }

    public Organization getOrganization() {
        return organization;
    }

    public String getTeamName() {
        return teamName;
    }

    public Employee getManagerEmployee() {
        return managerEmployee;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public void setManagerEmployee(Employee managerEmployee) {
        this.managerEmployee = managerEmployee;
    }
}
