package com.presenza.backend.push.entity;

import com.presenza.backend.user.entity.User;
import jakarta.persistence.*;

@Entity
@Table(name = "user_push_token")
public class PushToken {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "push_token_id")
    private Integer pushTokenId;

    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "user_id", nullable = false)
    private User user;
    @Column(name = "device_id", nullable = false, length = 100) private String deviceId;
    @Column(name = "expo_push_token", nullable = false, unique = true, length = 255) private String expoPushToken;
    @Column(name = "platform", length = 20) private String platform;
    @Column(name = "is_active", nullable = false) private Boolean active = true;

    protected PushToken() { }
    public PushToken(User user, String deviceId, String expoPushToken, String platform) {
        this.user = user; this.deviceId = deviceId; this.expoPushToken = expoPushToken; this.platform = platform; this.active = true;
    }
    public Integer getPushTokenId() { return pushTokenId; }
    public User getUser() { return user; }
    public String getDeviceId() { return deviceId; }
    public String getExpoPushToken() { return expoPushToken; }
    public Boolean getActive() { return active; }
    public void update(User user, String deviceId, String platform) { this.user = user; this.deviceId = deviceId; this.platform = platform; this.active = true; }
    public void setActive(Boolean active) { this.active = active; }
}
