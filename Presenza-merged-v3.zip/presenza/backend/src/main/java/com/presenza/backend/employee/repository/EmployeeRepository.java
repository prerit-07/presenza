package com.presenza.backend.employee.repository;

import com.presenza.backend.employee.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EmployeeRepository
        extends JpaRepository<Employee, Integer> {

    List<Employee> findByOrganizationOrgId(
            Integer orgId
    );

    Optional<Employee> findByUserUserId(
            Integer userId
    );

    List<Employee> findByTeamManagerEmployeeUserUserId(
            Integer userId
    );

    List<Employee> findByTeamTeamId(Integer teamId);
}
