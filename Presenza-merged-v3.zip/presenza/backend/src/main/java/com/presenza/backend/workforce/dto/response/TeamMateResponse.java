package com.presenza.backend.workforce.dto.response;

import java.time.OffsetDateTime;

public class TeamMateResponse {

    private final Integer employeeId;
    private final String employeeName;
    private final Integer departmentId;
    private final String attendanceStatus;
    private final OffsetDateTime effectiveCheckinTime;
    private final String attendanceSource;

    public TeamMateResponse(
            Integer employeeId,
            String employeeName,
            Integer departmentId,
            String attendanceStatus,
            OffsetDateTime effectiveCheckinTime,
            String attendanceSource
    ) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.departmentId = departmentId;
        this.attendanceStatus = attendanceStatus;
        this.effectiveCheckinTime = effectiveCheckinTime;
        this.attendanceSource = attendanceSource;
    }

    public Integer getEmployeeId() { return employeeId; }
    public String getEmployeeName() { return employeeName; }
    public Integer getDepartmentId() { return departmentId; }
    public String getAttendanceStatus() { return attendanceStatus; }
    public OffsetDateTime getEffectiveCheckinTime() { return effectiveCheckinTime; }
    public String getAttendanceSource() { return attendanceSource; }
}
