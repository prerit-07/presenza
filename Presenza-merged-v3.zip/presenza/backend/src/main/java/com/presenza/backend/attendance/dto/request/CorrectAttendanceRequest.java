package com.presenza.backend.attendance.dto.request;

import com.presenza.backend.attendance.entity.AttendanceStatus;
import jakarta.validation.constraints.Size;

import java.time.OffsetDateTime;

public class CorrectAttendanceRequest {

    private AttendanceStatus status;
    private OffsetDateTime effectiveCheckinTime;

    @Size(max = 2000, message = "Remarks must not exceed 2000 characters")
    private String remarks;

    public CorrectAttendanceRequest() {
    }

    public AttendanceStatus getStatus() { return status; }
    public OffsetDateTime getEffectiveCheckinTime() { return effectiveCheckinTime; }
    public String getRemarks() { return remarks; }
}
