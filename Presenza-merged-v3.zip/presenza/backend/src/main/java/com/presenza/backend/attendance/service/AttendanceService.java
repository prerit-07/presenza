package com.presenza.backend.attendance.service;

import com.presenza.backend.common.exception.ForbiddenException;
import com.presenza.backend.attendance.dto.request.ReviewAttendanceRequest;
import com.presenza.backend.attendance.dto.request.CreateManualAttendanceRequest;
import com.presenza.backend.attendance.dto.request.CorrectAttendanceRequest;
import com.presenza.backend.attendance.dto.response.AttendanceResponse;
import com.presenza.backend.attendance.dto.response.ManualAttendanceResponse;
import com.presenza.backend.attendance.entity.Attendance;
import com.presenza.backend.attendance.entity.AttendanceStatus;
import com.presenza.backend.attendance.entity.ManualAttendance;
import com.presenza.backend.attendance.repository.AttendanceRepository;
import com.presenza.backend.attendance.repository.ManualAttendanceRepository;
import com.presenza.backend.common.exception.BadRequestException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.employee.entity.Employee;
import com.presenza.backend.employee.repository.EmployeeRepository;
import com.presenza.backend.notification.NotificationType;
import com.presenza.backend.notification.service.NotificationService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

@Service
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final ManualAttendanceRepository manualAttendanceRepository;
    private final EmployeeRepository employeeRepository;
    private final NotificationService notificationService;

    public AttendanceService(
            AttendanceRepository attendanceRepository,
            ManualAttendanceRepository manualAttendanceRepository,
            EmployeeRepository employeeRepository,
            NotificationService notificationService
    ) {
        this.attendanceRepository = attendanceRepository;
        this.manualAttendanceRepository = manualAttendanceRepository;
        this.employeeRepository = employeeRepository;
        this.notificationService = notificationService;
    }

    @Transactional(readOnly = true)
    public List<AttendanceResponse> getMyAttendance(
            Integer userId
    ) {
        return attendanceRepository
                .findByCheckInUserUserIdOrderByAttendanceIdDesc(
                        userId
                )
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<AttendanceResponse> getOrganizationAttendance(
            Integer organizationId,
            String role
    ) {
        validateReviewerRole(role);

        return attendanceRepository
                .findByCheckInShiftOrganizationOrgIdOrderByAttendanceIdDesc(
                        organizationId
                )
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<AttendanceResponse> getPendingAttendance(
            Integer organizationId,
            String role
    ) {
        validateReviewerRole(role);

        return attendanceRepository
                .findByStatusAndCheckInShiftOrganizationOrgIdOrderByAttendanceIdDesc(
                        AttendanceStatus.PENDING,
                        organizationId
                )
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional
    public AttendanceResponse reviewAttendance(
            Integer attendanceId,
            Integer organizationId,
            String role,
            ReviewAttendanceRequest request
    ) {
        validateReviewerRole(role);

        Attendance attendance = attendanceRepository
                .findById(attendanceId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Attendance not found with id: "
                                        + attendanceId
                        )
                );

        Integer attendanceOrganizationId =
                attendance.getCheckIn()
                        .getShift()
                        .getOrganization()
                        .getOrgId();

        if (!attendanceOrganizationId.equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Attendance not found with id: "
                            + attendanceId
            );
        }

        if (attendance.getStatus() != AttendanceStatus.PENDING) {
            throw new BadRequestException(
                    "Only pending attendance can be reviewed"
            );
        }

        AttendanceStatus newStatus =
                Boolean.TRUE.equals(request.getApproved())
                        ? AttendanceStatus.PRESENT
                        : AttendanceStatus.REJECTED;

        attendance.setStatus(newStatus);
        attendance.setApprovedAt(OffsetDateTime.now());
        attendance.setRemarks(request.getRemarks());

        Attendance savedAttendance =
                attendanceRepository.save(attendance);

        notificationService.createNotification(
                organizationId, attendance.getCheckIn().getUser().getUserId(),
                NotificationType.ATTENDANCE,
                "Attendance review completed",
                "Your attendance was " + newStatus.name().toLowerCase() + ".",
                "ATTENDANCE", savedAttendance.getAttendanceId()
        );

        return toResponse(savedAttendance);
    }

    @Transactional
    public ManualAttendanceResponse createManualAttendance(
            Integer managerUserId,
            Integer organizationId,
            String role,
            CreateManualAttendanceRequest request
    ) {
        Employee employee = findEmployee(request.getEmployeeId());
        validateManagerAccess(
                managerUserId,
                organizationId,
                role,
                employee
        );
        validateManualStatus(request.getStatus());

        if (manualAttendanceRepository
                .existsByEmployeeEmployeeIdAndAttendanceDate(
                        employee.getEmployeeId(),
                        request.getAttendanceDate()
                )) {
            throw new BadRequestException(
                    "Manual attendance already exists for this employee and date"
            );
        }

        Employee createdBy = employeeRepository.findByUserUserId(managerUserId)
                .orElseThrow(() -> new BadRequestException(
                        "Authenticated user is not registered as an employee"
                ));

        ManualAttendance manualAttendance = new ManualAttendance(
                employee,
                request.getAttendanceDate(),
                request.getStatus(),
                request.getEffectiveCheckinTime(),
                request.getRemarks(),
                createdBy
        );

        return toManualResponse(
                manualAttendanceRepository.save(manualAttendance)
        );
    }

    @Transactional
    public AttendanceResponse correctAttendance(
            Integer attendanceId,
            Integer managerUserId,
            Integer organizationId,
            String role,
            CorrectAttendanceRequest request
    ) {
        if (request.getStatus() == null &&
                request.getEffectiveCheckinTime() == null &&
                request.getRemarks() == null) {
            throw new BadRequestException(
                    "At least one attendance correction is required"
            );
        }

        Attendance attendance = attendanceRepository.findById(attendanceId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Attendance not found with id: " + attendanceId
                ));
        Employee employee = employeeRepository.findByUserUserId(
                attendance.getCheckIn().getUser().getUserId()
        ).orElseThrow(() -> new ResourceNotFoundException(
                "Employee not found for attendance"
        ));

        validateManagerAccess(managerUserId, organizationId, role, employee);

        if (request.getStatus() != null) {
            validateManualStatus(request.getStatus());
            attendance.setStatus(request.getStatus());
        }
        if (request.getEffectiveCheckinTime() != null) {
            attendance.setEffectiveCheckinTime(
                    request.getEffectiveCheckinTime()
            );
        }
        if (request.getRemarks() != null) {
            attendance.setRemarks(request.getRemarks());
        }

        return toResponse(attendanceRepository.save(attendance));
    }

    private void validateReviewerRole(String role) {
        if (!"ORG_ADMIN".equals(role) &&
                !"MANAGER".equals(role)) {
            throw new ForbiddenException(
                    "User is not allowed to access or review organization attendance"
            );
        }
    }

    private Employee findEmployee(Integer employeeId) {
        return employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Employee not found with id: " + employeeId
                ));
    }

    private void validateManagerAccess(
            Integer managerUserId,
            Integer organizationId,
            String role,
            Employee employee
    ) {
        if (!employee.getOrganization().getOrgId().equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Employee not found with id: " + employee.getEmployeeId()
            );
        }

        if ("ORG_ADMIN".equals(role)) {
            return;
        }

        if (!"MANAGER".equals(role) || employee.getTeam() == null ||
                employee.getTeam().getManagerEmployee() == null ||
                !employee.getTeam().getManagerEmployee().getUser().getUserId()
                        .equals(managerUserId)) {
            throw new ForbiddenException(
                    "Manager is not allowed to manage this employee's attendance"
            );
        }
    }

    private void validateManualStatus(AttendanceStatus status) {
        if (status == AttendanceStatus.PENDING ||
                status == AttendanceStatus.REJECTED) {
            throw new BadRequestException(
                    "Manual attendance status must be PRESENT, LATE, or ABSENT"
            );
        }
    }

    private AttendanceResponse toResponse(
            Attendance attendance
    ) {
        return new AttendanceResponse(
                attendance.getAttendanceId(),
                attendance.getCheckIn().getCheckinId(),
                attendance.getCheckIn()
                        .getUser()
                        .getUserId(),
                attendance.getCheckIn().getShift() != null
                        ? attendance.getCheckIn()
                        .getShift()
                        .getShiftId()
                        : null,
                attendance.getStatus().name(),
                attendance.getApprovedAt(),
                attendance.getRemarks(),
                attendance.getCheckIn().getCheckinTime(),
                attendance.getEffectiveCheckinTime(),
                attendance.getCheckIn().getWifiVerified()
        );
    }

    private ManualAttendanceResponse toManualResponse(
            ManualAttendance attendance
    ) {
        return new ManualAttendanceResponse(
                attendance.getManualAttendanceId(),
                attendance.getEmployee().getEmployeeId(),
                attendance.getAttendanceDate(),
                attendance.getStatus().name(),
                attendance.getEffectiveCheckinTime(),
                attendance.getRemarks(),
                attendance.getCreatedByEmployee().getEmployeeId(),
                attendance.getCreatedAt()
        );
    }
}
