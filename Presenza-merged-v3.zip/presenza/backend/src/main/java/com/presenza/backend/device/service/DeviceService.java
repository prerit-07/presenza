package com.presenza.backend.device.service;

import com.presenza.backend.common.exception.BadRequestException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.device.dto.request.RegisterDeviceRequest;
import com.presenza.backend.device.dto.response.DeviceResponse;
import com.presenza.backend.device.entity.Device;
import com.presenza.backend.device.repository.DeviceRepository;
import com.presenza.backend.user.entity.User;
import com.presenza.backend.user.repository.UserRepository;
import jakarta.persistence.EntityManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

@Service
public class DeviceService {

    private final DeviceRepository deviceRepository;
    private final UserRepository userRepository;
    private final EntityManager entityManager;

    public DeviceService(
            DeviceRepository deviceRepository,
            UserRepository userRepository,
            EntityManager entityManager
    ) {
        this.deviceRepository = deviceRepository;
        this.userRepository = userRepository;
        this.entityManager = entityManager;
    }

    @Transactional
    public DeviceResponse registerDevice(
            Integer userId,
            RegisterDeviceRequest request
    ) {
        if (deviceRepository.existsById(request.getDeviceId())) {
            throw new BadRequestException(
                    "Device is already registered"
            );
        }

        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found with id: " + userId
                        )
                );

        Device device = new Device(
                request.getDeviceId(),
                user,
                request.getPlatform(),
                request.getModel(),
                request.getAppVersion()
        );

        Device savedDevice =
                deviceRepository.saveAndFlush(device);

        entityManager.refresh(savedDevice);

        return toResponse(savedDevice);
    }

    @Transactional(readOnly = true)
    public List<DeviceResponse> getUserDevices(
            Integer userId
    ) {
        return deviceRepository.findByUserUserId(userId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional
    public DeviceResponse deactivateDevice(
            Integer userId,
            String deviceId
    ) {
        Device device = deviceRepository.findById(deviceId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Device not found with id: " + deviceId
                        )
                );

        if (!device.getUser()
                .getUserId()
                .equals(userId)) {
            throw new ResourceNotFoundException(
                    "Device not found with id: " + deviceId
            );
        }

        if (!Boolean.TRUE.equals(device.getActive())) {
            throw new BadRequestException(
                    "Device is already inactive"
            );
        }

        device.setActive(false);
        device.setLastSeenAt(OffsetDateTime.now());

        Device savedDevice =
                deviceRepository.save(device);

        return toResponse(savedDevice);
    }

    private DeviceResponse toResponse(
            Device device
    ) {
        return new DeviceResponse(
                device.getDeviceId(),
                device.getPlatform(),
                device.getModel(),
                device.getAppVersion(),
                device.getBoundAt(),
                device.getLastSeenAt(),
                device.getActive()
        );
    }
}