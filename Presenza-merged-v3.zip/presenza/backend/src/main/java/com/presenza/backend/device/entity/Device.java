package com.presenza.backend.device.entity;

import com.presenza.backend.user.entity.User;
import jakarta.persistence.*;

import java.time.OffsetDateTime;

@Entity
@Table(name = "device")
public class Device {

    @Id
    @Column(name = "device_id", length = 100)
    private String deviceId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "platform", length = 50)
    private String platform;

    @Column(name = "model", length = 100)
    private String model;

    @Column(name = "app_version", length = 50)
    private String appVersion;

    @Column(
            name = "bound_at",
            nullable = false,
            insertable = false,
            updatable = false
    )
    private OffsetDateTime boundAt;

    @Column(name = "last_seen_at")
    private OffsetDateTime lastSeenAt;

    @Column(
            name = "is_active",
            nullable = false,
            insertable = false
    )
    private Boolean active;

    protected Device() {
    }

    public Device(
            String deviceId,
            User user,
            String platform,
            String model,
            String appVersion
    ) {
        this.deviceId = deviceId;
        this.user = user;
        this.platform = platform;
        this.model = model;
        this.appVersion = appVersion;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public User getUser() {
        return user;
    }

    public String getPlatform() {
        return platform;
    }

    public String getModel() {
        return model;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public OffsetDateTime getBoundAt() {
        return boundAt;
    }

    public OffsetDateTime getLastSeenAt() {
        return lastSeenAt;
    }

    public Boolean getActive() {
        return active;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public void setLastSeenAt(OffsetDateTime lastSeenAt) {
        this.lastSeenAt = lastSeenAt;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
}