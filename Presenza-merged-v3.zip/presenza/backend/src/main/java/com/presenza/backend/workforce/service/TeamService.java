package com.presenza.backend.workforce.service;

import com.presenza.backend.common.exception.ForbiddenException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.attendance.entity.Attendance;
import com.presenza.backend.attendance.entity.ManualAttendance;
import com.presenza.backend.attendance.repository.AttendanceRepository;
import com.presenza.backend.attendance.repository.ManualAttendanceRepository;
import com.presenza.backend.employee.entity.Employee;
import com.presenza.backend.employee.repository.EmployeeRepository;
import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.organisation.repository.OrganizationRepository;
import com.presenza.backend.workforce.dto.request.TeamRequest;
import com.presenza.backend.workforce.dto.response.TeamResponse;
import com.presenza.backend.workforce.dto.response.TeamMateResponse;
import com.presenza.backend.employee.dto.response.EmployeeResponse;
import com.presenza.backend.workforce.entity.Team;
import com.presenza.backend.workforce.repository.TeamRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class TeamService {

    private static final ZoneId ORGANIZATION_TIME_ZONE =
            ZoneId.of("Asia/Kolkata");

    private final TeamRepository teamRepository;
    private final OrganizationRepository organizationRepository;
    private final EmployeeRepository employeeRepository;
    private final AttendanceRepository attendanceRepository;
    private final ManualAttendanceRepository manualAttendanceRepository;

    public TeamService(
            TeamRepository teamRepository,
            OrganizationRepository organizationRepository,
            EmployeeRepository employeeRepository,
            AttendanceRepository attendanceRepository,
            ManualAttendanceRepository manualAttendanceRepository
    ) {
        this.teamRepository = teamRepository;
        this.organizationRepository = organizationRepository;
        this.employeeRepository = employeeRepository;
        this.attendanceRepository = attendanceRepository;
        this.manualAttendanceRepository = manualAttendanceRepository;
    }

    @Transactional
    public TeamResponse createTeam(
            Integer organizationId,
            String role,
            TeamRequest request
    ) {
        validateManagementRole(role);

        Organization organization =
                findOrganization(organizationId);

        Employee manager = resolveManager(
                request.getManagerEmployeeId(),
                organizationId
        );

        Team team = new Team(
                organization,
                request.getTeamName(),
                manager
        );

        return toResponse(
                teamRepository.save(team)
        );
    }

    @Transactional(readOnly = true)
    public TeamResponse getTeamById(
            Integer id,
            Integer organizationId
    ) {
        return toResponse(
                findTeamInOrganization(
                        id,
                        organizationId
                )
        );
    }

    @Transactional(readOnly = true)
    public List<TeamResponse> getTeamsByOrganization(
            Integer organizationId
    ) {
        findOrganization(organizationId);

        return teamRepository
                .findByOrganizationOrgId(organizationId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<EmployeeResponse> getMyTeamMembers(
            Integer userId,
            Integer organizationId,
            String role
    ) {
        if (!"MANAGER".equals(role)) {
            throw new ForbiddenException(
                    "Only managers can access their team members"
            );
        }

        return employeeRepository
                .findByTeamManagerEmployeeUserUserId(userId)
                .stream()
                .filter(employee -> employee.getOrganization().getOrgId()
                        .equals(organizationId))
                .map(this::toEmployeeResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<TeamMateResponse> getMyTeammates(
            Integer userId,
            Integer organizationId,
            LocalDate date
    ) {
        Employee employee = employeeRepository.findByUserUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Employee not found for authenticated user"
                ));

        if (!employee.getOrganization().getOrgId().equals(organizationId) ||
                employee.getTeam() == null) {
            return List.of();
        }

        List<Employee> teammates = employeeRepository
                .findByTeamTeamId(employee.getTeam().getTeamId())
                .stream()
                .filter(teammate -> !teammate.getEmployeeId()
                        .equals(employee.getEmployeeId()))
                .toList();

        if (teammates.isEmpty()) {
            return List.of();
        }

        LocalDate requestedDate = date != null
                ? date
                : LocalDate.now(ORGANIZATION_TIME_ZONE);
        OffsetDateTime start = requestedDate
                .atStartOfDay(ORGANIZATION_TIME_ZONE)
                .toOffsetDateTime();
        OffsetDateTime end = requestedDate.plusDays(1)
                .atStartOfDay(ORGANIZATION_TIME_ZONE)
                .toOffsetDateTime();
        List<Integer> userIds = teammates.stream()
                .map(teammate -> teammate.getUser().getUserId())
                .toList();
        List<Integer> employeeIds = teammates.stream()
                .map(Employee::getEmployeeId)
                .toList();

        Map<Integer, Attendance> attendanceByUserId = new HashMap<>();
        attendanceRepository
                .findByCheckInUserUserIdInAndCheckInCheckinTimeBetweenOrderByCheckInCheckinTimeDesc(
                        userIds, start, end
                )
                .forEach(attendance -> attendanceByUserId.putIfAbsent(
                        attendance.getCheckIn().getUser().getUserId(),
                        attendance
                ));

        Map<Integer, ManualAttendance> manualAttendanceByEmployeeId =
                new HashMap<>();
        manualAttendanceRepository
                .findByEmployeeEmployeeIdInAndAttendanceDate(
                        employeeIds, requestedDate
                )
                .forEach(attendance -> manualAttendanceByEmployeeId.put(
                        attendance.getEmployee().getEmployeeId(),
                        attendance
                ));

        return teammates.stream()
                .map(teammate -> toTeamMateResponse(
                        teammate,
                        attendanceByUserId.get(teammate.getUser().getUserId()),
                        manualAttendanceByEmployeeId.get(
                                teammate.getEmployeeId()
                        )
                ))
                .toList();
    }

    @Transactional
    public TeamResponse updateTeam(
            Integer id,
            Integer organizationId,
            String role,
            TeamRequest request
    ) {
        validateManagementRole(role);

        Team team = findTeamInOrganization(
                id,
                organizationId
        );

        Employee manager = resolveManager(
                request.getManagerEmployeeId(),
                organizationId
        );

        team.setTeamName(request.getTeamName());
        team.setManagerEmployee(manager);

        return toResponse(
                teamRepository.save(team)
        );
    }

    private Organization findOrganization(
            Integer organizationId
    ) {
        return organizationRepository
                .findById(organizationId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Organization not found with id: "
                                        + organizationId
                        )
                );
    }

    private Team findTeamInOrganization(
            Integer teamId,
            Integer organizationId
    ) {
        Team team = teamRepository
                .findById(teamId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Team not found with id: "
                                        + teamId
                        )
                );

        if (!team.getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Team not found with id: "
                            + teamId
            );
        }

        return team;
    }

    private Employee resolveManager(
            Integer managerEmployeeId,
            Integer organizationId
    ) {
        if (managerEmployeeId == null) {
            return null;
        }

        Employee manager = employeeRepository
                .findById(managerEmployeeId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Manager employee not found with id: "
                                        + managerEmployeeId
                        )
                );

        if (!manager.getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Manager employee not found with id: "
                            + managerEmployeeId
            );
        }

        return manager;
    }

    private void validateManagementRole(
            String role
    ) {
        if (!"ORG_ADMIN".equals(role) &&
                !"MANAGER".equals(role)) {
            throw new ForbiddenException(
                    "User is not allowed to manage teams"
            );
        }
    }

    private TeamResponse toResponse(
            Team team
    ) {
        return new TeamResponse(
                team.getTeamId(),
                team.getOrganization().getOrgId(),
                team.getTeamName(),
                team.getManagerEmployee() != null
                        ? team.getManagerEmployee()
                        .getEmployeeId()
                        : null
        );
    }

    private EmployeeResponse toEmployeeResponse(Employee employee) {
        return new EmployeeResponse(
                employee.getEmployeeId(),
                employee.getOrganization().getOrgId(),
                employee.getUser().getUserId(),
                employee.getEmployeeName(),
                employee.getDateOfJoining(),
                employee.getDepartment() != null
                        ? employee.getDepartment().getDepartmentId()
                        : null,
                employee.getShift() != null
                        ? employee.getShift().getShiftId()
                        : null,
                employee.getTeam() != null
                        ? employee.getTeam().getTeamId()
                        : null
        );
    }

    private TeamMateResponse toTeamMateResponse(
            Employee employee,
            Attendance attendance,
            ManualAttendance manualAttendance
    ) {
        if (manualAttendance != null) {
            return new TeamMateResponse(
                    employee.getEmployeeId(),
                    employee.getEmployeeName(),
                    employee.getDepartment() != null
                            ? employee.getDepartment().getDepartmentId()
                            : null,
                    manualAttendance.getStatus().name(),
                    manualAttendance.getEffectiveCheckinTime(),
                    "MANUAL"
            );
        }

        return new TeamMateResponse(
                employee.getEmployeeId(),
                employee.getEmployeeName(),
                employee.getDepartment() != null
                        ? employee.getDepartment().getDepartmentId()
                        : null,
                attendance != null ? attendance.getStatus().name() : null,
                attendance != null
                        ? attendance.getEffectiveCheckinTime() != null
                                ? attendance.getEffectiveCheckinTime()
                                : attendance.getCheckIn().getCheckinTime()
                        : null,
                attendance != null ? "CHECK_IN" : null
        );
    }
}
