package com.presenza.backend.geofence.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.geofence.dto.request.WifiNetworkRequest;
import com.presenza.backend.geofence.dto.response.WifiNetworkResponse;
import com.presenza.backend.geofence.service.WifiNetworkService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/wifi-networks")
public class WifiNetworkController {

    private final WifiNetworkService wifiNetworkService;
    private final TokenService tokenService;

    public WifiNetworkController(
            WifiNetworkService wifiNetworkService,
            TokenService tokenService
    ) {
        this.wifiNetworkService = wifiNetworkService;
        this.tokenService = tokenService;
    }

    @PostMapping
    public WifiNetworkResponse createWifiNetwork(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody WifiNetworkRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return wifiNetworkService.createWifiNetwork(
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        );
    }

    @GetMapping("/{id}")
    public WifiNetworkResponse getWifiNetworkById(
            @PathVariable Integer id,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return wifiNetworkService.getWifiNetworkById(
                id,
                authenticatedUser.getOrganizationId()
        );
    }

    @GetMapping("/geofence/{geofenceId}")
    public List<WifiNetworkResponse> getWifiNetworksByGeofence(
            @PathVariable Integer geofenceId,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return wifiNetworkService.getWifiNetworksByGeofence(
                geofenceId,
                authenticatedUser.getOrganizationId()
        );
    }

    @PutMapping("/{id}")
    public WifiNetworkResponse updateWifiNetwork(
            @PathVariable Integer id,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody WifiNetworkRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return wifiNetworkService.updateWifiNetwork(
                id,
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        );
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {
        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        return tokenService.getAuthenticatedUser(
                authorizationHeader.substring(7)
        );
    }
}