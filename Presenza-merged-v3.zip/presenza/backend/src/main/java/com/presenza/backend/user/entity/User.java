package com.presenza.backend.user.entity;

import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.security.entity.Role;
import jakarta.persistence.*;

import java.time.OffsetDateTime;

@Entity
@Table(
        name = "\"user\"",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "user_email_key",
                        columnNames = "email"
                ),
                @UniqueConstraint(
                        name = "user_org_id_username_key",
                        columnNames = {"org_id", "username"}
                )
        }
)
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Integer userId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "org_id", nullable = false)
    private Organization organization;

    @Column(name = "username", nullable = false, length = 100)
    private String username;

    @Column(name = "email", nullable = false, length = 150)
    private String email;

    @Column(name = "hash_password", nullable = false, length = 255)
    private String hashPassword;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "role_id")
    private Role role;

    @Column(
            name = "created_at",
            nullable = false,
            insertable = false,
            updatable = false
    )
    private OffsetDateTime createdAt;

    @Column(
            name = "is_active",
            nullable = false,
            insertable = false
    )
    private Boolean active;

    @Column(name = "last_login")
    private OffsetDateTime lastLogin;

    @Column(name = "must_change_password", nullable = false)
    private Boolean mustChangePassword = false;

    protected User() {
    }

    public User(
            Organization organization,
            String username,
            String email,
            String hashPassword,
            Role role
    ) {
        this.organization = organization;
        this.username = username;
        this.email = email;
        this.hashPassword = hashPassword;
        this.role = role;
        this.mustChangePassword = false;
    }

    public Integer getUserId() {
        return userId;
    }

    public Organization getOrganization() {
        return organization;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getHashPassword() {
        return hashPassword;
    }

    public Role getRole() {
        return role;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public Boolean getActive() {
        return active;
    }

    public OffsetDateTime getLastLogin() {
        return lastLogin;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setHashPassword(String hashPassword) {
        this.hashPassword = hashPassword;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public void setLastLogin(OffsetDateTime lastLogin) {
        this.lastLogin = lastLogin;
    }

    public Boolean getMustChangePassword() {
        return mustChangePassword;
    }

    public void setMustChangePassword(Boolean mustChangePassword) {
        this.mustChangePassword = mustChangePassword;
    }
}