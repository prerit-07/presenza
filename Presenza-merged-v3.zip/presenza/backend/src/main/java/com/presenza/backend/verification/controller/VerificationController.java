package com.presenza.backend.verification.controller;

import com.presenza.backend.verification.VerificationPurpose;
import com.presenza.backend.verification.dto.request.SendOtpRequest;
import com.presenza.backend.verification.dto.request.VerifyOtpRequest;
import com.presenza.backend.verification.dto.request.CompanyCodeVerificationRequest;
import com.presenza.backend.verification.dto.response.VerificationResponse;
import com.presenza.backend.verification.dto.response.CompanyCodeVerificationResponse;
import com.presenza.backend.verification.service.VerificationService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/verification")
public class VerificationController {

    private final VerificationService verificationService;

    public VerificationController(
            VerificationService verificationService
    ) {
        this.verificationService = verificationService;
    }

    @PostMapping("/send-otp")
    public ResponseEntity<VerificationResponse> sendOtp(
            @Valid
            @RequestBody
            SendOtpRequest request
    ) {

        VerificationResponse response =
                verificationService.sendOtp(
                        request.getEmail(),
                        request.getPurpose()
                );

        return ResponseEntity.ok(response);
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<VerificationResponse> verifyOtp(
            @Valid
            @RequestBody
            VerifyOtpRequest request
    ) {

        VerificationResponse response =
                verificationService.verifyOtp(
                        request.getEmail(),
                        request.getOtp(),
                        request.getPurpose()
                );

        return ResponseEntity.ok(response);
    }

    @PostMapping("/company-code")
    public ResponseEntity<CompanyCodeVerificationResponse> verifyCompanyCode(
            @Valid @RequestBody CompanyCodeVerificationRequest request
    ) {
        return ResponseEntity.ok(verificationService.verifyCompanyCode(
                request.getCompanyCode()
        ));
    }
}
