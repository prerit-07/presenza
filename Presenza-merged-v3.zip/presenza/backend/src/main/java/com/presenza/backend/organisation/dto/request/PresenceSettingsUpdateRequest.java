package com.presenza.backend.organisation.dto.request;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class PresenceSettingsUpdateRequest {

    @NotNull(message = "Presence monitoring enabled is required")
    private Boolean presenceMonitoringEnabled;

    @NotNull(message = "Presence update interval is required")
    @Min(value = 60, message = "Presence update interval must be at least 60 seconds")
    @Max(value = 3600, message = "Presence update interval must not exceed 3600 seconds")
    private Integer presenceUpdateIntervalSeconds;

    @NotNull(message = "Trusted WiFi requirement is required")
    private Boolean requireTrustedWifi;

    public PresenceSettingsUpdateRequest() {
    }

    public Boolean getPresenceMonitoringEnabled() {
        return presenceMonitoringEnabled;
    }

    public Integer getPresenceUpdateIntervalSeconds() {
        return presenceUpdateIntervalSeconds;
    }

    public Boolean getRequireTrustedWifi() {
        return requireTrustedWifi;
    }
}
