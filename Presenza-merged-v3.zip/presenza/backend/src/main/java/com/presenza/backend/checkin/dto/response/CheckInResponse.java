package com.presenza.backend.checkin.dto.response;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

public class CheckInResponse {

    private final Integer checkinId;
    private final Integer userId;
    private final Integer shiftId;
    private final String deviceId;
    private final Integer wifiId;
    private final String connectedSsid;
    private final String connectedBssid;
    private final Boolean wifiVerified;
    private final OffsetDateTime checkinTime;
    private final BigDecimal latitude;
    private final BigDecimal longitude;
    private final String deviceInfo;
    private final BigDecimal accuracy;

    public CheckInResponse(
            Integer checkinId,
            Integer userId,
            Integer shiftId,
            String deviceId,
            Integer wifiId,
            String connectedSsid,
            String connectedBssid,
            Boolean wifiVerified,
            OffsetDateTime checkinTime,
            BigDecimal latitude,
            BigDecimal longitude,
            String deviceInfo,
            BigDecimal accuracy
    ) {
        this.checkinId = checkinId;
        this.userId = userId;
        this.shiftId = shiftId;
        this.deviceId = deviceId;
        this.wifiId = wifiId;
        this.connectedSsid = connectedSsid;
        this.connectedBssid = connectedBssid;
        this.wifiVerified = wifiVerified;
        this.checkinTime = checkinTime;
        this.latitude = latitude;
        this.longitude = longitude;
        this.deviceInfo = deviceInfo;
        this.accuracy = accuracy;
    }

    public Integer getCheckinId() {
        return checkinId;
    }

    public Integer getUserId() {
        return userId;
    }

    public Integer getShiftId() {
        return shiftId;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public Integer getWifiId() {
        return wifiId;
    }

    public String getConnectedSsid() {
        return connectedSsid;
    }

    public String getConnectedBssid() {
        return connectedBssid;
    }

    public Boolean getWifiVerified() {
        return wifiVerified;
    }

    public OffsetDateTime getCheckinTime() {
        return checkinTime;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public String getDeviceInfo() {
        return deviceInfo;
    }

    public BigDecimal getAccuracy() {
        return accuracy;
    }
}