package com.presenza.backend.notification.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.notification.dto.response.NotificationResponse;
import com.presenza.backend.notification.service.NotificationService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final NotificationService notificationService;
    private final TokenService tokenService;

    public NotificationController(
            NotificationService notificationService,
            TokenService tokenService
    ) {
        this.notificationService = notificationService;
        this.tokenService = tokenService;
    }

    @GetMapping
    public List<NotificationResponse> getMyNotifications(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {

        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return notificationService.getMyNotifications(
                authenticatedUser.getUserId()
        );
    }

    @PutMapping("/{notificationId}/read")
    public void markAsRead(
            @PathVariable Integer notificationId,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {

        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        notificationService.markAsRead(
                notificationId,
                authenticatedUser.getUserId()
        );
    }

    @PutMapping("/read-all")
    public void markAllAsRead(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {

        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        notificationService.markAllAsRead(
                authenticatedUser.getUserId()
        );
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {

        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        return tokenService.getAuthenticatedUser(
                authorizationHeader.substring(7)
        );
    }
}