package com.presenza.backend.geofence.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import com.presenza.backend.organisation.entity.Organization;
import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import java.math.BigDecimal;

@Entity
@Table(name = "geofence")
public class Geofence {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "geofence_id")
    private Integer geofenceId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "org_id", nullable = false)
    private Organization organization;

    @Column(name = "latitude", nullable = false, precision = 9, scale = 6)
    private BigDecimal latitude;

    @Column(name = "longitude", nullable = false, precision = 9, scale = 6)
    private BigDecimal longitude;

    @Column(name = "radius", nullable = false)
    private Integer radius;

    @Column(name = "building_name", length = 150)
    private String buildingName;

    protected Geofence() {
    }

    public Geofence(
            Organization organization,
            BigDecimal latitude,
            BigDecimal longitude,
            Integer radius,
            String buildingName
    ) {
        this.organization = organization;
        this.latitude = latitude;
        this.longitude = longitude;
        this.radius = radius;
        this.buildingName = buildingName;
    }

    public Integer getGeofenceId() {
        return geofenceId;
    }

    public Organization getOrganization() {
        return organization;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public Integer getRadius() {
        return radius;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public void setRadius(Integer radius) {
        this.radius = radius;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }
}

