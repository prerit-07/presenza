package com.presenza.backend.notification.dto.response;

import com.presenza.backend.notification.NotificationType;

import java.time.OffsetDateTime;

public class NotificationResponse {

    private final Integer notificationId;
    private final String title;
    private final String message;
    private final NotificationType notificationType;
    private final String referenceType;
    private final Integer referenceId;
    private final Boolean isRead;
    private final OffsetDateTime createdAt;

    public NotificationResponse(
            Integer notificationId,
            String title,
            String message,
            NotificationType notificationType,
            String referenceType,
            Integer referenceId,
            Boolean isRead,
            OffsetDateTime createdAt
    ) {
        this.notificationId = notificationId;
        this.title = title;
        this.message = message;
        this.notificationType = notificationType;
        this.referenceType = referenceType;
        this.referenceId = referenceId;
        this.isRead = isRead;
        this.createdAt = createdAt;
    }

    public Integer getNotificationId() {
        return notificationId;
    }

    public String getTitle() {
        return title;
    }

    public String getMessage() {
        return message;
    }

    public NotificationType getNotificationType() {
        return notificationType;
    }

    public String getReferenceType() {
        return referenceType;
    }

    public Integer getReferenceId() {
        return referenceId;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }
}