package com.presenza.backend.geofence.repository;

import com.presenza.backend.geofence.entity.Geofence;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface GeofenceRepository
        extends JpaRepository<Geofence, Integer> {
    List<Geofence> findByOrganizationOrgId(Integer orgId);
}
