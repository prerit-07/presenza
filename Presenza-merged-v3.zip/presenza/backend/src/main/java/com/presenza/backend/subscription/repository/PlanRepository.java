package com.presenza.backend.subscription.repository;

import com.presenza.backend.subscription.entity.Plan;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PlanRepository
        extends JpaRepository<Plan, Integer> {

    Optional<Plan> findFirstByOrderByPriceAscPlanIdAsc();
}