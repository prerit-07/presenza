package com.presenza.backend.employee.service;

import com.presenza.backend.common.exception.BadRequestException;
import com.presenza.backend.common.exception.ForbiddenException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.email.service.EmailService;
import com.presenza.backend.notification.NotificationType;
import com.presenza.backend.notification.service.NotificationService;
import com.presenza.backend.employee.dto.request.CreateEmployeeRequest;
import com.presenza.backend.employee.dto.request.EmployeeRequest;
import com.presenza.backend.employee.dto.response.EmployeeResponse;
import com.presenza.backend.employee.entity.Employee;
import com.presenza.backend.employee.repository.EmployeeRepository;
import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.organisation.repository.OrganizationRepository;
import com.presenza.backend.security.entity.Role;
import com.presenza.backend.security.repository.RoleRepository;
import com.presenza.backend.shift.entity.Shift;
import com.presenza.backend.shift.repository.ShiftRepository;
import com.presenza.backend.user.entity.User;
import com.presenza.backend.user.repository.UserRepository;
import com.presenza.backend.workforce.entity.Department;
import com.presenza.backend.workforce.entity.Team;
import com.presenza.backend.workforce.repository.DepartmentRepository;
import com.presenza.backend.workforce.repository.TeamRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.util.List;



@Service
public class EmployeeService {

    private static final Logger log =
            LoggerFactory.getLogger(EmployeeService.class);

    private static final String EMPLOYEE_ROLE =
            "EMPLOYEE";

    private final EmployeeRepository employeeRepository;
    private final OrganizationRepository organizationRepository;
    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;
    private final TeamRepository teamRepository;
    private final ShiftRepository shiftRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;
    private final NotificationService notificationService;

    private final SecureRandom secureRandom =
            new SecureRandom();

    public EmployeeService(
            EmployeeRepository employeeRepository,
            OrganizationRepository organizationRepository,
            UserRepository userRepository,
            DepartmentRepository departmentRepository,
            TeamRepository teamRepository,
            ShiftRepository shiftRepository,
            RoleRepository roleRepository,
            PasswordEncoder passwordEncoder,
            EmailService emailService,
            NotificationService notificationService
    ) {
        this.employeeRepository = employeeRepository;
        this.organizationRepository =
                organizationRepository;
        this.userRepository = userRepository;
        this.departmentRepository =
                departmentRepository;
        this.teamRepository = teamRepository;
        this.shiftRepository = shiftRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.emailService = emailService;
        this.notificationService = notificationService;
    }

    private String generateTemporaryPassword() {

        final String upper =
                "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        final String lower =
                "abcdefghijklmnopqrstuvwxyz";

        final String numbers =
                "0123456789";

        final String special =
                "@#$%&*!?";

        final String all =
                upper +
                        lower +
                        numbers +
                        special;

        StringBuilder password =
                new StringBuilder();

        password.append(
                upper.charAt(
                        secureRandom.nextInt(
                                upper.length()
                        )
                )
        );

        password.append(
                lower.charAt(
                        secureRandom.nextInt(
                                lower.length()
                        )
                )
        );

        password.append(
                numbers.charAt(
                        secureRandom.nextInt(
                                numbers.length()
                        )
                )
        );

        password.append(
                special.charAt(
                        secureRandom.nextInt(
                                special.length()
                        )
                )
        );

        while (password.length() < 10) {

            password.append(
                    all.charAt(
                            secureRandom.nextInt(
                                    all.length()
                            )
                    )
            );
        }

        return password.toString();
    }

    @Transactional
    public EmployeeResponse createEmployee(
            Integer organizationId,
            String role,
            CreateEmployeeRequest request
    ) {
        validateStaffRole(role);

        Organization organization =
                getOrganization(organizationId);

        String normalizedEmail =
                request.getEmail()
                        .trim()
                        .toLowerCase();

        String normalizedUsername =
                request.getUsername().trim();

        if (userRepository
                .findByEmail(normalizedEmail)
                .isPresent()) {
            throw new BadRequestException(
                    "A user with this email already exists"
            );
        }

        Role employeeRole = roleRepository
                .findByOrganizationOrgIdAndRoleName(
                        organizationId,
                        EMPLOYEE_ROLE
                )
                .orElseGet(() ->
                        roleRepository.save(
                                new Role(
                                        organization,
                                        EMPLOYEE_ROLE
                                )
                        )
                );

        Department department =
                resolveDepartment(
                        request.getDepartmentId(),
                        organizationId
                );

        Shift shift =
                resolveShift(
                        request.getShiftId(),
                        organizationId
                );

        Team team =
                resolveTeam(
                        request.getTeamId(),
                        organizationId
                );

        String temporaryPassword =
                generateTemporaryPassword();

        String hashedPassword =
                passwordEncoder.encode(
                        temporaryPassword
                );

        User user = new User(
                organization,
                normalizedUsername,
                normalizedEmail,
                hashedPassword,
                employeeRole
        );

        user.setMustChangePassword(true);

        userRepository.save(user);

        Employee employee = new Employee(
                organization,
                user,
                request.getEmployeeName().trim(),
                request.getDateOfJoining(),
                department,
                shift,
                team
        );

        employee = employeeRepository.save(employee);

        notificationService.createNotification(
                organizationId, user.getUserId(), NotificationType.SYSTEM,
                "Employee account created",
                "Your employee account and work assignments are ready.",
                "EMPLOYEE", employee.getEmployeeId()
        );

        try {

            emailService.sendWelcomeEmail(
                    normalizedEmail,
                    employee.getEmployeeName(),
                    temporaryPassword
            );

        } catch (Exception e) {

            // Do not roll back employee creation just because the welcome
            // email failed to send (e.g. transient SMTP outage) — the
            // employee/user/role rows are the source of truth, the email
            // is a best-effort notification.
            log.warn(
                    "Welcome email could not be sent to {} for new employee {}: {}",
                    normalizedEmail,
                    employee.getEmployeeId(),
                    e.getMessage()
            );
        }

        return toResponse(employee);
    }

    @Transactional(readOnly = true)
    public EmployeeResponse getMyEmployee(
            Integer userId,
            Integer organizationId
    ) {
        Employee employee = employeeRepository
                .findByUserUserId(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Employee profile not found for user id: "
                                        + userId
                        )
                );

        if (!employee
                .getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Employee profile not found for user id: "
                            + userId
            );
        }

        return toResponse(employee);
    }

    @Transactional(readOnly = true)
    public EmployeeResponse getEmployeeById(
            Integer id,
            Integer organizationId,
            String role
    ) {
        validateStaffRole(role);

        Employee employee =
                findEmployeeInOrganization(
                        id,
                        organizationId
                );

        return toResponse(employee);
    }

    @Transactional(readOnly = true)
    public List<EmployeeResponse>
    getEmployeesByOrganization(
            Integer organizationId,
            String role
    ) {
        validateStaffRole(role);

        getOrganization(organizationId);

        return employeeRepository
                .findByOrganizationOrgId(
                        organizationId
                )
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional
    public EmployeeResponse updateEmployee(
            Integer id,
            Integer organizationId,
            String role,
            EmployeeRequest request
    ) {
        validateStaffRole(role);

        Employee employee =
                findEmployeeInOrganization(
                        id,
                        organizationId
                );

        User user = userRepository
                .findById(request.getUserId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found with id: "
                                        + request.getUserId()
                        )
                );

        validateUserOrganization(
                user,
                organizationId
        );

        employeeRepository
                .findByUserUserId(
                        user.getUserId()
                )
                .filter(existing ->
                        !existing
                                .getEmployeeId()
                                .equals(id)
                )
                .ifPresent(existing -> {
                    throw new BadRequestException(
                            "Employee already exists for user id: "
                                    + user.getUserId()
                    );
                });

        Department department =
                resolveDepartment(
                        request.getDepartmentId(),
                        organizationId
                );

        Shift shift =
                resolveShift(
                        request.getShiftId(),
                        organizationId
                );

        Team team =
                resolveTeam(
                        request.getTeamId(),
                        organizationId
                );

        employee.setUser(user);
        employee.setEmployeeName(
                request.getEmployeeName()
        );
        employee.setDateOfJoining(
                request.getDateOfJoining()
        );
        employee.setDepartment(department);
        employee.setShift(shift);
        employee.setTeam(team);

        Employee saved = employeeRepository.save(employee);
        notificationService.createNotification(
                organizationId, saved.getUser().getUserId(), NotificationType.SYSTEM,
                "Work assignments updated",
                "Your department, team, or shift assignment has been updated.",
                "EMPLOYEE", saved.getEmployeeId()
        );
        return toResponse(saved);
    }

    private Organization getOrganization(
            Integer organizationId
    ) {
        return organizationRepository
                .findById(organizationId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Organization not found with id: "
                                        + organizationId
                        )
                );
    }

    private Employee findEmployeeInOrganization(
            Integer employeeId,
            Integer organizationId
    ) {
        Employee employee =
                employeeRepository
                        .findById(employeeId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Employee not found with id: "
                                                + employeeId
                                )
                        );

        if (!employee
                .getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Employee not found with id: "
                            + employeeId
            );
        }

        return employee;
    }

    private Department resolveDepartment(
            Integer departmentId,
            Integer organizationId
    ) {
        if (departmentId == null) {
            return null;
        }

        Department department =
                departmentRepository
                        .findById(departmentId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Department not found with id: "
                                                + departmentId
                                )
                        );

        if (!department
                .getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Department not found with id: "
                            + departmentId
            );
        }

        return department;
    }

    private Shift resolveShift(
            Integer shiftId,
            Integer organizationId
    ) {
        if (shiftId == null) {
            return null;
        }

        Shift shift =
                shiftRepository
                        .findById(shiftId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Shift not found with id: "
                                                + shiftId
                                )
                        );

        if (!shift
                .getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Shift not found with id: "
                            + shiftId
            );
        }

        return shift;
    }

    private Team resolveTeam(
            Integer teamId,
            Integer organizationId
    ) {
        if (teamId == null) {
            return null;
        }

        Team team =
                teamRepository
                        .findById(teamId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Team not found with id: "
                                                + teamId
                                )
                        );

        if (!team
                .getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Team not found with id: "
                            + teamId
            );
        }

        return team;
    }

    private void validateUserOrganization(
            User user,
            Integer organizationId
    ) {
        if (user.getOrganization() == null ||
                !user
                        .getOrganization()
                        .getOrgId()
                        .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "User not found with id: "
                            + user.getUserId()
            );
        }
    }

    private void validateStaffRole(
            String role
    ) {
        if (!"ORG_ADMIN".equals(role) &&
                !"MANAGER".equals(role)) {
            throw new ForbiddenException(
                    "User is not allowed to manage employees"
            );
        }
    }

    private EmployeeResponse toResponse(
            Employee employee
    ) {
        return new EmployeeResponse(
                employee.getEmployeeId(),
                employee.getOrganization()
                        .getOrgId(),
                employee.getUser()
                        .getUserId(),
                employee.getEmployeeName(),
                employee.getDateOfJoining(),
                employee.getDepartment() != null
                        ? employee
                        .getDepartment()
                        .getDepartmentId()
                        : null,
                employee.getShift() != null
                        ? employee
                        .getShift()
                        .getShiftId()
                        : null,
                employee.getTeam() != null
                        ? employee
                        .getTeam()
                        .getTeamId()
                        : null
        );
    }
}
