package com.presenza.backend.push.service;

import com.presenza.backend.notification.event.NotificationCreatedEvent;
import com.presenza.backend.push.repository.PushTokenRepository;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

@Component
public class ExpoPushNotificationListener {
    private static final HttpClient CLIENT = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private final PushTokenRepository pushTokenRepository;
    public ExpoPushNotificationListener(PushTokenRepository pushTokenRepository) { this.pushTokenRepository = pushTokenRepository; }

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void deliver(NotificationCreatedEvent event) {
        pushTokenRepository.findByUserUserIdAndActiveTrue(event.recipientUserId())
                .forEach(token -> send(token.getExpoPushToken(), event));
    }

    private void send(String token, NotificationCreatedEvent notification) {
        try {
            String json = "{\"to\":\"" + escape(token) + "\",\"title\":\"" + escape(notification.title()) + "\",\"body\":\"" + escape(notification.message()) + "\",\"data\":{\"notificationId\":" + notification.notificationId() + ",\"referenceType\":\"" + escape(notification.referenceType()) + "\",\"referenceId\":" + (notification.referenceId() == null ? "null" : notification.referenceId()) + "}}";
            HttpRequest request = HttpRequest.newBuilder(URI.create("https://exp.host/--/api/v2/push/send"))
                    .timeout(Duration.ofSeconds(10)).header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(json)).build();
            CLIENT.send(request, HttpResponse.BodyHandlers.discarding());
        } catch (Exception ignored) {
            // Push delivery must never affect persisted in-app notifications.
        }
    }
    private String escape(String value) { return value == null ? "" : value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", ""); }
}
