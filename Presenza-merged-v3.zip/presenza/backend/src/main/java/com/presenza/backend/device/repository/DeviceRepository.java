package com.presenza.backend.device.repository;

import com.presenza.backend.device.entity.Device;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DeviceRepository
        extends JpaRepository<Device, String> {

    List<Device> findByUserUserId(Integer userId);

    List<Device> findByUserUserIdAndActiveTrue(Integer userId);

    boolean existsByDeviceIdAndUserUserId(
            String deviceId,
            Integer userId
    );
}