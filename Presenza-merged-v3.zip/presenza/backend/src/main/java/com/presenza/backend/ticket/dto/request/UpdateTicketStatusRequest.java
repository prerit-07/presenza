package com.presenza.backend.ticket.dto.request;

import jakarta.validation.constraints.NotBlank;

public class UpdateTicketStatusRequest {

    @NotBlank(message = "Status is required")
    private String status;

    public UpdateTicketStatusRequest() {
    }

    public String getStatus() {
        return status;
    }
}