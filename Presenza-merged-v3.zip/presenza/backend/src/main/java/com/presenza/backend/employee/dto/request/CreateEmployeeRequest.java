package com.presenza.backend.employee.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public class CreateEmployeeRequest {

    @NotBlank
    @Size(max = 100)
    private String username;

    @NotBlank
    @Email
    @Size(max = 150)
    private String email;

    @NotBlank
    private String employeeName;

    private LocalDate dateOfJoining;

    private Integer departmentId;

    private Integer shiftId;

    private Integer teamId;

    public CreateEmployeeRequest() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public LocalDate getDateOfJoining() {
        return dateOfJoining;
    }

    public void setDateOfJoining(
            LocalDate dateOfJoining
    ) {
        this.dateOfJoining = dateOfJoining;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(
            Integer departmentId
    ) {
        this.departmentId = departmentId;
    }

    public Integer getShiftId() {
        return shiftId;
    }

    public void setShiftId(
            Integer shiftId
    ) {
        this.shiftId = shiftId;
    }

    public Integer getTeamId() {
        return teamId;
    }

    public void setTeamId(
            Integer teamId
    ) {
        this.teamId = teamId;
    }
}