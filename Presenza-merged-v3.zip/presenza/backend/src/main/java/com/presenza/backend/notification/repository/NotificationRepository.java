package com.presenza.backend.notification.repository;

import com.presenza.backend.notification.entity.Notification;
import com.presenza.backend.user.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationRepository
        extends JpaRepository<Notification, Integer> {

    List<Notification> findByRecipientOrderByCreatedAtDesc(
            User recipient
    );

    List<Notification> findByRecipientAndIsReadFalseOrderByCreatedAtDesc(
            User recipient
    );

    long countByRecipientAndIsReadFalse(
            User recipient
    );
}