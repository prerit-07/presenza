package com.presenza.backend.presence.entity;

import com.presenza.backend.checkin.entity.CheckIn;
import com.presenza.backend.presence.enums.PresenceEventType;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * A persisted EXIT or RETURN transition. Periodic snapshots are deliberately
 * omitted so the history remains an auditable transition timeline.
 */
@Entity
@Table(name = "presence_event")
public class PresenceEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "event_id")
    private Integer eventId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "checkin_id", nullable = false)
    private CheckIn checkIn;

    @Enumerated(EnumType.STRING)
    @Column(name = "event_type", nullable = false, length = 10)
    private PresenceEventType eventType;

    @Column(name = "event_timestamp", nullable = false,
            insertable = false, updatable = false)
    private OffsetDateTime eventTimestamp;

    @Column(name = "latitude")
    private BigDecimal latitude;

    @Column(name = "longitude")
    private BigDecimal longitude;

    @Column(name = "accuracy")
    private BigDecimal accuracy;

    @Column(name = "wifi_verified")
    private Boolean wifiVerified;

    @Column(name = "connected_ssid", length = 150)
    private String connectedSsid;

    @Column(name = "connected_bssid", length = 50)
    private String connectedBssid;

    protected PresenceEvent() {
    }

    public PresenceEvent(CheckIn checkIn, PresenceEventType eventType) {
        this.checkIn = checkIn;
        this.eventType = eventType;
    }

    public Integer getEventId() { return eventId; }
    public CheckIn getCheckIn() { return checkIn; }
    public PresenceEventType getEventType() { return eventType; }
    public OffsetDateTime getEventTimestamp() { return eventTimestamp; }
    public BigDecimal getLatitude() { return latitude; }
    public BigDecimal getLongitude() { return longitude; }
    public BigDecimal getAccuracy() { return accuracy; }
    public Boolean getWifiVerified() { return wifiVerified; }
    public String getConnectedSsid() { return connectedSsid; }
    public String getConnectedBssid() { return connectedBssid; }

    public void setLatitude(BigDecimal latitude) { this.latitude = latitude; }
    public void setLongitude(BigDecimal longitude) { this.longitude = longitude; }
    public void setAccuracy(BigDecimal accuracy) { this.accuracy = accuracy; }
    public void setWifiVerified(Boolean wifiVerified) { this.wifiVerified = wifiVerified; }
    public void setConnectedSsid(String connectedSsid) { this.connectedSsid = connectedSsid; }
    public void setConnectedBssid(String connectedBssid) { this.connectedBssid = connectedBssid; }
}
