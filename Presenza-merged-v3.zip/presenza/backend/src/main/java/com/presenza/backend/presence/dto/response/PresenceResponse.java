package com.presenza.backend.presence.dto.response;

import com.presenza.backend.presence.enums.PresenceEventType;
import com.presenza.backend.presence.enums.PresenceState;

import java.time.OffsetDateTime;

public class PresenceResponse {
    private final boolean eventGenerated;
    private final PresenceEventType eventType;
    private final PresenceState currentState;
    private final OffsetDateTime eventTimestamp;

    public PresenceResponse(boolean eventGenerated, PresenceEventType eventType,
                            PresenceState currentState,
                            OffsetDateTime eventTimestamp) {
        this.eventGenerated = eventGenerated;
        this.eventType = eventType;
        this.currentState = currentState;
        this.eventTimestamp = eventTimestamp;
    }

    public boolean isEventGenerated() { return eventGenerated; }
    public PresenceEventType getEventType() { return eventType; }
    public PresenceState getCurrentState() { return currentState; }
    public OffsetDateTime getEventTimestamp() { return eventTimestamp; }
}
