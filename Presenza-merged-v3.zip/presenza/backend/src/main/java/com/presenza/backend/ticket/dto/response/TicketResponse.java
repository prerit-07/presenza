package com.presenza.backend.ticket.dto.response;

import java.time.OffsetDateTime;

public class TicketResponse {

    private final Integer ticketId;
    private final Integer organizationId;
    private final Integer raisedByUserId;
    private final Integer assignedToEmployeeId;
    private final Integer checkinId;
    private final Integer attendanceId;
    private final String subject;
    private final String description;
    private final String status;
    private final OffsetDateTime createdAt;
    private final OffsetDateTime resolvedAt;

    public TicketResponse(
            Integer ticketId,
            Integer organizationId,
            Integer raisedByUserId,
            Integer assignedToEmployeeId,
            Integer checkinId,
            Integer attendanceId,
            String subject,
            String description,
            String status,
            OffsetDateTime createdAt,
            OffsetDateTime resolvedAt
    ) {
        this.ticketId = ticketId;
        this.organizationId = organizationId;
        this.raisedByUserId = raisedByUserId;
        this.assignedToEmployeeId = assignedToEmployeeId;
        this.checkinId = checkinId;
        this.attendanceId = attendanceId;
        this.subject = subject;
        this.description = description;
        this.status = status;
        this.createdAt = createdAt;
        this.resolvedAt = resolvedAt;
    }

    public Integer getTicketId() {
        return ticketId;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public Integer getRaisedByUserId() {
        return raisedByUserId;
    }

    public Integer getAssignedToEmployeeId() {
        return assignedToEmployeeId;
    }

    public Integer getCheckinId() {
        return checkinId;
    }

    public Integer getAttendanceId() {
        return attendanceId;
    }

    public String getSubject() {
        return subject;
    }

    public String getDescription() {
        return description;
    }

    public String getStatus() {
        return status;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public OffsetDateTime getResolvedAt() {
        return resolvedAt;
    }
}