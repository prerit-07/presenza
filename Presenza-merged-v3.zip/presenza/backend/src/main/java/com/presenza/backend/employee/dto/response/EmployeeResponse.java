package com.presenza.backend.employee.dto.response;

import java.time.LocalDate;

public class EmployeeResponse {

    private Integer employeeId;
    private Integer orgId;
    private Integer userId;
    private String employeeName;
    private LocalDate dateOfJoining;
    private Integer departmentId;
    private Integer shiftId;
    private Integer teamId;

    public EmployeeResponse() {
    }

    public EmployeeResponse(
            Integer employeeId,
            Integer orgId,
            Integer userId,
            String employeeName,
            LocalDate dateOfJoining,
            Integer departmentId,
            Integer shiftId,
            Integer teamId
    ) {
        this.employeeId = employeeId;
        this.orgId = orgId;
        this.userId = userId;
        this.employeeName = employeeName;
        this.dateOfJoining = dateOfJoining;
        this.departmentId = departmentId;
        this.shiftId = shiftId;
        this.teamId = teamId;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public Integer getOrgId() {
        return orgId;
    }

    public void setOrgId(Integer orgId) {
        this.orgId = orgId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public LocalDate getDateOfJoining() {
        return dateOfJoining;
    }

    public void setDateOfJoining(LocalDate dateOfJoining) {
        this.dateOfJoining = dateOfJoining;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    public Integer getShiftId() {
        return shiftId;
    }

    public void setShiftId(Integer shiftId) {
        this.shiftId = shiftId;
    }

    public Integer getTeamId() {
        return teamId;
    }

    public void setTeamId(Integer teamId) {
        this.teamId = teamId;
    }
}