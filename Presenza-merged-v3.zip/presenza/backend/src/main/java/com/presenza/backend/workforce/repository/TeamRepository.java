package com.presenza.backend.workforce.repository;

import com.presenza.backend.workforce.entity.Team;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TeamRepository
        extends JpaRepository<Team, Integer> {

    List<Team> findByOrganizationOrgId(Integer orgId);

}