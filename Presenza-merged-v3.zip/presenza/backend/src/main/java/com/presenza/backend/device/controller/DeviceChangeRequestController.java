package com.presenza.backend.device.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.device.dto.request.CreateDeviceChangeRequest;
import com.presenza.backend.device.dto.request.ReviewDeviceChangeRequest;
import com.presenza.backend.device.dto.response.DeviceChangeRequestResponse;
import com.presenza.backend.device.service.DeviceChangeRequestService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/device-change-requests")
public class DeviceChangeRequestController {

    private final DeviceChangeRequestService service;
    private final TokenService tokenService;

    public DeviceChangeRequestController(
            DeviceChangeRequestService service,
            TokenService tokenService
    ) {
        this.service = service;
        this.tokenService = tokenService;
    }

    @PostMapping
    public DeviceChangeRequestResponse createRequest(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody CreateDeviceChangeRequest request
    ) {
        AuthenticatedUser user =
                authenticate(authorizationHeader);

        return service.createRequest(
                user.getUserId(),
                request
        );
    }

    @GetMapping("/me")
    public List<DeviceChangeRequestResponse> getMyRequests(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser user =
                authenticate(authorizationHeader);

        return service.getMyRequests(
                user.getUserId()
        );
    }

    @GetMapping("/pending")
    public List<DeviceChangeRequestResponse> getPendingRequests(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser user =
                authenticate(authorizationHeader);

        return service.getPendingRequests(
                user.getOrganizationId(),
                user.getRole()
        );
    }

    @PatchMapping("/{requestId}/review")
    public DeviceChangeRequestResponse reviewRequest(
            @PathVariable Integer requestId,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody ReviewDeviceChangeRequest request
    ) {
        AuthenticatedUser user =
                authenticate(authorizationHeader);

        return service.reviewRequest(
                requestId,
                user.getUserId(),
                user.getOrganizationId(),
                user.getRole(),
                request
        );
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {
        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        return tokenService.getAuthenticatedUser(
                authorizationHeader.substring(7)
        );
    }
}