package com.presenza.backend.push.repository;

import com.presenza.backend.push.entity.PushToken;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface PushTokenRepository extends JpaRepository<PushToken, Integer> {
    Optional<PushToken> findByExpoPushToken(String expoPushToken);
    List<PushToken> findByUserUserIdAndActiveTrue(Integer userId);
    List<PushToken> findByUserUserIdAndDeviceIdAndActiveTrue(Integer userId, String deviceId);
}
