package com.presenza.backend.attendance.repository;

import com.presenza.backend.attendance.entity.AttendanceRequest;
import com.presenza.backend.attendance.entity.AttendanceRequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AttendanceRequestRepository
        extends JpaRepository<AttendanceRequest, Integer> {

    List<AttendanceRequest>
    findByEmployeeUserUserIdOrderByRequestIdDesc(
            Integer userId
    );

    List<AttendanceRequest>
    findByEmployeeOrganizationOrgIdOrderByRequestIdDesc(
            Integer organizationId
    );

    List<AttendanceRequest>
    findByEmployeeOrganizationOrgIdAndStatusOrderByRequestIdDesc(
            Integer organizationId,
            AttendanceRequestStatus status
    );
}