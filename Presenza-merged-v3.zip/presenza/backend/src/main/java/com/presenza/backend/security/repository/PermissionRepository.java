package com.presenza.backend.security.repository;

import com.presenza.backend.security.entity.Permission;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PermissionRepository
        extends JpaRepository<Permission, Integer> {
}