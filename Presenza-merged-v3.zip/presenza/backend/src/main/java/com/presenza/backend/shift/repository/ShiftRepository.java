package com.presenza.backend.shift.repository;

import com.presenza.backend.shift.entity.Shift;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ShiftRepository
        extends JpaRepository<Shift, Integer> {

    List<Shift> findByOrganizationOrgId(Integer orgId);

}