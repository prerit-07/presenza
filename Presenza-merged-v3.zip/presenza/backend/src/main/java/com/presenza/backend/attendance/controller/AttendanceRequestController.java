package com.presenza.backend.attendance.controller;

import com.presenza.backend.attendance.dto.request.CreateAttendanceRequest;
import com.presenza.backend.attendance.dto.request.ReviewAttendanceRequestDecision;
import com.presenza.backend.attendance.dto.response.AttendanceRequestResponse;
import com.presenza.backend.attendance.service.AttendanceRequestService;
import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/attendance-requests")
public class AttendanceRequestController {

    private final AttendanceRequestService attendanceRequestService;
    private final TokenService tokenService;

    public AttendanceRequestController(
            AttendanceRequestService attendanceRequestService,
            TokenService tokenService
    ) {
        this.attendanceRequestService =
                attendanceRequestService;
        this.tokenService =
                tokenService;
    }

    @PostMapping
    public AttendanceRequestResponse createRequest(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody CreateAttendanceRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return attendanceRequestService.createRequest(
                authenticatedUser.getUserId(),
                authenticatedUser.getOrganizationId(),
                request
        );
    }

    @GetMapping("/me")
    public List<AttendanceRequestResponse> getMyRequests(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return attendanceRequestService.getMyRequests(
                authenticatedUser.getUserId()
        );
    }

    @GetMapping
    public List<AttendanceRequestResponse>
    getOrganizationRequests(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return attendanceRequestService
                .getOrganizationRequests(
                        authenticatedUser.getOrganizationId(),
                        authenticatedUser.getRole()
                );
    }

    @GetMapping("/pending")
    public List<AttendanceRequestResponse> getPendingRequests(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return attendanceRequestService
                .getPendingRequests(
                        authenticatedUser.getOrganizationId(),
                        authenticatedUser.getRole()
                );
    }

    @PatchMapping("/{requestId}/review")
    public AttendanceRequestResponse reviewRequest(
            @PathVariable Integer requestId,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody
            ReviewAttendanceRequestDecision request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return attendanceRequestService.reviewRequest(
                requestId,
                authenticatedUser.getUserId(),
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        );
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {
        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        return tokenService.getAuthenticatedUser(
                authorizationHeader.substring(7)
        );
    }
}