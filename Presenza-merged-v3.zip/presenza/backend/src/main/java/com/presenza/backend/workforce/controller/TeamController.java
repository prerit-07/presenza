package com.presenza.backend.workforce.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.workforce.dto.request.TeamRequest;
import com.presenza.backend.workforce.dto.response.TeamResponse;
import com.presenza.backend.employee.dto.response.EmployeeResponse;
import com.presenza.backend.workforce.dto.response.TeamMateResponse;
import com.presenza.backend.workforce.service.TeamService;
import org.springframework.format.annotation.DateTimeFormat;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.time.LocalDate;

@RestController
@RequestMapping("/api/teams")
public class TeamController {

    private final TeamService teamService;
    private final TokenService tokenService;

    public TeamController(
            TeamService teamService,
            TokenService tokenService
    ) {
        this.teamService = teamService;
        this.tokenService = tokenService;
    }

    @PostMapping
    public TeamResponse createTeam(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody TeamRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return teamService.createTeam(
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        );
    }

    @GetMapping("/{id}")
    public TeamResponse getTeamById(
            @PathVariable Integer id,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return teamService.getTeamById(
                id,
                authenticatedUser.getOrganizationId()
        );
    }

    @GetMapping
    public List<TeamResponse> getTeamsByOrganization(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return teamService.getTeamsByOrganization(
                authenticatedUser.getOrganizationId()
        );
    }

    @GetMapping("/me/members")
    public List<EmployeeResponse> getMyTeamMembers(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return teamService.getMyTeamMembers(
                authenticatedUser.getUserId(),
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole()
        );
    }

    @GetMapping("/me/teammates")
    public List<TeamMateResponse> getMyTeammates(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate date
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return teamService.getMyTeammates(
                authenticatedUser.getUserId(),
                authenticatedUser.getOrganizationId(),
                date
        );
    }

    @PutMapping("/{id}")
    public TeamResponse updateTeam(
            @PathVariable Integer id,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody TeamRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return teamService.updateTeam(
                id,
                authenticatedUser.getOrganizationId(),
                authenticatedUser.getRole(),
                request
        );
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {
        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        return tokenService.getAuthenticatedUser(
                authorizationHeader.substring(7)
        );
    }
}
