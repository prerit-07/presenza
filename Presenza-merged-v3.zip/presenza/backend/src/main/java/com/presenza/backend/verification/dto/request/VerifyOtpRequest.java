package com.presenza.backend.verification.dto.request;

import com.presenza.backend.verification.VerificationPurpose;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class VerifyOtpRequest {

    @NotBlank
    @Email
    private String email;

    @NotBlank
    private String otp;

    @NotNull
    private VerificationPurpose purpose;

    public VerifyOtpRequest() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public VerificationPurpose getPurpose() {
        return purpose;
    }

    public void setPurpose(
            VerificationPurpose purpose
    ) {
        this.purpose = purpose;
    }
}