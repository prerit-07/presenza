package com.presenza.backend.verification.service;

import com.presenza.backend.common.exception.BadRequestException;
import com.presenza.backend.email.service.EmailService;
import com.presenza.backend.verification.VerificationPurpose;
import com.presenza.backend.verification.dto.response.VerificationResponse;
import com.presenza.backend.verification.dto.response.CompanyCodeVerificationResponse;
import com.presenza.backend.verification.entity.EmailVerification;
import com.presenza.backend.verification.repository.EmailVerificationRepository;
import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.organisation.repository.OrganizationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.OffsetDateTime;

@Service
public class VerificationService {

    private static final long OTP_EXPIRY_MINUTES = 5;
    private static final int MAX_OTP_ATTEMPTS = 5;

    private final EmailVerificationRepository verificationRepository;
    private final EmailService emailService;
    private final OrganizationRepository organizationRepository;
    private final SecureRandom secureRandom = new SecureRandom();

    public VerificationService(
            EmailVerificationRepository verificationRepository,
            EmailService emailService,
            OrganizationRepository organizationRepository
    ) {
        this.verificationRepository = verificationRepository;
        this.emailService = emailService;
        this.organizationRepository = organizationRepository;
    }

    @Transactional(readOnly = true)
    public CompanyCodeVerificationResponse verifyCompanyCode(
            String companyCode
    ) {
        Organization organization = organizationRepository
                .findByCompanyCodeIgnoreCase(companyCode.trim())
                .orElseThrow(() -> new BadRequestException(
                        "Invalid company code."
                ));

        return new CompanyCodeVerificationResponse(
                true,
                organization.getOrgId(),
                organization.getOrgName()
        );
    }

    @Transactional
    public VerificationResponse sendOtp(
            String email,
            VerificationPurpose purpose
    ) {

        email = normalizeEmail(email);

        verificationRepository.deleteByEmailAndPurpose(
                email,
                purpose
        );

        String otp = generateOtp();

        EmailVerification verification =
                new EmailVerification(
                        email,
                        otp,
                        purpose,
                        now().plusMinutes(OTP_EXPIRY_MINUTES)
                );

        verification = verificationRepository.save(
                verification
        );

        try {

            emailService.sendOtp(
                    email,
                    otp,
                    purpose
            );

        } catch (Exception exception) {

            verificationRepository.delete(verification);

            throw new BadRequestException(
                    "Failed to send OTP email."
            );
        }

        return new VerificationResponse(
                true,
                "OTP sent successfully."
        );
    }

    @Transactional
    public VerificationResponse verifyOtp(
            String email,
            String otp,
            VerificationPurpose purpose
    ) {

        email = normalizeEmail(email);

        EmailVerification verification =
                verificationRepository
                        .findTopByEmailAndPurposeAndVerifiedFalseOrderByCreatedAtDesc(
                                email,
                                purpose
                        )
                        .orElseThrow(() ->
                                new BadRequestException(
                                        "No OTP found. Please request a new one."
                                )
                        );

        if (verification.getExpiresAt().isBefore(now())) {

            verificationRepository.delete(verification);

            throw new BadRequestException(
                    "OTP has expired. Please request a new one."
            );
        }

        if (verification.getAttemptCount() != null
                && verification.getAttemptCount() >= MAX_OTP_ATTEMPTS) {

            verificationRepository.delete(verification);

            throw new BadRequestException(
                    "Too many incorrect attempts. Please request a new OTP."
            );
        }

        if (!verification.getOtp().equals(otp.trim())) {

            verification.setAttemptCount(
                    (verification.getAttemptCount() == null ? 0 : verification.getAttemptCount()) + 1
            );
            verificationRepository.save(verification);

            throw new BadRequestException(
                    "Invalid OTP."
            );
        }

        verification.setVerified(true);
        verification.setVerifiedAt(now());

        verificationRepository.save(
                verification
        );

        return new VerificationResponse(
                true,
                "OTP verified successfully."
        );
    }

    private String generateOtp() {

        int otp =
                secureRandom.nextInt(900000)
                        + 100000;

        return String.valueOf(otp);
    }

    private String normalizeEmail(
            String email
    ) {

        return email
                .trim()
                .toLowerCase();
    }

    private OffsetDateTime now() {

        return OffsetDateTime.now();
    }
}
