package com.presenza.backend.geofence.controller;

import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.geofence.dto.request.GeofenceRequest;
import com.presenza.backend.geofence.dto.response.GeofenceResponse;
import com.presenza.backend.geofence.service.GeofenceService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/geofences")
public class GeofenceController {

    private final GeofenceService geofenceService;
    private final TokenService tokenService;

    public GeofenceController(
            GeofenceService geofenceService,
            TokenService tokenService
    ) {
        this.geofenceService = geofenceService;
        this.tokenService = tokenService;
    }

    @PostMapping
    public GeofenceResponse createGeofence(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody GeofenceRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return geofenceService.createGeofence(
                authenticatedUser,
                request
        );
    }

    @GetMapping("/{id}")
    public GeofenceResponse getGeofenceById(
            @PathVariable Integer id,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return geofenceService.getGeofenceById(
                authenticatedUser,
                id
        );
    }

    @GetMapping
    public List<GeofenceResponse> getGeofencesByOrganization(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return geofenceService.getGeofencesByOrganization(
                authenticatedUser,
                authenticatedUser.getOrganizationId()
        );
    }

    @PutMapping("/{id}")
    public GeofenceResponse updateGeofence(
            @PathVariable Integer id,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader,
            @Valid @RequestBody GeofenceRequest request
    ) {
        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        return geofenceService.updateGeofence(
                authenticatedUser,
                id,
                request
        );
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {
        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        return tokenService.getAuthenticatedUser(
                authorizationHeader.substring(7)
        );
    }
    @DeleteMapping("/{id}")
    public org.springframework.http.ResponseEntity<Void> deleteGeofence(
            @PathVariable Integer id,
            @RequestHeader(
                    value = "Authorization",
                    required = false
            ) String authorizationHeader
    ) {
        AuthenticatedUser authenticatedUser = authenticate(authorizationHeader);
        geofenceService.deleteGeofence(authenticatedUser, id);
        return org.springframework.http.ResponseEntity.noContent().build();
    }
}