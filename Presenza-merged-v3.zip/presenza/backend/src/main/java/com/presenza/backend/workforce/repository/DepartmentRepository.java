package com.presenza.backend.workforce.repository;

import com.presenza.backend.workforce.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DepartmentRepository
        extends JpaRepository<Department, Integer> {

    List<Department> findByOrganizationOrgId(Integer orgId);

}