package com.presenza.backend.attendance.entity;

public enum AttendanceRequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}