package com.presenza.backend.checkin.service;

import com.presenza.backend.attendance.entity.Attendance;
import com.presenza.backend.attendance.entity.AttendanceStatus;
import com.presenza.backend.attendance.repository.AttendanceRepository;
import com.presenza.backend.checkin.dto.request.EmployeeCheckInRequest;
import com.presenza.backend.checkin.dto.response.CheckInResponse;
import com.presenza.backend.checkin.entity.CheckIn;
import com.presenza.backend.checkin.repository.CheckInRepository;
import com.presenza.backend.common.exception.BadRequestException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.common.util.GeofenceDistanceCalculator;
import com.presenza.backend.device.entity.Device;
import com.presenza.backend.device.repository.DeviceRepository;
import com.presenza.backend.employee.entity.Employee;
import com.presenza.backend.employee.repository.EmployeeRepository;
import com.presenza.backend.geofence.entity.Geofence;
import com.presenza.backend.geofence.entity.WifiNetwork;
import com.presenza.backend.geofence.repository.WifiNetworkRepository;
import com.presenza.backend.shift.entity.Shift;
import com.presenza.backend.shift.repository.ShiftRepository;
import com.presenza.backend.user.entity.User;
import com.presenza.backend.user.repository.UserRepository;
import jakarta.persistence.EntityManager;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;

@Service
public class CheckInService {

    private static final ZoneId ORGANIZATION_TIME_ZONE =
            ZoneId.of("Asia/Kolkata");

    private static final long EARLY_CHECK_IN_MINUTES = 30;

    private final CheckInRepository checkInRepository;
    private final AttendanceRepository attendanceRepository;
    private final EmployeeRepository employeeRepository;
    private final UserRepository userRepository;
    private final ShiftRepository shiftRepository;
    private final DeviceRepository deviceRepository;
    private final WifiNetworkRepository wifiNetworkRepository;
    private final EntityManager entityManager;

    public CheckInService(
            CheckInRepository checkInRepository,
            AttendanceRepository attendanceRepository,
            EmployeeRepository employeeRepository,
            UserRepository userRepository,
            ShiftRepository shiftRepository,
            DeviceRepository deviceRepository,
            WifiNetworkRepository wifiNetworkRepository,
            EntityManager entityManager
    ) {
        this.checkInRepository = checkInRepository;
        this.attendanceRepository = attendanceRepository;
        this.employeeRepository = employeeRepository;
        this.userRepository = userRepository;
        this.shiftRepository = shiftRepository;
        this.deviceRepository = deviceRepository;
        this.wifiNetworkRepository = wifiNetworkRepository;
        this.entityManager = entityManager;
    }

    @Transactional
    public CheckInResponse employeeCheckIn(
            Integer userId,
            Integer organizationId,
            EmployeeCheckInRequest request
    ) {
        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found with id: " + userId
                        )
                );

        Employee employee = employeeRepository
                .findByUserUserId(userId)
                .orElseThrow(() ->
                        new BadRequestException(
                                "Authenticated user is not registered as an employee"
                        )
                );

        if (!employee.getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new BadRequestException(
                    "Employee does not belong to the authenticated organization"
            );
        }

        if (employee.getShift() == null) {
            throw new BadRequestException(
                    "Employee does not have a shift assigned"
            );
        }

        if (!employee.getShift()
                .getShiftId()
                .equals(request.getShiftId())) {
            throw new BadRequestException(
                    "Employee is not assigned to the requested shift"
            );
        }

        Shift shift = shiftRepository.findById(request.getShiftId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Shift not found with id: "
                                        + request.getShiftId()
                        )
                );

        if (!shift.getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Shift not found with id: "
                            + request.getShiftId()
            );
        }

        LocalDate today = LocalDate.now(ORGANIZATION_TIME_ZONE);
        LocalTime currentTime = LocalTime.now(ORGANIZATION_TIME_ZONE);
        boolean crossesMidnight = !shift.getEndTime()
                .isAfter(shift.getStartTime());

        // A check-in at 12:20 AM for a 10 PM-6 AM shift belongs to the
        // previous day's shift, not the following evening's shift.
        LocalDate shiftStartDate = crossesMidnight
                && !currentTime.isAfter(shift.getEndTime())
                && !shift.getEndTime().equals(shift.getStartTime())
                ? today.minusDays(1)
                : today;

        OffsetDateTime shiftStart = shiftStartDate
                .atTime(shift.getStartTime())
                .atZone(ORGANIZATION_TIME_ZONE)
                .toOffsetDateTime();
        OffsetDateTime earliestAllowedCheckIn = shiftStart
                .minusMinutes(EARLY_CHECK_IN_MINUTES);
        OffsetDateTime shiftEnd = (crossesMidnight
                ? shiftStartDate.plusDays(1)
                : shiftStartDate)
                .atTime(shift.getEndTime())
                .atZone(ORGANIZATION_TIME_ZONE)
                .toOffsetDateTime();
        OffsetDateTime now = OffsetDateTime.now(ORGANIZATION_TIME_ZONE);

        if (now.isBefore(earliestAllowedCheckIn)) {
            throw new BadRequestException(
                    "Check-in is not open yet"
            );
        }

        if (now.isAfter(shiftEnd)) {
            throw new BadRequestException(
                    "Check-in window has closed"
            );
        }

        Device device = deviceRepository.findById(request.getDeviceId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Device not found with id: "
                                        + request.getDeviceId()
                        )
                );

        if (!device.getUser()
                .getUserId()
                .equals(userId)) {
            throw new ResourceNotFoundException(
                    "Device not found with id: "
                            + request.getDeviceId()
            );
        }

        if (!Boolean.TRUE.equals(device.getActive())) {
            throw new BadRequestException(
                    "Device is inactive"
            );
        }

        Geofence geofence = shift.getGeofence();

        if (geofence == null) {
            throw new BadRequestException(
                    "Shift does not have a geofence configured"
            );
        }

        if (request.getLatitude() == null ||
                request.getLongitude() == null) {
            throw new BadRequestException(
                    "Latitude and longitude are required for check-in"
            );
        }

        double distanceMeters = GeofenceDistanceCalculator
                .calculateDistanceMeters(
                request.getLatitude().doubleValue(),
                request.getLongitude().doubleValue(),
                geofence.getLatitude().doubleValue(),
                geofence.getLongitude().doubleValue()
        );

        if (distanceMeters > geofence.getRadius()) {
            throw new BadRequestException(
                    "User is outside the allowed geofence"
            );
        }

        boolean alreadyCheckedIn =
                checkInRepository
                        .existsByUserUserIdAndShiftShiftIdAndCheckinTimeBetween(
                                userId,
                                shift.getShiftId(),
                                earliestAllowedCheckIn,
                                shiftEnd
                        );

        if (alreadyCheckedIn) {
            throw new BadRequestException(
                    "User has already checked in for this shift today"
            );
        }

        WifiNetwork wifiNetwork = null;
        boolean wifiVerified = false;

        if (request.getConnectedBssid() != null &&
                !request.getConnectedBssid().isBlank()) {

            wifiNetwork = wifiNetworkRepository
                    .findByBssidAndIsActiveTrue(
                            request.getConnectedBssid()
                    )
                    .orElse(null);

            if (wifiNetwork != null) {
                boolean sameGeofence =
                        wifiNetwork.getGeofence()
                                .getGeofenceId()
                                .equals(geofence.getGeofenceId());

                boolean sameSsid =
                        request.getConnectedSsid() != null &&
                                request.getConnectedSsid().equals(
                                        wifiNetwork.getSsid()
                                );

                wifiVerified =
                        sameGeofence && sameSsid;
            }
        }

        CheckIn checkIn = new CheckIn(
                user,
                shift,
                device,
                wifiNetwork,
                request.getConnectedSsid(),
                request.getConnectedBssid(),
                request.getLatitude(),
                request.getLongitude(),
                request.getDeviceInfo(),
                request.getAccuracy()
        );

        CheckIn savedCheckIn;
        try {
            savedCheckIn = checkInRepository.saveAndFlush(checkIn);
        } catch (DataIntegrityViolationException exception) {
            // Guards against the race where two concurrent requests both pass
            // the existsBy... check above before either commits; the DB-level
            // unique index (user_id, shift_id, day) is the real source of truth.
            throw new BadRequestException(
                    "User has already checked in for this shift today"
            );
        }

        entityManager.refresh(savedCheckIn);

        if (wifiVerified) {
            savedCheckIn.setWifiVerified(true);
            checkInRepository.saveAndFlush(savedCheckIn);
        }

        AttendanceStatus attendanceStatus =
                wifiVerified
                        ? AttendanceStatus.PRESENT
                        : AttendanceStatus.PENDING;

        String remarks =
                wifiVerified
                        ? "Automatically verified by geofence and trusted WiFi"
                        : "Pending review because trusted WiFi verification failed";

        Attendance attendance = new Attendance(
                savedCheckIn,
                attendanceStatus,
                remarks
        );

        attendanceRepository.save(attendance);

        return toResponse(savedCheckIn);
    }

    private CheckInResponse toResponse(
            CheckIn checkIn
    ) {
        return new CheckInResponse(
                checkIn.getCheckinId(),
                checkIn.getUser().getUserId(),
                checkIn.getShift() != null
                        ? checkIn.getShift().getShiftId()
                        : null,
                checkIn.getDevice() != null
                        ? checkIn.getDevice().getDeviceId()
                        : null,
                checkIn.getWifiNetwork() != null
                        ? checkIn.getWifiNetwork().getWifiId()
                        : null,
                checkIn.getConnectedSsid(),
                checkIn.getConnectedBssid(),
                checkIn.getWifiVerified(),
                checkIn.getCheckinTime(),
                checkIn.getLatitude(),
                checkIn.getLongitude(),
                checkIn.getDeviceInfo(),
                checkIn.getAccuracy()
        );
    }

}
