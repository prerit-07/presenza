package com.presenza.backend.ticket.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class CreateTicketRequest {

    @NotBlank(message = "Subject is required")
    @Size(max = 200, message = "Subject must not exceed 200 characters")
    private String subject;

    @Size(max = 5000, message = "Description must not exceed 5000 characters")
    private String description;

    private Integer checkinId;

    private Integer attendanceId;

    public CreateTicketRequest() {
    }

    public String getSubject() {
        return subject;
    }

    public String getDescription() {
        return description;
    }

    public Integer getCheckinId() {
        return checkinId;
    }

    public Integer getAttendanceId() {
        return attendanceId;
    }
}