package com.presenza.backend.device.service;

import com.presenza.backend.common.exception.BadRequestException;
import com.presenza.backend.common.exception.ForbiddenException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.device.dto.request.CreateDeviceChangeRequest;
import com.presenza.backend.device.dto.request.ReviewDeviceChangeRequest;
import com.presenza.backend.device.dto.response.DeviceChangeRequestResponse;
import com.presenza.backend.device.entity.Device;
import com.presenza.backend.device.entity.DeviceChangeRequest;
import com.presenza.backend.device.entity.DeviceChangeRequestStatus;
import com.presenza.backend.device.repository.DeviceChangeRequestRepository;
import com.presenza.backend.device.repository.DeviceRepository;
import com.presenza.backend.employee.entity.Employee;
import com.presenza.backend.employee.repository.EmployeeRepository;
import com.presenza.backend.notification.NotificationType;
import com.presenza.backend.notification.service.NotificationService;
import com.presenza.backend.user.entity.User;
import com.presenza.backend.user.repository.UserRepository;
import jakarta.persistence.EntityManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

@Service
public class DeviceChangeRequestService {

    private final DeviceChangeRequestRepository requestRepository;
    private final DeviceRepository deviceRepository;
    private final UserRepository userRepository;
    private final EmployeeRepository employeeRepository;
    private final EntityManager entityManager;
    private final NotificationService notificationService;

    public DeviceChangeRequestService(
            DeviceChangeRequestRepository requestRepository,
            DeviceRepository deviceRepository,
            UserRepository userRepository,
            EmployeeRepository employeeRepository,
            EntityManager entityManager,
            NotificationService notificationService
    ) {
        this.requestRepository = requestRepository;
        this.deviceRepository = deviceRepository;
        this.userRepository = userRepository;
        this.employeeRepository = employeeRepository;
        this.entityManager = entityManager;
        this.notificationService = notificationService;
    }

    @Transactional
    public DeviceChangeRequestResponse createRequest(
            Integer userId,
            CreateDeviceChangeRequest request
    ) {
        if (request.getOldDeviceId()
                .equals(request.getNewDeviceId())) {
            throw new BadRequestException(
                    "New device ID must be different from old device ID"
            );
        }

        if (requestRepository.existsByUserUserIdAndStatus(
                userId,
                DeviceChangeRequestStatus.PENDING
        )) {
            throw new BadRequestException(
                    "A pending device change request already exists"
            );
        }

        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found"
                        )
                );

        Device oldDevice = deviceRepository
                .findById(request.getOldDeviceId())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Old device not found"
                        )
                );

        if (!oldDevice.getUser()
                .getUserId()
                .equals(userId)) {
            throw new ResourceNotFoundException(
                    "Old device not found"
            );
        }

        if (!Boolean.TRUE.equals(oldDevice.getActive())) {
            throw new BadRequestException(
                    "Old device is already inactive"
            );
        }

        if (deviceRepository.existsById(
                request.getNewDeviceId()
        )) {
            throw new BadRequestException(
                    "New device ID is already registered"
            );
        }

        DeviceChangeRequest changeRequest =
                new DeviceChangeRequest(
                        user,
                        oldDevice,
                        request.getNewDeviceId(),
                        request.getReason()
                );

        changeRequest.setStatus(
                DeviceChangeRequestStatus.PENDING
        );

        DeviceChangeRequest saved =
                requestRepository.saveAndFlush(changeRequest);

        entityManager.refresh(saved);

        notificationService.notifyOrganizationRole(
                user.getOrganization().getOrgId(), "ORG_ADMIN",
                NotificationType.DEVICE_CHANGE_REQUEST,
                "Device change request pending",
                user.getUsername() + " requested a device change.",
                "DEVICE_CHANGE_REQUEST", saved.getRequestId()
        );

        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<DeviceChangeRequestResponse> getMyRequests(
            Integer userId
    ) {
        return requestRepository
                .findByUserUserIdOrderByRequestIdDesc(userId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<DeviceChangeRequestResponse> getPendingRequests(
            Integer organizationId,
            String role
    ) {
        validateAdmin(role);

        return requestRepository
                .findByUserOrganizationOrgIdAndStatusOrderByRequestIdDesc(
                        organizationId,
                        DeviceChangeRequestStatus.PENDING
                )
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional
    public DeviceChangeRequestResponse reviewRequest(
            Integer requestId,
            Integer reviewerUserId,
            Integer organizationId,
            String role,
            ReviewDeviceChangeRequest review
    ) {
        validateAdmin(role);

        DeviceChangeRequest request =
                requestRepository.findById(requestId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Device change request not found"
                                )
                        );

        if (!request.getUser()
                .getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Device change request not found"
            );
        }

        if (request.getStatus()
                != DeviceChangeRequestStatus.PENDING) {
            throw new BadRequestException(
                    "Only pending device change requests can be reviewed"
            );
        }

        // An organization admin may not have an Employee profile. The role
        // check above remains the authorization source in that case.
        Employee reviewer = employeeRepository
                .findByUserUserId(reviewerUserId)
                .orElse(null);

        if (reviewer != null && !reviewer.getOrganization()
                .getOrgId()
                .equals(organizationId)) {
            throw new ForbiddenException(
                    "Reviewer does not belong to organization"
            );
        }

        if (Boolean.TRUE.equals(review.getApproved())) {
            Device oldDevice = request.getOldDevice();

            if (oldDevice != null &&
                    Boolean.TRUE.equals(oldDevice.getActive())) {
                oldDevice.setActive(false);
                oldDevice.setLastSeenAt(OffsetDateTime.now());
                deviceRepository.save(oldDevice);
            }

            request.setStatus(
                    DeviceChangeRequestStatus.APPROVED
            );
        } else {
            request.setStatus(
                    DeviceChangeRequestStatus.REJECTED
            );
        }

        request.setReviewedBy(reviewer);
        request.setReviewedAt(OffsetDateTime.now());

        DeviceChangeRequest saved = requestRepository.save(request);
        notificationService.createNotification(
                organizationId, request.getUser().getUserId(),
                NotificationType.DEVICE_CHANGE_REQUEST,
                "Device change request " + request.getStatus().name().toLowerCase(),
                "Your device change request was " + request.getStatus().name().toLowerCase() + ".",
                "DEVICE_CHANGE_REQUEST", saved.getRequestId()
        );
        return toResponse(saved);
    }

    private void validateAdmin(String role) {
        if (!"ORG_ADMIN".equals(role)) {
            throw new ForbiddenException(
                    "Only organization admins can review device change requests"
            );
        }
    }

    private DeviceChangeRequestResponse toResponse(
            DeviceChangeRequest request
    ) {
        return new DeviceChangeRequestResponse(
                request.getRequestId(),
                request.getUser().getUserId(),
                request.getOldDevice() != null
                        ? request.getOldDevice().getDeviceId()
                        : null,
                request.getNewDeviceId(),
                request.getReason(),
                request.getStatus().name(),
                request.getReviewedBy() != null
                        ? request.getReviewedBy().getEmployeeId()
                        : null,
                request.getRequestedAt(),
                request.getReviewedAt()
        );
    }
}
