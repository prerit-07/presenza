package com.presenza.backend.auth.dto.response;

public class CurrentUserResponse {

    private final Integer userId;
    private final String username;
    private final String email;
    private final String role;

    public CurrentUserResponse(
            Integer userId,
            String username,
            String email,
            String role
    ) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.role = role;
    }

    public Integer getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }
}