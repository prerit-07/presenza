package com.presenza.backend.organisation.service;

import com.presenza.backend.common.exception.ForbiddenException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.organisation.dto.request.OrganizationUpdateRequest;
import com.presenza.backend.organisation.dto.request.PresenceSettingsUpdateRequest;
import com.presenza.backend.organisation.dto.response.OrganizationResponse;
import com.presenza.backend.organisation.dto.response.PresenceSettingsResponse;
import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.organisation.repository.OrganizationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrganizationService {

    private final OrganizationRepository organizationRepository;

    public OrganizationService(
            OrganizationRepository organizationRepository
    ) {
        this.organizationRepository = organizationRepository;
    }

    @Transactional(readOnly = true)
    public OrganizationResponse getOrganization(
            Integer organizationId
    ) {
        return toResponse(
                findOrganization(organizationId)
        );
    }

    @Transactional
    public OrganizationResponse updateOrganization(
            Integer organizationId,
            String role,
            OrganizationUpdateRequest request
    ) {
        if (!"ORG_ADMIN".equals(role)) {
            throw new ForbiddenException(
                    "Only organization admins can update organization settings"
            );
        }

        Organization organization =
                findOrganization(organizationId);

        organization.setOrgName(request.getOrgName());
        organization.setOrgType(request.getOrgType());

        // maxAllowedEmployee is intentionally not client-controlled.
        // It should be managed by plan/subscription logic.

        return toResponse(
                organizationRepository.save(organization)
        );
    }

    @Transactional(readOnly = true)
    public PresenceSettingsResponse getPresenceSettings(
            Integer organizationId,
            String role
    ) {
        // Employees need these read-only settings to start monitoring with
        // their organization's configured interval. Updates remain admin-only.
        return toPresenceSettingsResponse(findOrganization(organizationId));
    }

    @Transactional
    public PresenceSettingsResponse updatePresenceSettings(
            Integer organizationId,
            String role,
            PresenceSettingsUpdateRequest request
    ) {
        validateOrganizationAdmin(role);

        Organization organization = findOrganization(organizationId);
        organization.setPresenceMonitoringEnabled(
                request.getPresenceMonitoringEnabled()
        );
        organization.setPresenceUpdateIntervalSeconds(
                request.getPresenceUpdateIntervalSeconds()
        );
        organization.setRequireTrustedWifi(
                request.getRequireTrustedWifi()
        );

        return toPresenceSettingsResponse(
                organizationRepository.save(organization)
        );
    }

    private Organization findOrganization(
            Integer organizationId
    ) {
        return organizationRepository
                .findById(organizationId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Organization not found with id: "
                                        + organizationId
                        )
                );
    }

    private void validateOrganizationAdmin(String role) {
        if (!"ORG_ADMIN".equals(role)) {
            throw new ForbiddenException(
                    "Only organization admins can update organization settings"
            );
        }
    }

    private PresenceSettingsResponse toPresenceSettingsResponse(
            Organization organization
    ) {
        return new PresenceSettingsResponse(
                organization.getPresenceMonitoringEnabled(),
                organization.getPresenceUpdateIntervalSeconds(),
                organization.getRequireTrustedWifi()
        );
    }

    private OrganizationResponse toResponse(
            Organization organization
    ) {
        return new OrganizationResponse(
                organization.getOrgId(),
                organization.getOrgName(),
                organization.getCompanyCode(),
                organization.getPlan() != null
                        ? organization.getPlan().getPlanId()
                        : null,
                organization.getPlan() != null
                        ? organization.getPlan().getPlanName()
                        : null,
                organization.getOrgType().name(),
                organization.getMaxAllowedEmployee(),
                organization.getCreatedAt()
        );
    }
}
