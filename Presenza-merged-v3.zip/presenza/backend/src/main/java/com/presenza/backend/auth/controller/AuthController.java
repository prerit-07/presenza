package com.presenza.backend.auth.controller;

import com.presenza.backend.auth.dto.request.ForgotPasswordRequest;
import com.presenza.backend.auth.dto.request.ResetPasswordRequest;
import com.presenza.backend.verification.dto.response.VerificationResponse;
import com.presenza.backend.auth.dto.request.ChangePasswordRequest;
import com.presenza.backend.auth.dto.request.LoginRequest;
import com.presenza.backend.auth.dto.request.RegisterRequest;
import com.presenza.backend.auth.dto.response.CurrentUserResponse;
import com.presenza.backend.auth.dto.response.LoginResponse;
import com.presenza.backend.auth.dto.response.RegisterResponse;
import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.service.AuthService;
import com.presenza.backend.auth.service.TokenService;
import com.presenza.backend.common.dto.response.MessageResponse;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;
    private final TokenService tokenService;

    public AuthController(
            AuthService authService,
            TokenService tokenService
    ) {
        this.authService = authService;
        this.tokenService = tokenService;
    }

    @PostMapping("/register")
    public ResponseEntity<RegisterResponse> register(
            @Valid
            @RequestBody
            RegisterRequest request
    ) {

        RegisterResponse response =
                authService.register(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(
            @Valid
            @RequestBody
            LoginRequest request
    ) {

        LoginResponse response =
                authService.login(request);

        return ResponseEntity.ok(response);
    }

    @GetMapping("/me")
    public ResponseEntity<CurrentUserResponse> me(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            )
            String authorizationHeader
    ) {

        authenticate(authorizationHeader);

        CurrentUserResponse response =
                tokenService.authenticate(
                        authorizationHeader.substring(7)
                );

        return ResponseEntity.ok(response);
    }

    @PutMapping("/change-password")
    public ResponseEntity<MessageResponse> changePassword(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            )
            String authorizationHeader,

            @Valid
            @RequestBody
            ChangePasswordRequest request
    ) {

        AuthenticatedUser authenticatedUser =
                authenticate(authorizationHeader);

        authService.changePassword(
                authenticatedUser.getUserId(),
                request
        );

        return ResponseEntity.ok(
                new MessageResponse(
                        true,
                        "Password changed successfully."
                )
        );
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(
            @RequestHeader(
                    value = "Authorization",
                    required = false
            )
            String authorizationHeader
    ) {

        authenticate(authorizationHeader);

        tokenService.logout(
                authorizationHeader.substring(7)
        );

        return ResponseEntity.noContent().build();
    }

    private AuthenticatedUser authenticate(
            String authorizationHeader
    ) {

        if (authorizationHeader == null ||
                !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }

        return tokenService.getAuthenticatedUser(
                authorizationHeader.substring(7)
        );
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<VerificationResponse> forgotPassword(
            @Valid
            @RequestBody
            ForgotPasswordRequest request
    ) {

        VerificationResponse response =
                authService.forgotPassword(request);

        return ResponseEntity.ok(response);
    }

    @PutMapping("/reset-password")
    public ResponseEntity<MessageResponse> resetPassword(
            @Valid
            @RequestBody
            ResetPasswordRequest request
    ) {

        MessageResponse response =
                authService.resetPassword(request);

        return ResponseEntity.ok(response);
    }
    @PatchMapping("/me")
    public ResponseEntity<?> updateMe(
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader,
            @RequestBody java.util.Map<String, String> updates
    ) {
        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            throw new InvalidCredentialsException();
        }
        String rawToken = authorizationHeader.substring(7);
        Integer userId = tokenService.authenticate(rawToken).getUserId();
        authService.updateCurrentUser(userId, updates);
        return ResponseEntity.ok().build();
    }
}