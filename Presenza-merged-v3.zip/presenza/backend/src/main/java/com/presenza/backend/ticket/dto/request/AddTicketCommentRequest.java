package com.presenza.backend.ticket.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class AddTicketCommentRequest {

    @NotBlank(message = "Comment message is required")
    @Size(max = 5000, message = "Comment must not exceed 5000 characters")
    private String message;

    public AddTicketCommentRequest() {
    }

    public String getMessage() {
        return message;
    }
}