package com.presenza.backend.presence.service;

import com.presenza.backend.checkin.entity.CheckIn;
import com.presenza.backend.checkin.repository.CheckInRepository;
import com.presenza.backend.common.exception.BadRequestException;
import com.presenza.backend.common.exception.ForbiddenException;
import com.presenza.backend.common.exception.ResourceNotFoundException;
import com.presenza.backend.common.util.GeofenceDistanceCalculator;
import com.presenza.backend.employee.entity.Employee;
import com.presenza.backend.employee.repository.EmployeeRepository;
import com.presenza.backend.geofence.entity.Geofence;
import com.presenza.backend.geofence.entity.WifiNetwork;
import com.presenza.backend.geofence.repository.WifiNetworkRepository;
import com.presenza.backend.organisation.entity.Organization;
import com.presenza.backend.organisation.repository.OrganizationRepository;
import com.presenza.backend.presence.dto.request.PresenceUpdateRequest;
import com.presenza.backend.presence.dto.response.PresenceHistoryResponse;
import com.presenza.backend.presence.dto.response.PresenceResponse;
import com.presenza.backend.presence.entity.PresenceEvent;
import com.presenza.backend.presence.enums.PresenceEventType;
import com.presenza.backend.presence.enums.PresenceState;
import com.presenza.backend.presence.repository.PresenceEventRepository;
import com.presenza.backend.shift.entity.Shift;
import jakarta.persistence.EntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.List;

/**
 * Processes presence transitions and returns transition-only history. A
 * successful check-in starts INSIDE; only state changes persist EXIT or RETURN.
 */
@Service
public class PresenceService {

    private static final ZoneId ORGANIZATION_TIME_ZONE =
            ZoneId.of("Asia/Kolkata");

    private static final Logger logger =
            LoggerFactory.getLogger(PresenceService.class);

    private final CheckInRepository checkInRepository;
    private final PresenceEventRepository presenceEventRepository;
    private final WifiNetworkRepository wifiNetworkRepository;
    private final EmployeeRepository employeeRepository;
    private final OrganizationRepository organizationRepository;
    private final EntityManager entityManager;

    public PresenceService(CheckInRepository checkInRepository,
                           PresenceEventRepository presenceEventRepository,
                           WifiNetworkRepository wifiNetworkRepository,
                           EmployeeRepository employeeRepository,
                           OrganizationRepository organizationRepository,
                           EntityManager entityManager) {
        this.checkInRepository = checkInRepository;
        this.presenceEventRepository = presenceEventRepository;
        this.wifiNetworkRepository = wifiNetworkRepository;
        this.employeeRepository = employeeRepository;
        this.organizationRepository = organizationRepository;
        this.entityManager = entityManager;
    }

    @Transactional
    public PresenceResponse processPresenceUpdate(
            Integer userId,
            Integer organizationId,
            PresenceUpdateRequest request
    ) {
        CheckIn checkIn = findTodayActiveCheckIn(userId);
        Shift shift = checkIn.getShift();

        if (shift == null || !shift.getOrganization().getOrgId()
                .equals(organizationId)) {
            throw new BadRequestException("No active check-in found for today");
        }

        Organization organization = organizationRepository.findById(
                organizationId
        ).orElseThrow(() -> new ResourceNotFoundException(
                "Organization not found with id: " + organizationId
        ));

        if (!Boolean.TRUE.equals(organization.getPresenceMonitoringEnabled())) {
            throw new BadRequestException(
                    "Presence monitoring is disabled for this organization"
            );
        }

        Geofence geofence = shift.getGeofence();
        if (geofence == null) {
            throw new BadRequestException(
                    "Shift does not have a geofence configured"
            );
        }

        PresenceState currentState = determineCurrentState(
                geofence,
                request,
                Boolean.TRUE.equals(organization.getRequireTrustedWifi())
        );
        PresenceEvent latestEvent = presenceEventRepository
                .findFirstByCheckInCheckinIdOrderByEventTimestampDesc(
                        checkIn.getCheckinId()
                )
                .orElse(null);
        PresenceState previousState = latestEvent == null
                ? PresenceState.INSIDE
                : toState(latestEvent.getEventType());

        logger.info("Presence state evaluated for checkinId={}: previousState={} currentState={}",
                checkIn.getCheckinId(), previousState, currentState);

        if (previousState == currentState) {
            if (currentState == PresenceState.INSIDE) {
                return savePresenceEvent(checkIn, PresenceEventType.PRESENT,
                        currentState, geofence, request);
            }
            logger.info("No presence transition detected for checkinId={}",
                    checkIn.getCheckinId());
            return new PresenceResponse(false, null, currentState, null);
        }

        PresenceEventType eventType = currentState == PresenceState.OUTSIDE
                ? PresenceEventType.EXIT
                : PresenceEventType.RETURN;
        return savePresenceEvent(checkIn, eventType, currentState, geofence, request);
    }

    private PresenceResponse savePresenceEvent(CheckIn checkIn,
                                               PresenceEventType eventType,
                                               PresenceState currentState,
                                               Geofence geofence,
                                               PresenceUpdateRequest request) {
        PresenceEvent event = new PresenceEvent(checkIn, eventType);
        event.setLatitude(request.getLatitude());
        event.setLongitude(request.getLongitude());
        event.setAccuracy(request.getAccuracy());
        event.setConnectedSsid(request.getConnectedSsid());
        event.setConnectedBssid(request.getConnectedBssid());
        event.setWifiVerified(isTrustedWifiConnected(geofence, request));

        PresenceEvent savedEvent = presenceEventRepository.saveAndFlush(event);
        entityManager.refresh(savedEvent);

        logger.info("Presence event generated for checkinId={}: eventType={}",
                checkIn.getCheckinId(), eventType);
        return new PresenceResponse(true, eventType, currentState,
                savedEvent.getEventTimestamp());
    }

    @Transactional(readOnly = true)
    public List<PresenceHistoryResponse> getMyHistory(
            Integer userId,
            LocalDate date
    ) {
        return getHistoryForUser(userId, date);
    }

    @Transactional(readOnly = true)
    public List<PresenceHistoryResponse> getEmployeeHistory(
            Integer employeeId,
            Integer organizationId,
            String role,
            LocalDate date
    ) {
        validateManagementRole(role);

        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Employee not found with id: " + employeeId
                ));

        if (!employee.getOrganization().getOrgId().equals(organizationId)) {
            throw new ResourceNotFoundException(
                    "Employee not found with id: " + employeeId
            );
        }

        return getHistoryForUser(employee.getUser().getUserId(), date);
    }

    private List<PresenceHistoryResponse> getHistoryForUser(
            Integer userId,
            LocalDate date
    ) {
        LocalDate requestedDate = date != null
                ? date
                : LocalDate.now(ORGANIZATION_TIME_ZONE);
        OffsetDateTime start = requestedDate.atStartOfDay(ORGANIZATION_TIME_ZONE)
                .toOffsetDateTime();
        OffsetDateTime end = requestedDate.plusDays(1)
                .atStartOfDay(ORGANIZATION_TIME_ZONE)
                .toOffsetDateTime();

        return presenceEventRepository
                .findByCheckInUserUserIdAndEventTimestampBetweenOrderByEventTimestampAsc(
                        userId, start, end
                )
                .stream()
                .map(this::toHistoryResponse)
                .toList();
    }

    private CheckIn findTodayActiveCheckIn(Integer userId) {
        LocalDate today = LocalDate.now(ORGANIZATION_TIME_ZONE);
        OffsetDateTime start = today.atStartOfDay(ORGANIZATION_TIME_ZONE)
                .toOffsetDateTime();
        OffsetDateTime end = today.plusDays(1).atStartOfDay(ORGANIZATION_TIME_ZONE)
                .toOffsetDateTime();

        return checkInRepository
                .findFirstByUserUserIdAndCheckinTimeBetweenOrderByCheckinTimeDesc(
                        userId, start, end
                )
                .orElseThrow(() -> new BadRequestException(
                        "No active check-in found for today"
                ));
    }

    private PresenceState determineCurrentState(Geofence geofence,
                                                PresenceUpdateRequest request,
                                                boolean requireTrustedWifi) {
        if (request.getLatitude() == null || request.getLongitude() == null) {
            logger.warn("Presence update has no GPS coordinates");
            return PresenceState.OUTSIDE;
        }

        double distance = GeofenceDistanceCalculator.calculateDistanceMeters(
                request.getLatitude().doubleValue(),
                request.getLongitude().doubleValue(),
                geofence.getLatitude().doubleValue(),
                geofence.getLongitude().doubleValue()
        );

        return distance <= geofence.getRadius()
                && (!requireTrustedWifi ||
                isTrustedWifiConnected(geofence, request))
                ? PresenceState.INSIDE
                : PresenceState.OUTSIDE;
    }

    private boolean isTrustedWifiConnected(Geofence geofence,
                                           PresenceUpdateRequest request) {
        if (request.getConnectedBssid() == null ||
                request.getConnectedBssid().isBlank()) {
            return false;
        }

        WifiNetwork wifiNetwork = wifiNetworkRepository
                .findByBssidAndIsActiveTrue(request.getConnectedBssid())
                .orElse(null);

        return wifiNetwork != null
                && wifiNetwork.getGeofence().getGeofenceId()
                .equals(geofence.getGeofenceId())
                && request.getConnectedSsid() != null
                && request.getConnectedSsid().equals(wifiNetwork.getSsid());
    }

    private PresenceState toState(PresenceEventType eventType) {
        return eventType == PresenceEventType.EXIT
                ? PresenceState.OUTSIDE
                : PresenceState.INSIDE;
    }

    private PresenceHistoryResponse toHistoryResponse(PresenceEvent event) {
        return new PresenceHistoryResponse(
                event.getEventId(), event.getCheckIn().getCheckinId(),
                event.getEventType(), event.getEventTimestamp(),
                event.getLatitude(), event.getLongitude(), event.getAccuracy(),
                event.getWifiVerified()
        );
    }

    private void validateManagementRole(String role) {
        if (!"ORG_ADMIN".equals(role) && !"MANAGER".equals(role)) {
            throw new ForbiddenException(
                    "User is not allowed to access organization presence history"
            );
        }
    }
}
