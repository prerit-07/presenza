package com.presenza.backend.auth.service;

import com.presenza.backend.auth.dto.response.CurrentUserResponse;
import com.presenza.backend.auth.entity.Session;
import com.presenza.backend.auth.exception.InvalidCredentialsException;
import com.presenza.backend.auth.model.AuthenticatedUser;
import com.presenza.backend.auth.repository.SessionRepository;
import com.presenza.backend.user.entity.User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.OffsetDateTime;
import java.util.Base64;

@Service
public class TokenService {

    private final SessionRepository sessionRepository;

    public TokenService(SessionRepository sessionRepository) {
        this.sessionRepository = sessionRepository;
    }

    @Transactional(readOnly = true)
    public CurrentUserResponse authenticate(String rawToken) {

        Session session = getValidSession(rawToken);
        User user = session.getUser();

        return new CurrentUserResponse(
                user.getUserId(),
                user.getUsername(),
                user.getEmail(),
                user.getRole().getRoleName()
        );
    }

    @Transactional(readOnly = true)
    public AuthenticatedUser getAuthenticatedUser(String rawToken) {

        Session session = getValidSession(rawToken);
        User user = session.getUser();

        return new AuthenticatedUser(
                user.getUserId(),
                user.getOrganization().getOrgId(),
                user.getRole().getRoleName()
        );
    }

    @Transactional
    public void logout(String rawToken) {

        Session session = getValidSession(rawToken);

        session.setRevokedAt(OffsetDateTime.now());

        sessionRepository.save(session);
    }

    private Session getValidSession(String rawToken) {

        if (rawToken == null || rawToken.isBlank()) {
            throw new InvalidCredentialsException();
        }

        String tokenHash = hashToken(rawToken);

        Session session = sessionRepository.findByTokenHash(tokenHash)
                .orElseThrow(InvalidCredentialsException::new);

        if (session.getRevokedAt() != null) {
            throw new InvalidCredentialsException();
        }

        if (session.getExpiresAt() == null ||
                !session.getExpiresAt().isAfter(OffsetDateTime.now())) {
            throw new InvalidCredentialsException();
        }

        User user = session.getUser();

        if (!Boolean.TRUE.equals(user.getActive())) {
            throw new InvalidCredentialsException();
        }

        return session;
    }

    private String hashToken(String rawToken) {
        try {
            MessageDigest digest =
                    MessageDigest.getInstance("SHA-256");

            byte[] hash = digest.digest(
                    rawToken.getBytes(StandardCharsets.UTF_8)
            );

            return Base64.getUrlEncoder()
                    .withoutPadding()
                    .encodeToString(hash);

        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(
                    "SHA-256 algorithm is not available",
                    e
            );
        }
    }
}