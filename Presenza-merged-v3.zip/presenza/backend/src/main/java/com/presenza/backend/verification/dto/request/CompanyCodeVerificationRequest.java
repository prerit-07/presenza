package com.presenza.backend.verification.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class CompanyCodeVerificationRequest {

    @NotBlank(message = "Company code is required")
    @Size(max = 20, message = "Company code must not exceed 20 characters")
    private String companyCode;

    public CompanyCodeVerificationRequest() {
    }

    public String getCompanyCode() {
        return companyCode;
    }
}
