INSERT INTO plan (plan_name, max_employees, price)
SELECT 'Starter', 10, 0.00
WHERE NOT EXISTS (
    SELECT 1
    FROM plan
    WHERE plan_name = 'Starter'
);

INSERT INTO plan (plan_name, max_employees, price)
SELECT 'Growth', 100, 1499.00
WHERE NOT EXISTS (
    SELECT 1
    FROM plan
    WHERE plan_name = 'Growth'
);

-- Add the Enterprise plan after its approved employee limit and monthly price
-- are confirmed. The current plan table has no feature-description columns.
