CREATE TABLE IF NOT EXISTS user_push_token (
    push_token_id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES "user"(user_id) ON DELETE CASCADE,
    device_id VARCHAR(100) NOT NULL,
    expo_push_token VARCHAR(255) NOT NULL UNIQUE,
    platform VARCHAR(20),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS user_push_token_active_user_idx
    ON user_push_token (user_id) WHERE is_active = TRUE;
