ALTER TABLE organization
    ADD COLUMN presence_monitoring_enabled boolean NOT NULL DEFAULT true,
    ADD COLUMN presence_update_interval_seconds integer NOT NULL DEFAULT 300,
    ADD COLUMN require_trusted_wifi boolean NOT NULL DEFAULT true,
    ADD CONSTRAINT organization_presence_update_interval_check
        CHECK (presence_update_interval_seconds BETWEEN 60 AND 3600);
