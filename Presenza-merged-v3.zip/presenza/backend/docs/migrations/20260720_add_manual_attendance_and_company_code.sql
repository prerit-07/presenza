ALTER TABLE organization
    ADD COLUMN company_code varchar(20);

UPDATE organization
SET company_code = 'ORG-' || org_id
WHERE company_code IS NULL;

ALTER TABLE organization
    ALTER COLUMN company_code SET NOT NULL,
    ADD CONSTRAINT organization_company_code_key UNIQUE (company_code);

ALTER TABLE attendance
    ADD COLUMN effective_checkin_time timestamptz;

CREATE TABLE manual_attendance (
    manual_attendance_id serial PRIMARY KEY,
    employee_id integer NOT NULL REFERENCES employee(employee_id),
    attendance_date date NOT NULL,
    status varchar(30) NOT NULL,
    effective_checkin_time timestamptz,
    remarks text,
    created_by_employee_id integer NOT NULL REFERENCES employee(employee_id),
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT manual_attendance_employee_date_key
        UNIQUE (employee_id, attendance_date),
    CONSTRAINT manual_attendance_status_check
        CHECK (status IN ('PRESENT', 'LATE', 'ABSENT'))
);
