# Presenza Backend Reference

This document acts as a lightweight implementation reference for the Presenza backend team.

The API list defines the expected backend contracts. The live PostgreSQL schema is the source of truth for existing tables, columns, foreign keys, and constraints.

---

## 1. Project Overview

Presenza is an attendance and workforce management platform supporting organizations, employees, teams, shifts, geofenced check-ins, attendance tracking, leave/WFH requests, ticket management, device management, and related administrative workflows.

The current MVP is focused on the corporate employee workflow. 
---

## 2. Backend Stack

- Java 17
- Spring Boot
- Gradle
- Spring Web MVC
- Spring Data JPA
- Jakarta Validation
- PostgreSQL
- NeonDB
- Flyway dependency available for database migrations

---

## 3. Base Package

com.presenza.backend

Current feature packages:

- auth
- organisation
- user
- employee
- workforce
- shift
- geofence
- checkin
- attendance
- ticket
- device
- subscription
- notification

Shared infrastructure packages:

- common
- config
- security

**common**: Shared utility classes, exception handling, response wrappers, and reusable validation logic used across all feature modules.

**config**: Application-level configuration - security config, CORS, JPA/Hibernate settings, and environment-specific beans.

---

## 4. Live Schema Reference

Taken directly from `presenza_schema.sql`. This is the authoritative field list; do not add a column here that isn't in the actual dump.

### organization
| Fields |
|---|
| `org_id (PK)` |
| `org_name` |
| `org_type` |
| `plan_id (FK to plan)` |
| `max_allowed_employee` |
| `created_at` |

### plan
| Fields |
|---|
| `plan_id (PK)` |
| `plan_name` |
| `max_employees` |
| `price` |

### user
| Fields |
|---|
| `user_id (PK)` |
| `org_id (FK to organization)` |
| `username` |
| `email` |
| `hash_password` |
| `role_id (FK to role)` |
| `created_at` |
| `is_active` |
| `last_login` |

### employee
| Fields |
|---|
| `employee_id (PK)` |
| `org_id (FK to organization)` |
| `user_id (FK to user, cascade)` |
| `employee_name` |
| `date_of_joining` |
| `department_id (FK to department)` |
| `shift_id (FK to shift)` |
| `team_id (FK to team)` |

### department
| Fields |
|---|
| `department_id (PK)` |
| `org_id (FK to organization)` |
| `department_name` |

### team
| Fields |
|---|
| `team_id (PK)` |
| `org_id (FK to organization)` |
| `team_name` |
| `manager_employee_id (FK to employee)` |

### shift
| Fields |
|---|
| `shift_id (PK)` |
| `org_id (FK to organization)` |
| `shift_name` |
| `start_time` |
| `end_time` |
| `allowed_late_minutes (default 0)` |
| `geofence_id (FK to geofence)` |

### geofence
| Fields |
|---|
| `geofence_id (PK)` |
| `org_id (FK to organization)` |
| `latitude` |
| `longitude` |
| `radius` |
| `building_name` |

There is no `is_active` column here, so geofence deactivation isn't something the current schema can represent.

### wifi_network
| Fields |
|---|
| `wifi_id (PK)` |
| `geofence_id (FK to geofence)` |
| `ssid` |
| `bssid` |
| `added_at` |
| `is_active` |

This table does carry `is_active`; don't confuse it with geofence, which doesn't.

### device
| Fields |
|---|
| `device_id (PK, string)` |
| `user_id (FK to user, cascade)` |
| `platform` |
| `model` |
| `app_version` |
| `bound_at` |
| `last_seen_at` |
| `is_active` |

### device_change_request
| Fields |
|---|
| `request_id (PK)` |
| `user_id (FK to user)` |
| `old_device_id (FK to device)` |
| `new_device_id` |
| `reason` |
| `requested_at` |
| `status (default PENDING)` |
| `reviewed_by (FK to employee)` |
| `reviewed_at` |

### session
| Fields |
|---|
| `session_id (PK)` |
| `user_id (FK to user, cascade)` |
| `token_hash` |
| `created_at` |
| `expires_at` |
| `device_info` |
| `revoked_at` |

### role
| Fields |
|---|
| `role_id (PK)` |
| `org_id (FK to organization)` |
| `role_name` |

### permission
| Fields |
|---|
| `permission_id (PK)` |
| `permission_name` |
| `description` |

### role_permission
| Fields |
|---|
| `role_id (FK to role, cascade)` |
| `permission_id (FK to permission, cascade)` |

### check_in
| Fields |
|---|
| `checkin_id (PK)` |
| `user_id (FK to user)` |
| `shift_id (FK to shift, nullable)` |
| `slot_id (FK to timetable_slot, nullable)` |
| `device_id (FK to device)` |
| `wifi_id (FK to wifi_network)` |
| `connected_ssid` |
| `connected_bssid` |
| `wifi_verified (default false)` |
| `checkin_time` |
| `latitude` |
| `longitude` |
| `device_info` |
| `accuracy` |

A check constraint (`chk_checkin_context`) requires exactly one of `shift_id` or `slot_id` to be set, never both and never neither. That's how employee check-ins and student/timetable check-ins share the same table.

### attendance
| Fields |
|---|
| `attendance_id (PK)` |
| `checkin_id (FK to check_in)` |
| `status` |
| `approved_at` |
| `remarks` |

Status is constrained to PRESENT, LATE, ABSENT, PENDING, or REJECTED.

### attendance_request - confirmed in the live schema; treat this as settled, not a gap
| Fields |
|---|
| `request_id (PK)` |
| `employee_id (FK to employee)` |
| `request_type (LEAVE or WFH)` |
| `start_date` |
| `end_date (end must be on or after start)` |
| `reason` |
| `status (default PENDING; PENDING, APPROVED, or REJECTED)` |
| `reviewed_by (FK to employee)` |
| `review_remarks` |
| `reviewed_at` |
| `created_at` |
| `updated_at` |

This resolves the earlier concern raised against the older ERD, which had no request table. The live schema confirms attendance_request is a real, independent table. A leave or WFH request does not need an underlying check-in event to exist.

### ticket
| Fields |
|---|
| `ticket_id (PK)` |
| `org_id (FK to organization)` |
| `raised_by_user_id (FK to user)` |
| `assigned_to_employee_id (FK to employee, nullable)` |
| `checkin_id (FK to check_in, nullable)` |
| `attendance_id (FK to attendance, nullable)` |
| `subject` |
| `description` |
| `status (default OPEN)` |
| `created_at` |
| `resolved_at` |

There is no `issue_type`, no `manager_response`, and no `closed_at` column. Manager remarks belong in `ticket_comment`, and `resolved_at` is the only terminal timestamp the schema provides.

### ticket_comment
| Fields |
|---|
| `comment_id (PK)` |
| `ticket_id (FK to ticket, cascade)` |
| `user_id (FK to user)` |
| `message` |
| `created_at` |

### student, course, timetable, timetable_slot
Out of scope for the MVP. These support timetable-based check-ins for students or faculty; `check_in.slot_id` and the foreign keys on `timetable_slot` connect that path. Don't build against these tables unless a task specifically calls for it.

### Notification
No table exists in the live schema. Don't create one without an approved schema change. For now, notifications are fired directly from workflow events without being persisted anywhere (see Module 7 below).

## 5. API Contract by Module

> **General Rules**
>
> - Every endpoint requires a Bearer Token unless explicitly marked as **Public** or **Refresh Token**.
> - Organization scope is always derived from the authenticated user.
> - Clients must never provide organization IDs.
> - `PATCH` is used for partial updates.

---

### Module 1 - Authentication & Session

**Endpoints**

- `POST /auth/login`
  - Returns the access token, refresh token, and device status.

- `POST /auth/refresh`
  - Protected using a refresh token.
  - Issues a new access token.

- `POST /auth/logout`
  - Revokes the active session.

---

### Module 2 - Organization

**Endpoints**

- `POST /org/register` *(Public)*
  - Registers a new organization.
  - Creates the default roles and administrator account.

- `PATCH /org/setup`
  - Completes organization setup.
  - Accepts:
    - `address`
    - `timezone`

- `GET /org/profile`
  - Returns the organization profile.
  - Includes `max_allowed_employee`.

- `PATCH /org/profile`
  - Updates organization information.

> **Note**
>
> `logo_url` is not part of the current schema.

---

### Module 3 - User Administration

**Endpoints**

- `POST /users`
  - Creates a user.
  - Automatically creates the linked employee profile.

- `GET /users/{user_id}`
  - Returns user details along with the linked employee name.

- `PATCH /users/{user_id}/role`
  - Updates the user's role.

- `PATCH /users/{user_id}/status`
  - Activates or deactivates a user.
  - Deactivation revokes all active sessions.

- `POST /users/{user_id}/credential-reset`
  - Generates new login credentials.

---

### Module 4 - User Profile

**Endpoints**

- `GET /profile`
  - Returns the authenticated user's profile.

- `PATCH /profile`
  - Updates the employee profile.

- `POST /profile/password`
  - Changes the password.
  - Revokes all other active sessions.

> **Editable**
>
> - `employee_name`

> **Not Editable**
>
> - `username`

---

### Module 5 - Device Management

**Endpoints**

- `GET /devices/me`
  - Returns the registered device.

- `POST /devices/change-requests`
  - Creates a device change request.

- `GET /devices/change-requests/me/latest`
  - Returns the latest request status.

- `POST /devices/change-requests/{request_id}/review`
  - Reviews the request.
  - Approved requests replace the registered device.

---

### Module 6 - Subscription

**Endpoints**

- `GET /plans` *(Public)*
- `GET /subscription`
- `POST /subscription/activate`
- `PATCH /subscription/plan`

---

### Module 7 - Notification

> **Current MVP Status**
>
> Notification APIs are intentionally deferred.
> The live schema does not contain a Notification table.

Notifications are triggered directly from:

- Attendance Request Submitted
- Attendance Request Reviewed
- Ticket Created
- Ticket Updated
- Device Change Reviewed

Delivery Channels:

- Firebase Cloud Messaging (FCM)
- Email

---

### Module 8 - Department

**Endpoints**

- `POST /departments`
- `GET /departments`
- `GET /departments/{id}`
- `PATCH /departments/{id}`
- `PUT /employees/{employee_id}/department`

---

### Module 9 - Team

**Endpoints**

- `POST /teams`
- `GET /teams`
- `GET /teams/{team_id}`
- `PATCH /teams/{team_id}`
- `PUT /teams/{team_id}/manager`
- `POST /teams/{team_id}/members`
- `DELETE /teams/{team_id}/members/{employee_id}`
- `GET /teams/managed`
- `GET /teams/my-team/members`

> **Business Rule**
> Removing an active team manager must be rejected until another manager is assigned.

---

### Module 10 - Shift

**Endpoints**

- `POST /shifts`
- `GET /shifts`
- `GET /shifts/{shift_id}`
- `PATCH /shifts/{shift_id}`
- `PUT /shifts/{shift_id}/employees/{employee_id}`
- `PUT /shifts/{shift_id}/teams/{team_id}`

> `geofence_id` is optional while creating a shift.

---

### Module 11 - Geofence

**Endpoints**

- `POST /geofences`
- `GET /geofences`
- `GET /geofences/{geofence_id}`
- `PATCH /geofences/{geofence_id}` 
> **Note**
> There is no Geofence Deactivation endpoint because the schema does not include an `is_active` column.

---

### Module 12 - Check-In

**Endpoints**

- `GET /check-in/context`
  - Resolves the assigned shift and geofence.

- `POST /check-in/location-status`
  - Validates whether the user is inside the assigned geofence.

- `POST /check-ins`
  - Performs complete check-in validation.

Validation includes:

- Timing
- Coordinates
- GPS Accuracy
- Geofence
- Registered Device

> **Schema Constraint**
> Exactly one of `shift_id` or `slot_id` must be provided.

> **Deferred for MVP**
> - 20-minute continuous geofence verification
> - Complete Wi-Fi verification workflow

---

### Module 13 - Attendance

**Endpoints**

- `GET /attendance/me`
- `GET /attendance/team`
- `GET /attendance/organization`
- `GET /attendance/export`
- `POST /attendance/requests`
- `GET /attendance/requests/me`
- `GET /attendance/requests/pending`
- `POST /attendance/requests/{request_id}/review`

Attendance Requests support:

- LEAVE
- WFH

The review endpoint updates:

- `reviewed_by`
- `reviewed_at`
- `status`

---

### Module 14 - Ticket

**Endpoints**

- `POST /tickets`
- `GET /tickets/me`
- `GET /tickets/managed`
- `POST /tickets/{ticket_id}/comments`
- `GET /tickets/{ticket_id}/comments`
- `POST /tickets/{ticket_id}/review`
- `POST /tickets/{ticket_id}/close`

> **Note**
>
> `issue_type` and `manager_response` are not part of the current schema.

Manager remarks should be stored using `ticket_comment`.

Closing a ticket requires it to already be **Resolved**.

---

### Module 15 - Role & Permission

**Endpoints**

- `GET /roles`
- `GET /roles/{role_id}`

Permissions are returned using the `role_permission` relationship.

## 6. Module Responsibilities

### Auth
Responsible for authentication and session lifecycle.

Main database table:
- session

Depends on:
- user
- security

#### Figure 1 - Authentication and Session Flow

```mermaid
flowchart TD
A[User Login]
B[Validate Credentials]
C{Valid?}
D[Create Session/JWT]
E[Return Token]
F[Authentication Failed]

A --> B
B --> C
C -->|Yes| D
D --> E
C -->|No| F
```

---

### Organisation
Responsible for organization-level data and organization management.

Main database table:
- organization

Depends on:
- subscription

#### Figure 2 - Organisation Management

```mermaid
flowchart TD
    A[Create Organisation]
    B[Store Organisation Details]
    C[Assign Subscription Plan]
    D[Organisation Ready]

    A --> B
    B --> C
    C --> D
```

---

### User
Responsible for user accounts and credentials.

Main database table:
- user

Important:
Creating an employee account may involve both:
1. Creating user credentials
2. Creating the linked employee profile

Do not treat User and Employee as duplicate concepts.

#### Figure 3 - User Administration

```mermaid
flowchart TD
    A[Admin Creates User]
    B[Validate User Details]
    C[Create User Credentials]
    D[Save User]
    E[Link Employee Profile]

    A --> B
    B --> C
    C --> D
    D --> E
```

---

### Employee
Responsible for employee profiles belonging to organizations.

Main database table:
- employee

Depends on:
- user
- organisation

Employee records may later reference:
- department
- team
- shift

#### Figure 4 - Employee Profile

```mermaid
flowchart TD
A[Create Employee Profile]
B[Assign Department]
C[Assign Team]
D[Assign Shift]
E[Employee Profile Ready]

A --> E
A -.->|optional| B
A -.->|optional| C
A -.->|optional| D
```

---

### Workforce
Responsible for organizational workforce structure.

Main database tables:
- department
- team

Responsibilities include:
- department assignment
- team creation
- employee team assignment
- team manager assignment
- team member visibility

#### Figure 5A - Department Management

```mermaid
flowchart TD
    A[Create Department]
    B[Assign Employees]
    C[Department Updated]

    A --> B
    B --> C
```

#### Figure 5B - Team Management

```mermaid
flowchart TD
    A[Create Team]
    B[Assign Team Manager]
    C[Assign Team Members]
    D[Team Ready]

    A --> B
    B --> C
    C --> D
```

---

### Shift
Responsible for work shift definitions and employee shift-related workflows.

Main database table:
- shift

Depends on:
- organisation
- geofence

#### Figure 6 - Shift Management

```mermaid
flowchart TD
    A[Create Shift]
    B[Assign Geofence]
    C[Assign Employees]
    D[Shift Ready]

    A --> B
    B --> C
    C --> D
```

---

### Geofence
Responsible for organization geofence configuration.

Main database table:
- geofence

Responsibilities include:
- geofence creation
- location coordinates
- allowed radius
- building/location name

Used by:
- shift
- checkin

#### Figure 7 - Geofence Management

```mermaid
flowchart TD
    A[Create Geofence]
    B[Set Coordinates and Radius]
    C[Geofence Ready]
    D[Used by Shift]
    E[Used by Check-In]

    A --> B
    B --> C
    C --> D
    C --> E
```

---

### Check-In
Responsible for recording and validating employee check-ins.

Main database table:
- check_in

Depends on:
- user
- employee
- shift
- geofence
- device

MVP check-in flow:

#### Figure 8 - Check-In Workflow

```mermaid
flowchart TD
    A[Employee Opens Shift]
    B[Resolve Employee]
    C[Resolve Assigned Shift]
    D[Validate Device]
    E[Validate Geofence]
    F[Validate Coordinates]
    G[Create Check-In]
    H[Attendance Processing]

    A --> B
    B --> C
    C --> D
    D --> E
    E --> F
    F --> G
    G --> H
```

Deferred from MVP:
- mandatory 20-minute geofence stay verification
- full Wi-Fi verification workflow

---

### Attendance
Responsible for attendance records and attendance-related requests.

Main database tables:
- attendance
- attendance_request

`attendance` stores actual attendance outcomes.

Examples:
- PRESENT
- LATE
- ABSENT

`attendance_request` stores employee requests.

Request types:
- LEAVE
- WFH

Request statuses:
- PENDING
- APPROVED
- REJECTED

Organisation-level attendance functionality may include:
- viewing employee attendance
- team-level attendance visibility
- organization-wide attendance visibility
- CSV export

#### Figure 9 - Attendance Request Workflow

```mermaid
flowchart TD
    A[Employee Submits Request]
    B[Status = PENDING]
    C[Manager Reviews Request]
    D{Decision}
    E[APPROVED]
    F[REJECTED]
    G[Record Reviewer Information]

    A --> B
    B --> C
    C --> D
    D -->|Approve| E
    D -->|Reject| F
    E --> G
    F --> G
```

---

### Ticket
Responsible for attendance/check-in issue reporting.

Main database tables:
- ticket
- ticket_comment

#### Figure 10 - Ticket Management

```mermaid
flowchart TD
    A[Employee Reports Issue]
    B[Create Ticket]
    C[Assign Responsible Person]
    D[Discussion Through Comments]
    E[Update Ticket Status]
    F[Resolve / Close Ticket]

    A --> B
    B --> C
    C --> D
    D --> E
    E --> F
```

---

### Device
Responsible for registered user devices and device-change workflows.

Main database tables:
- device
- device_change_request

Responsibilities include:
- device binding
- device validation
- device change requests
- approval/rejection workflow

#### Figure 11 - Device Management

```mermaid
flowchart TD
    A[Register Device]
    B[Validate Device]
    C{Device Change Required?}
    D[Submit Change Request]
    E[Manager/Admin Reviews]
    F{Decision}
    G[Update Registered Device]
    H[Retain Existing Device]

    A --> B
    B --> C
    C -->|Yes| D
    C -->|No| H
    D --> E
    E --> F
    F -->|Approved| G
    F -->|Rejected| H
```

---

### Subscription
Responsible for organization plan information.

Main database table:
- plan

Used by:
- organisation

#### Figure 12 - Subscription Management

```mermaid
flowchart TD
    A[Create Organisation]
    B[Select Subscription Plan]
    C[Activate Subscription]
    D[Subscription Ready]

    A --> B
    B --> C
    C --> D
```

---

### Notification
Responsible for triggering notifications from backend workflows.

No persistent Notification entity/table is required for the current MVP.

Example triggers:
- attendance request submitted
- attendance request reviewed
- ticket created
- ticket updated
- device change request reviewed

A database table should only be added later if persistent notification history, read/unread state, inbox functionality, or retry tracking is required.

---

## 7. Entity and Repository Ownership

Each database table must have one owning module.

Do not recreate the same entity or repository inside another module.

Ownership:

- organisation
  - Organization
  - OrganizationRepository

- user
  - User
  - UserRepository

- employee
  - Employee
  - EmployeeRepository

- auth
  - Session
  - SessionRepository

- security
  - Role
  - Permission
  - RolePermission

- subscription
  - Plan
  - PlanRepository

- workforce
  - Department
  - Team
  - DepartmentRepository
  - TeamRepository

- shift
  - Shift
  - ShiftRepository

- geofence
  - Geofence
  - GeofenceRepository

- checkin
  - CheckIn
  - CheckInRepository

- attendance
  - Attendance
  - AttendanceRequest
  - AttendanceRepository
  - AttendanceRequestRepository

- ticket
  - Ticket
  - TicketComment
  - TicketRepository
  - TicketCommentRepository

- device
  - Device
  - DeviceChangeRequest
  - DeviceRepository
  - DeviceChangeRequestRepository

- notification
  - No persistent entity for MVP

Important rule:

If Check-In needs Employee data, it must use the Employee module's entity/repository or service contract.

It must NOT create another Employee entity.

---

## 8. Authorization Rules

Three effective access levels operate across modules, driven by role_permission assignments.

**Admin** (org-level): full access within their organization, including user creation, role assignment, department/team/shift/geofence management, and subscription control.

**Team Manager** (contextual, via team.manager_employee_id): scoped access limited to their own managed team, including reviewing attendance requests, reviewing tickets, and assigning shifts to team members. This is not a separate role field; it is determined dynamically by checking whether the current employee is set as manager_employee_id on a team.

**Employee** (self-service): access limited to their own profile, device, check-ins, attendance history, and tickets they raised.

Every endpoint in Section 5 that isn't marked Public should be checked against exactly one of these three levels. Where an endpoint's required level isn't obvious from its name, mark it TODO: NEEDS CONFIRMATION rather than assuming.

---

## 9. Important Cross-Module Workflows

### Employee Account Creation

Organisation/Admin
1. Create User Credentials
2. Create Linked Employee Profile
3. Optionally Assign Department
4. Optionally Assign Team
5. Optionally Assign Shift

---

### Team Management

Employee exists
1. Assign Department
2. Assign Team
3. Optionally Assign as Team Manager
4. Manager Receives Relevant Team-Management Permissions
5. Team Members Can View Relevant Team Information

---

### Shift Assignment

Organisation/Manager
1. Create or Select Shift
2. Optionally Connect Shift with Geofence
3. Assign Shift to Employee

---

### Check-In

Authenticated User
1. Resolve Employee
2. Resolve Assigned Shift
3. Resolve Shift Geofence
4. Validate Device
5. Validate Coordinates
6. Create Check-In
7. Attendance Workflow Follows

---

### Leave / WFH Request

Employee
1. Submit Attendance Request
2. Store Request with PENDING Status
3. Authorized Team Manager Reviews Request
4. Approve or Reject Request
5. Record Reviewer Information and Review Time

---

### Ticket Flow

Employee
1. Report Check-In or Attendance Issue
2. Create Ticket
3. Assign Ticket to Responsible Manager or Employee
4. Add Comments (If Required)
5. Update Ticket Status
6. Resolve or Close Ticket

---

## 10. General Backend Rules

- Controllers should handle HTTP request/response concerns.
- Business logic should live in services.
- Database access should go through repositories.
- JPA entities should map existing database tables.
- Request payloads should use request DTOs.
- API responses should use response DTOs where appropriate.
- Validate incoming requests.
- Do not expose passwords or password hashes.
- Do not trust organization IDs supplied by clients without authorization checks.
- Prevent cross-organization data access.
- Do not duplicate entities across modules.
- Do not invent database columns that do not exist in the live schema.
- Any schema change must be discussed before implementation.

---

## 11. MVP Scope Notes

Currently deferred or intentionally simplified:

- 20-minute mandatory geofence stay verification
- full Wi-Fi verification workflow
- persistent notification inbox
- notification read/unread state
- complex leave balance management
- multi-level leave approval chains
- advanced educational workflows unless explicitly assigned

---

## 12. Source of Truth

Use the following priority when implementing:

1. Confirmed current API contract
2. Live PostgreSQL schema dump
3. Confirmed module workflow/design
4. Older ERD only as supporting reference

If two sources conflict:

Do not guess.

Mark:

TODO: NEEDS CONFIRMATION

and ask the team before implementing.