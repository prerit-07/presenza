# Presence Monitoring Review

## Issues found and resolved

- The active check-in lookup was locked but loaded its shift, organization, and
  geofence lazily. It now uses an entity graph so the locked lookup fetches the
  presence dependencies together.
- Presence processing had no operational visibility. Structured logs now cover
  request receipt, state evaluation, generated events, no-transition outcomes,
  and Wi-Fi verification failures without logging location data or credentials.
- The presence table entity did not declare the lookup index required by the
  latest-event query. Its mapping now declares the `(checkin_id, event_timestamp)`
  index.
- The presence module had no automated coverage. Unit and controller-level
  integration tests now cover state transitions, duplicates, location/Wi-Fi
  verification, authentication, validation, and the missing-check-in path.

## Transition algorithm

A successful check-in is treated as `INSIDE`. For each mobile update, the
service derives the current state from geofence distance and trusted Wi-Fi
verification, obtains the last event for that check-in, and maps it to the
previous state. It stores an event only for `INSIDE -> OUTSIDE` (`EXIT`) or
`OUTSIDE -> INSIDE` (`RETURN`). Equal states do not create heartbeat records.

The active check-in is read with a pessimistic write lock for the duration of
the transaction. Concurrent updates for the same check-in therefore serialize:
the later update observes the event saved by the earlier update and does not
persist a duplicate transition.

## Remaining technical debt

The production `presence_event` table is externally managed and Hibernate runs
with schema validation. The declared JPA index documents the required index but
does not create it in an existing database. Confirm that production has a
  physical index on `(checkin_id, event_timestamp)` (preferably with descending event
time where supported) using the database migration process, then validate the
query plan with `EXPLAIN`.

The repository's locking behavior is covered by a metadata test. A true
multi-transaction concurrency integration test requires a configured test
database with the production locking semantics; add it when the project has a
PostgreSQL test environment or Testcontainers available.
