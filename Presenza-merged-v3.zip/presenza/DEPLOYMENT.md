# Deploying Presenza

## Option A — Push to the shared friend's-Azure repo (contributor access only)

This is the simplest path if the backend already runs on your friend's Azure
account and their existing PostgreSQL, and you only have GitHub contributor
access (no Azure/DB access).

**Key point: this is a code-only push. Nothing about the database or Azure
config needs to change.** V1-V5 migrations already match what's live (they're
the reverse-engineered baseline + your friend's own 4 patches), so Flyway
will auto-baseline past them and only run the one new migration, `V6`, which
just adds an `attempt_count` column and one unique index — both harmless
additive changes.

Steps:

1. Ask your friend to run the read-only checks in `check_live_db_state.sql`
   once (I gave you this file) and confirm: does `plan` already have
   Starter/Growth rows, does `manual_attendance`/`user_push_token` exist,
   does `organization` already have `company_code`/presence columns? If all
   yes, `V1-V5` are fully covered and the default `baseline-version=5` in
   `application.properties` is correct — no further changes needed.
   If any are missing, tell me which ones and I'll adjust the baseline
   version or add a small extra migration for just the gap.
2. Copy this repo's `backend/src/main/java/...` changes and
   `backend/src/main/resources/...` (including the new
   `db/migration/V1-V6` files and the updated `application.properties`) into
   your local clone of the shared GitHub repo, replacing the old files.
3. Commit and `git push` to whatever branch Azure App Service is watching
   (ask your friend which branch, if you don't already know — usually `main`).
4. Azure's continuous deployment picks up the push automatically and
   redeploys. Watch the Azure "Deployment Center" logs if your friend can
   share access to that screen, or just watch the app's behavior once it
   restarts (a few minutes).
5. Nothing changes in the app (`api.ts` still points at the same URL) — you
   don't need to touch the frontend at all for this.

If it turns out V2-V5 weren't actually applied to the live DB yet, don't
push until we fix that — running an `ALTER TABLE ADD COLUMN` on a table that
already has that column, or vice versa, is what would actually break
things. That's the one thing worth confirming with your friend first.

## Option B — Your own Postgres + Render

Plan: verify locally first with your own local Postgres, then deploy to Render.

## Phase 1 — Run locally against your local Postgres

1. Install PostgreSQL locally if you haven't already, then create the database:
   ```
   createdb presenza
   ```
   (or via psql: `CREATE DATABASE presenza;`)

2. In `backend/`, copy `.env.example` to `.env` and fill in:
   ```
   DB_URL=jdbc:postgresql://localhost:5432/presenza
   DB_USERNAME=<your local postgres username>
   DB_PASSWORD=<your local postgres password>
   MAIL_USERNAME=<a gmail address>
   MAIL_PASSWORD=<a gmail App Password, not your normal password>
   ```
   Spring Boot doesn't auto-load `.env` — either export these as real
   environment variables in your shell before running, or add
   `spring-dotenv` / use an IDE run-config with env vars. Simplest for a
   quick test, in the same terminal:
   ```
   export DB_URL=jdbc:postgresql://localhost:5432/presenza
   export DB_USERNAME=...
   export DB_PASSWORD=...
   export MAIL_USERNAME=...
   export MAIL_PASSWORD=...
   ```

3. From `backend/`, run:
   ```
   ./gradlew bootRun
   ```
   On startup, Flyway automatically runs all 5 migrations
   (`V1__baseline_schema.sql` through `V5__seed_subscription_plans.sql`)
   against your empty database, creating every table. Watch the logs for
   `Successfully applied 5 migrations` — if you see a Flyway error instead,
   stop and share the exact error before continuing.

4. Confirm it's up: `curl http://localhost:3000/actuator/health` (if
   actuator is enabled) or just try `POST /auth/register` with a test
   organization via curl/Postman.

5. Point the app at your local backend for testing: in
   `app/services/api.ts`, temporarily set
   `API_BASE_URL = 'http://<your-machine-LAN-IP>:3000'` (not `localhost`,
   since the phone/emulator needs your machine's real LAN IP), then
   `npx expo start` from `app/`.

6. Walk through: register an org → create an admin → log in → add an
   employee → check in (GPS+WiFi) → approve a leave request. If all of
   that works against your local Postgres, the schema and logic are solid.

## Phase 2 — Deploy to Render

1. Push this repo to your own GitHub (under your account/ID).
2. In Render: **New → PostgreSQL** — create a database in your Render
   account. Render gives you an "Internal Database URL" — copy it.
3. **New → Web Service** → connect the GitHub repo, root directory
   `backend/`.
   - Build command: `./gradlew build -x test`
   - Start command: `java -jar build/libs/*.jar`
   - Environment variables (Render dashboard → Environment):
     - `DB_URL` = the Render Postgres "Internal Database URL", but rewritten
       to JDBC form: `jdbc:postgresql://<host>:<port>/<db>` (Render gives you
       a `postgres://` URL — strip the `postgres://user:pass@` part into
       `DB_USERNAME`/`DB_PASSWORD` separately, and use `jdbc:postgresql://<host>:<port>/<dbname>`
       for `DB_URL`).
     - `DB_USERNAME`, `DB_PASSWORD` — from the same Render Postgres credentials.
     - `MAIL_USERNAME`, `MAIL_PASSWORD` — same Gmail App Password as local.
4. Deploy. Render builds and starts the service; Flyway runs the same 5
   migrations against the fresh Render Postgres automatically — no manual
   SQL step.
5. Once it's live, update `app/services/api.ts`'s `API_BASE_URL` to your
   Render service URL (e.g. `https://presenza-backend-yourname.onrender.com`),
   commit, and rebuild/redeploy the app (`eas build` if you're distributing
   it, or just `npx expo start` for local testing against the live backend).

## Notes

- Render's free tier spins the service down after inactivity — the first
  request after idle will be slow (cold start). Fine for testing, worth
  upgrading to a paid tier for real usage.
- Keep `.env` out of git (it already is, via `.gitignore` — double check
  before your first push).
