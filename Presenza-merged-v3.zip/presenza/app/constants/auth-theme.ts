export const AuthTheme = {
  dark: {
    // Screen background — deep purple (exactly matching the photo)
    background: '#291550',

    // Floating card — muted lilac purple
    cardBackground: '#C5B5D8',

    // Text colors (all must contrast well on the lilac card)
    title:    '#241245',   // very dark purple — for headings
    subtitle: '#6B4C9A',   // mid purple — for sub-text/hints
    label:    '#3A1F6E',   // dark-ish purple — for field labels

    // Inputs
    inputBackground:  '#DDD4EA',  // slightly lighter than card
    inputText:        '#241245',  // same as title for typing text
    inputPlaceholder: '#9B82B8',  // mid tone so placeholder is visible but not loud

    // Buttons
    buttonBackground: '#1F1040',  // near-black purple (matches the "Verify & Proceed" btn)
    buttonText:       '#FFFFFF',

    // Step progress indicator
    progressLine:            '#9B82B8',
    progressCircleActive:    '#1F1040',   // dark circle for active step
    progressTextActive:      '#FFFFFF',
    progressCircleInactive:  '#B5A3CB',   // light circle for future steps
    progressTextInactive:    '#3A1F6E',
  },
  light: {
    background:       '#F0E6F5',
    cardBackground:   '#FFFFFF',
    title:            '#291550',
    subtitle:         '#6B4C9A',
    label:            '#472A73',
    inputBackground:  '#F8F5FA',
    inputText:        '#291550',
    inputPlaceholder: '#A897B5',
    buttonBackground: '#291550',
    buttonText:       '#FFFFFF',
    progressLine:             '#C5B4D4',
    progressCircleActive:     '#291550',
    progressTextActive:       '#FFFFFF',
    progressCircleInactive:   '#E0D4E7',
    progressTextInactive:     '#6B4C9A',
  },
};
