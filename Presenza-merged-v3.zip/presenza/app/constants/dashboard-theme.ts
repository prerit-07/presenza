// Shared color palette for all dashboards — matches the screenshot exactly
// To use the real "Bitcount Grid Single", place the .ttf in assets/fonts/
// and change greetingFont to its PostScript name.
export const GREETING_FONT = 'DotGothic16_400Regular';

export const DashboardTheme = {
  // Backgrounds
  screenBg: '#F3EDF7',           // Very light lavender screen
  cardBg: '#FFFFFF',             // White cards
  quickAccessBg: '#D4C5E2',     // Muted lavender for quick access container
  tabBarBg: '#C5B4D6',          // Tab bar lavender

  // Purple accents
  purpleDark: '#5B3D7A',        // Dark purple — greeting text, headings
  purpleMedium: '#7B5EA7',      // Medium purple — secondary text
  purpleIcon: '#6B4E8D',        // Purple for icon circles
  purpleLight: '#EBE0F5',       // Light purple — notification btn bg, subtle fills
  purpleBorder: '#C5B4D6',      // Border color for clock-in btn etc

  // Text
  textDark: '#333333',
  textMuted: '#888888',
  textWhite: '#FFFFFF',

  // Misc
  redDot: '#FF5252',
  approveGreen: '#4CAF50',
};
