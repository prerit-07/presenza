/**
 * Below are the colors that are used in the app. The colors are defined in the light and dark mode.
 * There are many other ways to style your app. For example, [Nativewind](https://www.nativewind.dev/), [Tamagui](https://tamagui.dev/), [unistyles](https://reactnativeunistyles.vercel.app), etc.
 */

import { Platform } from 'react-native';

const tintColorLight = '#0a7ea4';
const tintColorDark = '#fff';

export const Colors = {
  light: {
    text: '#11181C',
    background: '#fff',
    tint: tintColorLight,
    icon: '#687076',
    tabIconDefault: '#687076',
    tabIconSelected: tintColorLight,
  },
  dark: {
    text: '#ECEDEE',
    background: '#151718',
    tint: tintColorDark,
    icon: '#9BA1A6',
    tabIconDefault: '#9BA1A6',
    tabIconSelected: tintColorDark,
  },
};

export const Fonts = Platform.select({
  ios: {
    /** iOS `UIFontDescriptorSystemDesignDefault` */
    sans: 'system-ui',
    /** iOS `UIFontDescriptorSystemDesignSerif` */
    serif: 'ui-serif',
    /** iOS `UIFontDescriptorSystemDesignRounded` */
    rounded: 'ui-rounded',
    /** iOS `UIFontDescriptorSystemDesignMonospaced` */
    mono: 'ui-monospace',
  },
  default: {
    sans: 'normal',
    serif: 'serif',
    rounded: 'normal',
    mono: 'monospace',
  },
  web: {
    sans: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    serif: "Georgia, 'Times New Roman', serif",
    rounded: "'SF Pro Rounded', 'Hiragino Maru Gothic ProN', Meiryo, 'MS PGothic', sans-serif",
    mono: "SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
  },
});

// ─── Theme object used by friend's components ──────────────────────────────
export const Theme = {
  colors: {
    primary: '#6F4AA8',
    primaryDark: '#5B3D7A',
    primaryLight: '#EAE6F4',
    secondary: '#9B80C4',
    background: '#F5F3FA',
    cardBackground: '#FFFFFF',
    card: '#FFFFFF',
    text: '#1A1025',
    subText: '#7A6E8A',
    white: '#FFFFFF',
    success: '#43C47A',
    error: '#E85D5D',
    warning: '#F0A500',
    info: '#4A9EE8',
    border: '#E8E4EC',
    inputBackground: '#F5F3FA',
    inputBg: '#F5F3FA',
    divider: '#EDE9F4',
    overlay: 'rgba(0,0,0,0.5)',
    socialGoogle: '#DB4437',
    socialApple: '#000000',
    socialFacebook: '#4267B2',
  },
  typography: {
    fontFamily: {
      regular: undefined as string | undefined,
      medium: undefined as string | undefined,
      semiBold: undefined as string | undefined,
      bold: undefined as string | undefined,
    },
    sizes: {
      xs: 11,
      sm: 13,
      md: 15,
      lg: 17,
      xl: 20,
      xxl: 26,
      xxxl: 32,
    },
  },
  spacing: { xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 48 },
  radius: { 
    sm: 8, 
    md: 12, 
    lg: 16, 
    xl: 24, 
    pill: 999
  },
  borderRadius: {
    card: 16,
    button: 12,
    input: 12,
    large: 20,
    modal: 24,
    pill: 999
  },
  button: {
    borderRadius: 12,
    height: 56,
  },
  input: {
    borderRadius: 12,
    height: 56,
  },
  shadow: {
    sm: {
      shadowColor: '#1A1025',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.06,
      shadowRadius: 4,
      elevation: 2,
    },
    md: {
      shadowColor: '#1A1025',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.08,
      shadowRadius: 8,
      elevation: 4,
    },
  },
};

