// services/organization.service.ts

import { api } from './api';

export interface Organization {
  orgId: number;
  orgName: string;
  orgType: string;
  planId: number;
  planName: string;
  maxAllowedEmployee: number;
  createdAt: string;
}

export interface UpdateOrganizationRequest {
  orgName?: string;
  orgType?: string;
}

export async function getMyOrganization(): Promise<Organization> {
  return api.get<Organization>(
    '/api/organizations/me'
  );
}

export async function updateMyOrganization(
  payload: UpdateOrganizationRequest
): Promise<Organization> {
  return api.put<Organization>(
    '/api/organizations/me',
    payload
  );
}

export const organizationService = {
  getMyOrganization,
  updateMyOrganization,
};