// services/api.ts

import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

const TOKEN_KEY = 'presenza_auth_token';

/**
 * Local backend URL
 *
 * Web:
 *   http://localhost:3000
 *
 * Android Emulator:
 *   http://10.0.2.2:3000
 *
 * Physical Android phone:
 *   http://YOUR_PC_LAN_IP:3000
 */
const API_BASE_URL ="https://presenza-backend-sumit-hugqdzfwfxeybngu.centralindia-01.azurewebsites.net";

type RequestOptions = {
  headers?: Record<string, string>;
  body?: unknown;
  token?: string | null;
};

export class ApiError extends Error {
  status: number;
  data: unknown;

  constructor(
    message: string,
    status: number,
    data?: unknown
  ) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

async function getStoredToken(): Promise<string | null> {
  return SecureStore.getItemAsync(TOKEN_KEY);
}

async function request<T>(
  endpoint: string,
  method: string,
  options: RequestOptions = {}
): Promise<T> {
  const storedToken = await getStoredToken();
  const token = options.token ?? storedToken;

  const headers: Record<string, string> = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    ...options.headers,
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  let response: Response;

  try {
    response = await fetch(
      `${API_BASE_URL}${endpoint}`,
      {
        method,
        headers,
        body:
          options.body !== undefined
            ? JSON.stringify(options.body)
            : undefined,
      }
    );
  } catch (error) {
    throw new ApiError(
      'Unable to connect to the server.',
      0,
      error
    );
  }

  const contentType =
    response.headers.get('content-type') ?? '';

  let data: unknown = null;

  if (response.status !== 204) {
    try {
      if (contentType.includes('application/json')) {
        data = await response.json();
      } else {
        const text = await response.text();
        data = text || null;
      }
    } catch {
      data = null;
    }
  }

  if (!response.ok) {
    let message = `Request failed with status ${response.status}`;

    if (
      data &&
      typeof data === 'object' &&
      'message' in data &&
      typeof data.message === 'string'
    ) {
      message = data.message;
    } else if (typeof data === 'string' && data.trim()) {
      message = data;
    }

    throw new ApiError(
      message,
      response.status,
      data
    );
  }

  return data as T;
}

export const api = {
  get<T>(
    endpoint: string,
    options?: Omit<RequestOptions, 'body'>
  ) {
    return request<T>(
      endpoint,
      'GET',
      options
    );
  },

  post<T>(
    endpoint: string,
    body?: unknown,
    options?: Omit<RequestOptions, 'body'>
  ) {
    return request<T>(
      endpoint,
      'POST',
      {
        ...options,
        body,
      }
    );
  },

  put<T>(
    endpoint: string,
    body?: unknown,
    options?: Omit<RequestOptions, 'body'>
  ) {
    return request<T>(
      endpoint,
      'PUT',
      {
        ...options,
        body,
      }
    );
  },

  patch<T>(
    endpoint: string,
    body?: unknown,
    options?: Omit<RequestOptions, 'body'>
  ) {
    return request<T>(
      endpoint,
      'PATCH',
      {
        ...options,
        body,
      }
    );
  },

  delete<T>(
    endpoint: string,
    options?: Omit<RequestOptions, 'body'>
  ) {
    return request<T>(
      endpoint,
      'DELETE',
      options
    );
  },
};

export const tokenStorage = {
  getToken() {
    return SecureStore.getItemAsync(TOKEN_KEY);
  },

  setToken(token: string) {
    return SecureStore.setItemAsync(
      TOKEN_KEY,
      token
    );
  },

  deleteToken() {
    return SecureStore.deleteItemAsync(
      TOKEN_KEY
    );
  },
};

export { API_BASE_URL };