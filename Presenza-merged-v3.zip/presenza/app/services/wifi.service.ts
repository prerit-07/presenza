import { Platform, PermissionsAndroid } from 'react-native';
import WifiManager from 'react-native-wifi-reborn';
import * as Location from 'expo-location';
import Constants from 'expo-constants';

export interface WifiInfo {
  ssid: string | null;
  bssid: string | null;
  error?: string;
}

class WifiService {
  /**
   * Requests necessary permissions and retrieves the current connected Wi-Fi info.
   */
  async getCurrentWifi(): Promise<WifiInfo> {
    try {
      // 0. If running inside Expo Go, we must mock the Wi-Fi result
      if (Constants.appOwnership === 'expo') {
        console.log('[WifiService] Running in Expo Go: returning mock Wi-Fi data.');
        return {
          ssid: 'MyOfficeWifi (Mock)',
          bssid: 'AA:BB:CC:DD:EE:FF',
        };
      }

      // 1. Check Location Services (Required for SSID on Android/iOS)
      const isLocationEnabled = await Location.hasServicesEnabledAsync();
      if (!isLocationEnabled) {
        return {
          ssid: null,
          bssid: null,
          error: 'Location services are OFF. Please turn on GPS to verify Wi-Fi.',
        };
      }

      // 2. Request Location Permissions
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        return {
          ssid: null,
          bssid: null,
          error: 'Location permission denied. Cannot verify Wi-Fi.',
        };
      }

      // 3. Android 13+ specifically needs NEARBY_WIFI_DEVICES
      if (Platform.OS === 'android' && Platform.Version >= 33) {
        const nearbyPermission = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.NEARBY_WIFI_DEVICES
        );
        if (nearbyPermission !== PermissionsAndroid.RESULTS.GRANTED) {
          return {
            ssid: null,
            bssid: null,
            error: 'Nearby Devices permission denied.',
          };
        }
      }

      // 4. Fetch SSID and BSSID
      const ssid = await WifiManager.getCurrentWifiSSID();
      const bssid = await WifiManager.getBSSID();

      console.log(`[WifiService] Detected Wi-Fi: ${ssid} (${bssid})`);

      return {
        ssid: ssid === '<unknown ssid>' || ssid === '_NOT_CONNECTED_' ? null : ssid,
        bssid: bssid === '02:00:00:00:00:00' ? null : bssid,
      };
    } catch (error) {
      console.warn('Failed to get current Wi-Fi:', error);
      return {
        ssid: null,
        bssid: null,
        error: error instanceof Error ? error.message : 'Unknown Wi-Fi error',
      };
    }
  }
}

export const wifiService = new WifiService();
