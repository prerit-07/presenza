import { api } from "./api";

export interface CreateTicketRequest {
    subject: string;
    description: string;
    checkinId?: number | null;
    attendanceId?: number | null;
}

export const createTicket = async (
    request: CreateTicketRequest
) => {
    return api.post("/tickets", request);
};

export const getMyTickets = async () => {
    return api.get("/tickets/me");
};

export const getTicket = async (ticketId: number) => {
    return api.get(`/tickets/${ticketId}`);
};

export const getOrganizationTickets = async () => {
    return api.get("/tickets");
};

export const addComment = async (
    ticketId: number,
    comment: string
) => {
    // Backend's AddTicketCommentRequest requires a field literally
    // named "message" (@NotBlank) — this was sending "comment",
    // which the DTO doesn't have a setter for, so it always arrived
    // as null and every comment attempt failed validation with
    // "Comment message is required".
    return api.post(`/tickets/${ticketId}/comments`, {
        message: comment,
    });
};

export const getComments = async (
    ticketId: number
) => {
    return api.get(`/tickets/${ticketId}/comments`);
};
//new