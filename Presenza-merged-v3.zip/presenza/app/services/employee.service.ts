// services/employee.service.ts

import { api } from './api';

export interface Employee {
  employeeId: number;
  orgId: number;
  userId: number;
  employeeName: string;
  dateOfJoining: string | null;
  departmentId: number | null;
  shiftId: number | null;
  teamId: number | null;
}

export interface CreateEmployeeRequest {
  username: string;
  email: string;
  employeeName: string;
  dateOfJoining?: string | null;
  departmentId?: number | null;
  shiftId?: number | null;
  teamId?: number | null;
}

export interface UpdateEmployeeRequest {
  orgId: number;
  userId: number;
  employeeName: string;
  dateOfJoining?: string | null;
  departmentId?: number | null;
  shiftId?: number | null;
  teamId?: number | null;
}

export async function getEmployees():
  Promise<Employee[]> {
  return api.get<Employee[]>(
    '/api/employees'
  );
}

export async function getMyEmployee():
  Promise<Employee> {
  return api.get<Employee>(
    '/api/employees/me'
  );
}

export async function getEmployeeById(
  employeeId: number
): Promise<Employee> {
  return api.get<Employee>(
    `/api/employees/${employeeId}`
  );
}

export async function createEmployee(
  payload: CreateEmployeeRequest
): Promise<Employee> {
  return api.post<Employee>(
    '/api/employees',
    payload
  );
}

export async function updateEmployee(
  employeeId: number,
  payload: UpdateEmployeeRequest
): Promise<Employee> {
  return api.put<Employee>(
    `/api/employees/${employeeId}`,
    payload
  );
}

export const employeeService = {
  getEmployees,
  getMyEmployee,
  getEmployeeById,
  createEmployee,
  updateEmployee,
};