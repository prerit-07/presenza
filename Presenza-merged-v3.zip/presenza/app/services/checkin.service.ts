// services/checkin.service.ts

import { api } from './api';

export interface EmployeeCheckInRequest {
  shiftId: number;
  deviceId: string;
  latitude: number;
  longitude: number;
  connectedSsid?: string | null;
  connectedBssid?: string | null;
}

export interface CheckInResponse {
  checkInId: number;
  employeeId: number;
  shiftId: number;
  deviceId: string;
  checkInTime: string;
  latitude: number | null;
  longitude: number | null;
  wifiVerified: boolean;
  attendanceStatus?: string | null;
}

export async function checkIn(
  payload: EmployeeCheckInRequest
): Promise<CheckInResponse> {
  return api.post<CheckInResponse>(
    '/check-ins/employee',
    payload
  );
}

export const checkInService = {
  checkIn,
};