// services/auth.service.ts

import { Platform } from 'react-native';

import { api, tokenStorage } from './api';

import {
  ensureCurrentDeviceRegistered,
} from './device.service';

export type UserRole =
  | 'ORG_ADMIN'
  | 'MANAGER'
  | 'EMPLOYEE'
  | string;

export interface AuthUser {
  id: string;
  userId: number;
  username: string;
  name: string;
  email: string;
  role: UserRole;

  avatar?: string;
  designation?: string;
  department?: string;
}

export interface LoginRequest {
  email: string;
  password: string;
  deviceInfo?: string;
}

export interface LoginResponse {
  token: string;
  userId: number;
  username: string;
  email: string;
  expiresAt: string;
  mustChangePassword: boolean;
}

export interface LoginResult {
  success: boolean;
  user?: AuthUser;
  mustChangePassword?: boolean;
  error?: string;
}

export interface ChangePasswordRequest {
  currentPassword: string;
  newPassword: string;
}

export interface ChangePasswordResponse {
  success: boolean;
  message: string;
}

export interface ForgotPasswordResponse {
  success: boolean;
  message: string;
}

export interface ResetPasswordRequest {
  email: string;
  newPassword: string;
}

export interface ResetPasswordResponse {
  success: boolean;
  message: string;
}

export interface VerifyPasswordResetOtpRequest {
  email: string;
  otp: string;
}

export interface VerifyOtpResponse {
  success: boolean;
  message: string;
}

export interface RegisterRequest {
  organizationName: string;
  username: string;
  email: string;
  password: string;
}

export interface RegisterResponse {
  organizationId: number;
  organizationName: string;
  userId: number;
  username: string;
  email: string;
  role: UserRole;
}

export interface SendOtpRequest {
  email: string;
  purpose: 'REGISTRATION' | 'PASSWORD_RESET';
}

export interface VerifyOtpRequest {
  email: string;
  otp: string;
  purpose: 'REGISTRATION' | 'PASSWORD_RESET';
}

export interface GenericResponse {
  success: boolean;
  message: string;
}

export interface CurrentUserResponse {
  userId: number;
  username: string;
  email: string;
  role: UserRole;
}

function getDefaultDeviceInfo(): string {
  if (Platform.OS === 'android') {
    return 'Android';
  }

  if (Platform.OS === 'ios') {
    return 'iOS';
  }

  if (Platform.OS === 'web') {
    return 'Web';
  }

  return Platform.OS;
}

function mapCurrentUserToAuthUser(
  user: CurrentUserResponse
): AuthUser {
  return {
    id: String(user.userId),
    userId: user.userId,
    username: user.username,
    name: user.username,
    email: user.email,
    role: user.role,
  };
}

export async function login(
  payload: LoginRequest
): Promise<LoginResult> {
  try {
    // =====================================
    // 1. LOGIN
    // =====================================

    const response =
      await api.post<LoginResponse>(
        '/auth/login',
        {
          email: payload.email
            .trim()
            .toLowerCase(),

          password: payload.password,

          deviceInfo:
            payload.deviceInfo ??
            getDefaultDeviceInfo(),
        }
      );

    // =====================================
    // 2. SAVE TOKEN
    // =====================================

    await tokenStorage.setToken(
      response.token
    );

    // =====================================
    // 3. FETCH VERIFIED CURRENT USER
    // =====================================

    const currentUser =
      await api.get<CurrentUserResponse>(
        '/auth/me'
      );

    const user =
      mapCurrentUserToAuthUser(
        currentUser
      );

    // =====================================
    // 4. RECONCILE CURRENT DEVICE
    //
    // IMPORTANT:
    // Device failure must NOT fail login.
    // =====================================

    try {
      const device =
        await ensureCurrentDeviceRegistered();

      console.log(
        'Current device ready after login:',
        device
      );
    } catch (deviceError) {
      console.warn(
        'Device reconciliation after login failed:',
        deviceError
      );
    }

    // =====================================
    // 5. RETURN AUTHENTICATED USER
    // =====================================

    return {
      success: true,
      user,
      mustChangePassword:
        response.mustChangePassword,
    };
  } catch (error) {
    // Any actual login/auth failure clears
    // the possibly stale token.

    await tokenStorage.deleteToken();

    return {
      success: false,

      error:
        error instanceof Error
          ? error.message
          : 'Login failed',
    };
  }
}

export async function register(
  payload: RegisterRequest
): Promise<RegisterResponse> {
  return api.post<RegisterResponse>(
    '/auth/register',
    payload
  );
}

export async function sendOtp(
  payload: SendOtpRequest
): Promise<GenericResponse> {
  return api.post<GenericResponse>(
    '/verification/send-otp',
    payload
  );
}

export async function verifyOtp(
  payload: VerifyOtpRequest
): Promise<GenericResponse> {
  return api.post<GenericResponse>(
    '/verification/verify-otp',
    payload
  );
}

export async function getMe():
  Promise<AuthUser> {
  const response =
    await api.get<CurrentUserResponse>(
      '/auth/me'
    );

  return mapCurrentUserToAuthUser(
    response
  );
}

export async function logout():
  Promise<void> {
  try {
    await api.post<void>(
      '/auth/logout'
    );
  } finally {
    await tokenStorage.deleteToken();
  }
}

export async function changePassword(
  payload: ChangePasswordRequest
): Promise<ChangePasswordResponse> {
  return api.put<ChangePasswordResponse>(
    '/auth/change-password',
    payload
  );
}

export async function forgotPassword(
  email: string
): Promise<ForgotPasswordResponse> {
  return api.post<ForgotPasswordResponse>(
    '/auth/forgot-password',
    { email }
  );
}

export async function verifyPasswordResetOtp(
  payload: VerifyPasswordResetOtpRequest
): Promise<VerifyOtpResponse> {
  return api.post<VerifyOtpResponse>(
    '/verification/verify-otp',
    {
      ...payload,
      purpose: 'PASSWORD_RESET',
    }
  );
}

export async function resetPassword(
  payload: ResetPasswordRequest
): Promise<ResetPasswordResponse> {
  return api.put<ResetPasswordResponse>(
    '/auth/reset-password',
    payload
  );
}

export const authService = {
  login,
  changePassword,
  forgotPassword,
  verifyPasswordResetOtp,
  resetPassword,
  register,
  sendOtp,
  verifyOtp,
  getMe,
  logout,
};
//new