import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';

export async function exportToCsv(
  filename: string,
  headers: string[],
  data: any[][]
): Promise<void> {
  try {
    const headerRow = headers.join(',');
    const dataRows = data.map((row) =>
      row
        .map((cell) => {
          const cellString = cell !== null && cell !== undefined ? String(cell) : '';
          if (cellString.includes(',') || cellString.includes('"')) {
            return `"${cellString.replace(/"/g, '""')}"`;
          }
          return cellString;
        })
        .join(',')
    );

    const csvContent = [headerRow, ...dataRows].join('\n');
    const fileUri = `${FileSystem.documentDirectory}${filename}`;
    
    await FileSystem.writeAsStringAsync(fileUri, csvContent, {
      encoding: FileSystem.EncodingType.UTF8,
    });

    const isAvailable = await Sharing.isAvailableAsync();
    if (isAvailable) {
      await Sharing.shareAsync(fileUri, {
        mimeType: 'text/csv',
        dialogTitle: 'Export Attendance CSV',
        UTI: 'public.comma-separated-values-text',
      });
    } else {
      console.warn('Sharing is not available');
    }
  } catch (error) {
    console.error('Failed to export CSV:', error);
    throw error;
  }
}
