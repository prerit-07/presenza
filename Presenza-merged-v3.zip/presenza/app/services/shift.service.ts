import { api } from './api';

export interface Shift {
  shiftId: number;
  orgId: number;
  shiftName: string;
  startTime: string;
  endTime: string;
  allowedLateMinutes: number | null;
  geofenceId: number | null;
}

export interface ShiftRequest {
  orgId: number;
  shiftName: string;
  startTime: string;
  endTime: string;
  allowedLateMinutes?: number | null;
  geofenceId?: number | null;
}

export type CreateShiftRequest =
  ShiftRequest;

export type UpdateShiftRequest =
  ShiftRequest;

export async function getShifts():
  Promise<Shift[]> {
  return api.get<Shift[]>(
    '/api/shifts'
  );
}

export async function createShift(
  payload: CreateShiftRequest
): Promise<Shift> {
  return api.post<Shift>(
    '/api/shifts',
    payload
  );
}

export async function getShiftById(
  shiftId: number
): Promise<Shift> {
  return api.get<Shift>(
    `/api/shifts/${shiftId}`
  );
}

export async function updateShift(
  shiftId: number,
  payload: UpdateShiftRequest
): Promise<Shift> {
  return api.put<Shift>(
    `/api/shifts/${shiftId}`,
    payload
  );
}

export const shiftService = {
  getShifts,
  createShift,
  getShiftById,
  updateShift,
};