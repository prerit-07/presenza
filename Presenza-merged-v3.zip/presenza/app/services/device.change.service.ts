import { api } from './api';

export interface DeviceChangeRequestResponse {
  requestId: number;
  userId: number;
  oldDeviceId: string;
  newDeviceId: string;
  reason: string;
  status: string;
  reviewedByEmployeeId: number | null;
  requestedAt: string;
  reviewedAt: string | null;
}

export const deviceChangeService = {
  getPendingRequests: async () => {
    return api.get<DeviceChangeRequestResponse[]>('/device-change-requests/pending');
  },
  
  createRequest: async (oldDeviceId: string, newDeviceId: string, reason: string) => {
    return api.post<DeviceChangeRequestResponse>('/device-change-requests', {
      oldDeviceId,
      newDeviceId,
      reason
    });
  },
  
  reviewRequest: async (requestId: number, approved: boolean) => {
    return api.patch<DeviceChangeRequestResponse>(`/device-change-requests/${requestId}/review`, {
      approved
    });
  }
};