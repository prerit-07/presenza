import { api } from './api';

export interface DepartmentResponse {
  departmentId: number;
  orgId: number;
  departmentName: string;
}

export interface DepartmentRequest {
  orgId: number;
  departmentName: string;
}

export const departmentService = {
  getDepartments: async () => {
    return api.get<DepartmentResponse[]>('/api/departments');
  },
  createDepartment: async (payload: DepartmentRequest) => {
    return api.post<DepartmentResponse>('/api/departments', payload);
  }
};