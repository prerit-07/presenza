import { api } from './api';

export interface Geofence {
  geofenceId: number;
  orgId: number;
  latitude: number;
  longitude: number;
  radius: number;
  buildingName: string | null;
}

export interface WifiNetworkRequest {
  ssid: string;
  bssid: string;
}

export interface CreateGeofenceRequest {
  orgId: number;
  latitude: number;
  longitude: number;
  radius: number;
  buildingName?: string | null;
  routers?: WifiNetworkRequest[];
}

export async function getGeofences(): Promise<Geofence[]> {
  return api.get<Geofence[]>('/api/geofences');
}

export async function getGeofenceById(id: number): Promise<Geofence> {
  return api.get<Geofence>(`/api/geofences/${id}`);
}

export async function getGeofenceRouters(geofenceId: number): Promise<any[]> {
  return api.get<any[]>(`/api/wifi-networks/geofence/${geofenceId}`);
}

export async function addWifiNetwork(payload: { geofenceId: number; ssid: string; bssid: string }): Promise<any> {
  return api.post<any>('/api/wifi-networks', payload);
}

export async function deleteWifiNetwork(wifiId: number): Promise<void> {
  return api.delete(`/api/wifi-networks/${wifiId}`);
}

export async function createGeofence(
  payload: CreateGeofenceRequest
): Promise<Geofence> {
  return api.post<Geofence>('/api/geofences', payload);
}

export async function updateGeofence(
  id: number,
  payload: CreateGeofenceRequest
): Promise<Geofence> {
  return api.put<Geofence>(`/api/geofences/${id}`, payload);
}

export async function deleteGeofence(id: number): Promise<void> {
  return api.delete(`/api/geofences/${id}`);
}

export const geofenceService = {
  getGeofences,
  getGeofenceById,
  getGeofenceRouters,
  addWifiNetwork,
  deleteWifiNetwork,
  createGeofence,
  updateGeofence,
  deleteGeofence,
};