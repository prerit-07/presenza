// services/device.service.ts

import { Platform } from 'react-native';
import * as Device from 'expo-device';
import * as SecureStore from 'expo-secure-store';
import Constants from 'expo-constants';

import { api } from './api';

const DEVICE_ID_STORAGE_KEY =
  'presenza_device_id';

export interface RegisterDeviceRequest {
  deviceId: string;
  platform: string;
  model: string;
  appVersion: string;
}

export interface DeviceResponse {
  deviceId: string;
  platform: string;
  model: string;
  appVersion: string;
  boundAt: string;
  lastSeenAt: string | null;
  active: boolean;
}

function generateStableDeviceId(): string {
  const randomPart = Math.random()
    .toString(36)
    .slice(2, 12);

  const timestampPart = Date.now()
    .toString(36);

  return `presenza-${timestampPart}-${randomPart}`;
}

export async function getStableDeviceId():
  Promise<string> {
  const existingDeviceId =
    await SecureStore.getItemAsync(
      DEVICE_ID_STORAGE_KEY
    );

  if (existingDeviceId) {
    return existingDeviceId;
  }

  const newDeviceId =
    generateStableDeviceId();

  await SecureStore.setItemAsync(
    DEVICE_ID_STORAGE_KEY,
    newDeviceId
  );

  return newDeviceId;
}

function getPlatformName(): string {
  if (Platform.OS === 'android') {
    return 'Android';
  }

  if (Platform.OS === 'ios') {
    return 'iOS';
  }

  if (Platform.OS === 'web') {
    return 'Web';
  }

  return Platform.OS;
}

function getDeviceModel(): string {
  return (
    Device.modelName ??
    Device.deviceName ??
    'Unknown Device'
  );
}

function getAppVersion(): string {
  return (
    Constants.expoConfig?.version ??
    '1.0.0'
  );
}

export async function getDeviceRegistrationPayload():
  Promise<RegisterDeviceRequest> {
  const deviceId =
    await getStableDeviceId();

  return {
    deviceId,
    platform: getPlatformName(),
    model: getDeviceModel(),
    appVersion: getAppVersion(),
  };
}

export async function registerCurrentDevice():
  Promise<DeviceResponse> {
  const payload =
    await getDeviceRegistrationPayload();

  return api.post<DeviceResponse>(
    '/devices',
    payload
  );
}

export async function getMyDevices():
  Promise<DeviceResponse[]> {
  return api.get<DeviceResponse[]>(
    '/devices'
  );
}

export async function deactivateDevice(
  deviceId: string
): Promise<DeviceResponse> {
  return api.patch<DeviceResponse>(
    `/devices/${encodeURIComponent(
      deviceId
    )}/deactivate`
  );
}

export async function ensureCurrentDeviceRegistered():
  Promise<DeviceResponse> {
  const currentDeviceId =
    await getStableDeviceId();

  const devices =
    await getMyDevices();

  const existingActiveDevice =
    devices.find(
      (device) =>
        device.deviceId ===
          currentDeviceId &&
        device.active
    );

  if (existingActiveDevice) {
    return existingActiveDevice;
  }

  return registerCurrentDevice();
}

export const deviceService = {
  getStableDeviceId,
  getDeviceRegistrationPayload,
  registerCurrentDevice,
  getMyDevices,
  deactivateDevice,
  ensureCurrentDeviceRegistered,
  isDeviceNotFoundError,
};

/**
 * Device registration is attempted once at login and once at
 * session-restore time (both fire-and-forget, errors are only
 * console.warn'd so they can never block sign-in). If that one
 * attempt fails — e.g. a cold-started backend timing out — the
 * device is never registered, and every check-in after that would
 * otherwise fail forever with "Device not found" until the app is
 * fully killed and reopened. This lets check-in screens recognize
 * that specific failure and retry registration once, inline.
 */
export function isDeviceNotFoundError(error: unknown): boolean {
  const message =
    error instanceof Error
      ? error.message
      : typeof error === 'object' && error !== null && 'message' in error
        ? String((error as { message?: unknown }).message ?? '')
        : '';

  return /device not found/i.test(message);
}