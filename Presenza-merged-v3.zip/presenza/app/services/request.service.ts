import { api } from "./api";

export interface AttendanceRequest {
    requestType: "LEAVE" | "WFH";
    startDate: string;
    endDate: string;
    reason: string;
}

export interface AttendanceRequestResponse {
    requestId: number;
    employeeId: number;
    employeeName: string;
    requestType: "LEAVE" | "WFH" | string;
    startDate: string;
    endDate: string;
    reason: string;
    status: "PENDING" | "APPROVED" | "REJECTED" | string;
    reviewedByEmployeeId: number | null;
    reviewRemarks: string | null;
    reviewedAt: string | null;
    createdAt: string;
    updatedAt: string;
}

export interface ReviewAttendanceRequestDecision {
    approved: boolean;
    remarks?: string;
}

export const createRequest = async (request: AttendanceRequest) => {
    return api.post<AttendanceRequestResponse>("/attendance-requests", request);
};

export const getMyRequests = async () => {
    return api.get<AttendanceRequestResponse[]>("/attendance-requests/me");
};

// Every request in the org, any status — used by approval screens that
// need to show APPROVED/REJECTED history, not just what's PENDING.
export const getOrganizationRequests = async () => {
    return api.get<AttendanceRequestResponse[]>("/attendance-requests");
};

export const getPendingRequests = async () => {
    return api.get<AttendanceRequestResponse[]>("/attendance-requests/pending");
};

export const reviewRequest = async (
    requestId: number,
    decision: ReviewAttendanceRequestDecision
) => {
    return api.patch<AttendanceRequestResponse>(
        `/attendance-requests/${requestId}/review`,
        decision
    );
};