import { api } from './api';

export type AttendanceStatus =
  | 'PRESENT'
  | 'PENDING'
  | 'REJECTED'
  | 'ABSENT'
  | 'LATE'
  | string;

export interface Attendance {
  attendanceId: number;
  checkinId: number;
  userId: number;
  shiftId: number | null;
  status: AttendanceStatus;
  approvedAt: string | null;
  remarks: string | null;
  checkinTime: string;
  wifiVerified: boolean;
}

export async function getOrganizationAttendance():
  Promise<Attendance[]> {
  return api.get<Attendance[]>(
    '/attendance'
  );
}

export const attendanceService = {
  getOrganizationAttendance,
};