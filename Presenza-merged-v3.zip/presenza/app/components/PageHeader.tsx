/**
 * PageHeader — Consistent header used across all inner screens.
 * Purple lavender bg, circle back button, centered title + optional subtitle.
 */
import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  rightElement?: React.ReactNode;
}

export function PageHeader({ title, subtitle, onBack, rightElement }: PageHeaderProps) {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const handleBack = () => {
    if (onBack) onBack();
    else if (router.canGoBack()) router.back();
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top + 12 }]}>
      {/* Back button — always top-left */}
      <TouchableOpacity style={styles.backCircle} onPress={handleBack}>
        <Ionicons name="chevron-back" size={20} color="#5B3D7A" />
      </TouchableOpacity>

      {/* Centered title block (absolute to guarantee true center regardless of side widths) */}
      <View style={[styles.center, { top: insets.top + 12 }]} pointerEvents="none">
        <Text style={styles.title}>{title}</Text>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
      </View>

      {/* Optional right element */}
      <View style={styles.right}>
        {rightElement}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#EDE8F5',
    paddingHorizontal: 16,
    paddingBottom: 18,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  backCircle: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: '#CAA6EC',
    justifyContent: 'center', alignItems: 'center',
  },
  center: {
    position: 'absolute',
    left: 0, right: 0, bottom: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 22, fontWeight: '700', color: '#29185c',
  },
  subtitle: {
    fontSize: 12, color: '#6B4E8D', marginTop: 3, textAlign: 'center',
  },
  right: {
    alignItems: 'flex-end',
    minWidth: 40,
  },
});
