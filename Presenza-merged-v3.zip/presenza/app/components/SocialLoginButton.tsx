import React from 'react';
import { StyleSheet, Pressable, ViewStyle, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Theme } from '@/constants/theme';

export type SocialProvider = 'google' | 'apple' | 'facebook';

interface SocialLoginButtonProps {
  provider: SocialProvider;
  onPress: () => void;
  style?: ViewStyle;
}

export const SocialLoginButton: React.FC<SocialLoginButtonProps> = ({
  provider,
  onPress,
  style,
}) => {
  let iconName: React.ComponentProps<typeof Ionicons>['name'] = 'logo-google';
  let iconColor = Theme.colors.text;

  switch (provider) {
    case 'google':
      iconName = 'logo-google';
      iconColor = Theme.colors.socialGoogle;
      break;
    case 'apple':
      iconName = 'logo-apple';
      iconColor = Theme.colors.socialApple;
      break;
    case 'facebook':
      iconName = 'logo-facebook';
      iconColor = Theme.colors.socialFacebook;
      break;
  }

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        Platform.OS === 'ios' && pressed && styles.pressed,
        style,
      ]}
      android_ripple={{ color: 'rgba(111, 74, 168, 0.1)' }}
    >
      <Ionicons name={iconName} size={28} color={iconColor} />
    </Pressable>
  );
};

const styles = StyleSheet.create({
  button: {
    width: 60,
    height: 60,
    borderRadius: 16,
    backgroundColor: Theme.colors.white,
    borderWidth: 1,
    borderColor: Theme.colors.border,
    justifyContent: 'center',
    alignItems: 'center',
    ...Theme.shadow,
    ...Platform.select({
      web: {
        cursor: 'pointer',
      },
    }),
  },
  pressed: {
    opacity: 0.8,
  },
});
