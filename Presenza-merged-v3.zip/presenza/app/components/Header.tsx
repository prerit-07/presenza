import React from 'react';
import { StyleSheet, Text, View, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const PURPLE_DARK   = '#5B3D7A';
const PURPLE_MED    = '#7B5EA7';
const PURPLE_LIGHT  = '#EBE0F5';
const PURPLE_BG     = '#F3EDF7';

interface HeaderProps {
  title: string;
  subtitle?: string;
  showBackButton?: boolean;
  onBackPress?: () => void;
  showNotificationButton?: boolean;
  notificationCount?: number;
  onNotificationPress?: () => void;
  lightMode?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  subtitle,
  showBackButton = true,
  onBackPress,
  showNotificationButton = false,
  notificationCount = 0,
  onNotificationPress,
  lightMode = false,
}) => {
  const insets = useSafeAreaInsets();

  const handleBack = () => {
    if (onBackPress) { onBackPress(); }
    else if (router.canGoBack()) { router.back(); }
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top + 10 }]}>
      <View style={styles.leftSection}>
        {showBackButton && (
          <Pressable
            onPress={handleBack}
            style={styles.circleButton}
            android_ripple={{ color: 'rgba(91,61,122,0.2)', radius: 20 }}
          >
            <Ionicons name="arrow-back" size={22} color={PURPLE_DARK} />
          </Pressable>
        )}
        <View style={[styles.titleContainer, !showBackButton && styles.titleNoBack]}>
          <Text style={styles.title}>{title}</Text>
          {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
        </View>
      </View>

      {showNotificationButton && (
        <Pressable
          onPress={onNotificationPress}
          style={styles.circleButton}
          android_ripple={{ color: 'rgba(91,61,122,0.2)', radius: 20 }}
        >
          <Ionicons name="notifications" size={22} color={PURPLE_DARK} />
          {notificationCount > 0 && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{notificationCount}</Text>
            </View>
          )}
        </Pressable>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 14,
    backgroundColor: PURPLE_BG,
  },
  leftSection: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  circleButton: {
    width: 42, height: 42, borderRadius: 21,
    backgroundColor: PURPLE_LIGHT,
    justifyContent: 'center', alignItems: 'center',
  },
  titleContainer: { marginLeft: 14, flex: 1, justifyContent: 'center' },
  titleNoBack:    { marginLeft: 0 },
  title: {
    fontSize: 20, fontWeight: '700', color: PURPLE_DARK,
  },
  subtitle: {
    fontSize: 12, color: PURPLE_MED, marginTop: 2,
  },
  badge: {
    position: 'absolute', top: 2, right: 2,
    backgroundColor: '#E85D5D',
    borderRadius: 8, width: 16, height: 16,
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 1.5, borderColor: '#FFF',
  },
  badgeText: { color: '#FFF', fontSize: 9, fontWeight: '700' },
});
