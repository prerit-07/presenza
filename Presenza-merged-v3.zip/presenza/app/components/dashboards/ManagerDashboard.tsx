import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { DashboardTheme as T, GREETING_FONT } from '@/constants/dashboard-theme';
import { useRouter } from 'expo-router';
import { useAppStore } from '@/store/useAppStore';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

interface Props {
  userName: string;
}

export default function ManagerDashboard({ userName }: Props) {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const session = useAppStore((s) => s.attendanceSession);
  const leaveRequests = useAppStore((s) => s.leaveRequests);
  const deviceRequests = useAppStore((s) => s.deviceRequests);
  const pendingLeaves = leaveRequests.filter((l) => l.status === 'PENDING').length;
  const pendingDevices = deviceRequests.filter((d) => d.status === 'PENDING').length;

  return (
    <ScrollView style={styles.container} contentContainerStyle={[styles.scrollContent, { paddingTop: insets.top + 10 }]} showsVerticalScrollIndicator={false}>
      {/* ─── Header ─── */}
      <View style={styles.header}>
        <Image source={{ uri: 'https://i.pravatar.cc/150?img=12' }} style={styles.avatar} />
        <View style={styles.searchBar}>
          <TextInput
            placeholder="Search Team Members"
            placeholderTextColor={T.textMuted}
            style={styles.searchInput}
          />
          <Ionicons name="search" size={18} color={T.textMuted} />
        </View>
        <TouchableOpacity style={styles.bellBtn} onPress={() => router.push('/notifications')}>
          <Ionicons name="notifications-outline" size={22} color={T.purpleDark} />
          <View style={styles.dot} />
        </TouchableOpacity>
      </View>

      {/* ─── Greeting ─── */}
      <Text style={styles.greetLine}>GOOD MORNING,</Text>
      <Text style={styles.greetName}>{userName.toUpperCase()}!</Text>

      {/* ─── Shift Card ─── */}
      <View style={styles.card}>
        <Text style={styles.shiftLabel}>SHIFT TODAY : GENERAL (9:00AM - 5:00PM)</Text>
        <View style={styles.shiftRow}>
          <View style={styles.calIconWrap}>
            <MaterialCommunityIcons name="calendar-month" size={30} color={T.purpleIcon} />
          </View>
          <View>
            <Text style={styles.shiftDate}>
              {new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', weekday: 'long' })}
            </Text>
            <Text style={styles.shiftHours}>
              {session?.isCheckedIn ? `Checked in at ${session.checkInTime}` : '0h / 8h'}
            </Text>
          </View>
        </View>
        {session?.isCheckedIn ? (
          <TouchableOpacity style={[styles.clockInBtn, styles.clockOutBtn]} onPress={() => router.push('/(manager)/remote-checkin')}>
            <MaterialCommunityIcons name="logout" size={14} color="#B23A48" />
            <Text style={[styles.clockInText, { color: '#B23A48' }]}>Clock Out</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity style={styles.clockInBtn} onPress={() => router.push('/(manager)/remote-checkin')}>
            <MaterialCommunityIcons name="login" size={14} color={T.purpleDark} />
            <Text style={styles.clockInText}>Clock In</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* ─── Team Attendance Card ─── */}
      <View style={styles.card}>
        <Text style={styles.cardLabel}>TEAM ATTENDANCE TODAY</Text>
        <View style={styles.statsRow}>
          <View style={styles.statBox}>
            <Text style={styles.statNum}>12</Text>
            <Text style={styles.statLabel}>Present</Text>
          </View>
          <View style={[styles.statBox, styles.statBorder]}>
            <Text style={[styles.statNum, { color: T.redDot }]}>2</Text>
            <Text style={styles.statLabel}>Absent</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={[styles.statNum, { color: T.purpleMedium }]}>1</Text>
            <Text style={styles.statLabel}>On Leave</Text>
          </View>
        </View>
      </View>

      {/* ─── Pending Requests ─── */}
      <Text style={styles.sectionTitle}>Pending Requests ({pendingLeaves + pendingDevices})</Text>

      {pendingLeaves === 0 && pendingDevices === 0 ? (
        <View style={styles.noPendingCard}>
          <MaterialCommunityIcons name="check-circle-outline" size={22} color="#4CAF50" />
          <Text style={styles.noPendingText}>All requests are processed</Text>
        </View>
      ) : (
        <>
          {pendingLeaves > 0 && (
            <TouchableOpacity style={styles.reqCard} onPress={() => router.push('/(manager)/leave-approvals')}>
              <View style={styles.reqInfo}>
                <View style={styles.reqIconWrap}>
                  <MaterialCommunityIcons name="calendar-clock" size={20} color="#F59E0B" />
                </View>
                <View>
                  <Text style={styles.reqName}>{pendingLeaves} Leave Request{pendingLeaves > 1 ? 's' : ''} Pending</Text>
                  <Text style={styles.reqType}>Tap to review and approve</Text>
                </View>
              </View>
              <MaterialCommunityIcons name="chevron-right" size={18} color={T.textMuted} />
            </TouchableOpacity>
          )}
          {pendingDevices > 0 && (
              <TouchableOpacity style={styles.reqCard} onPress={() => router.push('/(manager)/device-approvals')}>
                <View style={styles.reqInfo}>
                  <View style={[styles.reqIconWrap, { backgroundColor: T.purpleLight }]}>
                    <MaterialCommunityIcons name="cellphone-key" size={20} color={T.purpleIcon} />
                  </View>
                  <View>
                    <Text style={styles.reqName}>{pendingDevices} Device Request{pendingDevices > 1 ? 's' : ''} Pending</Text>
                    <Text style={styles.reqType}>Tap to review and approve</Text>
                  </View>
                </View>
                <MaterialCommunityIcons name="chevron-right" size={18} color={T.textMuted} />
              </TouchableOpacity>
          )}
        </>
      )}

      {/* ─── Quick Access ─── */}
      <Text style={[styles.sectionTitle, { marginTop: 22 }]}>Manager Tools</Text>
      <View style={styles.quickAccessBox}>
        <View style={styles.qaRow}>
          <QAIcon icon="calendar-plus" label={'Add\nAttendance'} onPress={() => router.push({ pathname: '/(manager)/(tabs)/my-team', params: { action: 'addAttendance' } })} />
          <QAIcon icon="calendar-check-outline" label={'Leave\nApprovals'} onPress={() => router.push('/(manager)/leave-approvals')} />
          <QAIcon icon="home-export-outline" label={'WFH\nApprovals'} onPress={() => router.push('/(manager)/wfh-approvals')} />
          <QAIcon icon="cellphone-check" label={'Device\nApprovals'} onPress={() => router.push('/(manager)/device-approvals')} />
        </View>
      </View>

      <View style={{ height: 120 }} />
    </ScrollView>
  );
}

/* ── Request Item ── */
function RequestItem({ name, type, avatar }: { name: string; type: string; avatar: string }) {
  return (
    <View style={styles.reqCard}>
      <View style={styles.reqInfo}>
        <Image source={{ uri: avatar }} style={styles.reqAvatar} />
        <View>
          <Text style={styles.reqName}>{name}</Text>
          <Text style={styles.reqType}>{type}</Text>
        </View>
      </View>
      <View style={styles.reqActions}>
        <TouchableOpacity style={styles.approveBtn}>
          <Ionicons name="checkmark" size={16} color="#FFF" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.rejectBtn}>
          <Ionicons name="close" size={16} color="#FFF" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

/* ── Quick Access Icon ── */
function QAIcon({ icon, label, onPress }: { icon: any; label: string; onPress?: () => void }) {
  return (
    <TouchableOpacity style={styles.qaItem} activeOpacity={0.7} onPress={onPress}>
      <View style={styles.qaCircle}>
        <MaterialCommunityIcons name={icon} size={22} color={T.textWhite} />
      </View>
      <Text style={styles.qaLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: T.screenBg },
  scrollContent: { paddingHorizontal: 20, paddingTop: 10 },

  /* Header */
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: 24 },
  avatar: { width: 44, height: 44, borderRadius: 22, borderWidth: 2, borderColor: T.purpleIcon },
  searchBar: {
    flex: 1, flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#FFF', borderRadius: 25,
    paddingHorizontal: 14, height: 40,
    marginHorizontal: 12,
    borderWidth: 1, borderColor: '#E8E4EC',
  },
  searchInput: { flex: 1, fontSize: 13, color: T.purpleDark },
  bellBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: T.purpleLight,
    justifyContent: 'center', alignItems: 'center',
  },
  dot: {
    position: 'absolute', top: 10, right: 11,
    width: 7, height: 7, borderRadius: 4, backgroundColor: T.redDot,
  },

  /* Greeting */
  greetLine: {
    fontSize: 32,
    fontFamily: 'BitcountGridSingle_400Regular',
    color: T.purpleDark,
    marginTop: 20,
    marginBottom: 4,
    paddingHorizontal: 20,
  },
  greetName: {
    fontSize: 32,
    fontFamily: 'BitcountGridSingle_400Regular',
    color: T.purpleDark,
    paddingHorizontal: 20,
    marginBottom: 20,
    lineHeight: 34,
  },

  /* Card */
  card: {
    backgroundColor: T.cardBg, borderRadius: 18, padding: 18,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06, shadowRadius: 8, elevation: 3,
    marginBottom: 24,
  },
  cardLabel: { fontSize: 11, fontWeight: '700', color: T.purpleDark, marginBottom: 14, letterSpacing: 0.3 },
  statsRow: { flexDirection: 'row',    justifyContent: 'space-between',
  },
  statBox: {
    alignItems: 'center',
    flex: 1,
  },
  statBorder: {
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: '#E8E2F0',
  },
  statNum: {
    fontSize: 24,
    fontWeight: '700',
    color: T.purpleDark,
    marginBottom: 2,
  },
  statLabel: {
    fontSize: 12,
    color: T.textMuted,
    fontWeight: '500',
  },

  /* Clock In Shift styles */
  shiftLabel: { fontSize: 11, fontWeight: '700', color: T.purpleDark, marginBottom: 14, letterSpacing: 0.3 },
  shiftRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  calIconWrap: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: T.purpleLight,
    justifyContent: 'center', alignItems: 'center', marginRight: 14,
  },
  shiftDate: { fontSize: 15, fontWeight: '700', color: T.purpleDark },
  shiftHours: { fontSize: 13, color: T.purpleMedium, marginTop: 2 },
  clockInBtn: {
    alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 6,
    borderWidth: 1.5, borderColor: T.purpleBorder, borderRadius: 25,
    paddingVertical: 8, paddingHorizontal: 24,
  },
  clockOutBtn: { borderColor: '#B23A48', backgroundColor: '#FFF1F3' },
  clockInText: { color: T.purpleDark, fontWeight: '600', fontSize: 13 },/* Section */
  sectionTitle: { fontSize: 15, fontWeight: '700', color: T.purpleDark, marginBottom: 14 },

  /* Request Cards */
  reqCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', borderRadius: 14, padding: 14, marginBottom: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 4, elevation: 2 },
  reqInfo: { flex: 1, flexDirection: 'row', alignItems: 'center' },
  reqIconWrap: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#FFF7E6', alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  reqAvatar: { width: 44, height: 44, borderRadius: 22, marginRight: 12 },
  reqName: { fontSize: 14, fontWeight: '700', color: T.purpleDark },
  reqType: { fontSize: 12, color: T.textMuted, marginTop: 2 },
  noPendingCard: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#F0FFF4', borderRadius: 14, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#C8E6C9' },
  noPendingText: { fontSize: 13, fontWeight: '600', color: '#2E7D32' },
  reqActions: { flexDirection: 'row', gap: 8 },
  approveBtn: {
    backgroundColor: T.approveGreen, width: 30, height: 30, borderRadius: 15,
    justifyContent: 'center', alignItems: 'center',
  },
  rejectBtn: {
    backgroundColor: T.redDot, width: 30, height: 30, borderRadius: 15,
    justifyContent: 'center', alignItems: 'center',
  },

  /* Quick Access */
  quickAccessBox: { backgroundColor: T.quickAccessBg, borderRadius: 22, padding: 18 },
  qaRow: { flexDirection: 'row', justifyContent: 'space-between' },
  qaItem: { alignItems: 'center', width: 60 },
  qaCircle: {
    width: 48, height: 48, borderRadius: 24,
    backgroundColor: T.purpleIcon,
    justifyContent: 'center', alignItems: 'center', marginBottom: 6,
  },
  qaLabel: { fontSize: 10, color: T.textWhite, textAlign: 'center', fontWeight: '600', lineHeight: 13 },
});

