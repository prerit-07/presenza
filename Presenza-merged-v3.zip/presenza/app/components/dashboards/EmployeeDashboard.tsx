import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { DashboardTheme as T, GREETING_FONT } from '@/constants/dashboard-theme';
import { useRouter } from 'expo-router';
import { useAppStore } from '@/store/useAppStore';
import { useState } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

interface Props {
  userName: string;
}

export default function EmployeeDashboard({ userName }: Props) {
  const router = useRouter();
  const session = useAppStore((s) => s.attendanceSession);
  const insets = useSafeAreaInsets();
  
  const [searchQuery, setSearchQuery] = useState('');

  const allFeatures = [
    { id: 'leave', icon: 'airplane', label: 'Apply\nLeave', searchKeys: 'apply leave time off', route: '/(employee)/apply-leave' },
    { id: 'wfh', icon: 'home-export-outline', label: 'Apply\nWFH', searchKeys: 'apply wfh work from home remote', route: '/(employee)/apply-wfh' },
    { id: 'ticket', icon: 'ticket-confirmation-outline', label: 'Raise\nTicket', searchKeys: 'raise ticket help desk support it', route: '/(employee)/help-desk' },
    { id: 'device', icon: 'cellphone-key', label: 'Device\nRequest', searchKeys: 'device request laptop phone hardware', route: '/(employee)/device-request' },
  ];

  const filteredFeatures = allFeatures.filter(f => 
    searchQuery === '' || f.searchKeys.includes(searchQuery.toLowerCase()) || f.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[styles.scrollContent, { paddingTop: insets.top + 10 }]}
      showsVerticalScrollIndicator={false}
    >
      {/* ─── Header ─── */}
      <View style={styles.header}>
        <Image source={{ uri: 'https://i.pravatar.cc/150?img=11' }} style={styles.avatar} />
        <View style={styles.searchBar}>
          <TextInput
            placeholder="Search features..."
            placeholderTextColor={T.textMuted}
            style={styles.searchInput}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          <Ionicons name="search" size={18} color={T.textMuted} />
        </View>
        <TouchableOpacity style={styles.bellBtn} onPress={() => router.push('/(employee)/notifications')}>
          <Ionicons name="notifications-outline" size={22} color={T.purpleDark} />
          <View style={styles.dot} />
        </TouchableOpacity>
      </View>

      {/* ─── Greeting ─── */}
      <Text style={styles.greetLine}>GOOD MORNING,</Text>
      <Text style={styles.greetName}>{userName.toUpperCase()}!</Text>

      {/* ─── Shift Card ─── */}
      <View style={styles.card}>
        <Text style={styles.shiftLabel}>SHIFT TODAY : GENERAL (9:00AM - 5:00PM)</Text>
        <View style={styles.shiftRow}>
          <View style={styles.calIconWrap}>
            <MaterialCommunityIcons name="calendar-month" size={30} color={T.purpleIcon} />
          </View>
          <View>
            <Text style={styles.shiftDate}>
              {new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', weekday: 'long' })}
            </Text>
            <Text style={styles.shiftHours}>
              {session?.isCheckedIn ? `Checked in at ${session.checkInTime}` : '0h / 8h'}
            </Text>
          </View>
        </View>
        {session?.isCheckedIn ? (
          <TouchableOpacity style={[styles.clockInBtn, styles.clockOutBtn]} onPress={() => router.push('/(employee)/remote-checkin')}>
            <MaterialCommunityIcons name="logout" size={14} color="#B23A48" />
            <Text style={[styles.clockInText, { color: '#B23A48' }]}>Clock Out</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity style={styles.clockInBtn} onPress={() => router.push('/(employee)/remote-checkin')}>
            <MaterialCommunityIcons name="login" size={14} color={T.purpleDark} />
            <Text style={styles.clockInText}>Clock In</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* ─── Quick Access ─── */}
      <Text style={styles.sectionTitle}>Quick Access</Text>
      <View style={styles.quickAccessBox}>
        {filteredFeatures.length > 0 ? (
          <View style={styles.qaRow}>
            {filteredFeatures.map(feature => (
              <QAIcon 
                key={feature.id}
                icon={feature.icon as any} 
                label={feature.label} 
                onPress={() => router.push(feature.route as any)} 
              />
            ))}
          </View>
        ) : (
          <Text style={{ textAlign: 'center', color: T.textMuted, fontSize: 13, paddingVertical: 10 }}>
            No features found for "{searchQuery}"
          </Text>
        )}
      </View>

      <View style={{ height: 120 }} />
    </ScrollView>
  );
}

/* ── Quick Access Icon ── */
function QAIcon({ icon, label, onPress }: { icon: any; label: string; onPress?: () => void }) {
  return (
    <TouchableOpacity style={styles.qaItem} activeOpacity={0.7} onPress={onPress}>
      <View style={styles.qaCircle}>
        <MaterialCommunityIcons name={icon} size={22} color={T.textWhite} />
      </View>
      <Text style={styles.qaLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: T.screenBg },
  scrollContent: { paddingHorizontal: 20 },

  /* Header */
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: 24 },
  avatar: { width: 44, height: 44, borderRadius: 22, borderWidth: 2, borderColor: T.purpleIcon },
  searchBar: {
    flex: 1, flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#FFF', borderRadius: 25,
    paddingHorizontal: 14, height: 40,
    marginHorizontal: 12,
    borderWidth: 1, borderColor: '#E8E4EC',
  },
  searchInput: { flex: 1, fontSize: 13, color: T.textDark },
  bellBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: T.purpleLight,
    justifyContent: 'center', alignItems: 'center',
  },
  dot: {
    position: 'absolute', top: 10, right: 11,
    width: 7, height: 7, borderRadius: 4, backgroundColor: T.redDot,
  },

  /* Greeting */
  greetLine: {
    fontSize: 32,
    fontFamily: 'BitcountGridSingle_400Regular',
    color: T.purpleDark,
    marginTop: 20,
    marginBottom: 4,
    paddingHorizontal: 20,
  },
  greetName: {
    fontSize: 32,
    fontFamily: 'BitcountGridSingle_400Regular',
    color: T.purpleDark,
    paddingHorizontal: 20,
    marginBottom: 20,
    lineHeight: 34,
  },

  /* Shift Card */
  card: {
    backgroundColor: T.cardBg, borderRadius: 18, padding: 18,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06, shadowRadius: 8, elevation: 3,
    marginBottom: 24,
  },
  shiftLabel: { fontSize: 11, fontWeight: '700', color: T.purpleDark, marginBottom: 14, letterSpacing: 0.3 },
  shiftRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  calIconWrap: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: T.purpleLight,
    justifyContent: 'center', alignItems: 'center', marginRight: 14,
  },
  // Date is now purple
  shiftDate: { fontSize: 15, fontWeight: '700', color: T.purpleDark },
  shiftHours: { fontSize: 13, color: T.purpleMedium, marginTop: 2 },
  clockInBtn: {
    alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 6,
    borderWidth: 1.5, borderColor: T.purpleBorder, borderRadius: 25,
    paddingVertical: 8, paddingHorizontal: 24,
  },
  clockOutBtn: { borderColor: '#B23A48', backgroundColor: '#FFF1F3' },
  clockInText: { color: T.purpleDark, fontWeight: '600', fontSize: 13 },

  /* Section */
  // "Quick Access" label is now purple
  sectionTitle: { fontSize: 15, fontWeight: '700', color: T.purpleDark, marginBottom: 14 },

  /* Quick Access */
  quickAccessBox: { backgroundColor: T.quickAccessBg, borderRadius: 22, padding: 18 },
  qaRow: { flexDirection: 'row', justifyContent: 'space-around' },
  qaItem: { alignItems: 'center', width: 60 },
  qaCircle: {
    width: 48, height: 48, borderRadius: 24,
    backgroundColor: T.purpleIcon,
    justifyContent: 'center', alignItems: 'center', marginBottom: 6,
  },
  qaLabel: { fontSize: 10, color: T.textWhite, textAlign: 'center', fontWeight: '600', lineHeight: 13 },
});
