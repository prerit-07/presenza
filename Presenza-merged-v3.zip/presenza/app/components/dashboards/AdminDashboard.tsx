import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  ActivityIndicator,
  Alert,
} from 'react-native';

import { Image } from 'expo-image';

import {
  Ionicons,
  MaterialCommunityIcons,
} from '@expo/vector-icons';

import { useRouter, type Href } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { useAppStore } from '@/store/useAppStore';
import { getOrganizationAttendance } from '@/services/attendance.service';
import { getEmployees } from '@/services/employee.service';
import { exportToCsv } from '@/services/export.service';
import { useState } from 'react';
import { ThemedModal, type ThemedModalType } from '@/components/ThemedModal';

interface Props {
  organizationName: string;
  organizationType: string;
  planName: string;
  maxAllowedEmployee: number;
}

export default function AdminDashboard({
  organizationName,
  organizationType,
  planName,
  maxAllowedEmployee,
}: Props) {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const user = useAppStore(
    (state) => state.user
  );
  const session = useAppStore((s) => s.attendanceSession);

  const displayName =
    user?.name?.trim() ||
    user?.username?.trim() ||
    'Admin';

  const [exportModalVisible, setExportModalVisible] = useState(false);
  const [exporting, setExporting] = useState(false);

  const [alertVisible, setAlertVisible] = useState(false);
  const [alertConfig, setAlertConfig] = useState<{
    type: ThemedModalType;
    title: string;
    message: string;
  }>({ type: 'info', title: '', message: '' });

  const [searchQuery, setSearchQuery] = useState('');

  const allFeatures = [
    { id: 'depts', icon: 'office-building-outline', label: 'Manage\nDepts', searchKeys: 'manage depts departments', route: '/(organization)/departments' },
    { id: 'member', icon: 'account-multiple-plus-outline', label: 'Add\nMember', searchKeys: 'add member user employee', route: '/(organization)/add-member' },
    { id: 'office', icon: 'map-marker-radius-outline', label: 'Office\nLocations', searchKeys: 'office locations geofence', route: '/office-locations' },
    { id: 'export', icon: 'file-download-outline', label: 'Export\nCSV', searchKeys: 'export csv download data', onPress: () => setExportModalVisible(true) },
    { id: 'device', icon: 'cellphone-check', label: 'Device\nRequests', searchKeys: 'device requests approvals hardware', route: '/(organization)/device-approvals' },
    { id: 'leave', icon: 'calendar-check-outline', label: 'Leave\nApprovals', searchKeys: 'leave approvals time off', route: '/(organization)/leave-approvals' },
    { id: 'shifts', icon: 'calendar-clock-outline', label: 'Manage\nShifts', searchKeys: 'manage shifts schedule', route: '/(organization)/shifts' },
    { id: 'attendance', icon: 'calendar-check-outline', label: 'View\nAttendance', searchKeys: 'view attendance records', route: '/(organization)/attendance' },
  ];

  const filteredFeatures = allFeatures.filter(f => 
    searchQuery === '' || f.searchKeys.includes(searchQuery.toLowerCase()) || f.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const chunkedFeatures = [];
  for (let i = 0; i < filteredFeatures.length; i += 4) {
    chunkedFeatures.push(filteredFeatures.slice(i, i + 4));
  }

  const showThemedAlert = (type: ThemedModalType, title: string, message: string) => {
    setAlertConfig({ type, title, message });
    setAlertVisible(true);
  };

  const handleExportCSV = async (range: 'today' | 'week' | 'month' | 'all') => {
    try {
      setExporting(true);
      
      const [attendanceRes, employeesRes] = await Promise.all([
        getOrganizationAttendance(),
        getEmployees(),
      ]);
      
      const now = new Date();
      let filteredData = attendanceRes;
      
      if (range === 'today') {
        const todayStr = now.toLocaleDateString();
        filteredData = attendanceRes.filter(r => new Date(r.checkinTime).toLocaleDateString() === todayStr);
      } else if (range === 'week') {
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        filteredData = attendanceRes.filter(r => new Date(r.checkinTime) >= weekAgo);
      } else if (range === 'month') {
        const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        filteredData = attendanceRes.filter(r => new Date(r.checkinTime) >= firstDayOfMonth);
      }
      
      if (filteredData.length === 0) {
        setExportModalVisible(false);
        showThemedAlert('info', 'No Data', 'There are no attendance records for the selected time period.');
        setExporting(false);
        return;
      }
      
      const employeeMap = new Map(employeesRes.map(emp => [emp.userId, emp]));
      
      const headers = ['Employee Name', 'Employee ID', 'Date', 'Status', 'Check-In', 'Check-Out'];
      
      const csvData = filteredData.map(r => {
        const emp = employeeMap.get(r.userId);
        const dateObj = new Date(r.checkinTime);
        const dateStr = dateObj.toLocaleDateString();
        const timeInStr = dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        let timeOutStr = 'N/A';
        if (r.checkoutTime) {
          timeOutStr = new Date(r.checkoutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }
        
        return [
          emp?.employeeName ?? `User #${r.userId}`,
          emp?.employeeId ?? 'N/A',
          dateStr,
          r.status,
          timeInStr,
          timeOutStr
        ];
      });
      
      const filename = `Attendance_Export_${range}_${now.getTime()}.csv`;
      await exportToCsv(filename, headers, csvData);
      
      setExportModalVisible(false);
      showThemedAlert('success', 'Export Complete', `CSV file successfully generated for ${range} range.`);
    } catch (err) {
      console.error('Export error:', err);
      showThemedAlert('error', 'Export Failed', 'There was an error generating the CSV file.');
    } finally {
      setExporting(false);
    }
  };

  return (
    <>
      <ScrollView
        style={styles.container}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: insets.top + 10,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={() =>
            router.push(
              '/(organization)/(tabs)/profile'
            )
          }
        >
          <Image
            source={{
              uri: 'https://i.pravatar.cc/150?img=59',
            }}
            style={styles.avatar}
          />
        </TouchableOpacity>

        <View style={styles.searchBar}>
          <TextInput
            placeholder="Search features..."
            placeholderTextColor={T.textMuted}
            style={styles.searchInput}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />

          <Ionicons
            name="search"
            size={18}
            color={T.textMuted}
          />
        </View>

        <TouchableOpacity
          style={styles.bellBtn}
          activeOpacity={0.7}
          onPress={() =>
            router.push('/notifications')
          }
        >
          <Ionicons
            name="notifications-outline"
            size={22}
            color={T.purpleDark}
          />

          <View style={styles.dot} />
        </TouchableOpacity>
      </View>

      {/* Greeting */}
      <Text style={styles.greetLine}>
        GOOD MORNING,
      </Text>

      <Text style={styles.greetName}>
        {displayName.toUpperCase()}!
      </Text>

      {/* ─── Shift Card ─── */}
      <View style={styles.card}>
        <Text style={styles.shiftLabel}>SHIFT TODAY : GENERAL (9:00AM - 5:00PM)</Text>
        <View style={styles.shiftRow}>
          <View style={styles.calIconWrap}>
            <MaterialCommunityIcons name="calendar-month" size={30} color={T.purpleIcon} />
          </View>
          <View>
            <Text style={styles.shiftDate}>
              {new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', weekday: 'long' })}
            </Text>
            <Text style={styles.shiftHours}>
              {session?.isCheckedIn ? `Checked in at ${session.checkInTime}` : '0h / 8h'}
            </Text>
          </View>
        </View>
        {session?.isCheckedIn ? (
          <TouchableOpacity style={[styles.clockInBtn, styles.clockOutBtn]} onPress={() => router.push('/(employee)/remote-checkin')}>
            <MaterialCommunityIcons name="logout" size={14} color="#B23A48" />
            <Text style={[styles.clockInText, { color: '#B23A48' }]}>Clock Out</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity style={styles.clockInBtn} onPress={() => router.push('/(employee)/remote-checkin')}>
            <MaterialCommunityIcons name="login" size={14} color={T.purpleDark} />
            <Text style={styles.clockInText}>Clock In</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Organization Overview */}
      <View style={styles.card}>
        <Text style={styles.cardLabel}>
          ORGANIZATION OVERVIEW
        </Text>

        <View style={styles.organizationInfo}>
          <View
            style={styles.organizationTextWrap}
          >
            <Text style={styles.organizationName}>
              {organizationName}
            </Text>

            <Text style={styles.organizationType}>
              {organizationType}
            </Text>
          </View>

          <View style={styles.limitBadge}>
            <Text style={styles.limitBadgeText}>
              Max {maxAllowedEmployee}
            </Text>
          </View>
        </View>
      </View>

      {/* Subscription Card */}
      <View style={styles.card}>
        <Text style={styles.cardLabel}>
          SUBSCRIPTION PLAN
        </Text>

        <View style={styles.subRow}>
          <View style={styles.planInfo}>
            <Text style={styles.planName}>
              {planName}
            </Text>

            <Text style={styles.planDetail}>
              Up to {maxAllowedEmployee}{' '}
              employees
            </Text>
          </View>

          <TouchableOpacity
            style={styles.upgradeBtn}
            activeOpacity={0.7}
          >
            <Text style={styles.upgradeText}>
              Upgrade
            </Text>
          </TouchableOpacity>
        </View>
      </View>



      {/* Admin Actions */}
      <Text
        style={[
          styles.sectionTitle,
          {
            marginTop: 22,
          },
        ]}
      >
        Admin Actions
      </Text>

      <View style={styles.quickAccessBox}>
        {chunkedFeatures.length > 0 ? (
          chunkedFeatures.map((row, rowIndex) => (
            <View 
              key={`row-${rowIndex}`} 
              style={[styles.qaRow, rowIndex > 0 && styles.qaSecondRow]}
            >
              {row.map(feature => (
                <QAIcon
                  key={feature.id}
                  icon={feature.icon as any}
                  label={feature.label}
                  onPress={feature.onPress ? feature.onPress : () => router.push(feature.route as any)}
                />
              ))}
              {/* Invisible placeholders to maintain space-between alignment for incomplete rows */}
              {Array.from({ length: 4 - row.length }).map((_, i) => (
                <View key={`empty-${i}`} style={styles.qaItem} />
              ))}
            </View>
          ))
        ) : (
          <Text style={{ textAlign: 'center', color: T.textMuted, fontSize: 13, paddingVertical: 10 }}>
            No features found for "{searchQuery}"
          </Text>
        )}
      </View>

      <View style={styles.bottomSpacer} />
    </ScrollView>

      {/* EXPORT CSV MODAL */}
      <Modal
        visible={exportModalVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setExportModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Export Attendance</Text>
              <TouchableOpacity onPress={() => setExportModalVisible(false)}>
                <Ionicons name="close-circle-outline" size={24} color={T.textMuted} />
              </TouchableOpacity>
            </View>

            <Text style={styles.modalDesc}>
              Select the date range you want to export as a CSV file.
            </Text>

            <View style={styles.exportOptions}>
              <TouchableOpacity 
                style={styles.exportOptionBtn}
                onPress={() => handleExportCSV('today')}
                disabled={exporting}
              >
                <Ionicons name="today-outline" size={20} color={T.purpleDark} />
                <Text style={styles.exportOptionText}>Today</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.exportOptionBtn}
                onPress={() => handleExportCSV('week')}
                disabled={exporting}
              >
                <Ionicons name="calendar-outline" size={20} color={T.purpleDark} />
                <Text style={styles.exportOptionText}>Last 7 Days</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.exportOptionBtn}
                onPress={() => handleExportCSV('month')}
                disabled={exporting}
              >
                <Ionicons name="documents-outline" size={20} color={T.purpleDark} />
                <Text style={styles.exportOptionText}>Current Month</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.exportOptionBtn}
                onPress={() => handleExportCSV('all')}
                disabled={exporting}
              >
                <Ionicons name="layers-outline" size={20} color={T.purpleDark} />
                <Text style={styles.exportOptionText}>All Time Records</Text>
              </TouchableOpacity>
            </View>

            {exporting && (
              <View style={styles.exportingOverlay}>
                <ActivityIndicator size="small" color={T.purpleDark} />
                <Text style={styles.exportingText}>Generating CSV...</Text>
              </View>
            )}
          </View>
        </View>
      </Modal>

      {/* THEMED ALERT MODAL */}
      <ThemedModal
        visible={alertVisible}
        type={alertConfig.type}
        title={alertConfig.title}
        message={alertConfig.message}
        onPrimaryPress={() => setAlertVisible(false)}
      />
    </>
  );
}

function ActivityItem({
  icon,
  title,
  subtitle,
  time,
}: {
  icon: any;
  title: string;
  subtitle: string;
  time: string;
}) {
  return (
    <View style={styles.actCard}>
      <View style={styles.actIconWrap}>
        <MaterialCommunityIcons
          name={icon}
          size={20}
          color={T.purpleIcon}
        />
      </View>

      <View style={styles.actInfo}>
        <Text style={styles.actTitle}>
          {title}
        </Text>

        <Text style={styles.actSub}>
          {subtitle}
        </Text>
      </View>

      <Text style={styles.actTime}>
        {time}
      </Text>
    </View>
  );
}

function QAIcon({
  icon,
  label,
  onPress,
}: {
  icon: any;
  label: string;
  onPress?: () => void;
}) {
  return (
    <TouchableOpacity
      style={styles.qaItem}
      activeOpacity={0.7}
      onPress={onPress}
    >
      <View style={styles.qaCircle}>
        <MaterialCommunityIcons
          name={icon}
          size={22}
          color={T.textWhite}
        />
      </View>

      <Text style={styles.qaLabel}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: T.screenBg,
  },

  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 10,
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },

  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 2,
    borderColor: T.purpleIcon,
  },

  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    borderRadius: 25,
    paddingHorizontal: 14,
    height: 40,
    marginHorizontal: 12,
    borderWidth: 1,
    borderColor: '#E8E4EC',
  },

  searchInput: {
    flex: 1,
    fontSize: 13,
    color: T.purpleDark,
  },

  bellBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: T.purpleLight,
    justifyContent: 'center',
    alignItems: 'center',
  },

  dot: {
    position: 'absolute',
    top: 10,
    right: 11,
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: T.redDot,
  },

  greetLine: {
    fontSize: 32,
    fontFamily:
      'BitcountGridSingle_400Regular',
    color: T.purpleDark,
    marginTop: 20,
    marginBottom: 4,
    paddingHorizontal: 20,
  },

  greetName: {
    fontSize: 32,
    fontFamily:
      'BitcountGridSingle_400Regular',
    color: T.purpleDark,
    paddingHorizontal: 20,
    marginBottom: 20,
    lineHeight: 34,
  },

  card: {
    backgroundColor: T.cardBg,
    borderRadius: 18,
    padding: 18,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 3,
    marginBottom: 24,
  },

  /* Shift Card Specific */
  shiftLabel: { fontSize: 11, fontWeight: '700', color: T.purpleDark, marginBottom: 14, letterSpacing: 0.3 },
  shiftRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  calIconWrap: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: T.purpleLight,
    justifyContent: 'center', alignItems: 'center', marginRight: 14,
  },
  shiftDate: { fontSize: 15, fontWeight: '700', color: T.purpleDark },
  shiftHours: { fontSize: 13, color: T.purpleMedium, marginTop: 2 },
  clockInBtn: {
    alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 6,
    borderWidth: 1.5, borderColor: T.purpleBorder, borderRadius: 25,
    paddingVertical: 8, paddingHorizontal: 24,
  },
  clockOutBtn: { borderColor: '#B23A48', backgroundColor: '#FFF1F3' },
  clockInText: { color: T.purpleDark, fontWeight: '600', fontSize: 13 },

  cardLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: T.purpleDark,
    marginBottom: 14,
    letterSpacing: 0.3,
  },

  organizationInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  organizationTextWrap: {
    flex: 1,
    paddingRight: 12,
  },

  organizationName: {
    fontSize: 20,
    fontWeight: '700',
    color: T.purpleDark,
  },

  organizationType: {
    fontSize: 12,
    color: T.textMuted,
    marginTop: 4,
  },

  limitBadge: {
    backgroundColor: T.purpleLight,
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },

  limitBadgeText: {
    fontSize: 11,
    fontWeight: '700',
    color: T.purpleDark,
  },

  subRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  planInfo: {
    flex: 1,
    paddingRight: 12,
  },

  planName: {
    fontSize: 16,
    fontWeight: '700',
    color: T.purpleDark,
  },

  planDetail: {
    fontSize: 12,
    color: T.textMuted,
    marginTop: 2,
  },

  upgradeBtn: {
    borderWidth: 1.5,
    borderColor: T.purpleBorder,
    borderRadius: 20,
    paddingVertical: 6,
    paddingHorizontal: 16,
  },

  upgradeText: {
    color: T.purpleDark,
    fontWeight: '600',
    fontSize: 12,
  },

  sectionTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: T.purpleDark,
    marginBottom: 14,
    marginTop: 8,
  },

  actCard: {
    backgroundColor: T.cardBg,
    borderRadius: 14,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 2,
  },

  actIconWrap: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: T.purpleLight,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },

  actInfo: {
    flex: 1,
  },

  actTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: T.purpleDark,
  },

  actSub: {
    fontSize: 11,
    color: T.textMuted,
    marginTop: 2,
  },

  actTime: {
    fontSize: 11,
    color: T.purpleDark,
  },

  quickAccessBox: {
    backgroundColor: T.quickAccessBg,
    borderRadius: 22,
    padding: 18,
    minHeight: 100,
  },

  qaRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },

  qaSecondRow: {
    marginTop: 18,
  },

  qaItem: {
    alignItems: 'center',
    width: 60,
  },

  qaCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: T.purpleIcon,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
  },

  qaLabel: {
    fontSize: 10,
    color: T.textWhite,
    textAlign: 'center',
    fontWeight: '600',
    lineHeight: 13,
  },

  bottomSpacer: {
    height: 120,
  },

  emptyActivity: {
    alignItems: 'center',
    paddingVertical: 20,
    gap: 8,
  },

  emptyActivityText: {
    fontSize: 13,
    color: '#C8B4E0',
    fontWeight: '500',
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#FFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    paddingBottom: 40,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: T.purpleDark,
  },
  modalDesc: {
    fontSize: 14,
    color: T.textMuted,
    marginBottom: 20,
    lineHeight: 20,
  },
  exportOptions: {
    gap: 12,
  },
  exportOptionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: T.cardBg,
    borderRadius: 14,
    gap: 12,
    borderWidth: 1,
    borderColor: '#E8E4EC',
  },
  exportOptionText: {
    fontSize: 15,
    fontWeight: '700',
    color: T.purpleDark,
  },
  exportingOverlay: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
    gap: 8,
  },
  exportingText: {
    fontSize: 14,
    fontWeight: '600',
    color: T.purpleDark,
  },
});