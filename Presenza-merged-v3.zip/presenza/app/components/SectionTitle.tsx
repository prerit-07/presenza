import React from 'react';
import { StyleSheet, Text, TextStyle } from 'react-native';
import { Theme } from '@/constants/theme';

interface SectionTitleProps {
  title: string;
  style?: TextStyle;
}

export const SectionTitle: React.FC<SectionTitleProps> = ({ title, style }) => {
  return <Text style={[styles.title, style]}>{title}</Text>;
};

const styles = StyleSheet.create({
  title: {
    fontSize: Theme.typography.sizes.lg,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Theme.colors.text,
    marginVertical: 14,
    paddingLeft: 4,
  },
});
