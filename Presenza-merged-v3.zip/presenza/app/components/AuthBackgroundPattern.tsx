import React from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';

const { width, height } = Dimensions.get('window');

interface Props {
  variant?: 'dark' | 'light';
}

export default function AuthBackgroundPattern({ variant = 'dark' }: Props) {
  // Use a single low-opacity color for a clean, glass-like scattered effect without muddy overlaps
  const fillAlpha = variant === 'light' ? 'rgba(120,80,180,0.15)' : 'rgba(255,255,255,0.06)';

  return (
    <View style={StyleSheet.absoluteFillObject} pointerEvents="none">
      {/* ═══ TOP LEFT ═══ */}
      <View style={[s.c, { width: 140, height: 140, top: -40, left: -40, backgroundColor: fillAlpha }]} />
      <View style={[s.c, { width: 40, height: 40, top: 120, left: -10, backgroundColor: fillAlpha }]} />
      <View style={[s.r, { width: 70, height: 70, top: 180, left: -30, backgroundColor: fillAlpha, transform: [{ rotate: '15deg' }] }]} />
      
      {/* ═══ TOP MIDDLE (behind logo) ═══ */}
      <View style={[s.r, { width: 30, height: 30, top: 70, left: width * 0.35, backgroundColor: fillAlpha, transform: [{ rotate: '25deg' }] }]} />
      <View style={[s.c, { width: 60, height: 60, top: -10, left: width * 0.5, backgroundColor: fillAlpha }]} />
      <View style={[s.c, { width: 25, height: 25, top: 90, left: width * 0.7, backgroundColor: fillAlpha }]} />

      {/* ═══ TOP RIGHT ═══ */}
      <View style={[s.r, { width: 80, height: 80, top: 10, right: -20, backgroundColor: fillAlpha, transform: [{ rotate: '45deg' }] }]} />
      <View style={[s.r, { width: 40, height: 40, top: 130, right: 30, backgroundColor: fillAlpha, transform: [{ rotate: '10deg' }] }]} />
      <View style={[s.c, { width: 50, height: 50, top: 160, right: -20, backgroundColor: fillAlpha }]} />

      {/* ═══ MID LEFT ═══ */}
      <View style={[s.c, { width: 70, height: 70, top: height * 0.4, left: 10, backgroundColor: fillAlpha }]} />
      <View style={[s.r, { width: 90, height: 90, top: height * 0.55, left: -40, backgroundColor: fillAlpha, transform: [{ rotate: '20deg' }] }]} />

      {/* ═══ MID RIGHT ═══ */}
      <View style={[s.c, { width: 80, height: 80, top: height * 0.38, right: -30, backgroundColor: fillAlpha }]} />
      <View style={[s.c, { width: 30, height: 30, top: height * 0.52, right: 20, backgroundColor: fillAlpha }]} />

      {/* ═══ BOTTOM LEFT ═══ */}
      <View style={[s.r, { width: 60, height: 60, top: height * 0.75, left: -20, backgroundColor: fillAlpha, transform: [{ rotate: '12deg' }] }]} />
      <View style={[s.c, { width: 100, height: 100, bottom: -30, left: 40, backgroundColor: fillAlpha }]} />

      {/* ═══ BOTTOM RIGHT ═══ */}
      <View style={[s.r, { width: 110, height: 110, top: height * 0.65, right: -40, backgroundColor: fillAlpha, transform: [{ rotate: '-15deg' }] }]} />
      <View style={[s.c, { width: 60, height: 60, bottom: 20, right: 10, backgroundColor: fillAlpha }]} />
      <View style={[s.c, { width: 90, height: 90, bottom: -40, right: -20, backgroundColor: fillAlpha }]} />

    </View>
  );
}

const s = StyleSheet.create({
  c: { position: 'absolute', borderRadius: 9999 },
  r: { position: 'absolute', borderRadius: 18 },
});
