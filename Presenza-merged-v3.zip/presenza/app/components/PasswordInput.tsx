import React, { useState, forwardRef } from 'react';
import { StyleSheet, Pressable, ViewStyle, TextStyle, TextInput as RNTextInput, TextInputProps as RNTextInputProps } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { TextInput } from './TextInput';
import { Theme } from '@/constants/theme';

interface PasswordInputProps extends RNTextInputProps {
  label?: string;
  placeholder?: string;
  error?: string;
  containerStyle?: ViewStyle;
  inputStyle?: ViewStyle;
  labelStyle?: TextStyle;
  icon?: React.ReactNode;
}

export const PasswordInput = forwardRef<RNTextInput, PasswordInputProps>(({
  label,
  placeholder = 'Password',
  error,
  containerStyle,
  inputStyle,
  labelStyle,
  icon,
  ...props
}, ref) => {
  const [secureTextEntry, setSecureTextEntry] = useState(true);

  const toggleSecureEntry = () => {
    setSecureTextEntry(!secureTextEntry);
  };

  return (
    <TextInput
      ref={ref}
      label={label}
      placeholder={placeholder}
      error={error}
      secureTextEntry={secureTextEntry}
      autoCapitalize="none"
      autoCorrect={false}
      containerStyle={containerStyle}
      inputStyle={inputStyle}
      labelStyle={labelStyle}
      icon={icon}
      {...props}
      rightIcon={
        <Pressable onPress={toggleSecureEntry} style={styles.eyeButton}>
          <Ionicons
            name={secureTextEntry ? 'eye-off-outline' : 'eye-outline'}
            size={22}
            color={Theme.colors.subText}
          />
        </Pressable>
      }
    />
  );
});

const styles = StyleSheet.create({
  eyeButton: {
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    paddingLeft: 8,
  },
});
