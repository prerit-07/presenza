import React from 'react';
import { TouchableOpacity, View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { DashboardTheme as T } from '@/constants/dashboard-theme';

interface CustomTabButtonProps {
  onPress?: (e?: any) => void;
  onLongPress?: (e?: any) => void;
  focused: boolean;
  iconName: { active: any; inactive: any };
  label: string;
}

export function CustomTabButton({
  onPress,
  onLongPress,
  focused,
  iconName,
  label,
}: CustomTabButtonProps) {
  return (
    <TouchableOpacity
      onPress={onPress}
      onLongPress={onLongPress}
      activeOpacity={0.8}
      style={styles.wrapper}
    >
      {focused ? (
        // ── ACTIVE: Horizontal pill with icon + label side by side ──
        <View style={styles.activePill}>
          <Ionicons name={iconName.active} size={20} color={T.purpleDark} />
          <Text style={styles.activeLabel}>{label}</Text>
        </View>
      ) : (
        // ── INACTIVE: Icon above label, no background ──
        <View style={styles.inactiveWrap}>
          <Ionicons name={iconName.inactive} size={22} color={T.purpleMedium} />
          <Text style={styles.inactiveLabel}>{label}</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
  },

  // Active: solid pill, horizontal
  activePill: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(75, 50, 110, 0.28)',
    borderRadius: 30,
    paddingHorizontal: 14,
    paddingVertical: 10,
    gap: 6,
  },
  activeLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: T.purpleDark,
    letterSpacing: 0.1,
  },

  // Inactive: vertical, no background
  inactiveWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    gap: 3,
  },
  inactiveLabel: {
    fontSize: 10,
    fontWeight: '500',
    color: T.purpleMedium,
  },
});
