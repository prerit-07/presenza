import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { DashboardTheme as T } from '@/constants/dashboard-theme';

export type ThemedModalType = 'success' | 'error' | 'warning' | 'info';

export interface ThemedModalProps {
  visible: boolean;
  type: ThemedModalType;
  title: string;
  message: string;
  primaryButtonText?: string;
  secondaryButtonText?: string;
  onPrimaryPress: () => void;
  onSecondaryPress?: () => void;
}

export function ThemedModal({
  visible,
  type,
  title,
  message,
  primaryButtonText,
  secondaryButtonText,
  onPrimaryPress,
  onSecondaryPress,
}: ThemedModalProps) {
  // Determine styles based on type
  const isSuccess = type === 'success';
  const isError = type === 'error';
  const isWarning = type === 'warning';

  let iconName: React.ComponentProps<typeof Ionicons>['name'] = 'information-circle';
  let primaryColor = T.purpleIcon;
  let bgColor = '#F5F1FA';
  
  if (isSuccess) {
    iconName = 'checkmark-circle';
  } else if (isError) {
    iconName = 'alert-circle';
  } else if (isWarning) {
    iconName = 'warning';
  }

  if (!visible) return null;

  return (
    <Modal transparent visible={visible} animationType="fade" onRequestClose={onPrimaryPress}>
      <View style={styles.modalOverlay}>
        <View style={styles.modalBox}>
          
          <View style={[styles.modalIconCircle, { backgroundColor: bgColor }]}>
            <Ionicons name={iconName} size={36} color={primaryColor} />
          </View>
          
          <Text style={styles.modalTitle}>{title}</Text>
          <Text style={styles.modalMessage}>{message}</Text>
          
          <View style={styles.actionsRow}>
            {secondaryButtonText && onSecondaryPress && (
              <TouchableOpacity
                style={[styles.modalBtn, styles.modalBtnSecondary]}
                onPress={onSecondaryPress}
                activeOpacity={0.7}
              >
                <Text style={styles.modalBtnSecondaryText}>{secondaryButtonText}</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity
              style={[
                styles.modalBtn,
                { backgroundColor: isSuccess ? T.purpleIcon : primaryColor },
                secondaryButtonText ? { flex: 1 } : { minWidth: 140 }
              ]}
              onPress={onPrimaryPress}
              activeOpacity={0.7}
            >
              <Text style={styles.modalBtnText}>
                {primaryButtonText || (isSuccess ? 'Great!' : 'OK')}
              </Text>
            </TouchableOpacity>
          </View>

        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(41, 24, 92, 0.55)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  modalBox: {
    backgroundColor: '#FFF',
    borderRadius: 24,
    padding: 28,
    alignItems: 'center',
    width: '100%',
    shadowColor: '#29185c',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.18,
    shadowRadius: 20,
    elevation: 10,
  },
  modalIconCircle: {
    width: 72, height: 72, borderRadius: 36,
    justifyContent: 'center', alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 20, fontWeight: '800', color: '#29185c',
    marginBottom: 8,
    textAlign: 'center',
  },
  modalMessage: {
    fontSize: 14, color: '#6B4E8D',
    textAlign: 'center', lineHeight: 20,
    marginBottom: 24,
  },
  actionsRow: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
    justifyContent: 'center',
  },
  modalBtn: {
    borderRadius: 14,
    paddingVertical: 14, 
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalBtnSecondary: {
    flex: 1,
    backgroundColor: '#F5F1FA',
  },
  modalBtnText: {
    fontSize: 15, fontWeight: '700', color: '#FFF',
  },
  modalBtnSecondaryText: {
    fontSize: 15, fontWeight: '700', color: T.purpleIcon,
  },
});
