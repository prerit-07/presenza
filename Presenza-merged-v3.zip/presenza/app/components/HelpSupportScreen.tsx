import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Pressable, Linking,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { PageHeader } from '@/components/PageHeader';

type FAQItem = { q: string; a: string };

const FAQS: FAQItem[] = [
  {
    q: 'How do I mark my attendance?',
    a: 'Go to the Home screen and tap "Clock In". You can clock in via GPS geofence or office WiFi. Make sure your location services are enabled.',
  },
  {
    q: 'How do I apply for leave?',
    a: 'Navigate to the Leave section from your profile or home screen, tap "Apply Leave", select the leave type, dates, and submit your request for manager approval.',
  },
  {
    q: 'What if I forget to clock out?',
    a: 'Contact your manager or admin. They can manually adjust your attendance record from the "Add Attendance" feature on the Manager Dashboard.',
  },
  {
    q: 'How do I request a device change?',
    a: 'Go to Profile → Device Change Request. Submit the request with your new device details. Your manager/admin will review and approve it.',
  },
  {
    q: 'How does remote check-in work?',
    a: 'Tap "Clock In" from the home screen and select "Remote Check-In". You\'ll need to share your live location so your manager can verify your work location.',
  },
  {
    q: 'Who approves my leave requests?',
    a: 'Your direct manager approves leave requests. If your manager is unavailable, the organization admin can also process approvals.',
  },
  {
    q: 'Can I view my attendance history?',
    a: 'Yes! Go to the Attendance tab in the bottom navigation bar. You can see your daily, weekly, and monthly attendance records with check-in/out times.',
  },
  {
    q: 'How do I update my profile information?',
    a: 'Go to Profile → Edit Profile. You can update your name, phone number, and other personal details. Some fields like email and employee ID can only be changed by an admin.',
  },
];

const SUPPORT_EMAIL = 'support@presenza.app';
const SUPPORT_PHONE = '+91 1800-123-4567';

function FAQCard({ item, isOpen, onToggle }: { item: FAQItem; isOpen: boolean; onToggle: () => void }) {
  return (
    <Pressable style={[styles.faqCard, isOpen && styles.faqCardOpen]} onPress={onToggle}>
      <View style={styles.faqHeader}>
        <View style={styles.faqIconWrap}>
          <MaterialCommunityIcons
            name={isOpen ? 'minus-circle-outline' : 'plus-circle-outline'}
            size={20}
            color={T.purpleIcon}
          />
        </View>
        <Text style={styles.faqQuestion}>{item.q}</Text>
        <MaterialCommunityIcons
          name={isOpen ? 'chevron-up' : 'chevron-down'}
          size={18}
          color={T.textMuted}
        />
      </View>
      {isOpen && (
        <View style={styles.faqAnswer}>
          <Text style={styles.faqAnswerText}>{item.a}</Text>
        </View>
      )}
    </Pressable>
  );
}

export default function HelpSupportScreen() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  const handleEmail = () => {
    Linking.openURL(`mailto:${SUPPORT_EMAIL}?subject=Presenza%20Support%20Request`);
  };

  const handleCall = () => {
    Linking.openURL(`tel:${SUPPORT_PHONE.replace(/[^+\d]/g, '')}`);
  };

  return (
    <View style={styles.root}>
      <PageHeader title="Help & Support" subtitle="We're here to help" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scroll}
      >
        {/* ─── FAQs ─── */}
        <View style={styles.sectionHeader}>
          <MaterialCommunityIcons name="frequently-asked-questions" size={20} color={T.purpleIcon} />
          <Text style={styles.sectionTitle}>Frequently Asked Questions</Text>
        </View>

        {FAQS.map((faq, idx) => (
          <FAQCard
            key={idx}
            item={faq}
            isOpen={openIdx === idx}
            onToggle={() => setOpenIdx(openIdx === idx ? null : idx)}
          />
        ))}

        {/* ─── Still Need Help ─── */}
        <View style={[styles.sectionHeader, { marginTop: 28 }]}>
          <MaterialCommunityIcons name="lifebuoy" size={20} color={T.purpleIcon} />
          <Text style={styles.sectionTitle}>Still Need Help?</Text>
        </View>

        <Text style={styles.stillHelpSub}>
          Can't find what you're looking for? Reach out to our support team directly.
        </Text>

        {/* Email Support */}
        <TouchableOpacity style={styles.contactCard} onPress={handleEmail} activeOpacity={0.7}>
          <View style={styles.contactIconWrap}>
            <MaterialCommunityIcons name="email-outline" size={24} color="#FFF" />
          </View>
          <View style={styles.contactInfo}>
            <Text style={styles.contactTitle}>Email Support</Text>
            <Text style={styles.contactSub}>{SUPPORT_EMAIL}</Text>
          </View>
          <MaterialCommunityIcons name="chevron-right" size={20} color={T.textMuted} />
        </TouchableOpacity>

        {/* Call Helpline */}
        <TouchableOpacity style={styles.contactCard} onPress={handleCall} activeOpacity={0.7}>
          <View style={[styles.contactIconWrap, { backgroundColor: '#4CAF50' }]}>
            <MaterialCommunityIcons name="phone-outline" size={24} color="#FFF" />
          </View>
          <View style={styles.contactInfo}>
            <Text style={styles.contactTitle}>Call Helpline</Text>
            <Text style={styles.contactSub}>{SUPPORT_PHONE}</Text>
          </View>
          <MaterialCommunityIcons name="chevron-right" size={20} color={T.textMuted} />
        </TouchableOpacity>

        {/* Bottom spacer */}
        <View style={{ height: 60 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: T.screenBg },
  scroll: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 40 },

  /* Section */
  sectionHeader: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    marginBottom: 14, marginTop: 8,
  },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: T.purpleDark },

  /* FAQ */
  faqCard: {
    backgroundColor: '#FFF', borderRadius: 14, padding: 16,
    marginBottom: 10,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04, shadowRadius: 4, elevation: 2,
  },
  faqCardOpen: {
    borderWidth: 1.5, borderColor: T.purpleBorder,
  },
  faqHeader: {
    flexDirection: 'row', alignItems: 'center',
  },
  faqIconWrap: { marginRight: 10 },
  faqQuestion: {
    flex: 1, fontSize: 13, fontWeight: '600', color: T.purpleDark, lineHeight: 18,
  },
  faqAnswer: {
    marginTop: 12, paddingTop: 12,
    borderTopWidth: 1, borderTopColor: '#F0ECF4',
  },
  faqAnswerText: {
    fontSize: 13, color: T.purpleMedium, lineHeight: 20,
  },

  /* Still need help */
  stillHelpSub: {
    fontSize: 13, color: T.textMuted, marginBottom: 16, lineHeight: 19,
  },

  /* Contact cards */
  contactCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#FFF', borderRadius: 14, padding: 16,
    marginBottom: 12,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06, shadowRadius: 6, elevation: 3,
  },
  contactIconWrap: {
    width: 48, height: 48, borderRadius: 24,
    backgroundColor: T.purpleIcon,
    justifyContent: 'center', alignItems: 'center', marginRight: 14,
  },
  contactInfo: { flex: 1 },
  contactTitle: { fontSize: 15, fontWeight: '700', color: T.purpleDark },
  contactSub: { fontSize: 12, color: T.textMuted, marginTop: 3 },
});
