import React, { useState } from 'react';
import { StyleSheet, Text, View, Pressable, LayoutAnimation } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Theme } from '@/constants/theme';
import { Card } from './Card';
import { Badge } from './Badge';
import { Ticket } from '@/store/useAppStore';

interface TicketCardProps {
  ticket: Ticket;
  onPress?: () => void;
}

export const TicketCard: React.FC<TicketCardProps> = ({ ticket }) => {
  const [expanded, setExpanded] = useState(false);

  const toggleExpand = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setExpanded(!expanded);
  };

  const priorityColor =
    ticket.priority === 'High'
      ? Theme.colors.error
      : ticket.priority === 'Medium'
      ? '#D97706' // Amber/orange
      : Theme.colors.success;

  return (
    <Card style={styles.card}>
      <View style={styles.header}>
        <Text style={styles.ticketNumber}>{ticket.ticketNumber}</Text>
        <Badge status={ticket.status} />
      </View>

      <Text style={styles.title} numberOfLines={expanded ? undefined : 2}>
        {ticket.title}
      </Text>

      <View style={styles.statsContainer}>
        {/* Raised On Cell */}
        <View style={styles.statCell}>
          <View style={styles.iconCircle}>
            <Ionicons name="calendar-outline" size={14} color={Theme.colors.primary} />
          </View>
          <View style={styles.statTextContainer}>
            <Text style={styles.statLabel}>Raised on</Text>
            <Text style={styles.statValue} numberOfLines={1}>{ticket.raisedDate}</Text>
          </View>
        </View>

        {/* Priority Cell */}
        <View style={styles.statCell}>
          <View style={[styles.iconCircle, { backgroundColor: 'rgba(217, 119, 6, 0.08)' }]}>
            <Ionicons name="flag-outline" size={14} color={priorityColor} />
          </View>
          <View style={styles.statTextContainer}>
            <Text style={styles.statLabel}>Priority</Text>
            <Text style={[styles.statValue, { color: priorityColor }]}>
              {ticket.priority}
            </Text>
          </View>
        </View>

        {/* Category Cell */}
        <View style={styles.statCell}>
          <View style={[styles.iconCircle, { backgroundColor: 'rgba(67, 196, 122, 0.08)' }]}>
            <Ionicons name="cube-outline" size={14} color={Theme.colors.success} />
          </View>
          <View style={styles.statTextContainer}>
            <Text style={styles.statLabel}>Category</Text>
            <Text style={styles.statValue} numberOfLines={1}>{ticket.category}</Text>
          </View>
        </View>
      </View>

      {expanded && (
        <View style={styles.expandedContent}>
          <View style={styles.divider} />
          <Text style={styles.descriptionLabel}>Details</Text>
          <Text style={styles.descriptionText}>
            {ticket.description ||
              'No additional details provided. The issue is currently being reviewed by our support team.'}
          </Text>
        </View>
      )}

      <Pressable onPress={toggleExpand} style={styles.viewMoreButton}>
        <Text style={styles.viewMoreText}>{expanded ? 'View Less' : 'View More'}</Text>
        <Ionicons
          name={expanded ? 'chevron-up' : 'chevron-down'}
          size={16}
          color={Theme.colors.text}
          style={styles.chevron}
        />
      </Pressable>
    </Card>
  );
};

const styles = StyleSheet.create({
  card: {
    paddingBottom: 0, // Let viewMoreButton touch bottom with padding inside it
    paddingHorizontal: 0,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 16,
    marginBottom: 12,
  },
  ticketNumber: {
    fontSize: Theme.typography.sizes.sm,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Theme.colors.subText,
    backgroundColor: '#F3EDFA',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  title: {
    fontSize: Theme.typography.sizes.sm,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.text,
    lineHeight: 20,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    marginBottom: 12,
  },
  statCell: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F7FC',
    borderWidth: 1,
    borderColor: '#F0ECF7',
    borderRadius: 12,
    padding: 6,
    marginHorizontal: 4,
  },
  iconCircle: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: 'rgba(111, 74, 168, 0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 6,
  },
  statTextContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  statLabel: {
    fontSize: 8,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Theme.colors.subText,
  },
  statValue: {
    fontSize: 9,
    fontFamily: Theme.typography.fontFamily.semiBold,
    color: Theme.colors.text,
  },
  expandedContent: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  divider: {
    height: 1,
    backgroundColor: Theme.colors.border,
    marginVertical: 12,
  },
  descriptionLabel: {
    fontSize: Theme.typography.sizes.xs,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Theme.colors.subText,
    marginBottom: 4,
  },
  descriptionText: {
    fontSize: Theme.typography.sizes.sm,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Theme.colors.text,
    lineHeight: 18,
  },
  viewMoreButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderColor: Theme.colors.border,
    paddingVertical: 14,
    paddingHorizontal: 16,
    width: '100%',
  },
  viewMoreText: {
    fontSize: Theme.typography.sizes.sm,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.text,
  },
  chevron: {
    marginLeft: 4,
  },
});
