// components/AuthLayout.tsx

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  ImageBackground,
  Pressable,
  StatusBar,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';

import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useRouter, type Href } from 'expo-router';

import { AuthTheme } from '@/constants/auth-theme';

const { width } = Dimensions.get('window');

// Keep logo layout size EXACTLY the same
const LOGO_LAYOUT_SIZE = width * 0.5;

// Keep logo visual scale EXACTLY the same
const LOGO_SCALE = 4;

// Keep logo position EXACTLY the same
const LOGO_TRANSLATE_Y = 45;

// Keep card overlap EXACTLY the same
const CARD_OVERLAP_ADJUSTMENT = 35;

interface Props {
  variant: 'dark' | 'light';
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  showBackButton?: boolean;
  backRoute?: Href;
  logoOverride?: any;
  bgOverride?: any;
}

export default function AuthLayout({
  variant,
  children,
  title,
  subtitle,
  showBackButton = true,
  backRoute,
  logoOverride,
  bgOverride,
}: Props) {
  const theme = AuthTheme[variant];
  const router = useRouter();

  const logoSource = logoOverride || (
    variant === 'dark'
      ? require('@/assets/images/presenza-logo-dark.png')
      : require('@/assets/images/presenza-logo-light.png')
  );

  const backgroundSource = bgOverride || require(
    '@/assets/images/auth-background.png'
  );

  const handleBack = () => {
    if (backRoute) {
      router.replace(backRoute);
      return;
    }

    if (router.canGoBack()) {
      router.back();
      return;
    }

    router.replace('/(auth)/sign-in');
  };

  return (
    <ImageBackground
      source={backgroundSource}
      style={styles.root}
      resizeMode="cover"
    >
      <StatusBar
        barStyle="light-content"
        backgroundColor="transparent"
        translucent
      />

      <SafeAreaView style={styles.safeArea}>
        {/* Back button */}
        {showBackButton && (
          <Pressable
            onPress={handleBack}
            style={styles.backBtn}
            hitSlop={16}
          >
            <MaterialCommunityIcons
              name="chevron-left"
              size={30}
              color="#FFFFFF"
            />
          </Pressable>
        )}

        <KeyboardAvoidingView
          style={styles.flex}
          behavior={
            Platform.OS === 'ios'
              ? 'padding'
              : undefined
          }
        >
          {/* =====================================
              LOGO AREA

              pointerEvents="none" prevents the
              enlarged logo from blocking touches.

              Logo size and position are unchanged.
          ====================================== */}
          <View
            style={styles.logoArea}
            pointerEvents="none"
          >
            <Image
              source={logoSource}
              style={[
                styles.logo,
                {
                  width: LOGO_LAYOUT_SIZE,
                  height: LOGO_LAYOUT_SIZE,

                  transform: [
                    {
                      translateY: LOGO_TRANSLATE_Y,
                    },
                    {
                      scale: LOGO_SCALE,
                    },
                  ],
                },
              ]}
              resizeMode="contain"
            />
          </View>

          {/* =====================================
              FLOATING CARD
          ====================================== */}
          <View
            style={[
              styles.card,
              {
                backgroundColor:
                  theme.cardBackground,
                marginTop:
                  -CARD_OVERLAP_ADJUSTMENT,
              },
            ]}
          >
            {/* Fixed header */}
            <View>
              <View
                style={{
                  height:
                    CARD_OVERLAP_ADJUSTMENT + 8,
                }}
              />

              {title && (
                <Text
                  style={[
                    styles.title,
                    {
                      color: theme.title,
                    },
                  ]}
                >
                  {title}
                </Text>
              )}

              {subtitle && (
                <Text
                  style={[
                    styles.subtitle,
                    {
                      color: theme.subtitle,
                    },
                  ]}
                >
                  {subtitle}
                </Text>
              )}
            </View>

            {/* Scrollable content */}
            <ScrollView
              contentContainerStyle={
                styles.cardContent
              }
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
            >
              <View style={styles.childrenWrapper}>
                {children}
              </View>
            </ScrollView>
          </View>

          {/* Bottom spacing */}
          <View style={styles.bottomSpacer} />
        </KeyboardAvoidingView>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  // =====================================
  // ROOT
  // =====================================

  root: {
    flex: 1,
    width: '100%',
    height: '100%',
  },

  flex: {
    flex: 1,
  },

  safeArea: {
    flex: 1,
  },

  // =====================================
  // BACK BUTTON
  // =====================================

  backBtn: {
    position: 'absolute',

    top: 30,
    left: 8,

    width: 52,
    height: 52,

    justifyContent: 'center',
    alignItems: 'center',

    // Keep above all overlapping views
    zIndex: 999,
    elevation: 999,
  },

  // =====================================
  // LOGO
  // =====================================

  logoArea: {
    alignItems: 'center',
    justifyContent: 'flex-end',

    marginTop: 20,

    // Logo can visually grow outside
    // its original layout footprint
    overflow: 'visible',

    // IMPORTANT:
    // no zIndex here, so it cannot create
    // an unnecessary touch layer above button
  },

  logo: {
    // Width and height stay assigned inline
    // using LOGO_LAYOUT_SIZE.
  },

  // =====================================
  // CARD
  // =====================================

  card: {
    marginHorizontal: 16,

    borderRadius: 28,

    flex: 1,

    overflow: 'hidden',

    shadowColor: '#000',

    shadowOffset: {
      width: 0,
      height: 8,
    },

    shadowOpacity: 0.25,
    shadowRadius: 16,

    elevation: 12,
  },

  cardContent: {
    paddingHorizontal: 24,
    paddingBottom: 32,

    flexGrow: 1,
  },

  // =====================================
  // HEADER TEXT
  // =====================================

  title: {
    fontSize: 22,
    fontWeight: '700',

    textAlign: 'center',

    marginBottom: 4,
  },

  subtitle: {
    fontSize: 13,

    textAlign: 'center',

    lineHeight: 18,

    marginBottom: 4,
  },

  // =====================================
  // CHILD CONTENT
  // =====================================

  childrenWrapper: {
    marginTop: 20,
  },

  // =====================================
  // BOTTOM SPACE
  // =====================================

  bottomSpacer: {
    height: 20,
  },
});