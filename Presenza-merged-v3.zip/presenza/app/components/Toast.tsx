import React, { useEffect } from 'react';
import { StyleSheet, Text, View, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withDelay,
  withTiming,
} from 'react-native-reanimated';
import { Theme } from '@/constants/theme';

export type ToastType = 'success' | 'error' | 'info';

interface ToastProps {
  message: string;
  type?: ToastType;
  visible: boolean;
  onDismiss: () => void;
  duration?: number;
}

export const Toast: React.FC<ToastProps> = ({
  message,
  type = 'info',
  visible,
  onDismiss,
  duration = 3000,
}) => {
  const translateY = useSharedValue(-100);
  const opacity = useSharedValue(0);

  useEffect(() => {
    if (visible) {
      // Fade/slide in
      translateY.value = withSpring(Platform.OS === 'ios' ? 60 : 40, {
        damping: 15,
      });
      opacity.value = withTiming(1, { duration: 250 });

      // Automatically dismiss
      const timer = setTimeout(() => {
        handleDismiss();
      }, duration);

      return () => clearTimeout(timer);
    } else {
      translateY.value = withTiming(-100, { duration: 250 });
      opacity.value = withTiming(0, { duration: 200 });
    }
  }, [visible]);

  const handleDismiss = () => {
    translateY.value = withTiming(-100, { duration: 250 });
    opacity.value = withTiming(0, { duration: 200 });
    // Delay onDismiss slightly to let exit animation finish
    setTimeout(onDismiss, 250);
  };

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
    opacity: opacity.value,
  }));

  if (!visible) return null;

  let iconName: React.ComponentProps<typeof Ionicons>['name'] = 'information-circle';
  let color = Theme.colors.primary;

  if (type === 'success') {
    iconName = 'checkmark-circle';
    color = Theme.colors.success;
  } else if (type === 'error') {
    iconName = 'alert-circle';
    color = Theme.colors.error;
  }

  return (
    <Animated.View style={[styles.container, animatedStyle]}>
      <View style={[styles.content, { borderLeftColor: color }]}>
        <Ionicons name={iconName} size={24} color={color} style={styles.icon} />
        <Text style={styles.text} numberOfLines={2}>
          {message}
        </Text>
        <Ionicons
          name="close"
          size={18}
          color={Theme.colors.subText}
          onPress={handleDismiss}
          style={styles.closeIcon}
        />
      </View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 20,
    right: 20,
    zIndex: 9999,
    ...Theme.shadow,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Theme.colors.white,
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 12,
    borderLeftWidth: 4,
    borderWidth: 1,
    borderColor: Theme.colors.border,
  },
  icon: {
    marginRight: 12,
  },
  text: {
    flex: 1,
    fontSize: Theme.typography.sizes.sm,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.text,
  },
  closeIcon: {
    marginLeft: 8,
    padding: 4,
  },
});
