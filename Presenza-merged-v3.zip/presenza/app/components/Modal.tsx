import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  Modal as RNModal,
  Pressable,
  TouchableWithoutFeedback,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Theme } from '@/constants/theme';

interface ModalProps {
  visible: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  showCloseButton?: boolean;
  bottomSheet?: boolean;
}

export const Modal: React.FC<ModalProps> = ({
  visible,
  onClose,
  title,
  children,
  showCloseButton = true,
  bottomSheet = false,
}) => {
  return (
    <RNModal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <TouchableWithoutFeedback onPress={onClose}>
        <View style={[styles.overlay, bottomSheet ? styles.bottomOverlay : styles.centerOverlay]}>
          <TouchableWithoutFeedback>
            <View
              style={[
                styles.content,
                bottomSheet ? styles.bottomContent : styles.centerContent,
              ]}
            >
              {(title || showCloseButton) && (
                <View style={styles.header}>
                  {title ? <Text style={styles.title}>{title}</Text> : <View />}
                  {showCloseButton && (
                    <Pressable
                      onPress={onClose}
                      style={styles.closeButton}
                      android_ripple={{ color: 'rgba(111, 74, 168, 0.1)', radius: 16 }}
                    >
                      <Ionicons name="close" size={24} color={Theme.colors.text} />
                    </Pressable>
                  )}
                </View>
              )}
              <View style={styles.body}>{children}</View>
            </View>
          </TouchableWithoutFeedback>
        </View>
      </TouchableWithoutFeedback>
    </RNModal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: Theme.colors.overlay,
  },
  centerOverlay: {
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  bottomOverlay: {
    justifyContent: 'flex-end',
  },
  content: {
    backgroundColor: Theme.colors.white,
    borderWidth: 1,
    borderColor: Theme.colors.border,
    ...Theme.shadow,
  },
  centerContent: {
    width: '90%',
    maxWidth: 400,
    borderRadius: Theme.borderRadius.large,
    padding: 20,
  },
  bottomContent: {
    width: '100%',
    borderTopLeftRadius: Theme.borderRadius.modal,
    borderTopRightRadius: Theme.borderRadius.modal,
    paddingHorizontal: 20,
    paddingBottom: Platform.OS === 'ios' ? 40 : 24,
    paddingTop: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    width: '100%',
  },
  title: {
    fontSize: Theme.typography.sizes.lg,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Theme.colors.text,
  },
  closeButton: {
    padding: 4,
    borderRadius: 16,
  },
  body: {
    width: '100%',
  },
});
