import React from 'react';
import { StyleSheet, Text, View, ViewStyle, TextStyle } from 'react-native';
import { Theme } from '@/constants/theme';

export type BadgeStatus = 'ON TIME' | 'LATE' | 'OPEN' | 'RESOLVED' | 'PENDING' | 'PRESENT' | 'ABSENT';

interface BadgeProps {
  status: BadgeStatus | string;
  style?: ViewStyle;
  textStyle?: TextStyle;
  showDot?: boolean;
}

export const Badge: React.FC<BadgeProps> = ({
  status,
  style,
  textStyle,
  showDot = false,
}) => {
  const normalizedStatus = status.toUpperCase();

  let bgColor = 'rgba(111, 74, 168, 0.1)';
  let textColor = Theme.colors.primary;
  let hasDot = showDot;

  switch (normalizedStatus) {
    case 'ON TIME':
    case 'RESOLVED':
    case 'PRESENT':
      bgColor = 'rgba(67, 196, 122, 0.1)';
      textColor = Theme.colors.success;
      break;
    case 'LATE':
    case 'ABSENT':
      bgColor = 'rgba(229, 72, 77, 0.1)';
      textColor = Theme.colors.error;
      break;
    case 'OPEN':
      bgColor = '#F0ECF7';
      textColor = Theme.colors.primary;
      hasDot = true;
      break;
    case 'PENDING':
      bgColor = 'rgba(123, 111, 145, 0.1)';
      textColor = Theme.colors.subText;
      break;
  }

  return (
    <View style={[styles.badge, { backgroundColor: bgColor }, style]}>
      <Text style={[styles.text, { color: textColor }, textStyle]}>
        {status}
      </Text>
      {hasDot && <View style={[styles.dot, { backgroundColor: textColor }]} />}
    </View>
  );
};

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'flex-start',
  },
  text: {
    fontSize: 11,
    fontFamily: Theme.typography.fontFamily.semiBold,
    textTransform: 'uppercase',
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginLeft: 6,
  },
});
