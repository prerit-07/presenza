import React, { useState } from 'react';
import { StyleSheet, Text, View, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const P_DARK   = '#5B3D7A';
const P_MED    = '#7B5EA7';
const P_LIGHT  = '#EBE0F5';
const P_BG     = '#F3EDF7';
const P_ICON   = '#6B4E8D';

interface CalendarProps {
  onDaySelect?: (day: number) => void;
  selectedDays?: number[];
}

export const Calendar: React.FC<CalendarProps> = ({
  onDaySelect,
  selectedDays = [3, 4],
}) => {
  const now = new Date();
  const [viewMonth, setViewMonth] = useState(now.getMonth());
  const [viewYear,  setViewYear]  = useState(now.getFullYear());
  const [selectedDay, setSelectedDay] = useState<number | null>(now.getDate());

  const monthNames = [
    'January','February','March','April','May','June',
    'July','August','September','October','November','December',
  ];
  const weekdays = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

  // Build calendar grid for the viewed month
  const firstDay = new Date(viewYear, viewMonth, 1).getDay(); // 0=Sun
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  // shift so Mon=0
  const startOffset = (firstDay + 6) % 7;

  const cells: (number | null)[] = [
    ...Array(startOffset).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];
  // pad to full weeks
  while (cells.length % 7 !== 0) cells.push(null);

  const rows: (number | null)[][] = [];
  for (let i = 0; i < cells.length; i += 7) rows.push(cells.slice(i, i + 7));

  const prevMonth = () => {
    if (viewMonth === 0) { setViewMonth(11); setViewYear(y => y - 1); }
    else setViewMonth(m => m - 1);
  };
  const nextMonth = () => {
    if (viewMonth === 11) { setViewMonth(0); setViewYear(y => y + 1); }
    else setViewMonth(m => m + 1);
  };

  const handleDayPress = (day: number | null) => {
    if (!day) return;
    setSelectedDay(day);
    onDaySelect?.(day);
  };

  return (
    <View style={styles.card}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{monthNames[viewMonth]} {viewYear}</Text>
        <View style={styles.arrowRow}>
          <Pressable onPress={prevMonth} style={styles.arrowBtn}>
            <Ionicons name="chevron-back" size={16} color="#FFF" />
          </Pressable>
          <Pressable onPress={nextMonth} style={styles.arrowBtn}>
            <Ionicons name="chevron-forward" size={16} color="#FFF" />
          </Pressable>
        </View>
      </View>

      {/* Weekday labels */}
      <View style={styles.weekRow}>
        {weekdays.map(d => (
          <Text key={d} style={styles.weekLabel}>{d}</Text>
        ))}
      </View>

      {/* Day grid */}
      {rows.map((row, ri) => (
        <View key={ri} style={styles.weekRow}>
          {row.map((day, di) => {
            const isSelected  = day !== null && selectedDay === day;
            const isPresent   = day !== null && selectedDays.includes(day);
            const isToday     = day !== null && day === now.getDate()
                                && viewMonth === now.getMonth()
                                && viewYear  === now.getFullYear();
            return (
              <Pressable
                key={di}
                onPress={() => handleDayPress(day)}
                disabled={!day}
                style={[
                  styles.dayCell,
                  isSelected && styles.cellSelected,
                  !isSelected && isPresent && styles.cellPresent,
                  !isSelected && isToday   && styles.cellToday,
                ]}
              >
                <Text style={[
                  styles.dayText,
                  isSelected && styles.textSelected,
                  !isSelected && isPresent && styles.textPresent,
                  !isSelected && isToday   && styles.textToday,
                  !day && { opacity: 0 },
                ]}>
                  {day || ''}
                </Text>
              </Pressable>
            );
          })}
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 18,
    marginBottom: 18,
    shadowColor: '#5B3D7A',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  header: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', marginBottom: 16,
  },
  headerTitle: { fontSize: 18, fontWeight: '700', color: P_DARK },
  arrowRow: { flexDirection: 'row', gap: 8 },
  arrowBtn: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: P_ICON,
    justifyContent: 'center', alignItems: 'center',
  },
  weekRow: {
    flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6,
  },
  weekLabel: {
    flex: 1, textAlign: 'center',
    fontSize: 12, fontWeight: '700', color: P_MED,
  },
  dayCell: {
    flex: 1, aspectRatio: 1,
    justifyContent: 'center', alignItems: 'center',
    borderRadius: 10, marginHorizontal: 2,
  },
  cellSelected: { backgroundColor: P_ICON },
  cellPresent:  { backgroundColor: 'rgba(67,196,122,0.12)' },
  cellToday:    { backgroundColor: P_LIGHT },
  dayText: { fontSize: 13, fontWeight: '500', color: P_DARK },
  textSelected: { color: '#FFF', fontWeight: '700' },
  textPresent:  { color: '#43C47A', fontWeight: '700' },
  textToday:    { color: P_ICON,   fontWeight: '700' },
});
