import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Theme } from '@/constants/theme';
import { Card } from './Card';
import { Badge } from './Badge';
import { AttendanceRecord } from '@/store/useAppStore';

interface AttendanceCardProps {
  record: AttendanceRecord;
}

export const AttendanceCard: React.FC<AttendanceCardProps> = ({ record }) => {
  // Parse date to get short month and day number
  const parsedDate = new Date(record.date);
  const dayNum = String(parsedDate.getDate()).padStart(2, '0');
  
  // Use day short name based on dayName, or compute from date
  const dayShort = record.dayName.substring(0, 3).toUpperCase();
  
  // Format long date string like "Wednesday, June 3"
  const formattedLongDate = `${record.dayName}, June ${parsedDate.getDate()}`;

  return (
    <Card style={styles.card}>
      <View style={styles.container}>
        {/* Left Side: Short Date Circle/Box */}
        <View style={styles.dateBox}>
          <Text style={styles.dayShortText}>{dayShort}</Text>
          <Text style={styles.dayNumText}>{dayNum}</Text>
        </View>

        {/* Middle: Details */}
        <View style={styles.detailsContainer}>
          <Text style={styles.titleText}>{formattedLongDate}</Text>
          <View style={styles.timeRow}>
            <Ionicons name="time-outline" size={14} color={Theme.colors.primary} style={styles.timeIcon} />
            <Text style={styles.timeText}>{`${record.checkIn} - ${record.checkOut}`}</Text>
          </View>
        </View>

        {/* Right Side: Working hours & status */}
        <View style={styles.rightContainer}>
          <Text style={styles.workingHoursText}>{record.workingHours}</Text>
          <Badge status={record.status} style={styles.badge} />
        </View>
      </View>
    </Card>
  );
};

const styles = StyleSheet.create({
  card: {
    padding: 12,
    marginBottom: 12,
  },
  container: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dateBox: {
    backgroundColor: '#F3EDFA',
    borderRadius: 12,
    width: 52,
    height: 52,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  dayShortText: {
    fontSize: 9,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.primary,
    letterSpacing: 0.5,
  },
  dayNumText: {
    fontSize: 16,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Theme.colors.primary,
    marginTop: -2,
  },
  detailsContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  titleText: {
    fontSize: Theme.typography.sizes.sm,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Theme.colors.text,
    marginBottom: 4,
  },
  timeRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  timeIcon: {
    marginRight: 4,
  },
  timeText: {
    fontSize: 11,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.subText,
  },
  rightContainer: {
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
  workingHoursText: {
    fontSize: Theme.typography.sizes.md,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Theme.colors.text,
    marginBottom: 6,
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
});
