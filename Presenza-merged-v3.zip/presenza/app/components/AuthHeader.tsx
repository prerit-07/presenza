import React from 'react';
import { StyleSheet, View, Text, useWindowDimensions, Platform } from 'react-native';
import Svg, { Path, Circle, Ellipse } from 'react-native-svg';
import { Theme } from '@/constants/theme';
import { FloatingIcon } from './FloatingIcon';

export const AuthHeader: React.FC = () => {
  const { width } = useWindowDimensions();

  // Arched text letters and angles
  const letters = ['P', 'R', 'E', 'S', 'E', 'N', 'Z', 'A'];
  const radius = 100; // Radius of the arc
  const startAngle = -35; // Start angle in degrees
  const angleStep = 10; // Degrees between letters

  return (
    <View style={styles.container}>
      {/* Animated background floating shapes */}
      <FloatingIcon size={30} top={20} left={25} opacity={0.12} type="square" delay={0} />
      <FloatingIcon size={50} top={70} right={30} opacity={0.08} type="circle" delay={500} />
      <FloatingIcon size={24} top={130} left={40} opacity={0.15} type="circle" delay={200} />
      <FloatingIcon size={44} top={170} right={60} opacity={0.1} type="square" delay={800} />
      <FloatingIcon size={18} top={50} left={width * 0.4} opacity={0.14} type="square" delay={1200} />

      {/* Arched Text Logo */}
      <View style={styles.logoArcContainer}>
        {letters.map((char, index) => {
          const angle = startAngle + index * angleStep;
          const rad = (angle * Math.PI) / 180;
          // Calculate positioning based on circle center (0, radius)
          const x = radius * Math.sin(rad);
          const y = radius - radius * Math.cos(rad);

          return (
            <Text
              key={index}
              style={[
                styles.logoLetter,
                {
                  transform: [
                    { translateX: x },
                    { translateY: y },
                    { rotate: `${angle}deg` },
                  ],
                },
              ]}
            >
              {char}
            </Text>
          );
        })}
      </View>

      {/* Waving Mascot Character */}
      <View style={styles.mascotContainer}>
        <Svg width="110" height="110" viewBox="0 0 100 100">
          {/* Shadow at bottom */}
          <Ellipse cx="50" cy="94" rx="20" ry="4" fill="rgba(47, 36, 64, 0.25)" />

          {/* Location Pin Outer Shape (Purple) */}
          <Path
            d="M 50 15 
               C 30 15, 20 28, 20 48 
               C 20 68, 42 85, 50 92 
               C 58 92, 80 68, 80 48 
               C 80 28, 70 15, 50 15 Z"
            fill={Theme.colors.primary}
            stroke="#FFFFFF"
            strokeWidth="3.5"
          />

          {/* Inner Face Shape (White) */}
          <Ellipse cx="50" cy="44" rx="20" ry="17" fill="#FFFFFF" />

          {/* Eyes */}
          <Circle cx="44" cy="42" r="2.5" fill={Theme.colors.text} />
          <Circle cx="56" cy="42" r="2.5" fill={Theme.colors.text} />

          {/* Smile */}
          <Path
            d="M 46 48 Q 50 52 54 48"
            fill="none"
            stroke={Theme.colors.text}
            strokeWidth="2"
            strokeLinecap="round"
          />

          {/* Left Waving Arm (white outline) */}
          <Path
            d="M 75 42 C 82 32, 85 28, 83 25 C 81 22, 75 27, 72 32"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="3.5"
            strokeLinecap="round"
          />

          {/* Right Arm */}
          <Path
            d="M 23 45 C 16 48, 14 52, 16 55 C 18 58, 24 53, 26 49"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
        </Svg>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 220,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'flex-end',
    backgroundColor: '#3E226B', // Deep dark purple background matching screenshots
    overflow: 'hidden',
    paddingBottom: 10,
  },
  logoArcContainer: {
    height: 70,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  logoLetter: {
    position: 'absolute',
    color: '#FFFFFF',
    fontSize: 24,
    fontFamily: Theme.typography.fontFamily.bold,
    textAlign: 'center',
    top: 30,
    // Add text shadow for subtle 3D pop
    ...Platform.select({
      ios: {
        textShadowColor: 'rgba(0, 0, 0, 0.2)',
        textShadowOffset: { width: 1, height: 2 },
        textShadowRadius: 3,
      },
      android: {
        elevation: 2,
      },
    }),
  },
  mascotContainer: {
    marginTop: 0,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10,
  },
});
