import React from 'react';
import {
  StyleSheet,
  Text,
  ActivityIndicator,
  Pressable,
  ViewStyle,
  TextStyle,
  Platform,
  StyleProp,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from 'react-native-reanimated';
import { Theme } from '@/constants/theme';

interface ButtonProps {
  title: string;
  onPress: () => void;
  loading?: boolean;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
  icon?: React.ReactNode;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export const Button: React.FC<ButtonProps> = ({
  title,
  onPress,
  loading = false,
  disabled = false,
  style,
  textStyle,
  icon,
}) => {
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    if (!disabled && !loading) {
      scale.value = withSpring(0.96);
    }
  };

  const handlePressOut = () => {
    scale.value = withSpring(1);
  };

  return (
    <AnimatedPressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      disabled={disabled || loading}
      android_ripple={{ color: 'rgba(255, 255, 255, 0.2)' }}
      style={({ pressed }: { pressed: boolean }) => [
        styles.button,
        style as any,
        disabled && styles.disabledButton,
        Platform.OS === 'ios' && pressed && styles.pressedIos,
        animatedStyle,
      ]}
    >
      {loading ? (
        <ActivityIndicator size="small" color={Theme.colors.white} />
      ) : (
        <Animated.View style={styles.contentContainer}>
          {icon && <Animated.View style={styles.iconContainer}>{icon}</Animated.View>}
          <Text style={[styles.text, textStyle, disabled && styles.disabledText]}>
            {title}
          </Text>
        </Animated.View>
      )}
    </AnimatedPressable>
  );
};

const styles = StyleSheet.create({
  button: {
    height: Theme.button.height,
    borderRadius: Theme.borderRadius.button,
    backgroundColor: Theme.colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    ...Theme.shadow,
  },
  contentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconContainer: {
    marginRight: 8,
  },
  text: {
    color: Theme.colors.white,
    fontSize: Theme.typography.sizes.md,
    fontFamily: Theme.typography.fontFamily.semiBold,
  },
  disabledButton: {
    backgroundColor: Theme.colors.border,
    elevation: 0,
    shadowOpacity: 0,
  },
  disabledText: {
    color: Theme.colors.subText,
  },
  pressedIos: {
    opacity: 0.9,
  },
});
