import React from 'react';
import { StyleSheet, Text, View, Pressable, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Theme } from '@/constants/theme';

interface ProfileTileProps {
  title: string;
  iconName: React.ComponentProps<typeof Ionicons>['name'];
  onPress: () => void;
}

export const ProfileTile: React.FC<ProfileTileProps> = ({
  title,
  iconName,
  onPress,
}) => {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.container,
        Platform.OS === 'ios' && pressed && styles.pressed,
      ]}
      android_ripple={{ color: 'rgba(111, 74, 168, 0.1)' }}
    >
      <View style={styles.leftSection}>
        <View style={styles.iconContainer}>
          <Ionicons name={iconName} size={20} color={Theme.colors.white} />
        </View>
        <Text style={styles.title}>{title}</Text>
      </View>
      <Ionicons
        name="chevron-forward"
        size={18}
        color={Theme.colors.border}
      />
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: Theme.borderRadius.card,
    backgroundColor: Theme.colors.white,
    borderWidth: 1,
    borderColor: Theme.colors.border,
    marginBottom: 12,
    ...Theme.shadow,
    ...Platform.select({
      web: {
        cursor: 'pointer',
      },
    }),
  },
  leftSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconContainer: {
    width: 38,
    height: 38,
    borderRadius: 10,
    backgroundColor: Theme.colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  title: {
    fontSize: Theme.typography.sizes.md,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.text,
  },
  pressed: {
    opacity: 0.8,
  },
});
