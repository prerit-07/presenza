import React from 'react';
import { StyleSheet, View, Text, Pressable, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Theme } from '@/constants/theme';

export interface TabOption {
  key: string;
  label: string;
  iconName?: React.ComponentProps<typeof Ionicons>['name'];
}

interface TabSelectorProps {
  options: TabOption[];
  activeTab: string;
  onChange: (key: string) => void;
}

export const TabSelector: React.FC<TabSelectorProps> = ({
  options,
  activeTab,
  onChange,
}) => {
  return (
    <View style={styles.container}>
      {options.map((option) => {
        const isActive = option.key === activeTab;
        return (
          <Pressable
            key={option.key}
            onPress={() => onChange(option.key)}
            style={[
              styles.tab,
              isActive && styles.activeTab,
            ]}
            android_ripple={{ color: 'rgba(111, 74, 168, 0.1)', radius: 30 }}
          >
            {option.iconName && (
              <Ionicons
                name={option.iconName}
                size={16}
                color={isActive ? Theme.colors.primary : Theme.colors.subText}
                style={styles.icon}
              />
            )}
            <Text
              style={[
                styles.label,
                isActive ? styles.activeLabel : styles.inactiveLabel,
              ]}
            >
              {option.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: '#F3EDFA',
    borderRadius: 24,
    padding: 4,
    width: '100%',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 20,
    ...Platform.select({
      web: {
        cursor: 'pointer',
      },
    }),
  },
  activeTab: {
    backgroundColor: Theme.colors.white,
    borderWidth: 1,
    borderColor: Theme.colors.border,
    ...Theme.shadow,
  },
  icon: {
    marginRight: 6,
  },
  label: {
    fontSize: Theme.typography.sizes.sm,
    fontFamily: Theme.typography.fontFamily.medium,
  },
  activeLabel: {
    color: Theme.colors.primary,
  },
  inactiveLabel: {
    color: Theme.colors.subText,
  },
});
