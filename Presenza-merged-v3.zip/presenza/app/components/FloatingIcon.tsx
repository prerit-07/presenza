import React, { useEffect } from 'react';
import { StyleSheet, ViewStyle } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSequence,
} from 'react-native-reanimated';

interface FloatingIconProps {
  size?: number;
  top?: number;
  left?: number;
  right?: number;
  bottom?: number;
  opacity?: number;
  borderRadius?: number;
  type?: 'circle' | 'square';
  delay?: number;
}

export const FloatingIcon: React.FC<FloatingIconProps> = ({
  size = 40,
  top,
  left,
  right,
  bottom,
  opacity = 0.1,
  borderRadius = 12,
  type = 'square',
  delay = 0,
}) => {
  const translateY = useSharedValue(0);
  const rotate = useSharedValue(0);

  useEffect(() => {
    // Start animation after delay
    const startAnimation = () => {
      translateY.value = withRepeat(
        withSequence(
          withTiming(-15, { duration: 3000 + Math.random() * 1000 }),
          withTiming(15, { duration: 3000 + Math.random() * 1000 })
        ),
        -1,
        true
      );

      rotate.value = withRepeat(
        withTiming(360, { duration: 15000 + Math.random() * 5000 }),
        -1,
        false
      );
    };

    const timer = setTimeout(startAnimation, delay);
    return () => clearTimeout(timer);
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateY: translateY.value },
      { rotate: type === 'square' ? `${rotate.value}deg` : '0deg' },
    ],
  }));

  const style: ViewStyle = {
    position: 'absolute',
    width: size,
    height: size,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    opacity: opacity,
    borderRadius: type === 'circle' ? size / 2 : borderRadius,
    top,
    left,
    right,
    bottom,
  };

  return <Animated.View style={[style, animatedStyle]} />;
};
