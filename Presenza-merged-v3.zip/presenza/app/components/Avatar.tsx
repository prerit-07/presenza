import React from 'react';
import { StyleSheet, View, Image, Pressable, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Theme } from '@/constants/theme';

interface AvatarProps {
  source: string;
  size?: number;
  onEditPress?: () => void;
  editable?: boolean;
}

export const Avatar: React.FC<AvatarProps> = ({
  source,
  size = 120,
  onEditPress,
  editable = true,
}) => {
  const containerSize = size;
  const imageSize = size - 8;
  const editBtnSize = Math.floor(size * 0.28);
  const iconSize = Math.floor(editBtnSize * 0.55);

  return (
    <View style={[styles.container, { width: containerSize, height: containerSize }]}>
      <View
        style={[
          styles.imageContainer,
          {
            width: imageSize,
            height: imageSize,
            borderRadius: imageSize / 2,
            borderColor: Theme.colors.border,
            borderWidth: 2,
          },
        ]}
      >
        <Image
          source={{ uri: source }}
          style={{ width: '100%', height: '100%', borderRadius: imageSize / 2 }}
          resizeMode="cover"
        />
      </View>
      {editable && (
        <Pressable
          onPress={onEditPress}
          style={[
            styles.editButton,
            {
              width: editBtnSize,
              height: editBtnSize,
              borderRadius: editBtnSize / 2,
              bottom: 4,
              right: 4,
            },
          ]}
          android_ripple={{ color: 'rgba(255, 255, 255, 0.3)' }}
        >
          <Ionicons name="pencil" size={iconSize} color={Theme.colors.white} />
        </Pressable>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  imageContainer: {
    backgroundColor: Theme.colors.white,
    padding: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  editButton: {
    position: 'absolute',
    backgroundColor: Theme.colors.secondary,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: Theme.colors.white,
    ...Platform.select({
      web: {
        cursor: 'pointer',
      },
    }),
  },
});
