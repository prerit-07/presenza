import React, { createContext, useContext, useState, ReactNode } from 'react';
import { ThemedModal, type ThemedModalType } from '@/components/ThemedModal';

interface AlertConfig {
  type: ThemedModalType;
  title: string;
  message: string;
  primaryButtonText?: string;
  secondaryButtonText?: string;
  onPrimaryPress?: () => void;
  onSecondaryPress?: () => void;
}

interface ThemedAlertContextType {
  showAlert: (config: AlertConfig) => void;
}

const ThemedAlertContext = createContext<ThemedAlertContextType | undefined>(undefined);

export function ThemedAlertProvider({ children }: { children: ReactNode }) {
  const [visible, setVisible] = useState(false);
  const [config, setConfig] = useState<AlertConfig | null>(null);

  const showAlert = (newConfig: AlertConfig) => {
    setConfig(newConfig);
    setVisible(true);
  };

  const handlePrimary = () => {
    setVisible(false);
    if (config?.onPrimaryPress) {
      config.onPrimaryPress();
    }
  };

  const handleSecondary = () => {
    setVisible(false);
    if (config?.onSecondaryPress) {
      config.onSecondaryPress();
    }
  };

  return (
    <ThemedAlertContext.Provider value={{ showAlert }}>
      {children}
      {config && (
        <ThemedModal
          visible={visible}
          type={config.type}
          title={config.title}
          message={config.message}
          primaryButtonText={config.primaryButtonText ?? 'OK'}
          secondaryButtonText={config.secondaryButtonText}
          onPrimaryPress={handlePrimary}
          onSecondaryPress={config.secondaryButtonText ? handleSecondary : undefined}
        />
      )}
    </ThemedAlertContext.Provider>
  );
}

export function useThemedAlert() {
  const context = useContext(ThemedAlertContext);
  if (!context) {
    throw new Error('useThemedAlert must be used within a ThemedAlertProvider');
  }
  return context;
}
