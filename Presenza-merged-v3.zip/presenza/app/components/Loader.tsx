import React from 'react';
import { StyleSheet, View, ActivityIndicator, Text } from 'react-native';
import { Theme } from '@/constants/theme';

interface LoaderProps {
  message?: string;
  fullScreen?: boolean;
}

export const Loader: React.FC<LoaderProps> = ({
  message,
  fullScreen = false,
}) => {
  if (fullScreen) {
    return (
      <View style={styles.fullScreenContainer}>
        <View style={styles.box}>
          <ActivityIndicator size="large" color={Theme.colors.primary} />
          {message && <Text style={styles.text}>{message}</Text>}
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ActivityIndicator size="small" color={Theme.colors.primary} />
      {message && <Text style={[styles.text, styles.inlineText]}>{message}</Text>}
    </View>
  );
};

const styles = StyleSheet.create({
  fullScreenContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: Theme.colors.overlay,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
  },
  box: {
    backgroundColor: Theme.colors.white,
    padding: 24,
    borderRadius: Theme.borderRadius.card,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: Theme.colors.border,
    ...Theme.shadow,
  },
  container: {
    padding: 16,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  text: {
    fontSize: Theme.typography.sizes.sm,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.text,
    marginTop: 12,
    textAlign: 'center',
  },
  inlineText: {
    marginTop: 0,
    marginLeft: 8,
  },
});
