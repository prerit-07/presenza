// store/auth.store.ts

import { create } from 'zustand';

import {
  getMe,
  logout as authLogout,
  type AuthUser,
} from '@/services/auth.service';

import { tokenStorage } from '@/services/api';

import {
  ensureCurrentDeviceRegistered,
} from '@/services/device.service';

import { useAppStore } from '@/store/useAppStore';

interface AuthState {
  user: AuthUser | null;

  isAuthenticated: boolean;
  isBootstrapping: boolean;
  error: string | null;

  restoreSession: () => Promise<boolean>;

  setAuthenticatedUser: (
    user: AuthUser
  ) => void;

  clearSession: () => Promise<void>;

  clearError: () => void;
}

export const useAuthStore =
  create<AuthState>((set) => ({
    user: null,

    isAuthenticated: false,
    isBootstrapping: true,
    error: null,

    restoreSession: async () => {
      set({
        isBootstrapping: true,
        error: null,
      });

      try {
        // =====================================
        // 1. CHECK PERSISTED TOKEN
        // =====================================

        const token =
          await tokenStorage.getToken();

        if (!token) {
          useAppStore
            .getState()
            .setUser(null);

          set({
            user: null,
            isAuthenticated: false,
            isBootstrapping: false,
            error: null,
          });

          return false;
        }

        // =====================================
        // 2. VALIDATE SESSION WITH BACKEND
        // =====================================

        const user = await getMe();

        // =====================================
        // 3. SYNC AUTHENTICATED USER
        // =====================================

        useAppStore
          .getState()
          .setUser(user);

        set({
          user,
          isAuthenticated: true,
          error: null,
        });

        // =====================================
        // 4. RECONCILE CURRENT DEVICE
        //
        // IMPORTANT:
        // Device failure must NOT invalidate
        // an otherwise valid auth session.
        // =====================================

        try {
          const device =
            await ensureCurrentDeviceRegistered();

          console.log(
            'Current device ready:',
            device
          );
        } catch (deviceError) {
          console.warn(
            'Device reconciliation failed:',
            deviceError
          );
        }

        // =====================================
        // 5. FINISH BOOTSTRAP
        // =====================================

        set({
          isBootstrapping: false,
        });

        return true;
      } catch (error) {
        // =====================================
        // AUTH RESTORE FAILURE
        //
        // Only failures from token/auth restore
        // reach this catch.
        // =====================================

        await tokenStorage.deleteToken();

        useAppStore
          .getState()
          .setUser(null);

        set({
          user: null,
          isAuthenticated: false,
          isBootstrapping: false,
          error:
            error instanceof Error
              ? error.message
              : 'Unable to restore session',
        });

        return false;
      }
    },

    setAuthenticatedUser: (user) => {
      useAppStore
        .getState()
        .setUser(user);

      set({
        user,
        isAuthenticated: true,
        error: null,
      });
    },

    clearSession: async () => {
      try {
        await authLogout();
      } finally {
        useAppStore
          .getState()
          .logout();

        set({
          user: null,
          isAuthenticated: false,
          isBootstrapping: false,
          error: null,
        });
      }
    },

    clearError: () => {
      set({
        error: null,
      });
    },
  }));