import { create } from 'zustand';
import type { AuthUser } from '@/services/auth.service';

// ─── Types ────────────────────────────────────────────────────────────────────
export type AttendanceRecord = {
  id: string;
  date: string;
  dayName: string;
  checkIn: string;
  checkOut: string;
  status: 'ON TIME' | 'LATE' | 'ABSENT' | 'WFH' | string;
  totalHours?: string;
  workingHours?: string;
};

export type Ticket = {
  id: string;
  ticketNumber?: string;
  title: string;
  description: string;
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'CLOSED' | string;
  priority: 'Low' | 'Medium' | 'High' | 'LOW' | 'MEDIUM' | 'HIGH' | string;
  createdAt?: string;
  raisedDate?: string;
  category: string;
};

export type LeaveRequest = {
  id: string;
  employeeId: string;
  employeeName: string;
  type: string;
  startDate: string;
  endDate: string;
  reason: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | string;
  createdAt: string;
};

export type DeviceRequest = {
  id: string;
  employeeId: string;
  employeeName: string;
  reason: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | string;
  createdAt: string;
};

export type Member = {
  id: string;
  name: string;
  email: string;
  role: 'employee' | 'manager' | 'admin';
  department: string;
  designation: string;
  avatar?: string;
  isActive: boolean;
  joinedAt: string;
};

export type Department = {
  id: string;
  name: string;
  memberCount: number;
  managerId?: string;
};

// ─── Attendance Session ───────────────────────────────────────────────────────
export type AttendanceSession = {
  isCheckedIn: boolean;
  checkInTime: string | null;
  checkOutTime: string | null;
};

// ─── Store State ──────────────────────────────────────────────────────────────
interface AppState {
  // Auth
  user: AuthUser | null;
  isAuthenticated: boolean;

  // Legacy auth flow fields (kept for OTP/register flow)
  tempEmail: string;
  otpSent: boolean;
  otpVerified: boolean;
  companyVerified: boolean;

  // Attendance
  attendanceRecords: AttendanceRecord[];
  attendanceSession: AttendanceSession;

  // HR Data
  tickets: Ticket[];
  leaveRequests: LeaveRequest[];
  deviceRequests: DeviceRequest[];
  members: Member[];
  departments: Department[];

  // Actions — Auth
  setUser: (user: AuthUser | null) => void;
  setTempEmail: (email: string) => void;
  setOtpSent: (sent: boolean) => void;
  setOtpVerified: (verified: boolean) => void;
  setCompanyVerified: (verified: boolean) => void;
  logout: () => void;

  // Actions — Attendance
  checkIn: (time: string) => void;
  checkOut: (time: string) => void;
  addAttendanceRecord: (record: AttendanceRecord) => void;

  // Actions — Leaves
  addLeave: (leave: Omit<LeaveRequest, 'id' | 'createdAt'>) => void;
  updateLeaveStatus: (id: string, status: LeaveRequest['status']) => void;

  // Actions — Tickets
  addTicket: (ticket: Omit<Ticket, 'id'>) => void;

  // Actions — Device Requests
  addDeviceRequest: (req: Omit<DeviceRequest, 'id' | 'createdAt'>) => void;
  updateDeviceRequest: (id: string, status: DeviceRequest['status']) => void;

  // Actions — Members
  addMember: (member: Omit<Member, 'id' | 'joinedAt'>) => void;
  updateMember: (id: string, updates: Partial<Member>) => void;
  deleteMember: (id: string) => void;

  // Legacy
  register: (data: any) => void;
  verifyOtp: (data: any) => void;
  verifyCompany: (data: any) => void;
}

// ─── Mock Data ────────────────────────────────────────────────────────────────
const mockAttendance: AttendanceRecord[] = [
  { id: '1', date: '2026-07-07', dayName: 'Monday', checkIn: '09:02 AM', checkOut: '06:05 PM', status: 'ON TIME', workingHours: '9h 3m' },
  { id: '2', date: '2026-07-08', dayName: 'Tuesday', checkIn: '09:45 AM', checkOut: '06:10 PM', status: 'LATE', workingHours: '8h 25m' },
  { id: '3', date: '2026-07-03', dayName: 'Thursday', checkIn: '08:58 AM', checkOut: '06:00 PM', status: 'ON TIME', workingHours: '9h 2m' },
];

const mockMembers: Member[] = [
  { id: 'emp-001', name: 'Alex Johnson', email: 'employee@presenza.com', role: 'employee', department: 'Engineering', designation: 'Software Engineer', avatar: 'https://i.pravatar.cc/150?img=11', isActive: true, joinedAt: '2025-01-15' },
  { id: 'emp-002', name: 'Priya Mehta', email: 'priya@presenza.com', role: 'employee', department: 'Design', designation: 'UI Designer', avatar: 'https://i.pravatar.cc/150?img=32', isActive: true, joinedAt: '2025-03-20' },
  { id: 'emp-003', name: 'Rahul Verma', email: 'rahul@presenza.com', role: 'employee', department: 'Engineering', designation: 'Backend Engineer', avatar: 'https://i.pravatar.cc/150?img=15', isActive: true, joinedAt: '2025-02-10' },
  { id: 'mgr-001', name: 'Sarah Williams', email: 'manager@presenza.com', role: 'manager', department: 'Engineering', designation: 'Engineering Manager', avatar: 'https://i.pravatar.cc/150?img=5', isActive: true, joinedAt: '2024-11-01' },
  { id: 'mgr-002', name: 'Karan Patel', email: 'karan@presenza.com', role: 'manager', department: 'Sales', designation: 'Sales Manager', avatar: 'https://i.pravatar.cc/150?img=68', isActive: true, joinedAt: '2025-01-05' },
];

const mockDepartments: Department[] = [
  { id: 'dept-1', name: 'Engineering', memberCount: 12, managerId: 'mgr-001' },
  { id: 'dept-2', name: 'Design', memberCount: 5 },
  { id: 'dept-3', name: 'Sales', memberCount: 8, managerId: 'mgr-002' },
  { id: 'dept-4', name: 'HR', memberCount: 3 },
];

const mockLeaves: LeaveRequest[] = [
  { id: 'lr-001', employeeId: 'emp-001', employeeName: 'Alex Johnson', type: 'Sick Leave', startDate: '2026-07-10', endDate: '2026-07-11', reason: 'Fever and cold', status: 'PENDING', createdAt: '2026-07-08T10:00:00Z' },
  { id: 'lr-002', employeeId: 'emp-002', employeeName: 'Priya Mehta', type: 'Casual Leave', startDate: '2026-07-15', endDate: '2026-07-15', reason: 'Family function', status: 'APPROVED', createdAt: '2026-07-06T09:00:00Z' },
];

const mockDeviceRequests: DeviceRequest[] = [
  { id: 'dr-001', employeeId: 'emp-003', employeeName: 'Rahul Verma', reason: 'Changed my phone, need to re-register new device.', status: 'PENDING', createdAt: '2026-07-07T14:00:00Z' },
];

// ─── Store ────────────────────────────────────────────────────────────────────
export const useAppStore = create<AppState>((set, get) => ({
  // Auth
  user: null,
  isAuthenticated: false,
  tempEmail: '',
  otpSent: false,
  otpVerified: false,
  companyVerified: false,

  // Attendance
  attendanceRecords: mockAttendance,
  attendanceSession: { isCheckedIn: false, checkInTime: null, checkOutTime: null },

  // HR
  tickets: [],
  leaveRequests: mockLeaves,
  deviceRequests: mockDeviceRequests,
  members: mockMembers,
  departments: mockDepartments,

  // ── Auth Actions ──
  setUser: (user) => set({ user, isAuthenticated: !!user }),
  setTempEmail: (tempEmail) => set({ tempEmail }),
  setOtpSent: (otpSent) => set({ otpSent }),
  setOtpVerified: (otpVerified) => set({ otpVerified }),
  setCompanyVerified: (companyVerified) => set({ companyVerified }),

  logout: () => set({
    user: null,
    isAuthenticated: false,
    tempEmail: '',
    otpSent: false,
    otpVerified: false,
    companyVerified: false,
    attendanceSession: { isCheckedIn: false, checkInTime: null, checkOutTime: null },
  }),

  // ── Attendance Actions ──
  checkIn: (time) => set({ attendanceSession: { isCheckedIn: true, checkInTime: time, checkOutTime: null } }),
  checkOut: (time) => set((state) => ({
    attendanceSession: { ...state.attendanceSession, isCheckedIn: false, checkOutTime: time }
  })),
  addAttendanceRecord: (record) => set((state) => ({
    attendanceRecords: [record, ...state.attendanceRecords]
  })),

  // ── Leave Actions ──
  addLeave: (leave) => set((state) => ({
    leaveRequests: [
      { ...leave, id: `lr-${Date.now()}`, createdAt: new Date().toISOString() },
      ...state.leaveRequests,
    ]
  })),
  updateLeaveStatus: (id, status) => set((state) => ({
    leaveRequests: state.leaveRequests.map((l) => l.id === id ? { ...l, status } : l)
  })),

  // ── Ticket Actions ──
  addTicket: (ticket) => set((state) => ({
    tickets: [{ ...ticket, id: `t-${Date.now()}` }, ...state.tickets]
  })),

  // ── Device Request Actions ──
  addDeviceRequest: (req) => set((state) => ({
    deviceRequests: [
      { ...req, id: `dr-${Date.now()}`, createdAt: new Date().toISOString() },
      ...state.deviceRequests,
    ]
  })),
  updateDeviceRequest: (id, status) => set((state) => ({
    deviceRequests: state.deviceRequests.map((d) => d.id === id ? { ...d, status } : d)
  })),

  // ── Member Actions ──
  addMember: (member) => set((state) => ({
    members: [
      { ...member, id: `emp-${Date.now()}`, joinedAt: new Date().toISOString().split('T')[0] },
      ...state.members,
    ]
  })),
  updateMember: (id, updates) => set((state) => ({
    members: state.members.map((m) => m.id === id ? { ...m, ...updates } : m)
  })),
  deleteMember: (id) => set((state) => ({
    members: state.members.filter((m) => m.id !== id)
  })),

  // ── Legacy ──
  register: () => set({ otpSent: true }),
  verifyOtp: () => set({ otpVerified: true }),
  verifyCompany: () => set({ companyVerified: true }),
}));
