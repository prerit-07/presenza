// store/onboarding.store.ts

import { create } from 'zustand';

export type OrganizationType =
  | 'Corporate'
  | 'Educational';

export type SelectedPlan =
  | 'Starter'
  | 'Growth'
  | 'Business'
  | string;

interface OnboardingState {
  // Step 1 — Organization
  organizationName: string;
  organizationType: OrganizationType;

  // Step 2 — Admin
  fullName: string;
  username: string;
  email: string;
  phone: string;
  password: string;

  // Step 3 — Plan
  selectedPlan: SelectedPlan | null;

  setOrganizationDetails: (
    organizationName: string,
    organizationType: OrganizationType
  ) => void;

  setAdminDetails: (details: {
    fullName: string;
    username: string;
    email: string;
    phone: string;
    password: string;
  }) => void;

  setSelectedPlan: (
    plan: SelectedPlan
  ) => void;

  resetOnboarding: () => void;
}

const initialState = {
  organizationName: '',
  organizationType: 'Corporate' as OrganizationType,

  fullName: '',
  username: '',
  email: '',
  phone: '',
  password: '',

  selectedPlan: null as SelectedPlan | null,
};

export const useOnboardingStore =
  create<OnboardingState>((set) => ({
    ...initialState,

    setOrganizationDetails: (
      organizationName,
      organizationType
    ) => {
      set({
        organizationName,
        organizationType,
      });
    },

    setAdminDetails: (details) => {
      set({
        fullName: details.fullName,
        username: details.username,
        email: details.email,
        phone: details.phone,
        password: details.password,
      });
    },

    setSelectedPlan: (plan) => {
      set({
        selectedPlan: plan,
      });
    },

    resetOnboarding: () => {
      set(initialState);
    },
  }));