import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  ScrollView,
  Pressable,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAppStore } from '@/store/useAppStore';
import { Theme } from '@/constants/theme';
import { Header } from '@/components/Header';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { TextInput } from '@/components/TextInput';
import { Modal } from '@/components/Modal';
import { Toast } from '@/components/Toast';

export default function ApplyLeaveScreen() {
  const router = useRouter();
  const user = useAppStore((state) => state.user);
  const addLeave = useAppStore((state) => state.addLeave);

  const [toast, setToast] = useState<{ visible: boolean; message: string; type: 'success' | 'error' | 'info' }>({
    visible: false,
    message: '',
    type: 'info',
  });
  const [loading, setLoading] = useState(false);

  // Leave Form States
  const [startDate, setStartDate] = useState(new Date('2026-06-14'));
  const [endDate, setEndDate] = useState(new Date('2026-06-15'));
  const [leaveType, setLeaveType] = useState('');
  const [note, setNote] = useState('');

  // Dialog Visibilities
  const [leaveTypeModalVisible, setLeaveTypeModalVisible] = useState(false);
  const [dateModalVisible, setDateModalVisible] = useState(false);
  const [selectingDateType, setSelectingDateType] = useState<'start' | 'end'>('start');

  const leaveTypes = [
    'Sick Leave',
    'Casual Leave',
    'Annual Leave',
    'Maternity/Paternity Leave',
    'Unpaid Leave',
  ];

  // Helper to format Date to "14 June, 2026"
  const formatDateString = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  };

  // Helper to get day name like "Tuesday"
  const getDayName = (date: Date) => {
    return date.toLocaleDateString('en-US', { weekday: 'long' });
  };

  // Compute total days between start and end
  const totalDays = Math.max(
    1,
    Math.round((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1
  );

  const handleDateSelect = (day: number) => {
    const selectedDate = new Date(2026, 5, day); // June is index 5
    if (selectingDateType === 'start') {
      setStartDate(selectedDate);
      if (selectedDate > endDate) {
        // Auto adjust end date if start date is after end date
        setEndDate(new Date(selectedDate.getTime() + 24 * 60 * 60 * 1000));
      }
    } else {
      if (selectedDate < startDate) {
        setToast({
          visible: true,
          message: 'End date cannot be before start date.',
          type: 'error',
        });
        return;
      }
      setEndDate(selectedDate);
    }
    setDateModalVisible(false);
  };

  const openDatePicker = (type: 'start' | 'end') => {
    setSelectingDateType(type);
    setDateModalVisible(true);
  };

  const handleApplyLeave = async () => {
    if (leaveType === '') {
      setToast({
        visible: true,
        message: 'Please select a leave type.',
        type: 'error',
      });
      return;
    }

    setLoading(true);
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    addLeave({
      employeeId: user?.id ?? '',
      employeeName: user?.name ?? '',
      type: leaveType,
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0],
      status: 'PENDING',
      reason: note,
    });
    
    setLoading(false);
    setToast({
      visible: true,
      message: 'Leave request submitted successfully!',
      type: 'success',
    });

    setTimeout(() => {
      router.back();
    }, 1200);
  };

  // Simulated day cells for June 2026 calendar picker
  const juneDays = Array.from({ length: 30 }, (_, i) => i + 1);

  return (
    <SafeAreaView style={styles.safeArea}>
      <Toast
        visible={toast.visible}
        message={toast.message}
        type={toast.type}
        onDismiss={() => setToast({ ...toast, visible: false })}
      />

      {/* Leave Type Bottom Sheet Picker */}
      <Modal
        visible={leaveTypeModalVisible}
        onClose={() => setLeaveTypeModalVisible(false)}
        title="Select Leave Type"
        bottomSheet
      >
        <View style={styles.modalOptionsContainer}>
          {leaveTypes.map((type) => (
            <Pressable
              key={type}
              style={[
                styles.modalOptionTile,
                leaveType === type && styles.modalOptionTileActive,
              ]}
              onPress={() => {
                setLeaveType(type);
                setLeaveTypeModalVisible(false);
              }}
              android_ripple={{ color: 'rgba(111, 74, 168, 0.1)' }}
            >
              <Ionicons
                name="briefcase-outline"
                size={18}
                color={leaveType === type ? Theme.colors.primary : Theme.colors.subText}
                style={styles.modalOptionIcon}
              />
              <Text
                style={[
                  styles.modalOptionText,
                  leaveType === type && styles.modalOptionTextActive,
                ]}
              >
                {type}
              </Text>
              {leaveType === type && (
                <Ionicons name="checkmark" size={18} color={Theme.colors.primary} />
              )}
            </Pressable>
          ))}
        </View>
      </Modal>

      {/* Simplified Date Picker Modal */}
      <Modal
        visible={dateModalVisible}
        onClose={() => setDateModalVisible(false)}
        title={`Select ${selectingDateType === 'start' ? 'Start' : 'End'} Date (June 2026)`}
      >
        <Text style={styles.dateModalHint}>Tap any date in June 2026 to select:</Text>
        <View style={styles.dateGrid}>
          {juneDays.map((day) => {
            const isStart = startDate.getDate() === day;
            const isEnd = endDate.getDate() === day;
            const isInRange = day > startDate.getDate() && day < endDate.getDate();

            return (
              <Pressable
                key={day}
                style={[
                  styles.dateCell,
                  isStart && styles.dateCellActiveStart,
                  isEnd && styles.dateCellActiveEnd,
                  isInRange && styles.dateCellRange,
                ]}
                onPress={() => handleDateSelect(day)}
              >
                <Text
                  style={[
                    styles.dateCellText,
                    (isStart || isEnd) && styles.dateCellTextActive,
                    isInRange && styles.dateCellTextRange,
                  ]}
                >
                  {day}
                </Text>
              </Pressable>
            );
          })}
        </View>
      </Modal>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        {/* Header */}
        <Header
          title="Apply Leave"
          subtitle="Submit a Leave Request"
          showBackButton={true}
        />

        <ScrollView contentContainerStyle={styles.scrollContent} bounces={false}>
          {/* Date Picker Card */}
          <Card style={styles.datePickerCard}>
            <View style={styles.datesRow}>
              {/* Start Date */}
              <Pressable style={styles.dateBlock} onPress={() => openDatePicker('start')}>
                <Text style={styles.dateLabel}>Start Date</Text>
                <View style={styles.dateValueRow}>
                  <View style={styles.calendarIconBg}>
                    <Ionicons name="calendar-outline" size={18} color={Theme.colors.primary} />
                  </View>
                  <View>
                    <Text style={styles.dateValueText}>{formatDateString(startDate)}</Text>
                    <Text style={styles.dateDayText}>{getDayName(startDate)}</Text>
                  </View>
                </View>
              </Pressable>

              {/* Vertical line separator */}
              <View style={styles.dateSeparator} />

              {/* End Date */}
              <Pressable style={styles.dateBlock} onPress={() => openDatePicker('end')}>
                <Text style={styles.dateLabel}>End Date</Text>
                <View style={styles.dateValueRow}>
                  <View style={styles.calendarIconBg}>
                    <Ionicons name="calendar-outline" size={18} color={Theme.colors.primary} />
                  </View>
                  <View>
                    <Text style={styles.dateValueText}>{formatDateString(endDate)}</Text>
                    <Text style={styles.dateDayText}>{getDayName(endDate)}</Text>
                  </View>
                </View>
              </Pressable>
            </View>

            {/* Total days badge */}
            <View style={styles.totalBadgeContainer}>
              <View style={styles.totalBadge}>
                <Ionicons name="calendar" size={12} color={Theme.colors.primary} style={styles.badgeIcon} />
                <Text style={styles.totalBadgeText}>Total: {totalDays} Day{totalDays > 1 ? 's' : ''}</Text>
              </View>
            </View>
          </Card>

          {/* Leave Type Selector Card */}
          <Text style={styles.fieldSectionTitle}>Leave Type</Text>
          <Pressable onPress={() => setLeaveTypeModalVisible(true)}>
            <Card style={styles.dropdownCard}>
              <View style={styles.dropdownLeft}>
                <View style={styles.suitcaseCircle}>
                  <Ionicons name="briefcase-outline" size={20} color={Theme.colors.primary} />
                </View>
                <View style={styles.dropdownTextWrapper}>
                  <Text style={styles.dropdownTitle}>Leave Type</Text>
                  <Text style={styles.dropdownValue}>
                    {leaveType || 'Select the type of Leave.'}
                  </Text>
                </View>
              </View>
              <Ionicons name="chevron-down" size={20} color={Theme.colors.text} />
            </Card>
          </Pressable>

          {/* Note to Approver Textarea */}
          <Text style={styles.fieldSectionTitle}>Note to Approver</Text>
          <View style={styles.textareaContainer}>
            <View style={styles.penIconContainer}>
              <Ionicons name="pencil" size={18} color={Theme.colors.primary} />
            </View>
            <TextInput
              placeholder="Type your message here..."
              value={note}
              onChangeText={(text) => text.length <= 500 && setNote(text)}
              multiline
              numberOfLines={4}
              maxLength={500}
              containerStyle={styles.textareaInputContainer}
              inputStyle={styles.textareaInput}
            />
            <Text style={styles.charCounter}>{note.length}/500</Text>
          </View>

          {/* Leave Policy Reminder Card */}
          <Card style={styles.policyCard}>
            <View style={styles.policyHeader}>
              <Ionicons name="information-circle-outline" size={20} color={Theme.colors.primary} style={styles.policyIcon} />
              <Text style={styles.policyTitle}>Leave policy reminder</Text>
            </View>
            <Text style={styles.policySubtitle}>
              Your leave will be subject to approval based on company policy and team availability
            </Text>
          </Card>

          {/* Apply Leave Button */}
          <Button
            title="Request Leave"
            onPress={handleApplyLeave}
            loading={loading}
            icon={<Ionicons name="paper-plane" size={18} color={Theme.colors.white} />}
            style={styles.requestButton}
          />

          {/* Policy footer disclaimer */}
          <View style={styles.footerDisclaimer}>
            <Ionicons name="shield-checkmark" size={16} color={Theme.colors.subText} style={styles.disclaimerIcon} />
            <Text style={styles.disclaimerText}>
              Your request will be sent to your manager for approval
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Theme.colors.background,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  datePickerCard: {
    padding: 16,
    marginTop: 8,
  },
  datesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  dateBlock: {
    flex: 1,
  },
  dateLabel: {
    fontSize: 10,
    fontFamily: Theme.typography.fontFamily.semiBold,
    color: Theme.colors.subText,
    marginBottom: 8,
    textAlign: 'center',
  },
  dateValueRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  calendarIconBg: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: 'rgba(111, 74, 168, 0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  dateValueText: {
    fontSize: 12,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Theme.colors.text,
  },
  dateDayText: {
    fontSize: 9,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.subText,
    marginTop: 1,
  },
  dateSeparator: {
    width: 1,
    height: 48,
    backgroundColor: Theme.colors.border,
    marginHorizontal: 12,
  },
  totalBadgeContainer: {
    alignItems: 'center',
    marginTop: 16,
  },
  totalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3EDFA',
    borderWidth: 1,
    borderColor: '#E2D5F3',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 5,
  },
  badgeIcon: {
    marginRight: 6,
  },
  totalBadgeText: {
    fontSize: 10,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Theme.colors.primary,
  },
  fieldSectionTitle: {
    fontSize: 14,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Theme.colors.text,
    marginTop: 18,
    marginBottom: 10,
    paddingLeft: 4,
  },
  dropdownCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    marginBottom: 0,
  },
  dropdownLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  suitcaseCircle: {
    width: 38,
    height: 38,
    borderRadius: 10,
    backgroundColor: 'rgba(111, 74, 168, 0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  dropdownTextWrapper: {
    flex: 1,
  },
  dropdownTitle: {
    fontSize: 12,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Theme.colors.text,
  },
  dropdownValue: {
    fontSize: 10,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.subText,
    marginTop: 1,
  },
  textareaContainer: {
    position: 'relative',
    backgroundColor: Theme.colors.white,
    borderRadius: Theme.borderRadius.card,
    borderWidth: 1,
    borderColor: Theme.colors.border,
    paddingTop: 12,
    paddingHorizontal: 16,
    paddingBottom: 30,
    minHeight: 120,
    ...Theme.shadow,
  },
  penIconContainer: {
    position: 'absolute',
    left: 16,
    top: 14,
    zIndex: 1,
  },
  textareaInputContainer: {
    marginBottom: 0,
  },
  textareaInput: {
    borderWidth: 0,
    paddingLeft: 22,
    backgroundColor: 'transparent',
    textAlignVertical: 'top',
    height: 80,
    fontSize: 12,
  },
  charCounter: {
    position: 'absolute',
    bottom: 12,
    right: 16,
    fontSize: 9,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.subText,
  },
  policyCard: {
    backgroundColor: '#EAE6F4', // Policy card matching Screenshot 7
    borderColor: '#DDD6F0',
    padding: 16,
    marginTop: 24,
    marginBottom: 20,
  },
  policyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  policyIcon: {
    marginRight: 8,
  },
  policyTitle: {
    fontSize: 12,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Theme.colors.primary,
  },
  policySubtitle: {
    fontSize: 10,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.subText,
    lineHeight: 14,
    paddingLeft: 28,
  },
  requestButton: {
    backgroundColor: '#7A54B1', // Purple submit button matching Screenshot 7
    borderRadius: 14,
    height: 52,
  },
  footerDisclaimer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 16,
  },
  disclaimerIcon: {
    marginRight: 6,
  },
  disclaimerText: {
    fontSize: 9,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.subText,
  },
  // Date modal styles
  dateModalHint: {
    fontSize: Theme.typography.sizes.sm,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.subText,
    marginBottom: 16,
    paddingLeft: 4,
  },
  dateGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
    marginHorizontal: -4,
  },
  dateCell: {
    width: '13.5%', // 7 cells in row
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: '0.4%',
    marginVertical: 4,
    borderRadius: 8,
  },
  dateCellActiveStart: {
    backgroundColor: Theme.colors.primary,
  },
  dateCellActiveEnd: {
    backgroundColor: Theme.colors.secondary,
  },
  dateCellRange: {
    backgroundColor: '#F3EDFA',
  },
  dateCellText: {
    fontSize: 11,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.text,
  },
  dateCellTextActive: {
    color: Theme.colors.white,
    fontFamily: Theme.typography.fontFamily.bold,
  },
  dateCellTextRange: {
    color: Theme.colors.primary,
    fontFamily: Theme.typography.fontFamily.bold,
  },
  modalOptionsContainer: {
    paddingVertical: 10,
  },
  modalOptionTile: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 10,
    marginBottom: 8,
    backgroundColor: '#F8F5FC',
  },
  modalOptionTileActive: {
    backgroundColor: '#F0ECF7',
    borderWidth: 1,
    borderColor: Theme.colors.primary,
  },
  modalOptionIcon: {
    marginRight: 12,
  },
  modalOptionText: {
    flex: 1,
    fontSize: 13,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.text,
  },
  modalOptionTextActive: {
    color: Theme.colors.primary,
    fontFamily: Theme.typography.fontFamily.bold,
  },
});
