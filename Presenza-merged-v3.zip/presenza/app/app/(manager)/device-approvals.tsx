// app/device-approvals.tsx
// Role: Manager + Admin
// Opens from: Manager/Admin dashboard, Team screen, Inbox

import React, { useCallback, useState } from 'react';
import {
  View, Text, StyleSheet, FlatList,
  Pressable, Image, ActivityIndicator,
} from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { PageHeader } from '@/components/PageHeader';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import {
  deviceChangeService,
  type DeviceChangeRequestResponse,
} from '@/services/device.change.service';
import { useThemedAlert } from '@/components/ThemedAlertProvider';

const STATUS_COLOR: Record<string, string> = {
  PENDING: '#F59E0B',
  APPROVED: '#4CAF50',
  REJECTED: '#B23A48',
};

export default function DeviceApprovalsScreen() {
  const router = useRouter();
  const { showAlert } = useThemedAlert();

  // This screen used to read/write a local mock store — approving or
  // rejecting a device change never reached the backend, so the
  // employee's real device_change_request row stayed PENDING forever
  // and their device swap was never actually applied server-side.
  const [requests, setRequests] = useState<DeviceChangeRequestResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [decidingId, setDecidingId] = useState<number | null>(null);
  const [filter, setFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('ALL');

  const loadRequests = useCallback(async () => {
    setLoading(true);
    try {
      // The backend only exposes /device-change-requests/pending —
      // there's no "all statuses" endpoint for this resource, so the
      // ALL/APPROVED/REJECTED tabs will only ever show what's still
      // pending plus whatever this session has just decided.
      const pending = await deviceChangeService.getPendingRequests();
      setRequests(pending);
    } catch (error) {
      console.error('Failed to load device change requests:', error);
      showAlert({ type: 'error', title: 'Error', message: 'Failed to load device requests.' });
    } finally {
      setLoading(false);
    }
  }, [showAlert]);

  useFocusEffect(
    useCallback(() => {
      loadRequests();
    }, [loadRequests])
  );

  const handleDecision = async (requestId: number, approved: boolean) => {
    setDecidingId(requestId);
    try {
      const updated = await deviceChangeService.reviewRequest(requestId, approved);
      setRequests((prev) => prev.map((r) => (r.requestId === requestId ? updated : r)));
    } catch (error) {
      console.error('Failed to review device change request:', error);
      showAlert({
        type: 'error',
        title: 'Error',
        message: error instanceof Error ? error.message : 'Failed to update this request.',
      });
    } finally {
      setDecidingId(null);
    }
  };

  const filtered = requests.filter((d) => filter === 'ALL' || d.status === filter);

  const formatDate = (d: string) =>
    new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

  return (
    <View style={styles.root}>
      <PageHeader title="Device Approvals" />

      {/* Filter */}
      <View style={styles.filterRow}>
        {(['ALL', 'PENDING', 'APPROVED', 'REJECTED'] as const).map((f) => (
          <Pressable
            key={f}
            style={[styles.filterPill, filter === f && styles.filterPillActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>
              {f === 'ALL' ? 'All' : f.charAt(0) + f.slice(1).toLowerCase()}
            </Text>
          </Pressable>
        ))}
      </View>

      {loading ? (
        <ActivityIndicator style={{ marginTop: 60 }} color={T.purpleIcon} />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(d) => String(d.requestId)}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <View style={styles.cardTop}>
                <Image
                  source={{ uri: `https://i.pravatar.cc/150?u=${item.userId}` }}
                  style={styles.avatar}
                />
                <View style={styles.empInfo}>
                  <Text style={styles.empName}>User #{item.userId}</Text>
                  <Text style={styles.dateText}>{formatDate(item.requestedAt)}</Text>
                </View>
                <View style={[styles.statusBadge, { backgroundColor: STATUS_COLOR[item.status] + '18' }]}>
                  <Text style={[styles.statusText, { color: STATUS_COLOR[item.status] }]}>
                    {item.status.charAt(0) + item.status.slice(1).toLowerCase()}
                  </Text>
                </View>
              </View>

              <View style={styles.reasonBox}>
                <MaterialCommunityIcons name="cellphone-key" size={14} color={T.textMuted} />
                <Text style={styles.reasonText}>{item.reason}</Text>
              </View>

              {item.status === 'PENDING' && (
                <View style={styles.actionRow}>
                  <Pressable
                    style={[styles.actionBtn, styles.rejectBtn]}
                    disabled={decidingId === item.requestId}
                    onPress={() => handleDecision(item.requestId, false)}
                  >
                    {decidingId === item.requestId ? (
                      <ActivityIndicator size="small" color="#B23A48" />
                    ) : (
                      <>
                        <MaterialCommunityIcons name="close" size={14} color="#B23A48" />
                        <Text style={[styles.actionBtnText, { color: '#B23A48' }]}>Reject</Text>
                      </>
                    )}
                  </Pressable>
                  <Pressable
                    style={[styles.actionBtn, styles.approveBtn]}
                    disabled={decidingId === item.requestId}
                    onPress={() => handleDecision(item.requestId, true)}
                  >
                    {decidingId === item.requestId ? (
                      <ActivityIndicator size="small" color="#FFF" />
                    ) : (
                      <>
                        <MaterialCommunityIcons name="check" size={14} color="#FFF" />
                        <Text style={[styles.actionBtnText, { color: '#FFF' }]}>Approve</Text>
                      </>
                    )}
                  </Pressable>
                </View>
              )}
            </View>
          )}
          ListEmptyComponent={
            <View style={styles.empty}>
              <MaterialCommunityIcons name="cellphone-check" size={48} color={T.textMuted} />
              <Text style={styles.emptyText}>No device requests</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: T.screenBg },
  filterRow: { flexDirection: 'row', gap: 8, paddingHorizontal: 20, marginBottom: 12 },
  filterPill: { borderRadius: 20, paddingVertical: 6, paddingHorizontal: 12, backgroundColor: '#FFF', borderWidth: 1, borderColor: '#E8E4EC' },
  filterPillActive: { backgroundColor: T.purpleIcon, borderColor: T.purpleIcon },
  filterText: { fontSize: 12, fontWeight: '600', color: T.purpleIcon },
  filterTextActive: { color: '#FFF' },
  list: { paddingHorizontal: 20, paddingBottom: 100 },
  card: { backgroundColor: '#FFF', borderRadius: 16, padding: 16, marginBottom: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 6, elevation: 3 },
  cardTop: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  avatar: { width: 40, height: 40, borderRadius: 20, marginRight: 10 },
  empInfo: { flex: 1 },
  empName: { fontSize: 14, fontWeight: '700', color: T.purpleDark },
  dateText: { fontSize: 11, color: T.textMuted, marginTop: 2 },
  statusBadge: { borderRadius: 8, paddingVertical: 4, paddingHorizontal: 8 },
  statusText: { fontSize: 11, fontWeight: '700' },
  reasonBox: { flexDirection: 'row', gap: 6, alignItems: 'flex-start', backgroundColor: T.screenBg, borderRadius: 8, padding: 10, marginBottom: 12 },
  reasonText: { flex: 1, fontSize: 12, color: T.purpleDark, lineHeight: 18 },
  actionRow: { flexDirection: 'row', gap: 10 },
  actionBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, borderRadius: 10, paddingVertical: 10 },
  rejectBtn: { backgroundColor: '#FFF1F3', borderWidth: 1, borderColor: '#B23A48' },
  approveBtn: { backgroundColor: '#4CAF50' },
  actionBtnText: { fontSize: 13, fontWeight: '700' },
  empty: { alignItems: 'center', marginTop: 60, gap: 10 },
  emptyText: { fontSize: 14, color: T.textMuted },
});
