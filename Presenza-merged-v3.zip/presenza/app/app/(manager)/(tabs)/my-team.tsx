import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Modal,
  Platform,
} from 'react-native';
import { Tabs, useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons, MaterialCommunityIcons, FontAwesome5 } from '@expo/vector-icons';
import { PageHeader } from '@/components/PageHeader';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { useThemedAlert } from '@/components/ThemedAlertProvider';

interface TeamMember {
  id: string;
  name: string;
  role: string;
  status: 'Present' | 'Late' | 'Absent';
  gender: 'male' | 'female';
}

export default function TeamManagerScreen() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const { showAlert } = useThemedAlert();

  // Search query
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Team list state
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([
    { id: '1', name: 'Arjun Mehta', role: 'Field Executive', status: 'Present', gender: 'male' },
    { id: '2', name: 'Priya Sharma', role: 'UI/UX Designer', status: 'Present', gender: 'female' },
    { id: '3', name: 'Rohan Verma', role: 'Field Executive', status: 'Late', gender: 'male' },
    { id: '4', name: 'Meera Sen', role: 'Marketing Specialist', status: 'Present', gender: 'female' },
    { id: '5', name: 'Aditya Goel', role: 'Sales Executive', status: 'Absent', gender: 'male' },
    { id: '6', name: 'Rahul Nair', role: 'Operations Lead', status: 'Present', gender: 'male' },
  ]);

  // Modal to add a new employee (for Manager Mode)
  const [isAddModalVisible, setIsAddModalVisible] = useState<boolean>(false);
  const [newEmployeeName, setNewEmployeeName] = useState<string>('');
  const [newEmployeeRole, setNewEmployeeRole] = useState<string>('');
  const [newEmployeeStatus, setNewEmployeeStatus] = useState<'Present' | 'Late' | 'Absent'>('Present');
  const [newEmployeeGender, setNewEmployeeGender] = useState<'male' | 'female'>('male');

  // Interactive Quick Action Modals Visibility
  const [isAssignShiftVisible, setIsAssignShiftVisible] = useState<boolean>(false);
  const [isAddAttendanceVisible, setIsAddAttendanceVisible] = useState<boolean>(false);
  const [isAttendanceLogVisible, setIsAttendanceLogVisible] = useState<boolean>(false);
  const [isTeamReportVisible, setIsTeamReportVisible] = useState<boolean>(false);

  // States for Assign Shift Form
  const [selectedShiftMemberId, setSelectedShiftMemberId] = useState<string>('1');
  const [selectedShiftTime, setSelectedShiftTime] = useState<string>('General Shift (9 AM - 6 PM)');
  const [selectedShiftDay, setSelectedShiftDay] = useState<string>('Mon');

  // States for Manual Add Attendance Form
  const [selectedAttendanceMemberId, setSelectedAttendanceMemberId] = useState<string>('1');
  const [selectedAttendanceStatus, setSelectedAttendanceStatus] = useState<'Present' | 'Late' | 'Absent'>('Present');
  const [attendanceTimeInput, setAttendanceTimeInput] = useState<string>('09:15 AM');

  // Mock logs list for Attendance Log
  const [attendanceLogs, setAttendanceLogs] = useState([
    { id: '1', name: 'Arjun Mehta', time: '09:05 AM', type: 'Present', logTime: 'Today, 09:05 AM' },
    { id: '2', name: 'Priya Sharma', time: '09:12 AM', type: 'Present', logTime: 'Today, 09:12 AM' },
    { id: '3', name: 'Rohan Verma', time: '10:15 AM', type: 'Late', logTime: 'Today, 10:15 AM' },
    { id: '4', name: 'Meera Sen', time: '09:20 AM', type: 'Present', logTime: 'Today, 09:20 AM' },
    { id: '5', name: 'Aditya Goel', time: '-', type: 'Absent', logTime: 'Today, 11:30 AM (Auto-Marked)' },
  ]);

  useEffect(() => {
    if (params.action === 'addAttendance') {
      setIsAddAttendanceVisible(true);
      router.setParams({ action: '' });
    }
  }, [params.action]);

  // Counts based on actual states
  const totalEmployees = teamMembers.length;
  const presentToday = teamMembers.filter((m) => m.status === 'Present').length;
  const lateToday = teamMembers.filter((m) => m.status === 'Late').length;
  const absentToday = teamMembers.filter((m) => m.status === 'Absent').length;

  // Filtered members list based on query
  const filteredMembers = teamMembers.filter((m) =>
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddEmployee = () => {
    if (!newEmployeeName.trim() || !newEmployeeRole.trim()) {
      showAlert({ type: 'error', title: 'Error', message: 'Please fill in all details.' });
      return;
    }

    const newMember: TeamMember = {
      id: Date.now().toString(),
      name: newEmployeeName.trim(),
      role: newEmployeeRole.trim(),
      status: newEmployeeStatus,
      gender: newEmployeeGender,
    };

    setTeamMembers([newMember, ...teamMembers]);
    setNewEmployeeName('');
    setNewEmployeeRole('');
    setIsAddModalVisible(false);
    showAlert({ type: 'success', title: 'Success ✅', message: `${newMember.name} has been added to the team list.` });
  };

  const handleAssignShift = () => {
    const member = teamMembers.find((m) => m.id === selectedShiftMemberId);
    if (!member) return;
    showAlert({
      type: 'success',
      title: 'Shift Assigned ✅',
      message: `Successfully assigned ${selectedShiftTime} to ${member.name} for ${selectedShiftDay}.`
    });
    setIsAssignShiftVisible(false);
  };

  const handleManualAddAttendance = () => {
    const member = teamMembers.find((m) => m.id === selectedAttendanceMemberId);
    if (!member) return;

    // Update status in the teamMembers list state
    updateMemberStatus(selectedAttendanceMemberId, selectedAttendanceStatus);

    // Append to logs list
    const newLog = {
      id: Date.now().toString(),
      name: member.name,
      time: selectedAttendanceStatus === 'Absent' ? '-' : attendanceTimeInput,
      type: selectedAttendanceStatus,
      logTime: `Today, ${attendanceTimeInput}`,
    };
    setAttendanceLogs([newLog, ...attendanceLogs]);

    showAlert({
      type: 'success',
      title: 'Attendance Logged ✅',
      message: `Attendance status "${selectedAttendanceStatus}" logged for ${member.name}.`
    });
    setIsAddAttendanceVisible(false);
  };

  const handleMemberMenuPress = (member: TeamMember) => {
    showAlert({
      type: 'info',
      title: member.name,
      message: `Designation: ${member.role}\nStatus Today: ${member.status}`,
      primaryButtonText: 'Update Status',
      secondaryButtonText: 'Cancel',
      onPrimaryPress: () => {
        setSelectedAttendanceMemberId(member.id);
        setIsAddAttendanceVisible(true);
      },
    });
  };

  const updateMemberStatus = (id: string, status: 'Present' | 'Late' | 'Absent') => {
    setTeamMembers(teamMembers.map(m => m.id === id ? { ...m, status } : m));
  };

  return (
    <View style={styles.container}>
      <Tabs.Screen options={{ headerShown: false }} />

      <PageHeader title="My Team" subtitle="Team Member Status" />

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* 🔍 SEARCH AND FILTER BAR */}
        <View style={styles.searchBarWrapper}>
          <View style={styles.searchContainer}>
            <Ionicons name="search" size={18} color="#828282" style={{ marginRight: 8 }} />
            <TextInput
              style={styles.searchInput}
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search by name or role"
              placeholderTextColor="#828282"
            />
          </View>
          <TouchableOpacity style={styles.filterButton}>
            <Ionicons name="options-outline" size={18} color="#6E4B8D" />
          </TouchableOpacity>
        </View>

        {/* 📊 HORIZONTAL STATISTICS GRID */}
        <View style={styles.statsContainer}>
          <View style={styles.statsCard}>
            <View style={[styles.statsIconBox, { backgroundColor: '#F3EFFF' }]}>
              <Ionicons name="people" size={16} color="#6E4B8D" />
            </View>
            <Text style={styles.statsNumber}>{totalEmployees}</Text>
            <Text style={styles.statsLabel}>Total</Text>
            <Text style={styles.statsLabel}>Employee</Text>
          </View>

          <View style={styles.statsCard}>
            <View style={[styles.statsIconBox, { backgroundColor: '#E8F9EE' }]}>
              <Ionicons name="checkmark-circle" size={16} color="#28C76F" />
            </View>
            <Text style={[styles.statsNumber, { color: '#28C76F' }]}>{presentToday}</Text>
            <Text style={styles.statsLabel}>Present</Text>
            <Text style={styles.statsLabel}>Today</Text>
          </View>

          <View style={styles.statsCard}>
            <View style={[styles.statsIconBox, { backgroundColor: '#FFF5EC' }]}>
              <Ionicons name="time" size={16} color="#FF9F43" />
            </View>
            <Text style={[styles.statsNumber, { color: '#FF9F43' }]}>{lateToday}</Text>
            <Text style={styles.statsLabel}>Late</Text>
            <Text style={styles.statsLabel}>Today</Text>
          </View>

          <View style={styles.statsCard}>
            <View style={[styles.statsIconBox, { backgroundColor: '#FFF1F1' }]}>
              <Ionicons name="alert-circle" size={16} color="#EA5455" />
            </View>
            <Text style={[styles.statsNumber, { color: '#EA5455' }]}>{absentToday}</Text>
            <Text style={styles.statsLabel}>Absent</Text>
            <Text style={styles.statsLabel}>Today</Text>
          </View>
        </View>

        {/* 👥 TEAM MEMBERS LIST SECTION */}
        <View style={styles.sectionHeaderRow}>
          <Text style={styles.sectionTitle}>Team Members</Text>
          <TouchableOpacity style={styles.viewMoreButton}>
            <Text style={styles.viewMoreText}>View More</Text>
            <Ionicons name="chevron-forward" size={12} color="#6E4B8D" style={{ marginLeft: 2 }} />
          </TouchableOpacity>
        </View>

        <View style={styles.membersListContainer}>
          {filteredMembers.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>No team members match your query.</Text>
            </View>
          ) : (
            filteredMembers.map((member) => (
              <View key={member.id} style={styles.memberCard}>
                <View style={styles.memberAvatarWrapper}>
                  <View style={[styles.avatarCircle, { backgroundColor: member.gender === 'female' ? '#F6EDFF' : '#E8F5FF' }]}>
                    <FontAwesome5
                      name={member.gender === 'female' ? 'user-ninja' : 'user-tie'}
                      size={18}
                      color={member.gender === 'female' ? '#aa80cf' : '#6E4B8D'}
                    />
                  </View>
                </View>
                <View style={styles.memberInfo}>
                  <Text style={styles.memberName}>{member.name}</Text>
                  <Text style={styles.memberRole}>{member.role}</Text>
                </View>
                <View style={styles.memberRightSection}>
                  <View
                    style={[
                      styles.statusBadge,
                      member.status === 'Present' && styles.presentBadge,
                      member.status === 'Late' && styles.lateBadge,
                      member.status === 'Absent' && styles.absentBadge,
                    ]}
                  >
                    <View
                      style={[
                        styles.statusDot,
                        member.status === 'Present' && { backgroundColor: '#28C76F' },
                        member.status === 'Late' && { backgroundColor: '#FF9F43' },
                        member.status === 'Absent' && { backgroundColor: '#EA5455' },
                      ]}
                    />
                    <Text
                      style={[
                        styles.statusText,
                        member.status === 'Present' && { color: '#28C76F' },
                        member.status === 'Late' && { color: '#FF9F43' },
                        member.status === 'Absent' && { color: '#EA5455' },
                      ]}
                    >
                      {member.status}
                    </Text>
                  </View>
                  <TouchableOpacity style={styles.dotsButton} onPress={() => handleMemberMenuPress(member)}>
                    <MaterialCommunityIcons name="dots-vertical" size={20} color="#828282" />
                  </TouchableOpacity>
                </View>
              </View>
            ))
          )}
        </View>

        {/* 🛠️ QUICK ACTIONS TILES (HR / MANAGER MODE ONLY) */}
        <View style={styles.quickActionsWrapper}>
          <View style={styles.quickActionsCard}>
            <TouchableOpacity style={styles.actionTile} onPress={() => setIsAssignShiftVisible(true)}>
              <View style={[styles.actionIconCircle, { backgroundColor: '#F3EFFF' }]}>
                <MaterialCommunityIcons name="calendar-clock" size={20} color="#6E4B8D" />
              </View>
              <Text style={styles.actionTileLabel}>Assign</Text>
              <Text style={styles.actionTileLabel}>Shift</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.actionTile} onPress={() => setIsAddAttendanceVisible(true)}>
              <View style={[styles.actionIconCircle, { backgroundColor: '#F3EFFF' }]}>
                <MaterialCommunityIcons name="account-plus-outline" size={20} color="#6E4B8D" />
              </View>
              <Text style={styles.actionTileLabel}>Add</Text>
              <Text style={styles.actionTileLabel}>Attendance</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.actionTile} onPress={() => setIsAttendanceLogVisible(true)}>
              <View style={[styles.actionIconCircle, { backgroundColor: '#F3EFFF' }]}>
                <MaterialCommunityIcons name="file-document-outline" size={20} color="#6E4B8D" />
              </View>
              <Text style={styles.actionTileLabel}>Attendance</Text>
              <Text style={styles.actionTileLabel}>Log</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.actionTile} onPress={() => setIsTeamReportVisible(true)}>
              <View style={[styles.actionIconCircle, { backgroundColor: '#F3EFFF' }]}>
                <MaterialCommunityIcons name="chart-bar" size={20} color="#6E4B8D" />
              </View>
              <Text style={styles.actionTileLabel}>Team</Text>
              <Text style={styles.actionTileLabel}>Report</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      {/* ➕ FLOATING ACTION BUTTON (MANAGER MODE ONLY) */}
      <TouchableOpacity style={styles.floatingActionButton} onPress={() => setIsAddModalVisible(true)}>
        <Ionicons name="person-add" size={22} color="#FFFFFF" />
      </TouchableOpacity>

      {/* ========================================================
         ================ ADD MEMBER MODAL ======================
         ======================================================== */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={isAddModalVisible}
        onRequestClose={() => setIsAddModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Team Member</Text>
              <TouchableOpacity onPress={() => setIsAddModalVisible(false)}>
                <Ionicons name="close" size={24} color="#29185c" />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <Text style={styles.inputLabel}>Full Name</Text>
              <TextInput
                style={styles.modalTextInput}
                value={newEmployeeName}
                onChangeText={setNewEmployeeName}
                placeholder="e.g. Rohan Sharma"
                placeholderTextColor="#A0A0A0"
              />

              <Text style={[styles.inputLabel, { marginTop: 12 }]}>Role / Designation</Text>
              <TextInput
                style={styles.modalTextInput}
                value={newEmployeeRole}
                onChangeText={setNewEmployeeRole}
                placeholder="e.g. Field Executive"
                placeholderTextColor="#A0A0A0"
              />

              <Text style={[styles.inputLabel, { marginTop: 12 }]}>Gender Profile</Text>
              <View style={styles.genderTabs}>
                <TouchableOpacity
                  style={[styles.genderTab, newEmployeeGender === 'male' && styles.activeGenderTab]}
                  onPress={() => setNewEmployeeGender('male')}
                >
                  <Text style={[styles.genderTabText, newEmployeeGender === 'male' && styles.activeGenderTabText]}>Male</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.genderTab, newEmployeeGender === 'female' && styles.activeGenderTab]}
                  onPress={() => setNewEmployeeGender('female')}
                >
                  <Text style={[styles.genderTabText, newEmployeeGender === 'female' && styles.activeGenderTabText]}>Female</Text>
                </TouchableOpacity>
              </View>

              <Text style={[styles.inputLabel, { marginTop: 12 }]}>Initial Status Today</Text>
              <View style={styles.statusSelectors}>
                {(['Present', 'Late', 'Absent'] as const).map((status) => (
                  <TouchableOpacity
                    key={`modal-status-${status}`}
                    style={[
                      styles.statusPillBtn,
                      newEmployeeStatus === status && {
                        backgroundColor:
                          status === 'Present'
                            ? 'rgba(40, 199, 111, 0.15)'
                            : status === 'Late'
                            ? 'rgba(255, 159, 67, 0.15)'
                            : 'rgba(234, 84, 85, 0.15)',
                        borderColor: status === 'Present' ? '#28C76F' : status === 'Late' ? '#FF9F43' : '#EA5455',
                      },
                    ]}
                    onPress={() => setNewEmployeeStatus(status)}
                  >
                    <Text
                      style={[
                        styles.statusPillBtnText,
                        newEmployeeStatus === status && {
                          color: status === 'Present' ? '#28C76F' : status === 'Late' ? '#FF9F43' : '#EA5455',
                          fontWeight: '700',
                        },
                      ]}
                    >
                      {status}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={() => setIsAddModalVisible(false)}
              >
                <Text style={styles.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalConfirmButton} onPress={handleAddEmployee}>
                <Text style={styles.modalConfirmText}>Add Member</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* ========================================================
         ================ ASSIGN SHIFT MODAL ====================
         ======================================================== */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={isAssignShiftVisible}
        onRequestClose={() => setIsAssignShiftVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Assign Shift</Text>
              <TouchableOpacity onPress={() => setIsAssignShiftVisible(false)}>
                <Ionicons name="close" size={24} color="#29185c" />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <Text style={styles.inputLabel}>Select Employee</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
                {teamMembers.map((m) => (
                  <TouchableOpacity
                    key={`shift-member-${m.id}`}
                    style={[
                      styles.avatarPill,
                      selectedShiftMemberId === m.id && styles.activeAvatarPill,
                    ]}
                    onPress={() => setSelectedShiftMemberId(m.id)}
                  >
                    <Text style={[styles.avatarPillText, selectedShiftMemberId === m.id && styles.activeAvatarPillText]}>
                      {m.name}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              <Text style={styles.inputLabel}>Shift Timing</Text>
              <View style={styles.verticalPillGroup}>
                {[
                  'Morning Shift (6 AM - 2 PM)',
                  'General Shift (9 AM - 6 PM)',
                  'Evening Shift (2 PM - 10 PM)',
                  'Night Shift (10 PM - 6 AM)',
                ].map((s) => (
                  <TouchableOpacity
                    key={`shift-time-${s}`}
                    style={[
                      styles.verticalPill,
                      selectedShiftTime === s && styles.activeVerticalPill,
                    ]}
                    onPress={() => setSelectedShiftTime(s)}
                  >
                    <Text style={[styles.verticalPillText, selectedShiftTime === s && styles.activeVerticalPillText]}>
                      {s}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={[styles.inputLabel, { marginTop: 12 }]}>Day</Text>
              <View style={styles.daysContainer}>
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map((day) => (
                  <TouchableOpacity
                    key={`shift-day-${day}`}
                    style={[
                      styles.dayCircle,
                      selectedShiftDay === day && styles.activeDayCircle,
                    ]}
                    onPress={() => setSelectedShiftDay(day)}
                  >
                    <Text style={[styles.dayCircleText, selectedShiftDay === day && styles.activeDayCircleText]}>
                      {day[0]}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={() => setIsAssignShiftVisible(false)}
              >
                <Text style={styles.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalConfirmButton} onPress={handleAssignShift}>
                <Text style={styles.modalConfirmText}>Assign Shift</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* ========================================================
         ================ ADD ATTENDANCE MODAL ==================
         ======================================================== */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={isAddAttendanceVisible}
        onRequestClose={() => setIsAddAttendanceVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Attendance</Text>
              <TouchableOpacity onPress={() => setIsAddAttendanceVisible(false)}>
                <Ionicons name="close" size={24} color="#29185c" />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <Text style={styles.inputLabel}>Select Employee</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
                {teamMembers.map((m) => (
                  <TouchableOpacity
                    key={`attendance-member-${m.id}`}
                    style={[
                      styles.avatarPill,
                      selectedAttendanceMemberId === m.id && styles.activeAvatarPill,
                    ]}
                    onPress={() => setSelectedAttendanceMemberId(m.id)}
                  >
                    <Text style={[styles.avatarPillText, selectedAttendanceMemberId === m.id && styles.activeAvatarPillText]}>
                      {m.name}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              <Text style={styles.inputLabel}>Attendance Status</Text>
              <View style={styles.statusSelectors}>
                {(['Present', 'Late', 'Absent'] as const).map((status) => (
                  <TouchableOpacity
                    key={`manual-status-${status}`}
                    style={[
                      styles.statusPillBtn,
                      selectedAttendanceStatus === status && {
                        backgroundColor:
                          status === 'Present'
                            ? 'rgba(40, 199, 111, 0.15)'
                            : status === 'Late'
                            ? 'rgba(255, 159, 67, 0.15)'
                            : 'rgba(234, 84, 85, 0.15)',
                        borderColor: status === 'Present' ? '#28C76F' : status === 'Late' ? '#FF9F43' : '#EA5455',
                      },
                    ]}
                    onPress={() => setSelectedAttendanceStatus(status)}
                  >
                    <Text
                      style={[
                        styles.statusPillBtnText,
                        selectedAttendanceStatus === status && {
                          color: status === 'Present' ? '#28C76F' : status === 'Late' ? '#FF9F43' : '#EA5455',
                          fontWeight: '700',
                        },
                      ]}
                    >
                      {status}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {selectedAttendanceStatus !== 'Absent' && (
                <>
                  <Text style={[styles.inputLabel, { marginTop: 12 }]}>Time (HH:MM AM/PM)</Text>
                  <TextInput
                    style={styles.modalTextInput}
                    value={attendanceTimeInput}
                    onChangeText={setAttendanceTimeInput}
                    placeholder="e.g. 09:15 AM"
                    placeholderTextColor="#A0A0A0"
                  />
                </>
              )}
            </View>
            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={() => setIsAddAttendanceVisible(false)}
              >
                <Text style={styles.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalConfirmButton} onPress={handleManualAddAttendance}>
                <Text style={styles.modalConfirmText}>Log Attendance</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* ========================================================
         ================ ATTENDANCE LOG MODAL ==================
         ======================================================== */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={isAttendanceLogVisible}
        onRequestClose={() => setIsAttendanceLogVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Attendance Log</Text>
              <TouchableOpacity onPress={() => setIsAttendanceLogVisible(false)}>
                <Ionicons name="close" size={24} color="#29185c" />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <Text style={styles.inputLabel}>Today's Activity Log</Text>
              <ScrollView style={{ maxHeight: 250 }} showsVerticalScrollIndicator={false}>
                {attendanceLogs.map((log) => (
                  <View key={`log-item-${log.id}`} style={styles.logCard}>
                    <View style={styles.logTextWrapper}>
                      <Text style={styles.logTitle}>{log.name}</Text>
                      <Text style={styles.logSubText}>{log.logTime}</Text>
                    </View>
                    <View
                      style={[
                        styles.statusBadgeTextOnly,
                        log.type === 'Present' && styles.presentBadgeText,
                        log.type === 'Late' && styles.lateBadgeText,
                        log.type === 'Absent' && styles.absentBadgeText,
                      ]}
                    >
                      <Text style={styles.logStatusLabel}>{log.type} {log.time !== '-' ? `(${log.time})` : ''}</Text>
                    </View>
                  </View>
                ))}
              </ScrollView>
            </View>
            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={styles.modalConfirmButton}
                onPress={() => setIsAttendanceLogVisible(false)}
              >
                <Text style={styles.modalConfirmText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* ========================================================
         ================ TEAM REPORT MODAL =====================
         ======================================================== */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={isTeamReportVisible}
        onRequestClose={() => setIsTeamReportVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Team Report</Text>
              <TouchableOpacity onPress={() => setIsTeamReportVisible(false)}>
                <Ionicons name="close" size={24} color="#29185c" />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              {/* Analytics Header Card */}
              <View style={styles.reportSummaryCard}>
                <View style={styles.reportSummaryCol}>
                  <Text style={styles.reportStatVal}>
                    {totalEmployees > 0 ? `${Math.round(((presentToday + lateToday) / totalEmployees) * 100)}%` : '0%'}
                  </Text>
                  <Text style={styles.reportStatLabel}>Attendance Rate</Text>
                </View>
                <View style={styles.reportSummaryDivider} />
                <View style={styles.reportSummaryCol}>
                  <Text style={[styles.reportStatVal, { color: '#FF9F43' }]}>
                    {totalEmployees > 0 ? `${Math.round((lateToday / totalEmployees) * 100)}%` : '0%'}
                  </Text>
                  <Text style={styles.reportStatLabel}>Late Rate</Text>
                </View>
              </View>

              {/* Progress bars ratios */}
              <Text style={styles.inputLabel}>Breakdown of Today</Text>

              {/* Present Ratio */}
              <View style={styles.reportRatioRow}>
                <Text style={styles.ratioLabel}>Present ({presentToday})</Text>
                <View style={styles.ratioBarContainer}>
                  <View style={[styles.ratioBarFill, { backgroundColor: '#28C76F', width: `${totalEmployees > 0 ? (presentToday / totalEmployees) * 100 : 0}%` }]} />
                </View>
              </View>

              {/* Late Ratio */}
              <View style={styles.reportRatioRow}>
                <Text style={styles.ratioLabel}>Late ({lateToday})</Text>
                <View style={styles.ratioBarContainer}>
                  <View style={[styles.ratioBarFill, { backgroundColor: '#FF9F43', width: `${totalEmployees > 0 ? (lateToday / totalEmployees) * 100 : 0}%` }]} />
                </View>
              </View>

              {/* Absent Ratio */}
              <View style={styles.reportRatioRow}>
                <Text style={styles.ratioLabel}>Absent ({absentToday})</Text>
                <View style={styles.ratioBarContainer}>
                  <View style={[styles.ratioBarFill, { backgroundColor: '#EA5455', width: `${totalEmployees > 0 ? (absentToday / totalEmployees) * 100 : 0}%` }]} />
                </View>
              </View>
            </View>
            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={styles.modalConfirmButton}
                onPress={() => setIsTeamReportVisible(false)}
              >
                <Text style={styles.modalConfirmText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3EDF7',
  },

  // Header styles
  headerContainer: {
    width: '100%',
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EBE5F5',
  },
  backButtonCircle: {
    width: 36,
    height: 36,
    backgroundColor: '#e7ddff',
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTextWrapper: {
    flex: 1,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: T.purpleDark,
  },
  bellIconWrapper: {
    width: 36,
    height: 36,
    backgroundColor: '#e7ddff',
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  bellDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: '#6E4B8D',
    position: 'absolute',
    top: 6,
    right: 8,
    borderWidth: 1,
    borderColor: '#FFFFFF',
  },

  // Scroll Container
  scrollContent: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 100, // Account for FAB
  },

  // Search Bar
  searchBarWrapper: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 16,
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 44,
    borderWidth: 1,
    borderColor: '#EBE5F5',
    shadowColor: '#6E4B8D',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.03,
    shadowRadius: 4,
    elevation: 1,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: T.purpleDark,
    height: '100%',
  },
  filterButton: {
    width: 44,
    height: 44,
    backgroundColor: '#F3EFFF',
    borderWidth: 1,
    borderColor: '#EBE5F5',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // Stats Dashboard
  statsContainer: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 20,
  },
  statsCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 10,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#EBE5F5',
    shadowColor: '#6E4B8D',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 2,
  },
  statsIconBox: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
  },
  statsNumber: {
    fontSize: 15,
    fontWeight: '700',
    color: T.purpleDark,
  },
  statsLabel: {
    fontSize: 9,
    color: '#828282',
    lineHeight: 11,
    textAlign: 'center',
  },

  // Section Headers
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: T.purpleDark,
  },
  viewMoreButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  viewMoreText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6E4B8D',
  },

  // Team list
  membersListContainer: {
    gap: 10,
    marginBottom: 20,
  },
  emptyContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#EBE5F5',
  },
  emptyText: {
    fontSize: 13,
    color: '#828282',
  },
  memberCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 12,
    borderWidth: 1,
    borderColor: '#EBE5F5',
    shadowColor: '#6E4B8D',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.03,
    shadowRadius: 6,
    elevation: 1,
  },
  memberAvatarWrapper: {
    marginRight: 12,
  },
  avatarCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#EBE5F5',
  },
  memberInfo: {
    flex: 1,
  },
  memberName: {
    fontSize: 14,
    fontWeight: '700',
    color: T.purpleDark,
  },
  memberRole: {
    fontSize: 11,
    color: '#828282',
    marginTop: 2,
  },
  memberRightSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 0.5,
  },
  presentBadge: {
    backgroundColor: '#E8F9EE',
    borderColor: 'rgba(40, 199, 111, 0.2)',
  },
  lateBadge: {
    backgroundColor: '#FFF5EC',
    borderColor: 'rgba(255, 159, 67, 0.2)',
  },
  absentBadge: {
    backgroundColor: '#FFF1F1',
    borderColor: 'rgba(234, 84, 85, 0.2)',
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 5,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
  },
  dotsButton: {
    padding: 4,
  },

  // Quick Action Panel grid
  quickActionsWrapper: {
    marginTop: 8,
  },
  quickActionsCard: {
    flexDirection: 'row',
    backgroundColor: '#F3EFFF',
    borderRadius: 16,
    padding: 16,
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: '#E7DDFF',
  },
  actionTile: {
    flex: 1,
    alignItems: 'center',
  },
  actionIconCircle: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
    shadowColor: '#6E4B8D',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  actionTileLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: T.purpleDark,
    textAlign: 'center',
    lineHeight: 13,
  },

  // FAB button
  floatingActionButton: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: '#29185c',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    right: 20,
    bottom: Platform.OS === 'ios' ? 40 : 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 5,
    zIndex: 10,
  },

  // Modal Custom Styling
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(41, 24, 92, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    width: '100%',
    maxWidth: 340,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 10,
    elevation: 5,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#F3EFFF',
    paddingBottom: 10,
    marginBottom: 14,
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: T.purpleDark,
  },
  modalBody: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: '#828282',
    marginBottom: 6,
  },
  modalTextInput: {
    backgroundColor: '#F9F8FF',
    borderWidth: 1,
    borderColor: '#EBE5F5',
    borderRadius: 8,
    height: 40,
    paddingHorizontal: 10,
    fontSize: 14,
    color: T.purpleDark,
  },
  genderTabs: {
    flexDirection: 'row',
    gap: 8,
  },
  genderTab: {
    flex: 1,
    height: 36,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#EBE5F5',
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  activeGenderTab: {
    backgroundColor: '#caa6ec',
    borderColor: '#caa6ec',
  },
  genderTabText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6E4B8D',
  },
  activeGenderTabText: {
    color: T.purpleDark,
    fontWeight: '700',
  },
  statusSelectors: {
    flexDirection: 'row',
    gap: 8,
  },
  statusPillBtn: {
    flex: 1,
    height: 36,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#EBE5F5',
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  statusPillBtnText: {
    fontSize: 12,
    color: '#828282',
    fontWeight: '600',
  },
  modalFooter: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 10,
  },
  modalCancelButton: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 8,
  },
  modalCancelText: {
    fontSize: 13,
    color: '#828282',
    fontWeight: '600',
  },
  modalConfirmButton: {
    backgroundColor: '#6E4B8D',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  modalConfirmText: {
    fontSize: 13,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  avatarPill: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: '#F3EFFF',
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#EBE5F5',
  },
  activeAvatarPill: {
    backgroundColor: '#6E4B8D',
    borderColor: '#6E4B8D',
  },
  avatarPillText: {
    fontSize: 12,
    color: '#6E4B8D',
    fontWeight: '600',
  },
  activeAvatarPillText: {
    color: '#FFFFFF',
  },
  verticalPillGroup: {
    gap: 8,
    marginBottom: 12,
  },
  verticalPill: {
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 8,
    backgroundColor: '#F9F8FF',
    borderWidth: 1,
    borderColor: '#EBE5F5',
  },
  activeVerticalPill: {
    backgroundColor: '#6E4B8D',
    borderColor: '#6E4B8D',
  },
  verticalPillText: {
    fontSize: 13,
    color: T.purpleDark,
  },
  activeVerticalPillText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  daysContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  dayCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#F9F8FF',
    borderWidth: 1,
    borderColor: '#EBE5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  activeDayCircle: {
    backgroundColor: '#caa6ec',
    borderColor: '#caa6ec',
  },
  dayCircleText: {
    fontSize: 13,
    color: '#6E4B8D',
    fontWeight: '600',
  },
  activeDayCircleText: {
    color: T.purpleDark,
    fontWeight: '700',
  },
  logCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F3EFFF',
  },
  logTextWrapper: {
    flex: 1,
  },
  logTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: T.purpleDark,
  },
  logSubText: {
    fontSize: 10,
    color: '#828282',
    marginTop: 2,
  },
  statusBadgeTextOnly: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  presentBadgeText: {
    backgroundColor: '#E8F9EE',
  },
  lateBadgeText: {
    backgroundColor: '#FFF5EC',
  },
  absentBadgeText: {
    backgroundColor: '#FFF1F1',
  },
  logStatusLabel: {
    fontSize: 11,
    fontWeight: '600',
  },
  reportSummaryCard: {
    flexDirection: 'row',
    backgroundColor: '#F3EFFF',
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#E7DDFF',
  },
  reportSummaryCol: {
    flex: 1,
    alignItems: 'center',
  },
  reportStatVal: {
    fontSize: 20,
    fontWeight: '800',
    color: '#28C76F',
  },
  reportStatLabel: {
    fontSize: 10,
    color: '#6E4B8D',
    marginTop: 2,
    fontWeight: '600',
  },
  reportSummaryDivider: {
    width: 1,
    backgroundColor: '#caa6ec',
    marginVertical: 4,
  },
  reportRatioRow: {
    marginBottom: 12,
  },
  ratioLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: T.purpleDark,
    marginBottom: 4,
  },
  ratioBarContainer: {
    height: 8,
    backgroundColor: '#F3EFFF',
    borderRadius: 4,
    width: '100%',
    overflow: 'hidden',
  },
  ratioBarFill: {
    height: '100%',
    borderRadius: 4,
  },
});
