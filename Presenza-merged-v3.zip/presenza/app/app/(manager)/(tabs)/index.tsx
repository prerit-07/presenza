import ManagerDashboard from "@/components/dashboards/ManagerDashboard";

export default function ManagerHomeScreen() {
  return <ManagerDashboard userName="Manager" />;
}
