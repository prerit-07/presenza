import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  FlatList,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAppStore } from '@/store/useAppStore';
import { Theme } from '@/constants/theme';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { PageHeader } from '@/components/PageHeader';
import { Calendar } from '@/components/Calendar';
import { AttendanceCard } from '@/components/AttendanceCard';
import { SectionTitle } from '@/components/SectionTitle';
import { Card } from '@/components/Card';
import { Toast } from '@/components/Toast';

export default function AttendanceScreen() {
  const attendanceRecords = useAppStore((state) => state.attendanceRecords);
  const [toast, setToast] = useState<{ visible: boolean; message: string; type: 'success' | 'error' | 'info' }>({
    visible: false,
    message: '',
    type: 'info',
  });

  // Filter out records for the active calendar view highlight (days 3 and 4)
  const highlightedDays = attendanceRecords
    .map((rec) => new Date(rec.date).getDate());

  const handleNotificationPress = () => {
    setToast({
      visible: true,
      message: 'You have no new notifications.',
      type: 'info',
    });
  };

  const handleDaySelect = (day: number) => {
    // Show quick toast details when selecting a day
    const record = attendanceRecords.find(
      (rec) => new Date(rec.date).getDate() === day
    );

    if (record) {
      setToast({
        visible: true,
        message: `${record.dayName}, June ${day}: Checked In at ${record.checkIn}, Status: ${record.status}`,
        type: 'success',
      });
    } else {
      setToast({
        visible: true,
        message: `June ${day}, 2026: No attendance record found for this date.`,
        type: 'info',
      });
    }
  };

  return (
    <View style={styles.safeArea}>
      <Toast
        visible={toast.visible}
        message={toast.message}
        type={toast.type}
        onDismiss={() => setToast({ ...toast, visible: false })}
      />
      
      {/* Header */}
      <PageHeader 
        title="Team Attendance" 
        subtitle="Daily check-in records" 
      />

      <ScrollView contentContainerStyle={styles.scrollContent} bounces={false}>
        {/* Month Calendar Component */}
        <Calendar
          selectedDays={highlightedDays}
          onDaySelect={handleDaySelect}
        />

        {/* This Week Section */}
        <SectionTitle title="This Week" />
        {attendanceRecords.length > 0 ? (
          attendanceRecords.map((item) => (
            <AttendanceCard key={item.id} record={item} />
          ))
        ) : (
          <Text style={styles.emptyText}>No logs found for this week</Text>
        )}

        {/* This Month Section */}
        <SectionTitle title="This Month" />
        <View style={styles.summaryContainer}>
          {/* Present Days Card */}
          <Card style={styles.summaryCard}>
            <View style={styles.summaryHeader}>
              <Ionicons name="checkmark-circle" size={18} color={Theme.colors.success} style={styles.summaryIcon} />
              <Text style={styles.summaryTitle}>Present</Text>
            </View>
            <View style={styles.presentBadge}>
              <Text style={styles.summaryValue}>
                {String(attendanceRecords.filter(r => r.status === 'ON TIME').length).padStart(2, '0')}
              </Text>
              <Text style={styles.summaryLabel}>days</Text>
            </View>
          </Card>

          {/* Attendance Percentage Card */}
          <Card style={styles.summaryCard}>
            <View style={styles.summaryHeader}>
              <Ionicons name="pie-chart-outline" size={18} color={Theme.colors.primary} style={styles.summaryIcon} />
              <Text style={styles.summaryTitle}>Attendance %</Text>
            </View>
            <View style={styles.percentageBadge}>
              <Text style={styles.summaryValue}>100%</Text>
            </View>
          </Card>
        </View>

        {/* Motivational Card */}
        <Card style={styles.motivationalCard}>
          <Text style={styles.partyIcon}>🎉</Text>
          <View style={styles.motivationalTextContainer}>
            <Text style={styles.motivationalTitle}>Keep it Up !!</Text>
            <Text style={styles.motivationalSubtitle}>
              Great job you have a perfect attendance this month.
            </Text>
          </View>
        </Card>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Theme.colors.background,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  emptyText: {
    fontSize: Theme.typography.sizes.sm,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Theme.colors.subText,
    textAlign: 'center',
    marginVertical: 12,
  },
  summaryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  summaryCard: {
    flex: 1,
    marginHorizontal: 5,
    padding: 14,
    alignItems: 'flex-start',
  },
  summaryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  summaryIcon: {
    marginRight: 6,
  },
  summaryTitle: {
    fontSize: 11,
    fontFamily: Theme.typography.fontFamily.semiBold,
    color: Theme.colors.subText,
  },
  presentBadge: {
    flexDirection: 'row',
    alignItems: 'baseline',
    backgroundColor: 'rgba(67, 196, 122, 0.08)',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  percentageBadge: {
    backgroundColor: '#F8F7FC',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: '#F0ECF7',
  },
  summaryValue: {
    fontSize: 18,
    fontFamily: Theme.typography.fontFamily.bold,
    color: T.purpleDark,
  },
  summaryLabel: {
    fontSize: 10,
    fontFamily: Theme.typography.fontFamily.regular,
    color: Theme.colors.subText,
    marginLeft: 4,
  },
  motivationalCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EAE6F4', // Matches purple card color in screenshot 4
    borderColor: '#DDD6F0',
    padding: 16,
    marginTop: 12,
  },
  partyIcon: {
    fontSize: 26,
    marginRight: 14,
  },
  motivationalTextContainer: {
    flex: 1,
  },
  motivationalTitle: {
    fontSize: Theme.typography.sizes.sm,
    fontFamily: Theme.typography.fontFamily.bold,
    color: Theme.colors.primary,
    marginBottom: 2,
  },
  motivationalSubtitle: {
    fontSize: 11,
    fontFamily: Theme.typography.fontFamily.medium,
    color: Theme.colors.subText,
    lineHeight: 16,
  },
});



