// app/(manager)/(tabs)/profile.tsx
// Role: All — shows user profile, settings, logout
// Opens from: Bottom nav "Profile" tab

import React from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  Pressable, Image, Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useAppStore } from '@/store/useAppStore';
import { logout as authLogout } from '@/services/auth.service';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { PageHeader } from '@/components/PageHeader';
import { useState } from 'react';
import { ThemedModal } from '@/components/ThemedModal';

type MenuItem = {
  icon: keyof typeof MaterialCommunityIcons.glyphMap;
  label: string;
  route?: string;
  action?: () => void;
  danger?: boolean;
};

export default function ProfileScreen() {
  const router = useRouter();
  const user = useAppStore((s) => s.user);
  const storeLogout = useAppStore((s) => s.logout);

  const [logoutModalVisible, setLogoutModalVisible] = useState(false);

  const handleLogout = () => {
    setLogoutModalVisible(true);
  };

  const MENU_ITEMS: MenuItem[] = [
    { icon: 'account-edit-outline', label: 'Edit Profile', route: '/edit-profile' },
    { icon: 'calendar-check-outline', label: 'Attendance History', route: '/attendance' },
    ...(user?.role === 'employee' ? ([
      { icon: 'airplane', label: 'Apply Leave', route: '/apply-leave' },
      { icon: 'cellphone-key', label: 'Device Change Request', route: '/device-request' },
    ] as MenuItem[]) : []),
    ...(user?.role === 'manager' || user?.role === 'admin' ? ([
      { icon: 'calendar-account-outline', label: 'Leave Approvals', route: '/leave-approvals' },
      { icon: 'cellphone-check', label: 'Device Approvals', route: '/device-approvals' },
    ] as MenuItem[]) : []),
    { icon: 'help-circle-outline', label: 'Help & Support', route: '/help-desk' },
    { icon: 'logout', label: 'Sign Out', action: handleLogout, danger: true },
  ];

  return (
    <View style={styles.root}>
      <PageHeader title="Profile" />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>

        {/* Avatar + Info */}
        <View style={styles.profileCard}>
          <Image
            source={{ uri: user?.avatar ?? `https://i.pravatar.cc/150?u=${user?.id}` }}
            style={styles.avatar}
          />
          <Text style={styles.name}>{user?.name ?? 'User'}</Text>
          <Text style={styles.email}>{user?.email ?? 'user@email.com'}</Text>
          <View style={styles.roleBadge}>
            <Text style={styles.roleText}>{user?.role === 'employee' ? 'Employee' : user?.role === 'manager' ? 'Manager' : 'Admin'}</Text>
          </View>
          <Text style={styles.designation}>{user?.designation ?? ''} {user?.department ? `• ${user.department}` : ''}</Text>
        </View>

        {/* Menu */}
        <View style={styles.menuCard}>
          {MENU_ITEMS.map((item, idx) => (
            <React.Fragment key={item.label}>
              <Pressable
                style={styles.menuItem}
                onPress={() => {
                  if (item.action) { item.action(); return; }
                  if (item.route) router.push(item.route as any);
                }}
              >
                <View style={[styles.menuIconWrap, item.danger && styles.menuIconDanger]}>
                  <MaterialCommunityIcons
                    name={item.icon as any}
                    size={20}
                    color={item.danger ? '#B23A48' : T.purpleIcon}
                  />
                </View>
                <Text style={[styles.menuLabel, item.danger && styles.menuLabelDanger]}>
                  {item.label}
                </Text>
                {!item.danger && (
                  <MaterialCommunityIcons name="chevron-right" size={18} color={T.textMuted} />
                )}
              </Pressable>
              {idx < MENU_ITEMS.length - 1 && <View style={styles.menuSep} />}
            </React.Fragment>
          ))}
        </View>

        <Text style={styles.version}>PRESENZA v1.0.0</Text>
        <View style={{ height: 100 }} />
      </ScrollView>

      <ThemedModal
        visible={logoutModalVisible}
        type="warning"
        title="Sign Out"
        message="Are you sure you want to sign out?"
        primaryButtonText="Sign Out"
        secondaryButtonText="Cancel"
        onPrimaryPress={async () => {
          setLogoutModalVisible(false);
          await authLogout();
          storeLogout();
          router.replace('/(auth)/sign-in');
        }}
        onSecondaryPress={() => setLogoutModalVisible(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F3EDF7' },
  scroll: { paddingHorizontal: 20 },
  headerTitle: { fontSize: 22, fontWeight: '700', color: T.purpleDark, paddingVertical: 16 },
  profileCard: {
    backgroundColor: '#FFF', borderRadius: 20, padding: 24,
    alignItems: 'center', marginBottom: 16,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06, shadowRadius: 10, elevation: 4,
  },
  avatar: {
    width: 88, height: 88, borderRadius: 44,
    borderWidth: 5, borderColor: T.purpleIcon, marginBottom: 12,
  },
  name: { fontSize: 20, fontWeight: '500', color: T.purpleMedium, marginBottom: 4 },
  roleBadge: {
    backgroundColor: T.purpleIcon, borderRadius: 8,
    paddingVertical: 6, paddingHorizontal: 14, marginBottom: 6,
  },
  roleText: { fontSize: 12, fontWeight: 'bold', color: '#FFF' },
  email: { fontSize: 13, color: T.textMuted, marginBottom: 12 },
  designation: { fontSize: 12, color: T.textMuted, marginTop: 4 },
  orgRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 },
  orgText: { fontSize: 12, color: T.textMuted },
  menuCard: {
    backgroundColor: '#FFF', borderRadius: 20, paddingVertical: 8,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04, shadowRadius: 6, elevation: 2,
  },
  menuItem: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    paddingVertical: 14, paddingHorizontal: 18,
  },
  menuIconWrap: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: T.purpleLight, justifyContent: 'center', alignItems: 'center',
  },
  menuIconDanger: { backgroundColor: '#FFF1F3' },
  menuLabel: { flex: 1, fontSize: 14, fontWeight: '600', color: T.purpleDark },
  menuLabelDanger: { color: '#B23A48' },
  menuSep: { height: 1, backgroundColor: '#F5F3F8', marginHorizontal: 18 },
  version: { fontSize: 11, color: T.textMuted, textAlign: 'center', marginTop: 20 },
});



