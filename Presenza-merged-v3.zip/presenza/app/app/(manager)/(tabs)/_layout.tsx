import React from "react";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import type { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import { Tabs, useRouter } from "expo-router";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { DashboardTheme as T } from "@/constants/dashboard-theme";

const TABS = [
  { name: "index", label: "Home", icon: "home-outline" },
  { name: "attendance", label: "Attendance", icon: "calendar-check-outline" },
  { name: "my-team", label: "Team", icon: "account-group-outline" },
  { name: "profile", label: "Profile", icon: "account-circle-outline" },
] as const;

function CustomTabBar({ state, navigation }: BottomTabBarProps) {
  const router = useRouter();
  const activeRouteName = state.routes[state.index]?.name;

  return (
    <View style={styles.wrapper}>
      <View style={styles.bar}>
        {TABS.map((tab) => {
          const route = state.routes.find((r) => r.name === tab.name);
          const isFocused = activeRouteName === tab.name;

          const onPress = () => {
            if (!route) return;

            const event = navigation.emit({
              type: "tabPress",
              target: route.key,
              canPreventDefault: true,
            });

            if (!isFocused && !event.defaultPrevented) {
              navigation.navigate(tab.name);
            }
          };

          return (
            <Pressable
              key={tab.name}
              onPress={onPress}
              style={[styles.tabItem, isFocused && styles.tabItemActive]}
            >
              <MaterialCommunityIcons
                name={tab.icon}
                size={20}
                color="#FFFFFF"
              />
              <Text
                style={[
                  styles.tabLabel,
                  { color: "#FFFFFF" },
                ]}
              >
                {tab.label}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

export default function ManagerTabsLayout() {
  return (
    <Tabs
      tabBar={(props) => <CustomTabBar {...props} />}
      screenOptions={{ headerShown: false }}
    >
      <Tabs.Screen name="index" />
      <Tabs.Screen name="attendance" />
      <Tabs.Screen name="my-team" />
      <Tabs.Screen name="inbox" />
      <Tabs.Screen name="profile" />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: "absolute",
    bottom: 24,
    left: 16,
    right: 16,
    alignItems: "center",
  },
  bar: {
    flexDirection: "row",
    backgroundColor: T.purpleIcon,
    borderRadius: 32,
    padding: 6,
    width: "100%",
    justifyContent: "space-between",
  },
  tabItem: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 10,
    paddingHorizontal: 4,
    borderRadius: 26,
  },
  tabItemActive: {
    backgroundColor: "rgba(255,255,255,0.15)",
  },
  tabLabel: {
    fontSize: 9,
    marginTop: 2,
    fontWeight: "600",
  },
});

