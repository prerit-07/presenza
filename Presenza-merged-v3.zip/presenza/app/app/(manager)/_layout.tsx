import { Stack } from "expo-router";

export default function ManagerLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="remote-checkin" />
      <Stack.Screen name="apply-leave" />
      <Stack.Screen name="apply-wfh" />
      <Stack.Screen name="ticket-details" />
    </Stack>
  );
}