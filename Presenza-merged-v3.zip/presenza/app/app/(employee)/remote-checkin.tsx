import React, {
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';

import {
  ActivityIndicator,
  Animated,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import MapView, {
  Marker,
} from 'react-native-maps';

import {
  useRouter,
} from 'expo-router';

import {
  Feather,
  Ionicons,
  MaterialCommunityIcons,
} from '@expo/vector-icons';

import * as Location from 'expo-location';

import {
  useSafeAreaInsets,
} from 'react-native-safe-area-context';

import {
  getMyEmployee,
  type Employee,
} from '@/services/employee.service';

import {
  getStableDeviceId,
  ensureCurrentDeviceRegistered,
  isDeviceNotFoundError,
} from '@/services/device.service';

import {
  checkIn,
  type CheckInResponse,
} from '@/services/checkin.service';

import { useThemedAlert } from '@/components/ThemedAlertProvider';

type ScreenStep =
  | 'landing'
  | 'map';

type CheckInPhase =
  | 'idle'
  | 'preparing'
  | 'submitting'
  | 'success';

function CheckInLanding({
  onStart,
}: {
  onStart: () => void;
}) {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const steps = [
    {
      icon: 'location-outline' as const,
      title: 'GPS Location',
      desc: 'Captures your current location',
    },
    {
      icon: 'phone-portrait-outline' as const,
      title: 'Registered Device',
      desc: 'Verifies your bound device',
    },
    {
      icon: 'calendar-outline' as const,
      title: 'Record Attendance',
      desc: 'Backend validates shift and geofence',
    },
  ];

  return (
    <View
      style={[
        landing.container,
        {
          paddingTop: insets.top,
        },
      ]}
    >
      <TouchableOpacity
        style={landing.backBtn}
        onPress={() => router.back()}
      >
        <Ionicons
          name="chevron-back"
          size={20}
          color="#5B3D7A"
        />
      </TouchableOpacity>

      <View style={landing.heroSection}>
        <View style={landing.heroBadge}>
          <Ionicons
            name="checkmark-circle"
            size={38}
            color="#6B4E8D"
          />
        </View>

        <Text style={landing.heroTitle}>
          Check In
        </Text>

        <Text style={landing.heroSubtitle}>
          Your attendance will be validated
          using{'\n'}
          your assigned shift, device and GPS.
        </Text>
      </View>

      <View style={landing.stepsCard}>
        {steps.map((step, index) => (
          <View
            key={step.title}
            style={[
              landing.stepRow,
              index < steps.length - 1 &&
                landing.stepRowBorder,
            ]}
          >
            <View style={landing.stepIconWrap}>
              <Ionicons
                name={step.icon}
                size={20}
                color="#6B4E8D"
              />
            </View>

            <View style={landing.stepText}>
              <Text style={landing.stepTitle}>
                {step.title}
              </Text>

              <Text style={landing.stepDesc}>
                {step.desc}
              </Text>
            </View>

            <View style={landing.stepCircle} />
          </View>
        ))}
      </View>

      <TouchableOpacity
        style={landing.ctaBtn}
        onPress={onStart}
      >
        <Text style={landing.ctaText}>
          Start Check In
        </Text>

        <Ionicons
          name="arrow-forward"
          size={18}
          color="#FFF"
        />
      </TouchableOpacity>
    </View>
  );
}

function CheckInMap({
  onBack,
}: {
  onBack: () => void;
}) {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { showAlert } = useThemedAlert();

  const mapRef = useRef<MapView>(null);

  const fadeAnim =
    useRef(
      new Animated.Value(0)
    ).current;

  const [
    currentTime,
    setCurrentTime,
  ] = useState('');

  const [
    currentAmPm,
    setCurrentAmPm,
  ] = useState('');

  const [
    currentDate,
    setCurrentDate,
  ] = useState('');

  const [
    phase,
    setPhase,
  ] = useState<CheckInPhase>('idle');

  const [
    employee,
    setEmployee,
  ] = useState<Employee | null>(null);

  const [
    userLocation,
    setUserLocation,
  ] =
    useState<Location.LocationObject | null>(
      null
    );

  const [
    locationLoading,
    setLocationLoading,
  ] = useState(true);

  const [
    locationError,
    setLocationError,
  ] = useState('');

  const [
    profileLoading,
    setProfileLoading,
  ] = useState(true);

  const [
    profileError,
    setProfileError,
  ] = useState('');

  const [
    result,
    setResult,
  ] =
    useState<CheckInResponse | null>(null);

  const updateClock = useCallback(() => {
    const now = new Date();

    let hours = now.getHours();

    const minutes = String(
      now.getMinutes()
    ).padStart(2, '0');

    const seconds = String(
      now.getSeconds()
    ).padStart(2, '0');

    const ampm =
      hours >= 12 ? 'PM' : 'AM';

    hours = hours % 12 || 12;

    setCurrentTime(
      `${String(hours).padStart(
        2,
        '0'
      )}:${minutes}:${seconds}`
    );

    setCurrentAmPm(ampm);

    setCurrentDate(
      now.toLocaleDateString(
        undefined,
        {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        }
      )
    );
  }, []);

  useEffect(() => {
    updateClock();

    const timer = setInterval(
      updateClock,
      1000
    );

    return () => clearInterval(timer);
  }, [updateClock]);

  const loadEmployee =
    useCallback(async () => {
      setProfileLoading(true);
      setProfileError('');

      try {
        const response =
          await getMyEmployee();

        setEmployee(response);
      } catch (error) {
        console.error(
          'Failed to load employee profile:',
          error
        );

        setEmployee(null);

        setProfileError(
          getErrorMessage(
            error,
            'Failed to load employee profile.'
          )
        );
      } finally {
        setProfileLoading(false);
      }
    }, []);

  useEffect(() => {
    loadEmployee();
  }, [loadEmployee]);

  const loadLocation =
    useCallback(async () => {
      setLocationLoading(true);
      setLocationError('');

      try {
        const permission =
          await Location
            .requestForegroundPermissionsAsync();

        if (
          permission.status !== 'granted'
        ) {
          setUserLocation(null);

          setLocationError(
            'Location permission is required to check in.'
          );

          return;
        }

        const servicesEnabled =
          await Location
            .hasServicesEnabledAsync();

        if (!servicesEnabled) {
          setUserLocation(null);

          setLocationError(
            'Turn on device location services to check in.'
          );

          return;
        }

        const location =
          await Location
            .getCurrentPositionAsync({
              accuracy:
                Location.Accuracy.High,
            });

        setUserLocation(location);

        mapRef.current
          ?.animateToRegion(
            {
              latitude:
                location.coords.latitude,
              longitude:
                location.coords.longitude,
              latitudeDelta: 0.005,
              longitudeDelta: 0.005,
            },
            700
          );
      } catch (error) {
        console.error(
          'Failed to get location:',
          error
        );

        setUserLocation(null);

        setLocationError(
          getErrorMessage(
            error,
            'Could not get your current location.'
          )
        );
      } finally {
        setLocationLoading(false);
      }
    }, []);

  useEffect(() => {
    loadLocation();
  }, [loadLocation]);

  const handleLocate = async () => {
    if (!userLocation) {
      await loadLocation();
      return;
    }

    mapRef.current?.animateToRegion(
      {
        latitude:
          userLocation.coords.latitude,
        longitude:
          userLocation.coords.longitude,
        latitudeDelta: 0.005,
        longitudeDelta: 0.005,
      },
      700
    );
  };

  const handleConfirmCheckIn =
    async () => {
      if (!employee) {
        showAlert({
          type: 'error',
          title: 'Employee Profile Missing',
          message: profileError || 'Could not load your employee profile.',
        });
        return;
      }

      if (employee.shiftId == null) {
        showAlert({
          type: 'error',
          title: 'No Shift Assigned',
          message: 'Ask your administrator to assign a work shift before checking in.',
        });
        return;
      }

      if (!userLocation) {
        showAlert({
          type: 'error',
          title: 'Location Required',
          message: locationError || 'Your current GPS location is required.',
        });
        return;
      }

      setPhase('preparing');

      try {
        const deviceId =
          await getStableDeviceId();

        setPhase('submitting');
        
        // --- UPDATED WIFI CHECK (Non-blocking) ---
        const { wifiService } = await import('@/services/wifi.service');
        const wifiInfo = await wifiService.getCurrentWifi();

        if (wifiInfo.error || !wifiInfo.ssid || !wifiInfo.bssid) {
          console.log('[CheckIn] Wi-Fi verification skipped or failed:', wifiInfo.error || 'Not connected');
          // We don't return here anymore, allowing the check-in to proceed as PENDING
        }

        const payload = {
          shiftId: employee.shiftId,
          deviceId,
          latitude: userLocation.coords.latitude,
          longitude: userLocation.coords.longitude,
          connectedSsid: wifiInfo.ssid || null,
          connectedBssid: wifiInfo.bssid || null,
        };

        console.log('[CheckIn] Sending Payload:', JSON.stringify(payload, null, 2));

        let response;
        try {
          response = await checkIn(payload);
        } catch (checkInError) {
          // Device registration at login/session-restore is
          // best-effort and swallows its own errors — if it never
          // actually succeeded, this is the first place we'd find
          // out. Register now and retry once instead of failing
          // check-in permanently until the app is restarted.
          if (isDeviceNotFoundError(checkInError)) {
            console.warn('[CheckIn] Device not registered yet, registering now and retrying...');
            await ensureCurrentDeviceRegistered();
            response = await checkIn(payload);
          } else {
            throw checkInError;
          }
        }

        console.log('[CheckIn] Server Response:', JSON.stringify(response, null, 2));

        setResult(response);
        setPhase('success');

        fadeAnim.setValue(0);

        Animated.timing(
          fadeAnim,
          {
            toValue: 1,
            duration: 400,
            useNativeDriver: true,
          }
        ).start();
      } catch (error) {
        console.error(
          'Check-in failed:',
          error
        );

        setPhase('idle');

        showAlert({
          type: 'error',
          title: 'Check In Failed',
          message: getErrorMessage(
            error,
            'Unable to complete check-in.'
          ),
        });
      }
    };

  if (phase === 'success') {
    const successTime =
      result?.checkInTime
        ? formatBackendTime(
            result.checkInTime
          )
        : `${currentTime} ${currentAmPm}`;

    const isPending =
      result?.attendanceStatus ===
        'PENDING' ||
      result?.wifiVerified === false;

    return (
      <Animated.View
        style={[
          success.container,
          {
            opacity: fadeAnim,
            paddingTop: insets.top,
          },
        ]}
      >
        <View style={success.circle}>
          <MaterialCommunityIcons
            name={
              isPending
                ? 'clock-alert-outline'
                : 'check-circle'
            }
            size={72}
            color="#6B4E8D"
          />
        </View>

        <Text style={success.title}>
          {isPending
            ? 'Check In Recorded'
            : 'Attendance Marked!'}
        </Text>

        <Text style={success.subtitle}>
          {result?.wifiVerified === false
            ? 'Wi-Fi verification failed. Attendance is pending approval.'
            : isPending
              ? 'Attendance is pending verification.'
              : 'You are present today 🎉'}
        </Text>

        <View style={success.infoRow}>
          <Ionicons
            name="time-outline"
            size={18}
            color="#6B4E8D"
          />

          <Text style={success.infoText}>
            {successTime}
          </Text>
        </View>

        <TouchableOpacity
          style={success.btn}
          onPress={() =>
            router.replace(
              '/(employee)/(tabs)/' as any
            )
          }
        >
          <Text style={success.btnText}>
            Go to Dashboard
          </Text>
        </TouchableOpacity>
      </Animated.View>
    );
  }

  const busy =
    phase === 'preparing' ||
    phase === 'submitting';

  const canCheckIn =
    !busy &&
    !profileLoading &&
    !locationLoading &&
    employee != null &&
    employee.shiftId != null &&
    userLocation != null;

  return (
    <View style={map.container}>
      <View
        style={[
          map.header,
          {
            paddingTop:
              insets.top + 12,
          },
        ]}
      >
        <TouchableOpacity
          style={map.backBtn}
          onPress={onBack}
          disabled={busy}
        >
          <Ionicons
            name="chevron-back"
            size={20}
            color="#5B3D7A"
          />
        </TouchableOpacity>

        <View style={map.headerText}>
          <Text style={map.headerTitle}>
            Remote Check In
          </Text>

          <Text style={map.headerSub}>
            Backend validates your shift,
            device and geofence
          </Text>
        </View>
      </View>

      <View style={map.mapFrame}>
        <MapView
          ref={mapRef}
          style={
            StyleSheet.absoluteFillObject
          }
          initialRegion={{
            latitude:
              userLocation?.coords.latitude ??
              28.4595,
            longitude:
              userLocation?.coords.longitude ??
              77.0266,
            latitudeDelta: 0.08,
            longitudeDelta: 0.08,
          }}
          showsUserLocation
        >
          {userLocation && (
            <Marker
              coordinate={{
                latitude:
                  userLocation.coords.latitude,
                longitude:
                  userLocation.coords.longitude,
              }}
            >
              <View style={map.blueDotOuter}>
                <View style={map.blueDotInner} />
              </View>
            </Marker>
          )}
        </MapView>

        <View style={map.floatingCard}>
          <View style={map.locIconWrap}>
            {locationLoading ? (
              <ActivityIndicator
                size="small"
                color="#6B4E8D"
              />
            ) : (
              <Ionicons
                name="location"
                size={18}
                color="#6B4E8D"
              />
            )}
          </View>

          <View style={{ flex: 1 }}>
            <Text style={map.locTitle}>
              Current Location
            </Text>

            <Text
              style={map.locSub}
              numberOfLines={1}
            >
              {locationLoading
                ? 'Getting GPS position...'
                : locationError
                  ? locationError
                  : userLocation
                    ? `${userLocation.coords.latitude.toFixed(
                        5
                      )}, ${userLocation.coords.longitude.toFixed(
                        5
                      )}`
                    : 'Location unavailable'}
            </Text>
          </View>

          <View
            style={
              userLocation
                ? map.greenBadge
                : map.redBadge
            }
          >
            <Ionicons
              name={
                userLocation
                  ? 'checkmark-circle'
                  : 'close-circle'
              }
              size={14}
              color={
                userLocation
                  ? '#28C76F'
                  : '#EA5455'
              }
              style={{
                marginRight: 3,
              }}
            />

            <Text
              style={
                userLocation
                  ? map.greenText
                  : map.redText
              }
            >
              {userLocation
                ? 'Ready'
                : 'Missing'}
            </Text>
          </View>
        </View>

        <View style={map.accuracyPill}>
          <View style={map.shieldWrap}>
            <Feather
              name="shield"
              size={14}
              color="#6B4E8D"
            />
          </View>

          <View style={{ marginLeft: 6 }}>
            <Text style={map.accLabel}>
              Accuracy
            </Text>

            <Text style={map.accValue}>
              {userLocation
                ? `${Math.round(
                    userLocation.coords
                      .accuracy ?? 0
                  )} m`
                : '--'}
            </Text>
          </View>
        </View>

        <View style={map.controls}>
          <TouchableOpacity
            style={map.ctrlBtn}
            onPress={handleLocate}
          >
            <Ionicons
              name="locate-sharp"
              size={18}
              color="#6B4E8D"
            />
          </TouchableOpacity>
        </View>
      </View>

      <View
        style={[
          map.sheet,
          {
            paddingBottom:
              Math.max(
                insets.bottom,
                20
              ) + 10,
          },
        ]}
      >
        <View style={map.handle} />

        {busy && (
          <View style={map.verifyRow}>
            <VerifyItem
              label="Device + GPS"
              done={
                phase === 'submitting'
              }
              active={
                phase === 'preparing'
              }
            />

            <View style={map.verifyLine} />

            <VerifyItem
              label="Backend Validation"
              done={false}
              active={
                phase === 'submitting'
              }
            />
          </View>
        )}

        {!busy && (
          <>
            <View style={map.timeRow}>
              <View style={map.dateWrap}>
                <View style={map.calBox}>
                  <MaterialCommunityIcons
                    name="calendar-heart"
                    size={24}
                    color="#29185c"
                  />
                </View>

                <View
                  style={{
                    marginLeft: 12,
                  }}
                >
                  <Text style={map.clock}>
                    {currentTime}
                    <Text style={map.ampm}>
                      {' '}
                      {currentAmPm}
                    </Text>
                  </Text>

                  <Text style={map.date}>
                    {currentDate}
                  </Text>
                </View>
              </View>

              <View style={map.tagPill}>
                <View style={map.tagDot} />

                <Text style={map.tagText}>
                  Check-in
                </Text>
              </View>
            </View>

            <View
              style={
                canCheckIn
                  ? map.infoBanner
                  : map.warnBanner
              }
            >
              <Ionicons
                name={
                  canCheckIn
                    ? 'information-circle-outline'
                    : 'alert-circle-outline'
                }
                size={18}
                color={
                  canCheckIn
                    ? '#6B4E8D'
                    : '#EA5455'
                }
                style={{
                  marginTop: 1,
                }}
              />

              <Text
                style={
                  canCheckIn
                    ? map.infoText
                    : map.warnText
                }
              >
                {getReadinessMessage({
                  profileLoading,
                  profileError,
                  employee,
                  locationLoading,
                  locationError,
                  userLocation,
                })}
              </Text>
            </View>
          </>
        )}

        <TouchableOpacity
          style={[
            map.cta,
            !canCheckIn &&
              map.ctaDis,
          ]}
          onPress={
            handleConfirmCheckIn
          }
          disabled={!canCheckIn}
        >
          {busy ? (
            <ActivityIndicator
              color="#FFF"
            />
          ) : (
            <View style={map.ctaContent}>
              <Ionicons
                name="checkmark-circle"
                size={18}
                color="#FFF"
                style={{
                  marginRight: 6,
                }}
              />

              <Text style={map.ctaText}>
                Confirm Check In
              </Text>
            </View>
          )}
        </TouchableOpacity>

        {!locationLoading &&
          !userLocation && (
            <TouchableOpacity
              style={map.retryLink}
              onPress={loadLocation}
            >
              <Ionicons
                name="refresh"
                size={16}
                color="#6B4E8D"
              />

              <Text style={map.retryText}>
                Retry Location
              </Text>
            </TouchableOpacity>
          )}

        {!profileLoading &&
          !employee && (
            <TouchableOpacity
              style={map.retryLink}
              onPress={loadEmployee}
            >
              <Ionicons
                name="refresh"
                size={16}
                color="#6B4E8D"
              />

              <Text style={map.retryText}>
                Retry Employee Profile
              </Text>
            </TouchableOpacity>
          )}
      </View>
    </View>
  );
}

function VerifyItem({
  label,
  done,
  active,
}: {
  label: string;
  done: boolean;
  active: boolean;
}) {
  return (
    <View
      style={{
        alignItems: 'center',
        flex: 1,
      }}
    >
      <View
        style={[
          vfy.circle,
          done && vfy.done,
          active && vfy.active,
        ]}
      >
        {done ? (
          <Ionicons
            name="checkmark"
            size={16}
            color="#FFF"
          />
        ) : active ? (
          <ActivityIndicator
            size="small"
            color="#FFF"
          />
        ) : (
          <View style={vfy.idle} />
        )}
      </View>

      <Text style={vfy.label}>
        {label}
      </Text>
    </View>
  );
}

export default function RemoteCheckInScreen() {
  const [
    step,
    setStep,
  ] =
    useState<ScreenStep>('landing');

  if (step === 'landing') {
    return (
      <CheckInLanding
        onStart={() => setStep('map')}
      />
    );
  }

  return (
    <CheckInMap
      onBack={() => setStep('landing')}
    />
  );
}

function getReadinessMessage({
  profileLoading,
  profileError,
  employee,
  locationLoading,
  locationError,
  userLocation,
}: {
  profileLoading: boolean;
  profileError: string;
  employee: Employee | null;
  locationLoading: boolean;
  locationError: string;
  userLocation:
    | Location.LocationObject
    | null;
}) {
  if (profileLoading) {
    return 'Loading your employee profile...';
  }

  if (profileError || !employee) {
    return (
      profileError ||
      'Employee profile unavailable.'
    );
  }

  if (employee.shiftId == null) {
    return 'No shift is assigned to your employee profile.';
  }

  if (locationLoading) {
    return 'Getting your current GPS location...';
  }

  if (
    locationError ||
    !userLocation
  ) {
    return (
      locationError ||
      'GPS location is unavailable.'
    );
  }

  return 'Ready. The server will validate your assigned shift, registered device and geofence.';
}

function getErrorMessage(
  error: unknown,
  fallback: string
): string {
  if (error instanceof Error) {
    return error.message || fallback;
  }

  if (
    typeof error === 'object' &&
    error !== null
  ) {
    const record =
      error as Record<string, unknown>;

    if (
      typeof record.message === 'string'
    ) {
      return record.message;
    }

    if (
      typeof record.error === 'string'
    ) {
      return record.error;
    }
  }

  return fallback;
}

function formatBackendTime(
  value: string
) {
  const parsed = new Date(value);

  if (
    Number.isNaN(parsed.getTime())
  ) {
    return value;
  }

  return parsed.toLocaleString();
}

const landing = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EDE8F5',
    paddingHorizontal: 24,
  },

  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#CAA6EC',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 12,
    marginBottom: 24,
  },

  heroSection: {
    alignItems: 'center',
    marginBottom: 40,
  },

  heroBadge: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#DDD0F0',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },

  heroTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#29185c',
    marginBottom: 10,
  },

  heroSubtitle: {
    fontSize: 14,
    color: '#6B4E8D',
    textAlign: 'center',
    lineHeight: 22,
  },

  stepsCard: {
    backgroundColor: '#FFF',
    borderRadius: 18,
    paddingHorizontal: 20,
    paddingVertical: 8,
    marginBottom: 40,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 3,
  },

  stepRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
  },

  stepRowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: '#F0ECF8',
  },

  stepIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#EDE8F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },

  stepText: {
    flex: 1,
  },

  stepTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#29185c',
  },

  stepDesc: {
    fontSize: 12,
    color: '#888',
    marginTop: 2,
  },

  stepCircle: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: '#C5B4D6',
  },

  ctaBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#6B4E8D',
    borderRadius: 14,
    height: 54,
    gap: 10,
  },

  ctaText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFF',
  },
});

const map = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EDE8F5',
    paddingHorizontal: 16,
    paddingBottom: 20,
  },

  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#CAA6EC',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },

  headerText: {
    flex: 1,
    alignItems: 'center',
    paddingRight: 54,
  },

  headerTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#29185c',
  },

  headerSub: {
    fontSize: 12,
    color: '#6B4E8D',
    marginTop: 3,
    textAlign: 'center',
  },

  mapFrame: {
    flex: 1,
    position: 'relative',
    overflow: 'hidden',
  },

  floatingCard: {
    position: 'absolute',
    top: 14,
    left: 14,
    right: 14,
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },

  locIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#F3EFFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },

  locTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#29185c',
  },

  locSub: {
    fontSize: 11,
    color: '#828282',
    marginTop: 2,
  },

  greenBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E8F9EE',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },

  greenText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#28C76F',
  },

  redBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FCE8E6',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },

  redText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#EA5455',
  },

  accuracyPill: {
    position: 'absolute',
    left: 14,
    bottom: 14,
    backgroundColor: '#FFF',
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 10,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 2,
  },

  shieldWrap: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#F3EFFF',
    justifyContent: 'center',
    alignItems: 'center',
  },

  accLabel: {
    fontSize: 10,
    color: '#828282',
  },

  accValue: {
    fontSize: 12,
    fontWeight: '700',
    color: '#29185c',
  },

  controls: {
    position: 'absolute',
    right: 14,
    bottom: 14,
  },

  ctrlBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#FFF',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 2,
  },

  blueDotOuter: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: '#FFF',
    justifyContent: 'center',
    alignItems: 'center',
  },

  blueDotInner: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#007AFF',
  },

  sheet: {
    backgroundColor: '#FFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 20,
    paddingTop: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: -3,
    },
    shadowOpacity: 0.08,
    shadowRadius: 10,
    elevation: 5,
  },

  handle: {
    width: 40,
    height: 4,
    backgroundColor: '#E0E0E0',
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 20,
  },

  verifyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },

  verifyLine: {
    width: 40,
    height: 1.5,
    backgroundColor: '#CAA6EC',
    marginHorizontal: 8,
  },

  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },

  dateWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },

  calBox: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: '#F3EFFF',
    justifyContent: 'center',
    alignItems: 'center',
  },

  clock: {
    fontSize: 20,
    fontWeight: '700',
    color: '#29185c',
  },

  ampm: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6B4E8D',
  },

  date: {
    fontSize: 12,
    color: '#6B4E8D',
    marginTop: 2,
  },

  tagPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3EFFF',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },

  tagDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#6B4E8D',
    marginRight: 6,
  },

  tagText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6B4E8D',
  },

  infoBanner: {
    flexDirection: 'row',
    backgroundColor: '#F9F8FF',
    borderStyle: 'dashed',
    borderWidth: 1.5,
    borderColor: '#CAA6EC',
    borderRadius: 12,
    padding: 12,
    marginBottom: 20,
    alignItems: 'flex-start',
  },

  infoText: {
    flex: 1,
    fontSize: 12,
    color: '#6B4E8D',
    marginLeft: 8,
    lineHeight: 18,
  },

  warnBanner: {
    flexDirection: 'row',
    backgroundColor: '#FFF9F9',
    borderStyle: 'dashed',
    borderWidth: 1.5,
    borderColor: '#FFCDD2',
    borderRadius: 12,
    padding: 12,
    marginBottom: 20,
    alignItems: 'flex-start',
  },

  warnText: {
    flex: 1,
    fontSize: 12,
    color: '#EA5455',
    marginLeft: 8,
    lineHeight: 18,
  },

  cta: {
    backgroundColor: '#6B4E8D',
    borderRadius: 12,
    height: 52,
    justifyContent: 'center',
    alignItems: 'center',
  },

  ctaDis: {
    opacity: 0.5,
  },

  ctaContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  ctaText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFF',
  },

  retryLink: {
    minHeight: 42,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    marginTop: 8,
  },

  retryText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#6B4E8D',
  },
});

const success = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EDE8F5',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
  },

  circle: {
    width: 130,
    height: 130,
    borderRadius: 65,
    backgroundColor: '#DDD0F0',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 28,
  },

  title: {
    fontSize: 26,
    fontWeight: '700',
    color: '#29185c',
    marginBottom: 8,
    textAlign: 'center',
  },

  subtitle: {
    fontSize: 16,
    color: '#6B4E8D',
    marginBottom: 24,
    textAlign: 'center',
  },

  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    borderRadius: 12,
    paddingHorizontal: 18,
    paddingVertical: 12,
    gap: 8,
    marginBottom: 40,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
  },

  infoText: {
    fontSize: 13,
    color: '#29185c',
    fontWeight: '600',
  },

  btn: {
    backgroundColor: '#6B4E8D',
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 48,
  },

  btnText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFF',
  },
});

const vfy = StyleSheet.create({
  circle: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: '#C5B4D6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
  },

  active: {
    backgroundColor: '#6B4E8D',
  },

  done: {
    backgroundColor: '#28C76F',
  },

  idle: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#9B8BB0',
  },

  label: {
    fontSize: 11,
    color: '#6B4E8D',
    fontWeight: '600',
    textAlign: 'center',
  },
});