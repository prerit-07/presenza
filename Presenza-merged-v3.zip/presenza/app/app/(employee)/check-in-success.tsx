// app/(employee)/remote-checkin-success.tsx
// Role: Employee only
// Opens from: /(employee)/remote-checkin (after both GPS + WiFi pass)
// Navigates to: /(employee)/(tabs) — back to dashboard

import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Pressable, Animated } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useAppStore } from '@/store/useAppStore';
import { DashboardTheme as T } from '@/constants/dashboard-theme';

export default function CheckInSuccessScreen() {
  const router = useRouter();
  const { time } = useLocalSearchParams<{ time: string }>();
  const user = useAppStore((s) => s.user);

  // Working timer (seconds since check-in)
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTimer = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  // Entrance animation
  const scale = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.spring(scale, {
      toValue: 1, tension: 60, friction: 7, useNativeDriver: true,
    }).start();
  }, []);

  return (
    <SafeAreaView style={styles.root} edges={['top', 'bottom']}>
      <View style={styles.content}>

        {/* Success Icon */}
        <Animated.View style={[styles.successRing, { transform: [{ scale }] }]}>
          <View style={styles.successInner}>
            <MaterialCommunityIcons name="check-bold" size={52} color="#FFF" />
          </View>
        </Animated.View>

        <Text style={styles.title}>You're In!</Text>
        <Text style={styles.subtitle}>Attendance marked successfully</Text>

        {/* Time Info */}
        <View style={styles.infoCard}>
          <View style={styles.infoRow}>
            <MaterialCommunityIcons name="clock-outline" size={18} color={T.purpleIcon} />
            <Text style={styles.infoLabel}>Check-In Time</Text>
            <Text style={styles.infoValue}>{time ?? '--'}</Text>
          </View>
          <View style={styles.infoSep} />
          <View style={styles.infoRow}>
            <MaterialCommunityIcons name="account-outline" size={18} color={T.purpleIcon} />
            <Text style={styles.infoLabel}>Name</Text>
            <Text style={styles.infoValue}>{user?.name ?? '--'}</Text>
          </View>
          <View style={styles.infoSep} />
          <View style={styles.infoRow}>
            <MaterialCommunityIcons name="map-marker-check-outline" size={18} color="#4CAF50" />
            <Text style={styles.infoLabel}>GPS</Text>
            <Text style={[styles.infoValue, { color: '#4CAF50' }]}>Verified ✓</Text>
          </View>
          <View style={styles.infoSep} />
          <View style={styles.infoRow}>
            <MaterialCommunityIcons name="wifi-check" size={18} color="#4CAF50" />
            <Text style={styles.infoLabel}>Office WiFi</Text>
            <Text style={[styles.infoValue, { color: '#4CAF50' }]}>Verified ✓</Text>
          </View>
        </View>

        {/* Working Timer */}
        <View style={styles.timerCard}>
          <Text style={styles.timerLabel}>Working Time</Text>
          <Text style={styles.timerValue}>{formatTimer(elapsed)}</Text>
          <Text style={styles.timerSub}>Timer started at check-in</Text>
        </View>

        {/* CTA */}
        <Pressable style={styles.doneBtn} onPress={() => router.replace('/(employee)/(tabs)')}>
          <Text style={styles.doneBtnText}>Go to Dashboard</Text>
        </Pressable>

      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: T.screenBg },
  content: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 24 },
  successRing: {
    width: 140, height: 140, borderRadius: 70,
    backgroundColor: '#4CAF5022', justifyContent: 'center',
    alignItems: 'center', marginBottom: 24,
  },
  successInner: {
    width: 108, height: 108, borderRadius: 54,
    backgroundColor: '#4CAF50', justifyContent: 'center', alignItems: 'center',
  },
  title: { fontSize: 30, fontWeight: '800', color: T.purpleDark, marginBottom: 6 },
  subtitle: { fontSize: 14, color: T.textMuted, marginBottom: 28 },
  infoCard: {
    width: '100%', backgroundColor: '#FFF', borderRadius: 20,
    padding: 20, marginBottom: 16,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06, shadowRadius: 10, elevation: 4,
  },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  infoLabel: { flex: 1, fontSize: 13, color: T.textMuted, fontWeight: '500' },
  infoValue: { fontSize: 13, fontWeight: '700', color: T.purpleDark },
  infoSep: { height: 1, backgroundColor: '#F5F3F8', marginVertical: 12 },
  timerCard: {
    width: '100%', backgroundColor: T.purpleIcon, borderRadius: 20,
    padding: 20, alignItems: 'center', marginBottom: 28,
  },
  timerLabel: { fontSize: 12, color: 'rgba(255,255,255,0.7)', fontWeight: '600', letterSpacing: 1 },
  timerValue: { fontSize: 40, fontWeight: '800', color: '#FFF', letterSpacing: 2, marginVertical: 4 },
  timerSub: { fontSize: 11, color: 'rgba(255,255,255,0.6)' },
  doneBtn: {
    width: '100%', backgroundColor: T.purpleDark, borderRadius: 16,
    height: 54, alignItems: 'center', justifyContent: 'center',
  },
  doneBtnText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
});



