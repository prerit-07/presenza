import EmployeeDashboard from "@/components/dashboards/EmployeeDashboard";

export default function EmployeeHomeScreen() {
  return <EmployeeDashboard userName="Employee" />;
}
