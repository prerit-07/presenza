export interface TeamMember {
  id: string;
  name: string;
  role: string;
  status: 'Present' | 'Late' | 'Absent';
  gender: 'male' | 'female';
}

let teamMembers: TeamMember[] = [
  { id: '1', name: 'Arjun Mehta', role: 'Field Executive', status: 'Present', gender: 'male' },
  { id: '2', name: 'Priya Sharma', role: 'UI/UX Designer', status: 'Present', gender: 'female' },
  { id: '3', name: 'Rohan Verma', role: 'Field Executive', status: 'Late', gender: 'male' },
  { id: '4', name: 'Meera Sen', role: 'Marketing Specialist', status: 'Present', gender: 'female' },
  { id: '5', name: 'Aditya Goel', role: 'Sales Executive', status: 'Absent', gender: 'male' },
  { id: '6', name: 'Rahul Nair', role: 'Operations Lead', status: 'Present', gender: 'male' },
];

const listeners = new Set<() => void>();

export const teamState = {
  getMembers() {
    return teamMembers;
  },
  addMember(name: string, role: string, status: 'Present' | 'Late' | 'Absent', gender: 'male' | 'female') {
    const newMember: TeamMember = {
      id: Date.now().toString(),
      name,
      role,
      status,
      gender,
    };
    teamMembers = [newMember, ...teamMembers];
    listeners.forEach((l) => l());
  },
  deleteMember(id: string) {
    teamMembers = teamMembers.filter((m) => m.id !== id);
    listeners.forEach((l) => l());
  },
  updateMemberStatus(id: string, status: 'Present' | 'Late' | 'Absent') {
    teamMembers = teamMembers.map((m) => (m.id === id ? { ...m, status } : m));
    listeners.forEach((l) => l());
  },
  subscribe(listener: () => void) {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  },
};
