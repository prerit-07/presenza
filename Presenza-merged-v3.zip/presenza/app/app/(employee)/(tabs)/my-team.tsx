import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Platform,
} from 'react-native';
import { Tabs, useRouter } from 'expo-router';
import { Ionicons, MaterialCommunityIcons, FontAwesome5 } from '@expo/vector-icons';
import { PageHeader } from '@/components/PageHeader';
import { useThemedAlert } from '@/components/ThemedAlertProvider';

interface TeamMember {
  id: string;
  name: string;
  role: string;
  status: 'Present' | 'Late' | 'Absent';
  gender: 'male' | 'female';
}

export default function TeamEmployeeScreen() {
  const router = useRouter();
  const { showAlert } = useThemedAlert();

  // Search query
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Team list state
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([
    { id: '1', name: 'Arjun Mehta', role: 'Field Executive', status: 'Present', gender: 'male' },
    { id: '2', name: 'Priya Sharma', role: 'UI/UX Designer', status: 'Present', gender: 'female' },
    { id: '3', name: 'Rohan Verma', role: 'Field Executive', status: 'Late', gender: 'male' },
    { id: '4', name: 'Meera Sen', role: 'Marketing Specialist', status: 'Present', gender: 'female' },
    { id: '5', name: 'Aditya Goel', role: 'Sales Executive', status: 'Absent', gender: 'male' },
    { id: '6', name: 'Rahul Nair', role: 'Operations Lead', status: 'Present', gender: 'male' },
  ]);

  // Counts based on actual states
  const totalEmployees = teamMembers.length;
  const presentToday = teamMembers.filter((m) => m.status === 'Present').length;
  const lateToday = teamMembers.filter((m) => m.status === 'Late').length;
  const absentToday = teamMembers.filter((m) => m.status === 'Absent').length;

  // Filtered members list based on query
  const filteredMembers = teamMembers.filter((m) =>
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleMemberPress = (member: TeamMember) => {
    showAlert({
      type: 'info',
      title: member.name,
      message: `Designation: ${member.role}\nStatus Today: ${member.status}`
    });
  };

  return (
    <View style={styles.container}>
      <Tabs.Screen options={{ headerShown: false }} />

      <PageHeader title="My Team" subtitle="Today's team attendance" />

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* 🔍 SEARCH AND FILTER BAR */}
        <View style={styles.searchBarWrapper}>
          <View style={styles.searchContainer}>
            <Ionicons name="search" size={18} color="#828282" style={{ marginRight: 8 }} />
            <TextInput
              style={styles.searchInput}
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search by name or role"
              placeholderTextColor="#828282"
            />
          </View>
          <TouchableOpacity style={styles.filterButton}>
            <Ionicons name="options-outline" size={18} color="#6E4B8D" />
          </TouchableOpacity>
        </View>

        {/* 📊 HORIZONTAL STATISTICS GRID */}
        <View style={styles.statsContainer}>
          <View style={styles.statsCard}>
            <View style={[styles.statsIconBox, { backgroundColor: '#F3EFFF' }]}>
              <Ionicons name="people" size={16} color="#6E4B8D" />
            </View>
            <Text style={styles.statsNumber}>{totalEmployees}</Text>
            <Text style={styles.statsLabel}>Total</Text>
            <Text style={styles.statsLabel}>Employee</Text>
          </View>

          <View style={styles.statsCard}>
            <View style={[styles.statsIconBox, { backgroundColor: '#E8F9EE' }]}>
              <Ionicons name="checkmark-circle" size={16} color="#28C76F" />
            </View>
            <Text style={[styles.statsNumber, { color: '#28C76F' }]}>{presentToday}</Text>
            <Text style={styles.statsLabel}>Present</Text>
            <Text style={styles.statsLabel}>Today</Text>
          </View>

          <View style={styles.statsCard}>
            <View style={[styles.statsIconBox, { backgroundColor: '#FFF5EC' }]}>
              <Ionicons name="time" size={16} color="#FF9F43" />
            </View>
            <Text style={[styles.statsNumber, { color: '#FF9F43' }]}>{lateToday}</Text>
            <Text style={styles.statsLabel}>Late</Text>
            <Text style={styles.statsLabel}>Today</Text>
          </View>

          <View style={styles.statsCard}>
            <View style={[styles.statsIconBox, { backgroundColor: '#FFF1F1' }]}>
              <Ionicons name="alert-circle" size={16} color="#EA5455" />
            </View>
            <Text style={[styles.statsNumber, { color: '#EA5455' }]}>{absentToday}</Text>
            <Text style={styles.statsLabel}>Absent</Text>
            <Text style={styles.statsLabel}>Today</Text>
          </View>
        </View>

        {/* 👥 TEAM MEMBERS LIST SECTION */}
        <View style={styles.sectionHeaderRow}>
          <Text style={styles.sectionTitle}>Team Members</Text>
          <TouchableOpacity style={styles.viewMoreButton}>
            <Text style={styles.viewMoreText}>View More</Text>
            <Ionicons name="chevron-forward" size={12} color="#6E4B8D" style={{ marginLeft: 2 }} />
          </TouchableOpacity>
        </View>

        <View style={styles.membersListContainer}>
          {filteredMembers.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>No team members match your query.</Text>
            </View>
          ) : (
            filteredMembers.map((member) => (
              <TouchableOpacity key={member.id} style={styles.memberCard} onPress={() => handleMemberPress(member)}>
                <View style={styles.memberAvatarWrapper}>
                  <View style={[styles.avatarCircle, { backgroundColor: member.gender === 'female' ? '#F6EDFF' : '#E8F5FF' }]}>
                    <FontAwesome5
                      name={member.gender === 'female' ? 'user-ninja' : 'user-tie'}
                      size={18}
                      color={member.gender === 'female' ? '#aa80cf' : '#6E4B8D'}
                    />
                  </View>
                </View>
                <View style={styles.memberInfo}>
                  <Text style={styles.memberName}>{member.name}</Text>
                  <Text style={styles.memberRole}>{member.role}</Text>
                </View>
                <View style={styles.memberRightSection}>
                  <View
                    style={[
                      styles.statusBadge,
                      member.status === 'Present' && styles.presentBadge,
                      member.status === 'Late' && styles.lateBadge,
                      member.status === 'Absent' && styles.absentBadge,
                    ]}
                  >
                    <View
                      style={[
                        styles.statusDot,
                        member.status === 'Present' && { backgroundColor: '#28C76F' },
                        member.status === 'Late' && { backgroundColor: '#FF9F43' },
                        member.status === 'Absent' && { backgroundColor: '#EA5455' },
                      ]}
                    />
                    <Text
                      style={[
                        styles.statusText,
                        member.status === 'Present' && { color: '#28C76F' },
                        member.status === 'Late' && { color: '#FF9F43' },
                        member.status === 'Absent' && { color: '#EA5455' },
                      ]}
                    >
                      {member.status}
                    </Text>
                  </View>
                  <View style={styles.dotsButton}>
                    <MaterialCommunityIcons name="dots-vertical" size={20} color="#828282" />
                  </View>
                </View>
              </TouchableOpacity>
            ))
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3EDF7',
  },

  // Scroll Container
  scrollContent: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 60,
  },

  // Search Bar
  searchBarWrapper: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 16,
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 44,
    borderWidth: 1,
    borderColor: '#EBE5F5',
    shadowColor: '#6E4B8D',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.03,
    shadowRadius: 4,
    elevation: 1,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: '#29185c',
    height: '100%',
  },
  filterButton: {
    width: 44,
    height: 44,
    backgroundColor: '#F3EFFF',
    borderWidth: 1,
    borderColor: '#EBE5F5',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // Stats Dashboard
  statsContainer: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 20,
  },
  statsCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 10,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#EBE5F5',
    shadowColor: '#6E4B8D',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 2,
  },
  statsIconBox: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
  },
  statsNumber: {
    fontSize: 15,
    fontWeight: '700',
    color: '#29185c',
  },
  statsLabel: {
    fontSize: 9,
    color: '#828282',
    lineHeight: 11,
    textAlign: 'center',
  },

  // Section Headers
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#29185c',
  },
  viewMoreButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  viewMoreText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6E4B8D',
  },

  // Team list
  membersListContainer: {
    gap: 10,
    marginBottom: 20,
  },
  emptyContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#EBE5F5',
  },
  emptyText: {
    fontSize: 13,
    color: '#828282',
  },
  memberCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 12,
    borderWidth: 1,
    borderColor: '#EBE5F5',
    shadowColor: '#6E4B8D',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.03,
    shadowRadius: 6,
    elevation: 1,
  },
  memberAvatarWrapper: {
    marginRight: 12,
  },
  avatarCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#EBE5F5',
  },
  memberInfo: {
    flex: 1,
  },
  memberName: {
    fontSize: 14,
    fontWeight: '700',
    color: '#29185c',
  },
  memberRole: {
    fontSize: 11,
    color: '#828282',
    marginTop: 2,
  },
  memberRightSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 0.5,
  },
  presentBadge: {
    backgroundColor: '#E8F9EE',
    borderColor: 'rgba(40, 199, 111, 0.2)',
  },
  lateBadge: {
    backgroundColor: '#FFF5EC',
    borderColor: 'rgba(255, 159, 67, 0.2)',
  },
  absentBadge: {
    backgroundColor: '#FFF1F1',
    borderColor: 'rgba(234, 84, 85, 0.2)',
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 5,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
  },
  dotsButton: {
    padding: 4,
  },
});
