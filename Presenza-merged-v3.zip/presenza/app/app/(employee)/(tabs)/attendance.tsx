import React, { useState } from 'react';
import { StyleSheet, Text, View, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAppStore } from '@/store/useAppStore';
import { PageHeader } from '@/components/PageHeader';
import { Calendar } from '@/components/Calendar';
import { AttendanceCard } from '@/components/AttendanceCard';
import { Toast } from '@/components/Toast';

const P_DARK  = '#5B3D7A';
const P_MED   = '#7B5EA7';
const P_LIGHT = '#EBE0F5';
const P_BG    = '#F3EDF7';
const P_ICON  = '#6B4E8D';

export default function AttendanceScreen() {
  const attendanceRecords = useAppStore((state) => state.attendanceRecords);
  const [toast, setToast] = useState<{ visible: boolean; message: string; type: 'success' | 'error' | 'info' }>({
    visible: false, message: '', type: 'info',
  });

  const highlightedDays = attendanceRecords.map((rec) => new Date(rec.date).getDate());

  const handleDaySelect = (day: number) => {
    const record = attendanceRecords.find((rec) => new Date(rec.date).getDate() === day);
    if (record) {
      setToast({ visible: true, message: `${record.dayName}: Checked in at ${record.checkIn} · ${record.status}`, type: 'success' });
    } else {
      setToast({ visible: true, message: `No attendance record for day ${day}`, type: 'info' });
    }
  };

  const presentCount = attendanceRecords.filter(r => r.status === 'ON TIME').length;

  return (
    <View style={styles.container}>
      <Toast
        visible={toast.visible}
        message={toast.message}
        type={toast.type}
        onDismiss={() => setToast({ ...toast, visible: false })}
      />

      <PageHeader 
        title="Attendance Record" 
        subtitle="Track your check-in history" 
      />

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Calendar */}
        <Calendar selectedDays={highlightedDays} onDaySelect={handleDaySelect} />

        {/* Summary Row */}
        <View style={styles.summaryRow}>
          <View style={[styles.summaryCard, { flex: 1, marginRight: 8 }]}>
            <View style={styles.summaryTop}>
              <Ionicons name="checkmark-circle" size={18} color="#43C47A" />
              <Text style={styles.summaryLabel}>Present</Text>
            </View>
            <Text style={styles.summaryBig}>{String(presentCount).padStart(2, '0')}</Text>
            <Text style={styles.summaryUnit}>days</Text>
          </View>
          <View style={[styles.summaryCard, { flex: 1, marginLeft: 8 }]}>
            <View style={styles.summaryTop}>
              <Ionicons name="pie-chart-outline" size={18} color={P_ICON} />
              <Text style={styles.summaryLabel}>Attendance</Text>
            </View>
            <Text style={styles.summaryBig}>100%</Text>
            <Text style={styles.summaryUnit}>this month</Text>
          </View>
        </View>

        {/* Motivational Banner */}
        <View style={styles.motiveBanner}>
          <Text style={styles.motiveEmoji}>🎉</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.motiveTitle}>Keep it Up!!</Text>
            <Text style={styles.motiveSub}>Perfect attendance this month. Great work!</Text>
          </View>
        </View>

        {/* This Week */}
        <Text style={styles.sectionTitle}>This Week</Text>
        {attendanceRecords.length > 0 ? (
          attendanceRecords.map((item) => <AttendanceCard key={item.id} record={item} />)
        ) : (
          <Text style={styles.emptyText}>No logs found for this week</Text>
        )}

        <View style={{ height: 120 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: P_BG },
  scroll: { paddingHorizontal: 18, paddingTop: 18 },

  summaryRow: { flexDirection: 'row', marginBottom: 16 },
  summaryCard: {
    backgroundColor: '#FFF', borderRadius: 16, padding: 16,
    shadowColor: P_DARK, shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.07, shadowRadius: 6, elevation: 2,
  },
  summaryTop: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 },
  summaryLabel: { fontSize: 12, fontWeight: '600', color: P_MED },
  summaryBig: { fontSize: 26, fontWeight: '800', color: P_DARK },
  summaryUnit: { fontSize: 11, color: P_MED, marginTop: 2 },

  motiveBanner: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: P_LIGHT, borderRadius: 16,
    padding: 16, marginBottom: 22, gap: 14,
  },
  motiveEmoji: { fontSize: 28 },
  motiveTitle: { fontSize: 15, fontWeight: '700', color: P_DARK, marginBottom: 3 },
  motiveSub:   { fontSize: 12, color: P_MED, lineHeight: 17 },

  sectionTitle: { fontSize: 16, fontWeight: '700', color: P_DARK, marginBottom: 12 },
  emptyText: { fontSize: 13, color: P_MED, textAlign: 'center', marginVertical: 14 },
});
