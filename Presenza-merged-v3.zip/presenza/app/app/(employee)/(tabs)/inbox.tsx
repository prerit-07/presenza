import { View, Text, StyleSheet } from "react-native";

export default function PlaceholderScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Presenza</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F8F4FA",
  },
  text: {
    fontSize: 24,
    fontWeight: "700",
    color: "#35156B",
  },
});
