// app/device-request.tsx
// Role: Employee only
// Opens from: Employee dashboard Quick Access, Profile menu

import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput,
  Pressable, ActivityIndicator, ScrollView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { PageHeader } from '@/components/PageHeader';
import { deviceChangeService } from '@/services/device.change.service';
import { getStableDeviceId } from '@/services/device.service';

const REASONS = [
  'Lost my phone',
  'Phone stolen',
  'Switched to a new device',
  'Phone damaged / repaired',
  'Other',
];

export default function DeviceRequestScreen() {
  const router = useRouter();

  const [selectedReason, setSelectedReason] = useState('');
  const [customReason, setCustomReason] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const finalReason = selectedReason === 'Other' ? customReason : selectedReason;

  const handleSubmit = async () => {
    if (!finalReason.trim()) return;
    setSubmitting(true);
    
    try {
      // We grab the ID of the new device they are currently holding in their hand
      const currentNewDeviceId = await getStableDeviceId();
      
      // We send 'UNKNOWN' for old device since they don't have it anymore
      await deviceChangeService.createRequest('PREVIOUS_DEVICE_UNKNOWN', currentNewDeviceId, finalReason.trim());
      
      setSubmitted(true);
    } catch (error) {
      console.error('Failed to submit device request:', error);
      alert('Failed to submit request. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <View style={styles.root}>
        <View style={styles.successView}>
          <View style={styles.successIcon}>
            <MaterialCommunityIcons name="cellphone-check" size={48} color="#FFF" />
          </View>
          <Text style={styles.successTitle}>Request Submitted!</Text>
          <Text style={styles.successSub}>
            Your device change request has been sent to your manager for approval. You'll be notified once it's processed.
          </Text>
          <Pressable style={styles.doneBtn} onPress={() => router.replace('/(employee)/(tabs)')}>
            <Text style={styles.doneBtnText}>Back to Dashboard</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <PageHeader title="Device Request" subtitle="Request a new device or replacement" />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <View style={styles.infoBanner}>
          <MaterialCommunityIcons name="information-outline" size={18} color={T.purpleIcon} />
          <Text style={styles.infoBannerText}>
            Attendance is tied to your registered device. Request a device change if you've switched phones.
          </Text>
        </View>

        <Text style={styles.sectionTitle}>Reason for Device Change</Text>
        {REASONS.map((r) => (
          <Pressable
            key={r}
            style={[styles.reasonPill, selectedReason === r && styles.reasonPillActive]}
            onPress={() => setSelectedReason(r)}
          >
            <View style={[styles.radio, selectedReason === r && styles.radioActive]}>
              {selectedReason === r && <View style={styles.radioInner} />}
            </View>
            <Text style={[styles.reasonText, selectedReason === r && styles.reasonTextActive]}>{r}</Text>
          </Pressable>
        ))}

        {selectedReason === 'Other' && (
          <TextInput
            style={styles.input}
            placeholder="Describe your reason..."
            placeholderTextColor={T.textMuted}
            value={customReason}
            onChangeText={setCustomReason}
            multiline
            numberOfLines={3}
            textAlignVertical="top"
          />
        )}

        <Pressable
          style={[styles.submitBtn, (!finalReason || submitting) && styles.submitBtnDisabled]}
          onPress={handleSubmit}
          disabled={!finalReason || submitting}
        >
          {submitting ? (
            <ActivityIndicator color="#FFF" />
          ) : (
            <>
              <MaterialCommunityIcons name="send-outline" size={16} color="#FFF" />
              <Text style={styles.submitBtnText}>Submit Request</Text>
            </>
          )}
        </Pressable>
        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: T.screenBg },
  scroll: { paddingHorizontal: 20 },
  infoBanner: { flexDirection: 'row', gap: 10, alignItems: 'flex-start', backgroundColor: T.purpleLight, borderRadius: 12, padding: 14, marginBottom: 16 },
  infoBannerText: { flex: 1, fontSize: 13, color: T.purpleIcon, lineHeight: 18 },
  sectionTitle: { fontSize: 13, fontWeight: '700', color: T.purpleDark, marginBottom: 10, letterSpacing: 0.4 },
  reasonPill: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#FFF', borderRadius: 14, padding: 14, marginBottom: 8, borderWidth: 1.5, borderColor: '#E8E4EC' },
  reasonPillActive: { borderColor: T.purpleIcon, backgroundColor: T.purpleLight },
  radio: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: '#CCC', alignItems: 'center', justifyContent: 'center' },
  radioActive: { borderColor: T.purpleIcon },
  radioInner: { width: 10, height: 10, borderRadius: 5, backgroundColor: T.purpleIcon },
  reasonText: { fontSize: 14, color: T.purpleDark },
  reasonTextActive: { fontWeight: '600', color: T.purpleIcon },
  input: { backgroundColor: '#FFF', borderRadius: 12, paddingHorizontal: 14, paddingTop: 12, paddingBottom: 12, fontSize: 14, color: T.purpleDark, borderWidth: 1, borderColor: '#E8E4EC', marginBottom: 16, minHeight: 80 },
  submitBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: T.purpleIcon, borderRadius: 14, height: 54, marginTop: 8 },
  submitBtnDisabled: { opacity: 0.4 },
  submitBtnText: { color: '#FFF', fontSize: 15, fontWeight: '700' },
  successView: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28 },
  successIcon: { width: 100, height: 100, borderRadius: 50, backgroundColor: T.purpleIcon, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  successTitle: { fontSize: 26, fontWeight: '800', color: T.purpleDark, marginBottom: 10 },
  successSub: { fontSize: 14, color: T.textMuted, textAlign: 'center', lineHeight: 20, marginBottom: 30 },
  doneBtn: { backgroundColor: T.purpleIcon, borderRadius: 14, height: 50, justifyContent: 'center', alignItems: 'center', width: '100%' },
  doneBtnText: { color: '#FFF', fontSize: 15, fontWeight: '700' },
});
