import { Toast } from "@/components/Toast";
import { createRequest } from "@/services/request.service";
import React, { useState } from 'react';
import {
  StyleSheet, Text, View, ScrollView,
  Pressable, TextInput, TouchableOpacity,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { PageHeader } from '@/components/PageHeader';

const P_DARK  = '#5B3D7A';
const P_MED   = '#7B5EA7';
const P_ICON  = '#6B4E8D';
const P_LIGHT = '#EBE0F5';
const P_BG    = '#F3EDF7';

const WFH_REASONS = [
  'Personal Work',
  'Home Emergency',
  'Medical / Health',
  'Family Obligation',
  'Poor Weather / Travel Issues',
  'Other',
];

export default function ApplyWFHScreen() {
  const router = useRouter();

  const [selectedReason, setSelectedReason] = useState("");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(new Date());

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const [toast, setToast] = useState<{
    visible: boolean;
    message: string;
    type: "success" | "error" | "info";
  }>({
    visible: false,
    message: "",
    type: "info",
  });

  const handleApplyWFH = async () => {
    if (!selectedReason) {
      setToast({
        visible: true,
        message: "Please select a reason.",
        type: "error",
      });
      return;
    }

    if (note.trim() === "") {
      setToast({
        visible: true,
        message: "Please enter a reason.",
        type: "error",
      });
      return;
    }

    try {
      setLoading(true);

      await createRequest({
        requestType: "WFH",
        startDate: date.toISOString().split("T")[0],
        endDate: date.toISOString().split("T")[0],
        reason: `${selectedReason}\n${note}`,
      });

      setToast({
        visible: true,
        message: "WFH request submitted successfully!",
        type: "success",
      });

      setSubmitted(true);

      setTimeout(() => {
        router.back();
      }, 1500);

    } catch (error: any) {
      console.error("WFH Request Error:", error);

      setToast({
        visible: true,
        message: error?.message || "Failed to submit WFH request.",
        type: "error",
      });

    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
        <View style={styles.successContainer}>
          <View style={styles.successCircle}>
            <MaterialCommunityIcons
                name="check-circle"
                size={60}
                color={P_ICON}
            />
          </View>

          <Text style={styles.successTitle}>
            WFH Request Submitted!
          </Text>

          <Text style={styles.successSub}>
            Your manager will review it shortly.
          </Text>
        </View>
    );
  }

  return (
      <View style={styles.container}>

        <Toast
            visible={toast.visible}
            message={toast.message}
            type={toast.type}
            onDismiss={() =>
                setToast({
                  ...toast,
                  visible: false,
                })
            }
        />

        <PageHeader
            title="Apply WFH"
            subtitle="Work From Home Request"
        />

        <ScrollView
            contentContainerStyle={styles.scroll}
            showsVerticalScrollIndicator={false}
        >
          {/* Date card */}
          <View style={styles.dateCard}>
            <MaterialCommunityIcons
                name="calendar-today"
                size={22}
                color={P_ICON}
            />

            <View style={{ marginLeft: 12 }}>
              <Text style={styles.dateLabel}>
                Requested Date
              </Text>

              <Text style={styles.dateValue}>
                {date.toLocaleDateString("en-IN", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}
              </Text>
            </View>
          </View>

          {/* Reason selection */}
          <Text style={styles.sectionLabel}>
            Reason for WFH
          </Text>

          <View style={styles.reasonGrid}>
            {WFH_REASONS.map((reason) => (
                <Pressable
                    key={reason}
                    style={[
                      styles.reasonChip,
                      selectedReason === reason &&
                      styles.reasonChipActive,
                    ]}
                    onPress={() =>
                        setSelectedReason(reason)
                    }
                >
                  <Text
                      style={[
                        styles.reasonText,
                        selectedReason === reason &&
                        styles.reasonTextActive,
                      ]}
                  >
                    {reason}
                  </Text>
                </Pressable>
            ))}
          </View>

          {/* Note */}
          <Text style={styles.sectionLabel}>
            Additional Note
          </Text>

          <TextInput
              style={styles.noteInput}
              placeholder="Add any details for your manager..."
              placeholderTextColor={P_MED}
              multiline
              numberOfLines={4}
              value={note}
              onChangeText={setNote}
              textAlignVertical="top"
          />

          {/* Policy */}
          <View style={styles.policyCard}>
            <Ionicons
                name="information-circle-outline"
                size={18}
                color={P_ICON}
                style={{
                  marginRight: 8,
                  marginTop: 1,
                }}
            />

            <Text style={styles.policyText}>
              WFH requests should be submitted at least
              1 day in advance. Subject to manager
              approval.
            </Text>
          </View>

          {/* Submit */}
          <TouchableOpacity
              style={[
                styles.submitBtn,
                (!selectedReason || loading) &&
                styles.submitBtnDis,
              ]}
              onPress={handleApplyWFH}
              disabled={!selectedReason || loading}
          >
            <Ionicons
                name="checkmark-circle-outline"
                size={20}
                color="#FFF"
                style={{ marginRight: 8 }}
            />

            <Text style={styles.submitText}>
              {loading
                  ? "Submitting..."
                  : "Submit WFH Request"}
            </Text>
          </TouchableOpacity>

          <View style={{ height: 100 }} />
        </ScrollView>
      </View>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: P_BG },

  successContainer: {
    flex: 1, backgroundColor: P_BG,
    alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 32,
  },
  successCircle: {
    width: 110, height: 110, borderRadius: 55,
    backgroundColor: P_LIGHT, justifyContent: 'center', alignItems: 'center',
    marginBottom: 24,
  },
  successTitle: { fontSize: 22, fontWeight: '700', color: P_DARK, marginBottom: 8 },
  successSub:   { fontSize: 14, color: P_MED, textAlign: 'center' },

  scroll: { paddingHorizontal: 20, paddingTop: 4 },

  dateCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#FFF', borderRadius: 14, padding: 16,
    marginBottom: 22,
    shadowColor: P_DARK, shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.07, shadowRadius: 6, elevation: 2,
  },
  dateLabel: { fontSize: 11, color: P_MED, fontWeight: '600' },
  dateValue: { fontSize: 15, fontWeight: '700', color: P_DARK, marginTop: 2 },

  sectionLabel: { fontSize: 14, fontWeight: '700', color: P_DARK, marginBottom: 12 },

  reasonGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 22 },
  reasonChip: {
    paddingHorizontal: 16, paddingVertical: 10,
    borderRadius: 24, borderWidth: 1.5, borderColor: '#D4C5E2',
    backgroundColor: '#FFF',
  },
  reasonChipActive: { backgroundColor: P_ICON, borderColor: P_ICON },
  reasonText:       { fontSize: 13, color: P_MED, fontWeight: '500' },
  reasonTextActive: { color: '#FFF', fontWeight: '700' },

  noteInput: {
    backgroundColor: '#FFF', borderRadius: 14,
    borderWidth: 1.5, borderColor: '#D4C5E2',
    paddingHorizontal: 16, paddingVertical: 14,
    fontSize: 14, color: P_DARK,
    minHeight: 100, marginBottom: 22,
  },

  policyCard: {
    flexDirection: 'row', alignItems: 'flex-start',
    backgroundColor: P_LIGHT, borderRadius: 12, padding: 14,
    marginBottom: 24,
  },
  policyText: { flex: 1, fontSize: 12, color: P_MED, lineHeight: 18 },

  submitBtn: {
    backgroundColor: P_ICON, borderRadius: 14,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    paddingVertical: 15,
  },
  submitBtnDis: { opacity: 0.5 },
  submitText: { fontSize: 16, fontWeight: '700', color: '#FFF' },
});
//new