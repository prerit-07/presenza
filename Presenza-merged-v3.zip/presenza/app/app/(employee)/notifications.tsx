// app/notifications.tsx
// Role: All
// Opens from: Bell icon on all dashboards

import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { PageHeader } from '@/components/PageHeader';

type Notification = {
  id: string;
  icon: keyof typeof MaterialCommunityIcons.glyphMap;
  iconColor: string;
  title: string;
  body: string;
  time: string;
  read: boolean;
};

const MOCK_NOTIFICATIONS: Notification[] = [
  { id: '1', icon: 'calendar-check-outline', iconColor: '#4CAF50', title: 'Attendance Marked', body: 'Check-in recorded at 09:02 AM today.', time: '10 min ago', read: false },
  { id: '2', icon: 'calendar-clock', iconColor: '#F59E0B', title: 'Leave Request Update', body: 'Your Casual Leave for Jul 15 was approved.', time: '2h ago', read: false },
  { id: '3', icon: 'cellphone-key', iconColor: T.purpleIcon, title: 'Device Request Pending', body: 'Your device change request is awaiting approval.', time: '1d ago', read: true },
  { id: '4', icon: 'account-plus-outline', iconColor: '#4CAF50', title: 'New Team Member', body: 'Priya Mehta joined your team in Design.', time: '2d ago', read: true },
  { id: '5', icon: 'map-marker-alert-outline', iconColor: '#B23A48', title: 'Check-in Failed', body: 'GPS validation failed at 09:15 AM on Jul 6.', time: '3d ago', read: true },
];

export default function NotificationsScreen() {
  const router = useRouter();
  const [notifications, setNotifications] = useState(MOCK_NOTIFICATIONS);

  const markAllRead = () =>
    setNotifications((ns) => ns.map((n) => ({ ...n, read: true })));

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <View style={styles.root}>
      <PageHeader
        title="Notifications"
        subtitle={unreadCount > 0 ? `${unreadCount} unread` : undefined}
        rightElement={
          unreadCount > 0 ? (
            <Pressable onPress={markAllRead}>
              <Text style={styles.markAllText}>Mark all read</Text>
            </Pressable>
          ) : undefined
        }
      />

      <FlatList
        data={notifications}
        keyExtractor={(n) => n.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <Pressable
            style={[styles.notifCard, !item.read && styles.notifCardUnread]}
            onPress={() => setNotifications((ns) => ns.map((n) => n.id === item.id ? { ...n, read: true } : n))}
          >
            <View style={[styles.iconWrap, { backgroundColor: item.iconColor + '18' }]}>
              <MaterialCommunityIcons name={item.icon} size={20} color={item.iconColor} />
            </View>
            <View style={styles.notifInfo}>
              <Text style={styles.notifTitle}>{item.title}</Text>
              <Text style={styles.notifBody}>{item.body}</Text>
              <Text style={styles.notifTime}>{item.time}</Text>
            </View>
            {!item.read && <View style={styles.unreadDot} />}
          </Pressable>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons name="bell-check-outline" size={48} color={T.textMuted} />
            <Text style={styles.emptyText}>All caught up!</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: T.screenBg },
  markAllText: { fontSize: 12, fontWeight: '600', color: T.purpleIcon },
  list: { paddingHorizontal: 20, paddingBottom: 100 },
  notifCard: { flexDirection: 'row', alignItems: 'flex-start', backgroundColor: '#FFF', borderRadius: 14, padding: 14, marginBottom: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 4, elevation: 2 },
  notifCardUnread: { borderLeftWidth: 3, borderLeftColor: T.purpleIcon },
  iconWrap: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  notifInfo: { flex: 1 },
  notifTitle: { fontSize: 13, fontWeight: '700', color: T.purpleDark, marginBottom: 3 },
  notifBody: { fontSize: 12, color: T.textMuted, lineHeight: 17, marginBottom: 4 },
  notifTime: { fontSize: 10, color: '#C4C4C4' },
  unreadDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: T.purpleIcon, marginTop: 4 },
  empty: { alignItems: 'center', marginTop: 80, gap: 10 },
  emptyText: { fontSize: 14, color: T.textMuted },
});
