import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  SafeAreaView,
  Pressable,
} from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { router } from 'expo-router';
import { useAppStore } from '@/store/useAppStore';
import { Theme } from '@/constants/theme';
import { AuthHeader } from '@/components/AuthHeader';
import { TextInput } from '@/components/TextInput';
import { PasswordInput } from '@/components/PasswordInput';
import { Button } from '@/components/Button';
import { SocialLoginButton } from '@/components/SocialLoginButton';
import { Toast } from '../../components/Toast';

export default function RegisterScreen() {
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ visible: boolean; message: string; type: 'success' | 'error' | 'info' }>({
    visible: false,
    message: '',
    type: 'info',
  });
  const register = useAppStore((state) => state.register);

  const {
    control,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm({
    defaultValues: {
      email: '',
      password: '',
      confirmPassword: '',
    },
  });

  const passwordVal = watch('password');

  const onSubmit = async (data: any) => {
    setLoading(true);
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 800));
    await register(data.email);
    setLoading(false);

    setToast({
      visible: true,
      message: 'OTP sent successfully to your email!',
      type: 'success',
    });

    setTimeout(() => {
      router.push('/(auth)/otp-verification');
    }, 1000);
  };

  const handleSocialPress = (provider: string) => {
    setToast({
      visible: true,
      message: `Simulating sign-in with ${provider}`,
      type: 'info',
    });
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <Toast
        visible={toast.visible}
        message={toast.message}
        type={toast.type}
        onDismiss={() => setToast({ ...toast, visible: false })}
      />
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          bounces={false}
        >
          {/* Logo and Mascot */}
          <AuthHeader />

          {/* Form Card */}
          <View style={styles.formContainer}>
            {/* Email Field */}
            <Controller
              control={control}
              name="email"
              rules={{
                required: 'Email address is required',
                pattern: {
                  value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                  message: 'Invalid email address',
                },
              }}
              render={({ field: { onChange, onBlur, value, ref } }) => (
                <TextInput
                  ref={ref}
                  label="Email Address"
                  placeholder="Email Address"
                  onBlur={onBlur}
                  onChangeText={onChange}
                  value={value}
                  error={errors.email?.message}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                  inputStyle={styles.input}
                  labelStyle={styles.label}
                />
              )}
            />

            {/* Password Field */}
            <Controller
              control={control}
              name="password"
              rules={{
                required: 'Password is required',
                minLength: {
                  value: 8,
                  message: 'Password must be at least 8 characters',
                },
                validate: {
                  hasUppercase: (value) =>
                    /[A-Z]/.test(value) || 'Password must have at least one uppercase letter',
                  hasLowercase: (value) =>
                    /[a-z]/.test(value) || 'Password must have at least one lowercase letter',
                  hasNumber: (value) =>
                    /[0-9]/.test(value) || 'Password must have at least one number',
                },
              }}
              render={({ field: { onChange, onBlur, value, ref } }) => (
                <PasswordInput
                  ref={ref}
                  onBlur={onBlur}
                  label="Password"
                  placeholder="Password"
                  onChangeText={onChange}
                  value={value}
                  error={errors.password?.message}
                  inputStyle={styles.input}
                  labelStyle={styles.label}
                />
              )}
            />

            {/* Confirm Password Field */}
            <Controller
              control={control}
              name="confirmPassword"
              rules={{
                required: 'Confirm password is required',
                validate: (value) =>
                  value === passwordVal || 'Passwords do not match',
              }}
              render={({ field: { onChange, onBlur, value, ref } }) => (
                <PasswordInput
                  ref={ref}
                  onBlur={onBlur}
                  label="Confirm Password"
                  placeholder="Confirm Password"
                  onChangeText={onChange}
                  value={value}
                  error={errors.confirmPassword?.message}
                  inputStyle={styles.input}
                  labelStyle={styles.label}
                />
              )}
            />

            {/* Submit Button */}
            <Button
              title="Send OTP"
              onPress={handleSubmit(onSubmit)}
              loading={loading}
              style={styles.button}
            />

            {/* Already have an account */}
            <View style={styles.loginContainer}>
              <Text style={styles.loginText}>Already have an account? </Text>
              <Pressable onPress={() => router.push('/(auth)/company-verification')}>
                <Text style={styles.signUpLink}>Sign Up</Text>
              </Pressable>
            </View>

            {/* Divider */}
            <View style={styles.dividerContainer}>
              <View style={styles.dividerLine} />
              <Text style={styles.dividerText}>Or sign in with</Text>
              <View style={styles.dividerLine} />
            </View>

            {/* Social Logins */}
            <View style={styles.socialContainer}>
              <SocialLoginButton
                provider="google"
                onPress={() => handleSocialPress('Google')}
              />
              <SocialLoginButton
                provider="apple"
                onPress={() => handleSocialPress('Apple')}
                style={styles.socialMargin}
              />
              <SocialLoginButton
                provider="facebook"
                onPress={() => handleSocialPress('Facebook')}
              />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#3E226B',
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'flex-start',
  },
  formContainer: {
    flex: 1,
    backgroundColor: '#C4B5E2', // Soft light purple background matching screenshot 3
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    paddingHorizontal: 28,
    paddingTop: 30,
    paddingBottom: 40,
    marginTop: -4,
  },
  label: {
    color: '#2F2440',
    fontFamily: Theme.typography.fontFamily.medium,
  },
  input: {
    backgroundColor: 'rgba(255, 255, 255, 0.6)',
    borderColor: 'transparent',
  },
  button: {
    backgroundColor: '#2F2440',
    marginTop: 12,
  },
  loginContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 18,
  },
  loginText: {
    fontSize: 13,
    fontFamily: Theme.typography.fontFamily.medium,
    color: '#605278',
  },
  signUpLink: {
    fontSize: 13,
    fontFamily: Theme.typography.fontFamily.bold,
    color: '#2F2440',
  },
  dividerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 24,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(96, 82, 120, 0.2)',
  },
  dividerText: {
    fontSize: 12,
    fontFamily: Theme.typography.fontFamily.medium,
    color: '#605278',
    marginHorizontal: 12,
  },
  socialContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  socialMargin: {
    marginHorizontal: 24,
  },
});

