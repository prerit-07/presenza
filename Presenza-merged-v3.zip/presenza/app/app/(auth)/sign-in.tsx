// app/(auth)/sign-in.tsx
// Role: All users — Employee, Manager, Admin
// Opens from: App start
// Navigates according to authenticated backend role
// API: services/auth.service.ts → login()

import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Pressable,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Image,
  ImageBackground,
} from 'react-native';

import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import { login } from '@/services/auth.service';
import { useAuthStore } from '@/store/auth.store';
import { DashboardTheme as T } from '@/constants/dashboard-theme';

export default function LoginScreen() {
  const router = useRouter();

  const setAuthenticatedUser = useAuthStore(
    (state) => state.setAuthenticatedUser
  );

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const navigateByRole = (role: string) => {
    switch (role) {
      case 'ORG_ADMIN':
        router.replace('/(organization)/(tabs)/overview');
        break;

      case 'MANAGER':
        router.replace('/(manager)/(tabs)');
        break;

      case 'EMPLOYEE':
        router.replace('/(employee)/(tabs)');
        break;

      default:
        setError(`Unsupported role: ${role}`);
    }
  };

  const handleLogin = async () => {
    setError('');
    setLoading(true);

    try {
      const result = await login({
        email: email.trim(),
        password,
      });

      if (result.success && result.user) {
        // This also syncs the existing useAppStore internally.
        setAuthenticatedUser(result.user);

        if (result.mustChangePassword) {
          router.replace('/(auth)/change-password');
          return;
        }

        // Navigate using the real role returned by /auth/me.
        navigateByRole(result.user.role);
      } else {
        setError(
          result.error ??
            'Login failed. Please try again.'
        );
      }
    } catch {
      setError(
        'Something went wrong. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <ImageBackground
      source={require('@/assets/images/auth-background.png')}
      style={styles.background}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.root}>
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={
            Platform.OS === 'ios'
              ? 'padding'
              : undefined
          }
        >
          <ScrollView
            contentContainerStyle={styles.scroll}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            {/* Logo + Brand */}
            <View style={styles.logoArea}>
              <Image
                source={require(
                  '@/assets/images/presenza-logo-dark.png'
                )}
                style={styles.logo}
                resizeMode="contain"
              />
            </View>

            {/* Card */}
            <View style={styles.card}>
              <Text style={styles.cardTitle}>
                Welcome back
              </Text>

              <Text style={styles.cardSubtitle}>
                Log in to your account
              </Text>

              {/* Email */}
              <Text style={styles.label}>
                Email Address
              </Text>

              <View style={styles.inputWrap}>
                <MaterialCommunityIcons
                  name="email-outline"
                  size={18}
                  color={T.textMuted}
                />

                <TextInput
                  style={styles.input}
                  placeholder="your@email.com"
                  placeholderTextColor={T.textMuted}
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                  editable={!loading}
                />
              </View>

              {/* Password */}
              <Text style={styles.label}>
                Password
              </Text>

              <View style={styles.inputWrap}>
                <MaterialCommunityIcons
                  name="lock-outline"
                  size={18}
                  color={T.textMuted}
                />

                <TextInput
                  style={styles.input}
                  placeholder="Enter your password"
                  placeholderTextColor={T.textMuted}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                  editable={!loading}
                  onSubmitEditing={handleLogin}
                  returnKeyType="done"
                />

                <Pressable
                  onPress={() =>
                    setShowPassword((previous) => !previous)
                  }
                  disabled={loading}
                >
                  <MaterialCommunityIcons
                    name={
                      showPassword
                        ? 'eye-off-outline'
                        : 'eye-outline'
                    }
                    size={18}
                    color={T.textMuted}
                  />
                </Pressable>
              </View>

              {/* Error */}
              {error ? (
                <View style={styles.errorBox}>
                  <MaterialCommunityIcons
                    name="alert-circle-outline"
                    size={14}
                    color="#B23A48"
                  />

                  <Text style={styles.errorText}>
                    {error}
                  </Text>
                </View>
              ) : null}

              {/* Forgot Password */}
              <Pressable
                style={styles.forgotRow}
                onPress={() =>
                  router.push(
                    '/(auth)/forgot-password'
                  )
                }
              >
                <Text style={styles.forgotText}>
                  Forgot Password?
                </Text>
              </Pressable>

              {/* Login Button */}
              <Pressable
                style={[
                  styles.loginBtn,
                  loading &&
                    styles.loginBtnDisabled,
                ]}
                onPress={handleLogin}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator
                    color="#FFF"
                    size="small"
                  />
                ) : (
                  <Text style={styles.loginBtnText}>
                    Log In
                  </Text>
                )}
              </Pressable>
            </View>

            {/* Register link */}
            <View style={styles.signupRow}>
              <Text style={styles.signupText}>
                Creating an organization?{' '}
              </Text>

              <Pressable
                onPress={() =>
                  router.push(
                    '/(organization)/register'
                  )
                }
                disabled={loading}
              >
                <Text style={styles.signupLink}>
                  Register
                </Text>
              </Pressable>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  /* Background image */
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },

  root: {
    flex: 1,
    backgroundColor: 'transparent',
  },

  flex: {
    flex: 1,
  },

  scroll: {
    paddingHorizontal: 24,
    paddingBottom: 40,
  },

  /* Logo */
  logoArea: {
    alignItems: 'center',
    paddingTop: 90,
    paddingBottom: 30,
    marginBottom: 32,
  },

  logo: {
    width: 90,
    height: 90,
    transform: [
      { translateY: 60 },
      { scale: 10 },
    ],
  },

  /* Card */
  card: {
    backgroundColor: '#C5B5D8',
    borderRadius: 24,
    padding: 24,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.07,
    shadowRadius: 16,

    elevation: 4,
  },

  cardTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: T.purpleDark,
    marginBottom: 4,
  },

  cardSubtitle: {
    fontSize: 13,
    color: T.purpleMedium,
    marginBottom: 24,
  },

  /* Inputs */
  label: {
    fontSize: 12,
    fontWeight: '600',
    color: T.purpleDark,
    marginBottom: 6,
  },

  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',

    backgroundColor: T.screenBg,

    borderRadius: 12,
    paddingHorizontal: 14,
    height: 50,
    marginBottom: 16,

    borderWidth: 1,
    borderColor: '#E8E4EC',

    gap: 10,
  },

  input: {
    flex: 1,
    fontSize: 14,
    color: T.purpleDark,
  },

  /* Error */
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',

    gap: 6,

    backgroundColor: '#FFF1F3',

    borderRadius: 8,
    padding: 10,
    marginBottom: 12,
  },

  errorText: {
    fontSize: 12,
    color: '#B23A48',
    flex: 1,
  },

  /* Forgot */
  forgotRow: {
    alignItems: 'flex-end',
    marginTop: -8,
    marginBottom: 20,
  },

  forgotText: {
    fontSize: 12,
    color: T.purpleIcon,
    fontWeight: '600',
  },

  /* Login Btn */
  loginBtn: {
    backgroundColor: T.purpleIcon,

    borderRadius: 14,
    height: 52,

    alignItems: 'center',
    justifyContent: 'center',
  },

  loginBtnDisabled: {
    opacity: 0.6,
  },

  loginBtnText: {
    color: '#FFF',
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: 0.3,
  },

  /* Divider */
  divider: {
    flexDirection: 'row',
    alignItems: 'center',

    gap: 10,
    marginVertical: 20,
  },

  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#E8E4EC',
  },

  dividerText: {
    fontSize: 11,
    color: T.purpleMedium,
    fontWeight: '600',
  },

  /* Quick Login */
  quickRow: {
    flexDirection: 'row',
    gap: 8,
  },

  quickBtn: {
    flex: 1,

    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',

    gap: 5,

    borderWidth: 1.5,
    borderColor: T.purpleBorder,

    borderRadius: 10,
    paddingVertical: 10,

    backgroundColor: T.purpleLight,
  },

  quickBtnText: {
    fontSize: 11,
    fontWeight: '600',
    color: T.purpleIcon,
  },

  /* Sign Up */
  signupRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 24,
  },

  signupText: {
    fontSize: 13,
    color: T.textWhite,
  },

  signupLink: {
    fontSize: 13,
    color: T.purpleIcon,
    fontWeight: '700',
  },
});
