import React, { useState } from 'react';
import {
  StyleSheet,
  View,
} from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { router } from 'expo-router';
import { useAppStore } from '@/store/useAppStore';
import { AuthTheme } from '@/constants/auth-theme';
import AuthLayout from '@/components/AuthLayout';
import { TextInput } from '@/components/TextInput';
import { Button } from '@/components/Button';
import { Toast } from '../../components/Toast';

interface FormData {
  companyCode: string;
}

export default function CompanyVerificationScreen() {
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ visible: boolean; message: string; type: 'success' | 'error' | 'info' }>({
    visible: false,
    message: '',
    type: 'info',
  });
  const verifyCompany = useAppStore((state) => state.verifyCompany);

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>({
    defaultValues: {
      companyCode: '',
    },
  });

  const onSubmit = async (data: any) => {
    setLoading(true);
    try {
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 800));
      
      verifyCompany(data.companyCode);
      setLoading(false);
  
      router.replace("/(employee)/(tabs)");
    } catch (error) {
      setToast({
        visible: true,
        message: 'Invalid company code. Please try again.',
        type: 'error',
      });
      setLoading(false);
    }
  };

  return (
    <>
      <Toast
        visible={toast.visible}
        message={toast.message}
        type={toast.type}
        onDismiss={() => setToast({ ...toast, visible: false })}
      />
      <AuthLayout variant="dark" title="Company Verification" subtitle="Enter your company code to continue">
        <Controller
          control={control}
          name="companyCode"
          rules={{ required: 'Company code is required' }}
          render={({ field: { onChange, onBlur, value, ref } }) => (
            <TextInput
              ref={ref}
              label="Company Code"
              placeholder="Code"
              onBlur={onBlur}
              onChangeText={onChange}
              value={value}
              error={errors.companyCode?.message}
              autoCapitalize="none"
              autoCorrect={false}
              inputStyle={styles.input}
              labelStyle={styles.label}
              placeholderTextColor={AuthTheme.dark.inputPlaceholder}
            />
          )}
        />

        <Button
          title="Verify & Proceed"
          onPress={handleSubmit(onSubmit)}
          loading={loading}
          style={styles.button}
          textStyle={styles.buttonText}
        />
      </AuthLayout>
    </>
  );
}

const styles = StyleSheet.create({
  label: {
    color: AuthTheme.dark.label,
    fontWeight: '700',
    marginBottom: 8,
  },
  input: {
    backgroundColor: AuthTheme.dark.inputBackground,
    borderColor: 'transparent',
    color: AuthTheme.dark.inputText,
    borderRadius: 16,
    height: 56,
  },
  button: {
    backgroundColor: AuthTheme.dark.buttonBackground,
    marginTop: 32,
    borderRadius: 16,
    height: 56,
  },
  buttonText: {
    color: AuthTheme.dark.buttonText,
    fontWeight: '700',
    fontSize: 16,
  },
});


