import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Pressable,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Image,
  ImageBackground,
} from 'react-native';

import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import { resetPassword } from '@/services/auth.service';
import { DashboardTheme as T } from '@/constants/dashboard-theme';

function getParamValue(
  value: string | string[] | undefined
): string {
  if (Array.isArray(value)) {
    return value[0] ?? '';
  }

  return value ?? '';
}

export default function ResetPasswordScreen() {
  const router = useRouter();
  const params = useLocalSearchParams();

  const email = getParamValue(params.email);

  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (!success) {
      return;
    }

    const timer = setTimeout(() => {
      router.replace('/(auth)/sign-in');
    }, 1300);

    return () => clearTimeout(timer);
  }, [router, success]);

  const handleResetPassword = async () => {
    if (!email) {
      setError('Reset email is missing.');
      return;
    }

    const hasNewPassword = newPassword.length > 0;
    const hasConfirmPassword = confirmPassword.length > 0;

    if (!hasNewPassword || !hasConfirmPassword) {
      setError('All fields are required.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError('New password and confirm password must match.');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const response = await resetPassword({
        email,
        newPassword,
      });

      if (!response.success) {
        setError(response.message || 'Password reset failed. Please try again.');
        return;
      }

      setSuccess(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Password reset failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <ImageBackground
        source={require('@/assets/images/auth-background.png')}
        style={styles.background}
        resizeMode="cover"
      >
        <SafeAreaView style={styles.root}>
          <View style={styles.successView}>
            <View style={styles.successRing}>
              <MaterialCommunityIcons
                name="check-bold"
                size={44}
                color="#FFF"
              />
            </View>

            <Text style={styles.successTitle}>
              Password reset successfully.
            </Text>

            <Text style={styles.successSub}>
              You can now sign in with your new password.
            </Text>
          </View>
        </SafeAreaView>
      </ImageBackground>
    );
  }

  return (
    <ImageBackground
      source={require('@/assets/images/auth-background.png')}
      style={styles.background}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.root}>
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <ScrollView
            contentContainerStyle={styles.scroll}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            <View style={styles.logoArea}>
              <Image
                source={require('@/assets/images/presenza-logo-dark.png')}
                style={styles.logo}
                resizeMode="contain"
              />
            </View>

            <View style={styles.card}>
              <Text style={styles.cardTitle}>Reset password</Text>

              <Text style={styles.cardSubtitle}>
                Set a new password to continue
              </Text>

              <Text style={styles.label}>New Password</Text>

              <View style={styles.inputWrap}>
                <MaterialCommunityIcons
                  name="lock-outline"
                  size={18}
                  color={T.textMuted}
                />

                <TextInput
                  style={styles.input}
                  placeholder="Enter new password"
                  placeholderTextColor={T.textMuted}
                  value={newPassword}
                  onChangeText={setNewPassword}
                  secureTextEntry={!showNewPassword}
                  editable={!loading}
                  returnKeyType="next"
                />

                <Pressable
                  onPress={() => setShowNewPassword((previous) => !previous)}
                  disabled={loading}
                >
                  <MaterialCommunityIcons
                    name={showNewPassword ? 'eye-off-outline' : 'eye-outline'}
                    size={18}
                    color={T.textMuted}
                  />
                </Pressable>
              </View>

              <Text style={styles.label}>Confirm Password</Text>

              <View style={styles.inputWrap}>
                <MaterialCommunityIcons
                  name="lock-outline"
                  size={18}
                  color={T.textMuted}
                />

                <TextInput
                  style={styles.input}
                  placeholder="Confirm new password"
                  placeholderTextColor={T.textMuted}
                  value={confirmPassword}
                  onChangeText={setConfirmPassword}
                  secureTextEntry={!showConfirmPassword}
                  editable={!loading}
                  onSubmitEditing={handleResetPassword}
                  returnKeyType="done"
                />

                <Pressable
                  onPress={() => setShowConfirmPassword((previous) => !previous)}
                  disabled={loading}
                >
                  <MaterialCommunityIcons
                    name={showConfirmPassword ? 'eye-off-outline' : 'eye-outline'}
                    size={18}
                    color={T.textMuted}
                  />
                </Pressable>
              </View>

              {error ? (
                <View style={styles.errorBox}>
                  <MaterialCommunityIcons
                    name="alert-circle-outline"
                    size={14}
                    color="#B23A48"
                  />
                  <Text style={styles.errorText}>
                    {error}
                  </Text>
                </View>
              ) : null}

              <Pressable
                style={[
                  styles.loginBtn,
                  loading && styles.loginBtnDisabled,
                ]}
                onPress={handleResetPassword}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#FFF" size="small" />
                ) : (
                  <Text style={styles.loginBtnText}>
                    Reset Password
                  </Text>
                )}
              </Pressable>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  root: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  flex: {
    flex: 1,
  },
  scroll: {
    paddingHorizontal: 24,
    paddingBottom: 40,
  },
  logoArea: {
    alignItems: 'center',
    paddingTop: 90,
    paddingBottom: 30,
    marginBottom: 32,
  },
  logo: {
    width: 90,
    height: 90,
    transform: [
      { translateY: 60 },
      { scale: 10 },
    ],
  },
  card: {
    backgroundColor: '#C5B5D8',
    borderRadius: 24,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.07,
    shadowRadius: 16,
    elevation: 4,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: T.purpleDark,
    marginBottom: 4,
  },
  cardSubtitle: {
    fontSize: 13,
    color: T.purpleMedium,
    marginBottom: 24,
  },
  label: {
    fontSize: 12,
    fontWeight: '600',
    color: T.purpleDark,
    marginBottom: 6,
  },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: T.screenBg,
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 50,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#E8E4EC',
    gap: 10,
  },
  input: {
    flex: 1,
    fontSize: 14,
    color: T.purpleDark,
  },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#FFF1F3',
    borderRadius: 8,
    padding: 10,
    marginBottom: 12,
  },
  errorText: {
    flex: 1,
    fontSize: 12,
    color: '#B23A48',
  },
  loginBtn: {
    backgroundColor: T.purpleIcon,
    borderRadius: 14,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loginBtnDisabled: {
    opacity: 0.7,
  },
  loginBtnText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '700',
  },
  successView: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  successRing: {
    width: 84,
    height: 84,
    borderRadius: 42,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: T.purpleIcon,
    marginBottom: 20,
  },
  successTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: T.purpleDark,
    textAlign: 'center',
  },
  successSub: {
    marginTop: 10,
    fontSize: 13,
    lineHeight: 18,
    color: T.purpleMedium,
    textAlign: 'center',
  },
});
