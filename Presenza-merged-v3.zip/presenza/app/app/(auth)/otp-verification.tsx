import React, { useEffect, useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Pressable,
  TextInput,
} from 'react-native';

import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

import AuthLayout from '@/components/AuthLayout';
import { Toast } from '../../components/Toast';

import { AuthTheme } from '@/constants/auth-theme';

import {
  sendOtp,
  verifyOtp,
  forgotPassword,
  verifyPasswordResetOtp,
} from '@/services/auth.service';

import { useOnboardingStore } from '@/store/onboarding.store';
import { useAppStore } from '@/store/useAppStore';

const C = AuthTheme.dark;

const PASSWORD_RESET = 'PASSWORD_RESET';

const STEPS = [
  { id: 1, label: 'Organization' },
  { id: 2, label: 'Admin' },
  { id: 3, label: 'Verify' },
  { id: 4, label: 'Plan' },
  { id: 5, label: 'Review' },
];

function param(value: string | string[] | undefined): string {
  if (Array.isArray(value)) {
    return value[0] ?? '';
  }

  return value ?? '';
}

export default function OtpScreen() {
  const params = useLocalSearchParams();

  const flow = param(params.flow);
  const purpose = param(params.purpose);
  const resetEmail = param(params.email);

  const adminEmail = useOnboardingStore((state) => state.email);
  const saveOtp = useAppStore((state) => state.verifyOtp);

  const isPasswordReset = purpose === PASSWORD_RESET;
  const isAdminFlow = flow === 'admin' && !isPasswordReset;

  const displayEmail = isPasswordReset ? resetEmail : adminEmail ?? '';

  const [loading, setLoading] = useState(false);
  const [otpValue, setOtpValue] = useState('');
  const [timerCount, setTimerCount] = useState(30);
  const [toast, setToast] = useState<{
    visible: boolean;
    message: string;
    type: 'success' | 'error' | 'info';
  }>({
    visible: false,
    message: '',
    type: 'info',
  });

  useEffect(() => {
    if (timerCount <= 0) {
      return;
    }

    const timer = setInterval(() => {
      setTimerCount((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timerCount]);

  const handleResend = async () => {
    if (timerCount > 0) {
      return;
    }

    try {
      if (isPasswordReset) {
        if (!resetEmail) {
          throw new Error('Email not found.');
        }

        await forgotPassword(resetEmail);
      } else {
        if (!adminEmail) {
          throw new Error('Email not found.');
        }

        await sendOtp({
          email: adminEmail,
          purpose: 'REGISTRATION',
        });
      }

      setTimerCount(30);

      setToast({
        visible: true,
        message: 'OTP sent successfully.',
        type: 'success',
      });
    } catch (error) {
      setToast({
        visible: true,
        message:
          error instanceof Error ? error.message : 'Failed to resend OTP.',
        type: 'error',
      });
    }
  };

  const handleVerify = async () => {
    if (otpValue.length !== 6) {
      setToast({
        visible: true,
        message: 'Please enter a valid 6-digit OTP.',
        type: 'error',
      });

      return;
    }

    try {
      setLoading(true);

      if (isPasswordReset) {
        if (!resetEmail) {
          throw new Error('Email not found.');
        }

        const response = await verifyPasswordResetOtp({
          email: resetEmail,
          otp: otpValue,
        });

        if (!response.success) {
          throw new Error(response.message);
        }

        setToast({
          visible: true,
          message: response.message,
          type: 'success',
        });

        router.replace({
          pathname: '/(auth)/reset-password',
          params: {
            email: resetEmail,
          },
        });

        return;
      }

      if (!adminEmail) {
        throw new Error('Email not found.');
      }

      const response = await verifyOtp({
        email: adminEmail,
        otp: otpValue,
        purpose: 'REGISTRATION',
      });

      if (!response.success) {
        throw new Error(response.message);
      }

      saveOtp(otpValue);

      setToast({
        visible: true,
        message: 'OTP verified successfully.',
        type: 'success',
      });

      setTimeout(() => {
        router.replace('/(organization)/plan');
      }, 500);
    } catch (error) {
      setToast({
        visible: true,
        message:
          error instanceof Error ? error.message : 'Verification failed.',
        type: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <AuthLayout
        variant="dark"
        title="OTP Verification"
        subtitle={`Enter the 6-digit verification code sent to\n${displayEmail}`}
      >
        {isAdminFlow && (
          <View style={styles.stepsContainer}>
            <View style={styles.stepsRow}>
              {STEPS.map((step, index) => {
                const currentStep = 3;
                const isActive = step.id === currentStep;
                const isCompleted = step.id < currentStep;
                const isLast = index === STEPS.length - 1;

                return (
                  <View key={step.id} style={styles.stepSlot}>
                    {!isLast && (
                      <View
                        style={[
                          styles.stepConnector,
                          {
                            backgroundColor: isCompleted
                              ? C.progressCircleActive
                              : C.progressLine,
                          },
                        ]}
                      />
                    )}

                    <View style={styles.stepColumn}>
                      <View
                        style={[
                          styles.stepCircle,
                          {
                            backgroundColor:
                              isActive || isCompleted
                                ? C.progressCircleActive
                                : C.progressCircleInactive,
                          },
                        ]}
                      >
                        {isCompleted ? (
                          <Ionicons name="checkmark" size={16} color="#fff" />
                        ) : (
                          <Text
                            style={[
                              styles.stepNumber,
                              {
                                color: isActive
                                  ? C.progressTextActive
                                  : C.progressTextInactive,
                              },
                            ]}
                          >
                            {step.id}
                          </Text>
                        )}
                      </View>

                      <Text style={styles.stepLabel} numberOfLines={1}>
                        {step.label}
                      </Text>
                    </View>
                  </View>
                );
              })}
            </View>
          </View>
        )}

        <View style={styles.contentWrapper}>
          <TextInput
            style={styles.singleOtpInput}
            placeholder="OTP"
            placeholderTextColor={C.inputPlaceholder}
            keyboardType="number-pad"
            maxLength={6}
            value={otpValue}
            onChangeText={setOtpValue}
          />

          <View style={styles.timerContainer}>
            {timerCount > 0 ? (
              <Text style={styles.timerText}>
                Resend OTP in {timerCount}s
              </Text>
            ) : (
              <Pressable onPress={handleResend}>
                <Text style={styles.resendLink}>Resend OTP</Text>
              </Pressable>
            )}
          </View>

          <Pressable
            style={[
              styles.continueButton,
              otpValue.length !== 6 && styles.continueButtonDisabled,
            ]}
            disabled={loading || otpValue.length !== 6}
            onPress={handleVerify}
          >
            <Text style={styles.continueButtonText}>
              {loading ? 'Verifying...' : 'Verify OTP'}
            </Text>
          </Pressable>
        </View>
      </AuthLayout>

      {/* Toast Notification */}
      <Toast
        visible={toast.visible}
        message={toast.message}
        type={toast.type}
        onDismiss={() =>
          setToast((prev) => ({
            ...prev,
            visible: false,
          }))
        }
      />
    </>
  );
}

const styles = StyleSheet.create({
  contentWrapper: {
    paddingHorizontal: 16,
  },

  singleOtpInput: {
    backgroundColor: C.inputBackground,
    borderRadius: 14,
    paddingHorizontal: 16,
    height: 44,
    fontSize: 14,
    color: C.inputText,
    marginBottom: 8,
  },

  timerContainer: {
    alignItems: 'flex-end',
    marginBottom: 24,
  },

  timerText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#9e89b3',
  },

  resendLink: {
    fontSize: 12,
    fontWeight: '700',
    color: '#CAA6EC',
  },

  continueButton: {
    backgroundColor: C.buttonBackground,
    borderRadius: 16,
    height: 48,
    justifyContent: 'center',
    alignItems: 'center',
  },

  continueButtonDisabled: {
    opacity: 0.5,
  },

  continueButtonText: {
    color: C.buttonText,
    fontSize: 15,
    fontWeight: '600',
  },

  stepsContainer: {
    width: '100%',
    marginBottom: 32,
  },

  stepsRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    width: '100%',
  },

  stepSlot: {
    flex: 1,
    position: 'relative',
    alignItems: 'center',
  },

  stepColumn: {
    width: '100%',
    alignItems: 'center',
    zIndex: 2,
  },

  stepCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },

  stepNumber: {
    fontSize: 14,
    fontWeight: '700',
  },

  stepLabel: {
    width: '100%',
    fontSize: 11,
    color: C.title,
    marginTop: 4,
    textAlign: 'center',
  },

  stepConnector: {
    position: 'absolute',
    top: 15,
    left: '50%',
    width: '100%',
    height: 2,
    zIndex: 1,
  },
});
