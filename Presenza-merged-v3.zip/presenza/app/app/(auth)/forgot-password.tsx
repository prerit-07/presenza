import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Pressable,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Image,
  ImageBackground,
} from 'react-native';

import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import { forgotPassword } from '@/services/auth.service';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { Toast } from '../../components/Toast';

export default function ForgotPasswordScreen() {
  const router = useRouter();

  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [toast, setToast] = useState<{ visible: boolean; message: string; type: 'success' | 'error' | 'info' }>({
    visible: false,
    message: '',
    type: 'info',
  });

  const handleSendOtp = async () => {
    const trimmedEmail = email.trim().toLowerCase();

    if (!trimmedEmail) {
      setError('Email address is required.');
      return;
    }

    if (!/^\S+@\S+\.\S+$/.test(trimmedEmail)) {
      setError('Please enter a valid email address.');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const response = await forgotPassword(trimmedEmail);

      if (!response.success) {
        setError(response.message || 'Failed to send OTP. Please try again.');
        return;
      }

      setToast({
        visible: true,
        message: response.message || 'OTP sent successfully.',
        type: 'success',
      });

      setTimeout(() => {
        router.push(
          `/(auth)/otp-verification?purpose=PASSWORD_RESET&email=${encodeURIComponent(trimmedEmail)}`
        );
      }, 800);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send OTP. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ImageBackground
      source={require('@/assets/images/auth-background.png')}
      style={styles.background}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.root}>
        <KeyboardAvoidingView
          style={styles.flex}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <ScrollView
            contentContainerStyle={styles.scroll}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            <View style={styles.logoArea}>
              <Image
                source={require('@/assets/images/presenza-logo-dark.png')}
                style={styles.logo}
                resizeMode="contain"
              />
            </View>

            <View style={styles.card}>
              <Text style={styles.cardTitle}>Forgot password</Text>

              <Text style={styles.cardSubtitle}>
                Enter your email to receive a verification code
              </Text>

              <Text style={styles.label}>Email Address</Text>

              <View style={styles.inputWrap}>
                <MaterialCommunityIcons
                  name="email-outline"
                  size={18}
                  color={T.textMuted}
                />

                <TextInput
                  style={styles.input}
                  placeholder="your@email.com"
                  placeholderTextColor={T.textMuted}
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                  editable={!loading}
                />
              </View>

              {error ? (
                <View style={styles.errorBox}>
                  <MaterialCommunityIcons
                    name="alert-circle-outline"
                    size={14}
                    color="#B23A48"
                  />

                  <Text style={styles.errorText}>
                    {error}
                  </Text>
                </View>
              ) : null}

              <Pressable
                style={[
                  styles.loginBtn,
                  loading && styles.loginBtnDisabled,
                ]}
                onPress={handleSendOtp}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator
                    color="#FFF"
                    size="small"
                  />
                ) : (
                  <Text style={styles.loginBtnText}>
                    Send OTP
                  </Text>
                )}
              </Pressable>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>

      <Toast
        visible={toast.visible}
        message={toast.message}
        type={toast.type}
        onDismiss={() =>
          setToast((current) => ({
            ...current,
            visible: false,
          }))
        }
      />
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  root: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  flex: {
    flex: 1,
  },
  scroll: {
    paddingHorizontal: 24,
    paddingBottom: 40,
  },
  logoArea: {
    alignItems: 'center',
    paddingTop: 90,
    paddingBottom: 30,
    marginBottom: 32,
  },
  logo: {
    width: 90,
    height: 90,
    transform: [
      { translateY: 60 },
      { scale: 10 },
    ],
  },
  card: {
    backgroundColor: '#C5B5D8',
    borderRadius: 24,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.07,
    shadowRadius: 16,
    elevation: 4,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: T.purpleDark,
    marginBottom: 4,
  },
  cardSubtitle: {
    fontSize: 13,
    color: T.purpleMedium,
    marginBottom: 24,
  },
  label: {
    fontSize: 12,
    fontWeight: '600',
    color: T.purpleDark,
    marginBottom: 6,
  },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: T.screenBg,
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 50,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#E8E4EC',
    gap: 10,
  },
  input: {
    flex: 1,
    fontSize: 14,
    color: T.purpleDark,
  },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#FFF1F3',
    borderRadius: 8,
    padding: 10,
    marginBottom: 12,
  },
  errorText: {
    flex: 1,
    fontSize: 12,
    color: '#B23A48',
  },
  loginBtn: {
    backgroundColor: T.purpleIcon,
    borderRadius: 14,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loginBtnDisabled: {
    opacity: 0.7,
  },
  loginBtnText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
