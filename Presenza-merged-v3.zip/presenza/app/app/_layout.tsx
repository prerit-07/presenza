// app/_layout.tsx

import { useEffect } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import { BitcountGridSingle_400Regular } from '@expo-google-fonts/bitcount-grid-single';

import { useAuthStore } from '@/store/auth.store';
import { ThemedAlertProvider } from '@/components/ThemedAlertProvider';

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    BitcountGridSingle_400Regular,
  });

  const isBootstrapping = useAuthStore(
    (state) => state.isBootstrapping
  );

  const restoreSession = useAuthStore(
    (state) => state.restoreSession
  );

  useEffect(() => {
    restoreSession();
  }, [restoreSession]);

  if (!fontsLoaded || isBootstrapping) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#291550',
        }}
      >
        <ActivityIndicator
          size="large"
          color="#FFFFFF"
        />
      </View>
    );
  }

  return (
    <ThemedAlertProvider>
      <StatusBar
        style="dark"
        translucent
        backgroundColor="transparent"
      />

      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="(auth)" />
        <Stack.Screen name="(employee)" />
        <Stack.Screen name="(manager)" />
        <Stack.Screen name="(organization)" />
      </Stack>
    </ThemedAlertProvider>
  );
}