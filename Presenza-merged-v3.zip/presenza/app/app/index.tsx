// app/index.tsx

import { Redirect } from 'expo-router';

import { useAuthStore } from '@/store/auth.store';

export default function Index() {
  const user = useAuthStore(
    (state) => state.user
  );

  const isAuthenticated = useAuthStore(
    (state) => state.isAuthenticated
  );

  if (!isAuthenticated || !user) {
    return (
      <Redirect href="/(auth)/sign-in" />
    );
  }

  switch (user.role) {
    case 'ORG_ADMIN':
      return (
        <Redirect href="/(organization)/(tabs)/overview" />
      );

    case 'MANAGER':
      return (
        <Redirect href="/(manager)/(tabs)" />
      );

    case 'EMPLOYEE':
      return (
        <Redirect href="/(employee)/(tabs)" />
      );

    default:
      return (
        <Redirect href="/(auth)/sign-in" />
      );
  }
}
