// app/(organization)/(tabs)/members.tsx

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react';

import {
  ActivityIndicator,
  FlatList,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import { useRouter } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import { PageHeader } from '@/components/PageHeader';
import { DashboardTheme as T } from '@/constants/dashboard-theme';

import {
  getEmployees,
  type Employee,
} from '@/services/employee.service';

export default function MembersScreen() {
  const router = useRouter();

  const [employees, setEmployees] =
    useState<Employee[]>([]);

  const [search, setSearch] =
    useState('');

  const [isLoading, setIsLoading] =
    useState(true);

  const [isRefreshing, setIsRefreshing] =
    useState(false);

  const [error, setError] =
    useState('');

  const loadEmployees = useCallback(
    async (refresh = false) => {
      if (refresh) {
        setIsRefreshing(true);
      } else {
        setIsLoading(true);
      }

      try {
        setError('');

        const response =
          await getEmployees();

        setEmployees(response);
      } catch (err) {
        console.error(
          'Failed to load employees:',
          err
        );

        setError(
          err instanceof Error
            ? err.message
            : 'Failed to load employees'
        );
      } finally {
        if (refresh) {
          setIsRefreshing(false);
        } else {
          setIsLoading(false);
        }
      }
    },
    []
  );

  useEffect(() => {
    loadEmployees();
  }, [loadEmployees]);

  const filteredEmployees =
    useMemo(() => {
      const query =
        search.trim().toLowerCase();

      if (!query) {
        return employees;
      }

      return employees.filter(
        (employee) => {
          const searchableValues = [
            employee.employeeName,
            String(employee.employeeId),
            String(employee.userId),
            employee.departmentId != null
              ? String(employee.departmentId)
              : '',
            employee.teamId != null
              ? String(employee.teamId)
              : '',
            employee.shiftId != null
              ? String(employee.shiftId)
              : '',
          ];

          return searchableValues.some(
            (value) =>
              value
                .toLowerCase()
                .includes(query)
          );
        }
      );
    }, [employees, search]);

  const handleRefresh = () => {
    loadEmployees(true);
  };

  if (isLoading) {
    return (
      <View style={styles.root}>
        <PageHeader
          title="Manage Members"
          subtitle="Employee Directory"
        />

        <View style={styles.centered}>
          <ActivityIndicator size="large" />

          <Text style={styles.loadingText}>
            Loading employees...
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <PageHeader
        title="Manage Members"
        subtitle={`${employees.length} employee${
          employees.length === 1
            ? ''
            : 's'
        }`}
      />

      {/* Search */}
      <View style={styles.searchRow}>
        <MaterialCommunityIcons
          name="magnify"
          size={18}
          color={T.textMuted}
        />

        <TextInput
          style={styles.searchInput}
          placeholder="Search employees..."
          placeholderTextColor={
            T.textMuted
          }
          value={search}
          onChangeText={setSearch}
        />

        {search.length > 0 && (
          <Pressable
            onPress={() => setSearch('')}
          >
            <MaterialCommunityIcons
              name="close-circle"
              size={16}
              color={T.textMuted}
            />
          </Pressable>
        )}
      </View>

      {/* Backend error */}
      {error ? (
        <View style={styles.errorBox}>
          <MaterialCommunityIcons
            name="alert-circle-outline"
            size={18}
            color="#B23A48"
          />

          <Text style={styles.errorText}>
            {error}
          </Text>

          <Pressable
            onPress={() =>
              loadEmployees()
            }
          >
            <Text style={styles.retryText}>
              Retry
            </Text>
          </Pressable>
        </View>
      ) : null}

      {/* Employee List */}
      <FlatList
        data={filteredEmployees}
        keyExtractor={(employee) =>
          String(employee.employeeId)
        }
        contentContainerStyle={
          styles.list
        }
        showsVerticalScrollIndicator={
          false
        }
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
          />
        }
        renderItem={({ item }) => (
          <Pressable
            style={styles.memberCard}
            onPress={() =>
              router.push({
                pathname:
                  '/(organization)/member-detail',
                params: {
                  id: String(
                    item.employeeId
                  ),
                },
              })
            }
          >
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>
                {getInitials(
                  item.employeeName
                )}
              </Text>
            </View>

            <View style={styles.memberInfo}>
              <Text
                style={styles.memberName}
                numberOfLines={1}
              >
                {item.employeeName}
              </Text>

              <Text
                style={styles.memberSub}
                numberOfLines={1}
              >
                Employee #{item.employeeId}
                {' · '}
                User #{item.userId}
              </Text>

              <View style={styles.metaRow}>
                {item.departmentId !=
                  null && (
                  <MetaChip
                    icon="office-building-outline"
                    label={`Dept ${item.departmentId}`}
                  />
                )}

                {item.teamId != null && (
                  <MetaChip
                    icon="account-group-outline"
                    label={`Team ${item.teamId}`}
                  />
                )}

                {item.shiftId != null && (
                  <MetaChip
                    icon="clock-outline"
                    label={`Shift ${item.shiftId}`}
                  />
                )}
              </View>
            </View>

            <MaterialCommunityIcons
              name="chevron-right"
              size={22}
              color={T.textMuted}
            />
          </Pressable>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons
              name="account-search-outline"
              size={48}
              color={T.textMuted}
            />

            <Text style={styles.emptyTitle}>
              No employees found
            </Text>

            <Text style={styles.emptyText}>
              {search
                ? 'Try a different search.'
                : 'Add your first employee to get started.'}
            </Text>
          </View>
        }
      />

      {/* Add Employee */}
      <TouchableOpacity
        style={[
          styles.fab,
          {
            bottom: 110,
          },
        ]}
        activeOpacity={0.8}
        onPress={() =>
          router.push(
            '/(organization)/add-member'
          )
        }
      >
        <MaterialCommunityIcons
          name="plus"
          size={28}
          color="#FFF"
        />
      </TouchableOpacity>
    </View>
  );
}

function MetaChip({
  icon,
  label,
}: {
  icon: any;
  label: string;
}) {
  return (
    <View style={styles.metaChip}>
      <MaterialCommunityIcons
        name={icon}
        size={12}
        color={T.purpleIcon}
      />

      <Text style={styles.metaChipText}>
        {label}
      </Text>
    </View>
  );
}

function getInitials(
  employeeName: string
): string {
  const parts = employeeName
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  if (parts.length === 0) {
    return '?';
  }

  if (parts.length === 1) {
    return parts[0]
      .slice(0, 2)
      .toUpperCase();
  }

  return (
    parts[0][0] +
    parts[parts.length - 1][0]
  ).toUpperCase();
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: T.screenBg,
  },

  centered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },

  loadingText: {
    marginTop: 12,
    fontSize: 13,
    color: T.textMuted,
  },

  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#FFF',
    borderRadius: 14,
    marginHorizontal: 20,
    paddingHorizontal: 14,
    height: 44,
    borderWidth: 1,
    borderColor: '#E8E4EC',
    marginBottom: 12,
  },

  searchInput: {
    flex: 1,
    fontSize: 13,
    color: T.purpleDark,
  },

  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginHorizontal: 20,
    marginBottom: 12,
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#FFF1F3',
  },

  errorText: {
    flex: 1,
    fontSize: 12,
    color: '#B23A48',
  },

  retryText: {
    fontSize: 12,
    fontWeight: '700',
    color: T.purpleIcon,
  },

  list: {
    paddingHorizontal: 20,
    paddingBottom: 140,
    flexGrow: 1,
  },

  memberCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 2,
  },

  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    marginRight: 12,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: T.purpleLight,
  },

  avatarText: {
    fontSize: 14,
    fontWeight: '800',
    color: T.purpleDark,
  },

  memberInfo: {
    flex: 1,
    paddingRight: 8,
  },

  memberName: {
    fontSize: 14,
    fontWeight: '700',
    color: T.purpleDark,
  },

  memberSub: {
    fontSize: 11,
    color: T.textMuted,
    marginTop: 3,
  },

  metaRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    marginTop: 8,
  },

  metaChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: T.purpleLight,
    borderRadius: 8,
    paddingHorizontal: 7,
    paddingVertical: 4,
  },

  metaChipText: {
    fontSize: 10,
    fontWeight: '600',
    color: T.purpleDark,
  },

  empty: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 60,
    gap: 8,
  },

  emptyTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: T.purpleDark,
  },

  emptyText: {
    fontSize: 12,
    color: T.textMuted,
    textAlign: 'center',
  },

  fab: {
    position: 'absolute',
    right: 20,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: T.purpleIcon,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
});