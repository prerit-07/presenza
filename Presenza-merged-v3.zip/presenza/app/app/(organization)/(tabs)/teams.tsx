// app/(manager)/(organization)/admin/my-team.tsx
// Role: Manager
// Opens from: Bottom nav "Team" tab
// Navigates to: /member-detail, /leave-approvals, /device-approvals

import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList,
  TextInput, Pressable, Image,
} from 'react-native';
import { PageHeader } from '@/components/PageHeader';
import { useRouter, useFocusEffect } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useAppStore } from '@/store/useAppStore';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { employeeService, type Employee } from '@/services/employee.service';

const STATUS_COLOR: Record<string, string> = {
  present: '#4CAF50',
  absent: '#B23A48',
  late: '#F59E0B',
};

export default function TeamScreen() {
  const router = useRouter();
  const leaveRequests = useAppStore((s) => s.leaveRequests);
  const deviceRequests = useAppStore((s) => s.deviceRequests);
  const [search, setSearch] = useState('');

  const [team, setTeam] = useState<Employee[]>([]);

  // Automatically fetch the employees from your actual backend!
  useFocusEffect(
    useCallback(() => {
      let isActive = true;
      const fetchTeam = async () => {
        try {
          const data = await employeeService.getEmployees();
          if (isActive) setTeam(data);
        } catch (error) {
          console.error('Failed to fetch team:', error);
        }
      };
      fetchTeam();
      return () => { isActive = false; };
    }, [])
  );

  // Filter the fetched team based on the search bar
  const filteredTeam = team.filter((m) =>
    m.employeeName?.toLowerCase().includes(search.toLowerCase())
  );

  const pendingLeaves = leaveRequests.filter((l) => l.status === 'PENDING').length;
  const pendingDevices = deviceRequests.filter((d) => d.status === 'PENDING').length;

  // Mock today's status per member (since attendance API isn't connected yet)
  const getMockStatus = (id: number) => {
    // Adding fallback to 1 just in case id is somehow missing
    const safeId = id || 1;
    const statuses = ['present', 'present', 'late', 'present', 'absent'];
    return statuses[safeId % statuses.length];
  };

  return (
    <View style={styles.root}>
      <PageHeader title="Teams" subtitle="Manage Teams" />

      {/* Pending Action Banners */}
      {(pendingLeaves > 0 || pendingDevices > 0) && (
        <View style={styles.alertRow}>
          {pendingLeaves > 0 && (
            <Pressable style={styles.alertCard} onPress={() => router.push('/leave-approvals')}>
              <MaterialCommunityIcons name="calendar-clock" size={18} color="#F59E0B" />
              <Text style={styles.alertText}>{pendingLeaves} leave{pendingLeaves > 1 ? 's' : ''} pending</Text>
              <MaterialCommunityIcons name="chevron-right" size={14} color="#F59E0B" />
            </Pressable>
          )}
          {pendingDevices > 0 && (
            <Pressable style={styles.alertCard} onPress={() => router.push('/device-approvals')}>
              <MaterialCommunityIcons name="cellphone-key" size={18} color={T.purpleIcon} />
              <Text style={styles.alertText}>{pendingDevices} device request{pendingDevices > 1 ? 's' : ''}</Text>
              <MaterialCommunityIcons name="chevron-right" size={14} color={T.purpleIcon} />
            </Pressable>
          )}
        </View>
      )}

      {/* Today's Summary */}
      <View style={styles.summaryRow}>
        <SummaryBadge label="Present" count={filteredTeam.filter((m) => getMockStatus(m.employeeId) === 'present').length} color="#4CAF50" />
        <SummaryBadge label="Late" count={filteredTeam.filter((m) => getMockStatus(m.employeeId) === 'late').length} color="#F59E0B" />
        <SummaryBadge label="Absent" count={filteredTeam.filter((m) => getMockStatus(m.employeeId) === 'absent').length} color="#B23A48" />
      </View>

      {/* Search */}
      <View style={styles.searchRow}>
        <MaterialCommunityIcons name="magnify" size={18} color={T.textMuted} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search team members..."
          placeholderTextColor={T.textMuted}
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* Team List */}
      <FlatList
        data={filteredTeam}
        keyExtractor={(m) => String(m.employeeId)}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => {
          const status = getMockStatus(item.employeeId);
          return (
            <Pressable
              style={styles.memberCard}
              onPress={() => router.push({ pathname: '/member-detail', params: { id: item.employeeId } })}
            >
              <Image
                source={{ uri: `https://i.pravatar.cc/150?u=${item.employeeId}` }}
                style={styles.avatar}
              />
              <View style={styles.memberInfo}>
                <Text style={styles.memberName}>{item.employeeName}</Text>
                {/* We show Department ID here because we don't fetch the department name yet */}
                <Text style={styles.memberSub}>Dept ID: {item.departmentId || 'Unassigned'}</Text>
              </View>
              <View style={[styles.statusDot, { backgroundColor: STATUS_COLOR[status] + '22' }]}>
                <View style={[styles.statusDotInner, { backgroundColor: STATUS_COLOR[status] }]} />
                <Text style={[styles.statusText, { color: STATUS_COLOR[status] }]}>
                  {status.charAt(0).toUpperCase() + status.slice(1)}
                </Text>
              </View>
            </Pressable>
          );
        }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons name="account-group-outline" size={48} color={T.textMuted} />
            <Text style={styles.emptyText}>No team members found</Text>
          </View>
        }
      />
    </View>
  );
}

function SummaryBadge({ label, count, color }: { label: string; count: number; color: string }) {
  return (
    <View style={[styles.summaryBadge, { backgroundColor: color + '15', borderColor: color + '30' }]}>
      <Text style={[styles.summaryCount, { color }]}>{count}</Text>
      <Text style={[styles.summaryLabel, { color }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: T.screenBg },
  alertRow: { paddingHorizontal: 20, gap: 8, marginBottom: 4 },
  alertCard: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#FFF', borderRadius: 10, padding: 10, borderWidth: 1, borderColor: '#E8E4EC' },
  alertText: { flex: 1, fontSize: 12, fontWeight: '600', color: T.purpleDark },
  summaryRow: { flexDirection: 'row', gap: 10, paddingHorizontal: 20, marginBottom: 12 },
  summaryBadge: { flex: 1, borderRadius: 12, borderWidth: 1, padding: 10, alignItems: 'center' },
  summaryCount: { fontSize: 20, fontWeight: '800' },
  summaryLabel: { fontSize: 11, fontWeight: '600', marginTop: 2 },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#FFF', borderRadius: 14, marginHorizontal: 20, paddingHorizontal: 14, height: 44, borderWidth: 1, borderColor: '#E8E4EC', marginBottom: 12 },
  searchInput: { flex: 1, fontSize: 13, color: T.purpleDark },
  list: { paddingHorizontal: 20, paddingBottom: 120 },
  memberCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', borderRadius: 14, padding: 14, marginBottom: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 4, elevation: 2 },
  avatar: { width: 44, height: 44, borderRadius: 22, marginRight: 12 },
  memberInfo: { flex: 1 },
  memberName: { fontSize: 14, fontWeight: '600', color: T.purpleDark },
  memberSub: { fontSize: 11, color: T.textMuted, marginTop: 2 },
  statusDot: { flexDirection: 'row', alignItems: 'center', gap: 5, borderRadius: 20, paddingVertical: 4, paddingHorizontal: 10 },
  statusDotInner: { width: 6, height: 6, borderRadius: 3 },
  statusText: { fontSize: 11, fontWeight: '700' },
  empty: { alignItems: 'center', marginTop: 60, gap: 10 },
  emptyText: { fontSize: 14, color: T.textMuted },
});