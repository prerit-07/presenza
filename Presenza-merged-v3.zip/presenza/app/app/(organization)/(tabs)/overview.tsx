// app/(organization)/(tabs)/overview.tsx

import { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import AdminDashboard from '@/components/dashboards/AdminDashboard';

import {
  getMyOrganization,
  type Organization,
} from '@/services/organization.service';

export default function OrganizationOverviewScreen() {
  const [organization, setOrganization] =
    useState<Organization | null>(null);

  const [isLoading, setIsLoading] =
    useState(true);

  const [error, setError] =
    useState('');

  useEffect(() => {
    let isMounted = true;

    const loadOrganization = async () => {
      try {
        setError('');

        const response =
          await getMyOrganization();

        if (isMounted) {
          setOrganization(response);
        }
      } catch (err) {
        console.error(
          'Failed to load organization overview:',
          err
        );

        if (isMounted) {
          setError(
            err instanceof Error
              ? err.message
              : 'Failed to load organization'
          );
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    loadOrganization();

    return () => {
      isMounted = false;
    };
  }, []);

  if (isLoading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" />

        <Text style={styles.message}>
          Loading organization...
        </Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.centered}>
        <Text style={styles.errorText}>
          {error}
        </Text>
      </View>
    );
  }

  return (
    <AdminDashboard
      organizationName={
        organization?.orgName ??
        'Organization'
      }
      organizationType={
        organization?.orgType ?? '—'
      }
      planName={
        organization?.planName ?? '—'
      }
      maxAllowedEmployee={
        organization?.maxAllowedEmployee ?? 0
      }
    />
  );
}

const styles = StyleSheet.create({
  centered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },

  message: {
    marginTop: 12,
    fontSize: 14,
  },

  errorText: {
    fontSize: 14,
    textAlign: 'center',
  },
});