// app/(organization)/geofence-setup.tsx

import React, {
  useCallback,
  useEffect,
  useState,
} from 'react';

import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Location from 'expo-location';

import { PageHeader } from '@/components/PageHeader';
import { Modal } from '@/components/Modal';
import { DashboardTheme as T } from '@/constants/dashboard-theme';

import {
  createGeofence,
  getGeofences,
  type Geofence,
} from '@/services/geofence.service';

import {
  getMyOrganization,
} from '@/services/organization.service';
import { useThemedAlert } from '@/components/ThemedAlertProvider';

const PRESET_RADII = [
  50,
  100,
  150,
  200,
  300,
  500,
];

export default function GeofenceSetupScreen() {
  const { showAlert } = useThemedAlert();
  const [geofences, setGeofences] =
    useState<Geofence[]>([]);

  const [orgId, setOrgId] =
    useState<number | null>(null);

  const [loading, setLoading] =
    useState(true);

  const [showAdd, setShowAdd] =
    useState(false);

  const [name, setName] =
    useState('');

  const [lat, setLat] =
    useState('28.6139');

  const [lng, setLng] =
    useState('77.2090');

  const [radius, setRadius] =
    useState(200);

  const [saving, setSaving] =
    useState(false);

  const [
    detectingLocation,
    setDetectingLocation,
  ] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);

    try {
      const [
        organization,
        geofenceList,
      ] = await Promise.all([
        getMyOrganization(),
        getGeofences(),
      ]);

      setOrgId(organization.orgId);
      setGeofences(geofenceList);
    } catch (error) {
      console.error(
        'Failed to load geofences:',
        error
      );

      showAlert({
        type: 'error',
        title: 'Error',
        message: error instanceof Error
          ? error.message
          : 'Failed to load geofences.'
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleUseCurrentLocation =
    async () => {
      if (detectingLocation) {
        return;
      }

      setDetectingLocation(true);

      try {
        const servicesEnabled =
          await Location.hasServicesEnabledAsync();

        if (!servicesEnabled) {
          showAlert({
            type: 'info',
            title: 'Location Services Disabled',
            message: 'Please enable GPS or Location Services and try again.'
          });
          return;
        }

        const permission =
          await Location
            .requestForegroundPermissionsAsync();

        if (
          permission.status !==
          Location.PermissionStatus.GRANTED
        ) {
          showAlert({
            type: 'info',
            title: 'Location Permission Required',
            message: 'Please allow location access to use your current coordinates.'
          });
          return;
        }

        const currentLocation =
          await Location.getCurrentPositionAsync({
            accuracy: Location.Accuracy.High,
          });

        const {
          latitude,
          longitude,
        } = currentLocation.coords;

        setLat(latitude.toFixed(6));
        setLng(longitude.toFixed(6));

        showAlert({
          type: 'success',
          title: 'Location Detected',
          message: 'Your current GPS coordinates have been filled successfully.'
        });
      } catch (error) {
        console.error(
          'Failed to detect location:',
          error
        );

        showAlert({
          type: 'error',
          title: 'Location Error',
          message: error instanceof Error
            ? error.message
            : 'Could not get your current location.'
        });
      } finally {
        setDetectingLocation(false);
      }
    };

  const handleSave = async () => {
    const buildingName = name.trim();
    const latitude = Number(lat.trim());
    const longitude = Number(lng.trim());

    if (!buildingName) {
      showAlert({
        type: 'error',
        title: 'Error',
        message: 'Please enter a location name.'
      });
      return;
    }

    if (
      !Number.isFinite(latitude) ||
      latitude < -90 ||
      latitude > 90
    ) {
      showAlert({
        type: 'error',
        title: 'Error',
        message: 'Latitude must be between -90 and 90.'
      });
      return;
    }

    if (
      !Number.isFinite(longitude) ||
      longitude < -180 ||
      longitude > 180
    ) {
      showAlert({
        type: 'error',
        title: 'Error',
        message: 'Longitude must be between -180 and 180.'
      });
      return;
    }

    if (orgId == null) {
      showAlert({
        type: 'error',
        title: 'Error',
        message: 'Organization is not loaded yet.'
      });
      return;
    }

    setSaving(true);

    try {
      const created =
        await createGeofence({
          orgId,
          latitude,
          longitude,
          radius,
          buildingName,
        });

      setGeofences((current) => [
        ...current,
        created,
      ]);

      setShowAdd(false);
      setName('');
      setRadius(200);

      showAlert({
        type: 'success',
        title: 'Success',
        message: 'Geofence created successfully.'
      });
    } catch (error) {
      console.error(
        'Failed to create geofence:',
        error
      );

      showAlert({
        type: 'error',
        title: 'Error',
        message: error instanceof Error
          ? error.message
          : 'Failed to create geofence.'
      });
    } finally {
      setSaving(false);
    }
  };

  const handleCloseModal = () => {
    if (
      saving ||
      detectingLocation
    ) {
      return;
    }

    setShowAdd(false);
  };

  return (
    <View style={styles.root}>
      <PageHeader
        title="Geofences"
        subtitle="Office Locations"
      />

      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" />

          <Text style={styles.loadingText}>
            Loading geofences...
          </Text>
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={styles.scroll}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.infoBanner}>
            <MaterialCommunityIcons
              name="information-outline"
              size={18}
              color={T.purpleIcon}
            />

            <Text style={styles.infoBannerText}>
              Employees must be within one
              of these GPS boundaries to
              clock in.
            </Text>
          </View>

          {geofences.length === 0 ? (
            <View style={styles.emptyCard}>
              <MaterialCommunityIcons
                name="map-marker-off-outline"
                size={42}
                color={T.textMuted}
              />

              <Text style={styles.emptyTitle}>
                No geofences yet
              </Text>

              <Text style={styles.emptySub}>
                Add an office location to
                create a GPS boundary.
              </Text>
            </View>
          ) : (
            geofences.map((gf) => (
              <View
                key={gf.geofenceId}
                style={styles.gfCard}
              >
                <View style={styles.gfIconWrap}>
                  <MaterialCommunityIcons
                    name="map-marker-radius"
                    size={24}
                    color={T.purpleIcon}
                  />
                </View>

                <View style={styles.gfContent}>
                  <Text style={styles.gfName}>
                    {gf.buildingName ||
                      `Geofence #${gf.geofenceId}`}
                  </Text>

                  <Text style={styles.gfCoords}>
                    {gf.latitude},{' '}
                    {gf.longitude}
                  </Text>

                  <Text style={styles.gfRadius}>
                    {gf.radius}m radius
                  </Text>
                </View>

                <MaterialCommunityIcons
                  name="chevron-right"
                  size={20}
                  color={T.textMuted}
                />
              </View>
            ))
          )}

          <View style={styles.listSpacer} />
        </ScrollView>
      )}

      <TouchableOpacity
        style={styles.fab}
        onPress={() => setShowAdd(true)}
        disabled={loading}
        activeOpacity={0.8}
      >
        <MaterialCommunityIcons
          name="plus"
          size={28}
          color="#FFF"
        />
      </TouchableOpacity>

      <Modal
        visible={showAdd}
        onClose={handleCloseModal}
        title="Add Geofence"
      >
        <ScrollView
          style={styles.modalScroll}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.mapPlaceholder}>
            <MaterialCommunityIcons
              name="map-marker-radius"
              size={48}
              color={T.purpleIcon}
            />

            <Text style={styles.mapPlaceholderText}>
              Map Preview
            </Text>
          </View>

          <Text style={styles.label}>
            Location Name
          </Text>

          <TextInput
            style={styles.input}
            value={name}
            onChangeText={setName}
            placeholder="e.g. New Delhi HQ"
            placeholderTextColor={T.textMuted}
            editable={!saving}
          />

          <Text
            style={[
              styles.sectionTitle,
              styles.coordinatesTitle,
            ]}
          >
            Coordinates
          </Text>

          <View style={styles.coordRow}>
            <View style={styles.coordField}>
              <Text style={styles.label}>
                Latitude
              </Text>

              <TextInput
                style={styles.input}
                value={lat}
                onChangeText={setLat}
                keyboardType="decimal-pad"
                placeholder="28.6139"
                placeholderTextColor={
                  T.textMuted
                }
                editable={
                  !saving &&
                  !detectingLocation
                }
              />
            </View>

            <View style={styles.coordField}>
              <Text style={styles.label}>
                Longitude
              </Text>

              <TextInput
                style={styles.input}
                value={lng}
                onChangeText={setLng}
                keyboardType="decimal-pad"
                placeholder="77.2090"
                placeholderTextColor={
                  T.textMuted
                }
                editable={
                  !saving &&
                  !detectingLocation
                }
              />
            </View>
          </View>

          <Pressable
            style={[
              styles.detectBtn,
              detectingLocation &&
                styles.detectBtnDisabled,
            ]}
            onPress={
              handleUseCurrentLocation
            }
            disabled={
              detectingLocation ||
              saving
            }
          >
            {detectingLocation ? (
              <ActivityIndicator
                size="small"
                color={T.purpleIcon}
              />
            ) : (
              <MaterialCommunityIcons
                name="crosshairs-gps"
                size={16}
                color={T.purpleIcon}
              />
            )}

            <Text style={styles.detectBtnText}>
              {detectingLocation
                ? 'Detecting Location...'
                : 'Use Current Location'}
            </Text>
          </Pressable>

          <Text style={styles.sectionTitle}>
            Geofence Radius
          </Text>

          <View style={styles.radiusRow}>
            {PRESET_RADII.map((value) => (
              <Pressable
                key={value}
                style={[
                  styles.radiusPill,
                  radius === value &&
                    styles.radiusPillActive,
                ]}
                onPress={() =>
                  setRadius(value)
                }
                disabled={
                  saving ||
                  detectingLocation
                }
              >
                <Text
                  style={[
                    styles.radiusPillText,
                    radius === value &&
                      styles.radiusPillTextActive,
                  ]}
                >
                  {value}m
                </Text>
              </Pressable>
            ))}
          </View>

          <View style={styles.radiusInfoCard}>
            <MaterialCommunityIcons
              name="map-marker-radius-outline"
              size={20}
              color={T.purpleIcon}
            />

            <View style={styles.gfContent}>
              <Text style={styles.radiusInfoTitle}>
                {radius} metre radius selected
              </Text>

              <Text style={styles.radiusInfoSub}>
                Recommended: 100–200m
              </Text>
            </View>
          </View>

          <Pressable
            style={[
              styles.saveBtn,
              (saving ||
                detectingLocation) &&
                styles.saveBtnDisabled,
            ]}
            onPress={handleSave}
            disabled={
              saving ||
              detectingLocation
            }
          >
            {saving ? (
              <ActivityIndicator color="#FFF" />
            ) : (
              <Text style={styles.saveBtnText}>
                Add Geofence
              </Text>
            )}
          </Pressable>
        </ScrollView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: T.screenBg,
  },

  centered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },

  loadingText: {
    marginTop: 10,
    fontSize: 13,
    color: T.textMuted,
  },

  scroll: {
    paddingHorizontal: 20,
  },

  infoBanner: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'flex-start',
    backgroundColor: T.purpleLight,
    borderRadius: 12,
    padding: 14,
    marginBottom: 16,
  },

  infoBannerText: {
    flex: 1,
    fontSize: 13,
    color: T.purpleIcon,
    lineHeight: 18,
  },

  gfCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: '#FFF',
    borderRadius: 14,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 2,
  },

  gfContent: {
    flex: 1,
  },

  gfIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: T.purpleLight,
    justifyContent: 'center',
    alignItems: 'center',
  },

  gfName: {
    fontSize: 15,
    fontWeight: '700',
    color: T.purpleDark,
    marginBottom: 2,
  },

  gfCoords: {
    fontSize: 12,
    color: T.textMuted,
    fontFamily: 'monospace',
    marginBottom: 2,
  },

  gfRadius: {
    fontSize: 12,
    color: T.purpleMedium,
    fontWeight: '600',
  },

  emptyCard: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF',
    borderRadius: 14,
    padding: 32,
  },

  emptyTitle: {
    marginTop: 10,
    fontSize: 15,
    fontWeight: '700',
    color: T.purpleDark,
  },

  emptySub: {
    marginTop: 5,
    fontSize: 12,
    color: T.textMuted,
    textAlign: 'center',
  },

  listSpacer: {
    height: 100,
  },

  fab: {
    position: 'absolute',
    right: 20,
    bottom: 40,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: T.purpleIcon,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },

  modalScroll: {
    maxHeight: 550,
  },

  mapPlaceholder: {
    backgroundColor: '#F3EDF7',
    borderRadius: 14,
    height: 140,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    borderWidth: 1.5,
    borderColor: '#E8E4EC',
    borderStyle: 'dashed',
  },

  mapPlaceholderText: {
    fontSize: 13,
    fontWeight: '600',
    color: T.purpleDark,
    marginTop: 4,
  },

  sectionTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: T.purpleDark,
    marginBottom: 10,
    letterSpacing: 0.4,
  },

  coordinatesTitle: {
    marginTop: 16,
  },

  coordRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 10,
  },

  coordField: {
    flex: 1,
  },

  label: {
    fontSize: 12,
    fontWeight: '600',
    color: T.purpleDark,
    marginBottom: 6,
  },

  input: {
    backgroundColor: '#FFF',
    borderRadius: 10,
    paddingHorizontal: 12,
    height: 44,
    fontSize: 14,
    color: T.purpleDark,
    borderWidth: 1,
    borderColor: '#E8E4EC',
    marginBottom: 12,
  },

  detectBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1.5,
    borderColor: T.purpleBorder,
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 14,
    alignSelf: 'flex-start',
    marginBottom: 16,
  },

  detectBtnDisabled: {
    opacity: 0.6,
  },

  detectBtnText: {
    fontSize: 12,
    fontWeight: '600',
    color: T.purpleIcon,
  },

  radiusRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 14,
  },

  radiusPill: {
    borderRadius: 16,
    paddingVertical: 6,
    paddingHorizontal: 12,
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#E8E4EC',
  },

  radiusPillActive: {
    backgroundColor: T.purpleIcon,
    borderColor: T.purpleIcon,
  },

  radiusPillText: {
    fontSize: 12,
    fontWeight: '600',
    color: T.purpleIcon,
  },

  radiusPillTextActive: {
    color: '#FFF',
  },

  radiusInfoCard: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'center',
    backgroundColor: '#F0FFF4',
    borderRadius: 10,
    padding: 12,
    marginBottom: 20,
  },

  radiusInfoTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: '#2E7D32',
  },

  radiusInfoSub: {
    fontSize: 11,
    color: '#4CAF50',
    marginTop: 2,
  },

  saveBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: T.purpleIcon,
    borderRadius: 14,
    height: 50,
    marginBottom: 10,
  },

  saveBtnDisabled: {
    opacity: 0.6,
  },

  saveBtnText: {
    color: '#FFF',
    fontSize: 15,
    fontWeight: '700',
  },
});