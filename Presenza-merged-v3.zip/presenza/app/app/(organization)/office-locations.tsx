import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { PageHeader } from '@/components/PageHeader';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { geofenceService, Geofence } from '@/services/geofence.service';
import { ThemedModal, ThemedModalType } from '@/components/ThemedModal';

export default function OfficeLocationsScreen() {
  const router = useRouter();
  const [locations, setLocations] = useState<Geofence[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal State
  const [modalVisible, setModalVisible] = useState(false);
  const [modalConfig, setModalConfig] = useState<{
    type: ThemedModalType;
    title: string;
    message: string;
    primaryButtonText?: string;
    secondaryButtonText?: string;
    onPrimaryPress: () => void;
    onSecondaryPress?: () => void;
  }>({ type: 'info', title: '', message: '', onPrimaryPress: () => setModalVisible(false) });

  const showAlert = (
    type: ThemedModalType,
    title: string,
    message: string,
    onPrimaryPress: () => void = () => setModalVisible(false),
    primaryButtonText?: string,
    secondaryButtonText?: string,
    onSecondaryPress?: () => void
  ) => {
    setModalConfig({ type, title, message, onPrimaryPress, primaryButtonText, secondaryButtonText, onSecondaryPress });
    setModalVisible(true);
  };

  // This automatically fetches the real data from the backend every time this screen opens!
  useFocusEffect(
    useCallback(() => {
      let isActive = true;
      const fetchLocations = async () => {
        setLoading(true);
        try {
          const data = await geofenceService.getGeofences();
          if (isActive) setLocations(data);
        } catch (error) {
          console.error('Failed to fetch geofences', error);
        } finally {
          if (isActive) setLoading(false);
        }
      };
      fetchLocations();
      return () => { isActive = false; };
    }, [])
  );

  const handleDelete = (id: number, name: string) => {
    showAlert(
      'warning',
      'Delete Office?',
      `Are you sure you want to delete ${name}?`,
      async () => {
        try {
          await geofenceService.deleteGeofence(id);
          setLocations(prev => prev.filter(l => l.geofenceId !== id));
          setModalVisible(false);
        } catch (e) {
          showAlert('error', 'Error', 'Failed to delete office location.');
        }
      },
      'Delete',
      'Cancel',
      () => setModalVisible(false)
    );
  };

  return (
    <View style={styles.root}>
      <PageHeader 
        title="Office Locations" 
        subtitle="Manage geofences & Wi-Fi routers" 
      />

      <ScrollView contentContainerStyle={styles.list}>
        {loading ? (
          <ActivityIndicator size="large" color={T.purpleIcon} style={{ marginTop: 40 }} />
        ) : (
          locations.map((loc) => (
            <TouchableOpacity 
              key={loc.geofenceId} 
              style={styles.card}
              activeOpacity={0.7}
              onPress={() => router.push(`/(organization)/manage-geofence?id=${loc.geofenceId}`)}
            >
              <View style={styles.cardIcon}>
                <MaterialCommunityIcons name="office-building" size={24} color={T.purpleIcon} />
              </View>
              <View style={styles.cardInfo}>
                <Text style={styles.cardTitle}>{loc.buildingName || 'Office'}</Text>
                <Text style={styles.cardAddress} numberOfLines={1}>Radius: {loc.radius}m</Text>
              </View>
              <TouchableOpacity 
                style={styles.deleteBtn}
                onPress={() => handleDelete(loc.geofenceId, loc.buildingName || 'Office')}
                hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              >
                <MaterialCommunityIcons name="trash-can-outline" size={22} color="#F44336" />
              </TouchableOpacity>
            </TouchableOpacity>
          ))
        )}

        {!loading && locations.length === 0 && (
          <View style={styles.emptyState}>
            <MaterialCommunityIcons name="map-marker-off" size={64} color="#D0C4DF" />
            <Text style={styles.emptyText}>No office locations found.</Text>
            <Text style={styles.emptySub}>Tap the + button to add one.</Text>
          </View>
        )}
      </ScrollView>

      <ThemedModal
        visible={modalVisible}
        type={modalConfig.type}
        title={modalConfig.title}
        message={modalConfig.message}
        primaryButtonText={modalConfig.primaryButtonText}
        secondaryButtonText={modalConfig.secondaryButtonText}
        onPrimaryPress={modalConfig.onPrimaryPress}
        onSecondaryPress={modalConfig.onSecondaryPress}
      />

      {/* Floating Action Button for Adding New Location */}
      <TouchableOpacity 
        style={styles.fab}
        activeOpacity={0.8}
        onPress={() => router.push('/(organization)/manage-geofence?id=new')}
      >
        <MaterialCommunityIcons name="plus" size={32} color="#FFF" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#F8F4FA',
  },
  list: {
    padding: 20,
    gap: 12,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E8E4EC',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.03,
    shadowRadius: 6,
    elevation: 2,
  },
  cardIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F3EDF9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  cardInfo: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#29185c',
    marginBottom: 4,
  },
  cardAddress: {
    fontSize: 13,
    color: '#6B4E8D',
  },
  deleteBtn: {
    padding: 8,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 80,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#29185c',
    marginTop: 16,
  },
  emptySub: {
    fontSize: 14,
    color: '#6B4E8D',
    marginTop: 8,
  },
  fab: {
    position: 'absolute',
    bottom: 30,
    right: 24,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: T.purpleIcon,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
});