// app/(organization)/add-member.tsx

import React, {
  useEffect,
  useState,
} from 'react';

import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';

import { useRouter } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { PageHeader } from '@/components/PageHeader';

import {
  createEmployee,
  type Employee,
} from '@/services/employee.service';

import {
  getShifts,
  type Shift,
} from '@/services/shift.service';

export default function AddMemberScreen() {
  const router = useRouter();

  const [form, setForm] = useState({
    employeeName: '',
    username: '',
    email: '',
    dateOfJoining: '',
  });

  const [shifts, setShifts] =
    useState<Shift[]>([]);

  const [
    selectedShiftId,
    setSelectedShiftId,
  ] = useState<number | null>(null);

  const [loadingShifts, setLoadingShifts] =
    useState(true);

  const [shiftError, setShiftError] =
    useState('');

  const [loading, setLoading] =
    useState(false);

  const [error, setError] =
    useState('');

  const [
    createdEmployee,
    setCreatedEmployee,
  ] = useState<Employee | null>(null);

  useEffect(() => {
    let mounted = true;

    const loadShifts = async () => {
      setLoadingShifts(true);
      setShiftError('');

      try {
        const shiftList = await getShifts();

        if (!mounted) {
          return;
        }

        setShifts(shiftList);

        if (shiftList.length > 0) {
          setSelectedShiftId(
            shiftList[0].shiftId
          );
        }
      } catch (err) {
        console.error(
          'Failed to load shifts:',
          err
        );

        if (!mounted) {
          return;
        }

        setShiftError(
          err instanceof Error
            ? err.message
            : 'Failed to load shifts.'
        );
      } finally {
        if (mounted) {
          setLoadingShifts(false);
        }
      }
    };

    loadShifts();

    return () => {
      mounted = false;
    };
  }, []);

  const handleCreate = async () => {
    const employeeName =
      form.employeeName.trim();

    const username =
      form.username.trim();

    const email =
      form.email.trim().toLowerCase();

    const rawDateOfJoining =
      form.dateOfJoining.trim();

    const dateOfJoining =
      rawDateOfJoining.replace(/\//g, '-');

    if (!employeeName) {
      setError(
        'Employee name is required.'
      );
      return;
    }

    if (!username) {
      setError(
        'Username is required.'
      );
      return;
    }

    if (!email) {
      setError(
        'Email address is required.'
      );
      return;
    }

    if (
      dateOfJoining &&
      !/^\d{4}-\d{2}-\d{2}$/.test(
        dateOfJoining
      )
    ) {
      setError(
        'Joining date must use YYYY-MM-DD format.'
      );
      return;
    }

    if (selectedShiftId === null) {
      setError(
        'Please select a shift for this employee.'
      );
      return;
    }

    setError('');
    setLoading(true);

    try {
      const employee =
        await createEmployee({
          username,
          email,
          employeeName,

          dateOfJoining:
            dateOfJoining || null,

          departmentId: null,
          shiftId: selectedShiftId,
          teamId: null,
        });

      console.log(
        'Employee created:',
        employee
      );

      setCreatedEmployee(employee);
    } catch (err) {
      console.error(
        'Failed to create employee:',
        err
      );

      setError(
        err instanceof Error
          ? err.message
          : 'Failed to create employee'
      );
    } finally {
      setLoading(false);
    }
  };

  if (createdEmployee) {
    const selectedShift =
      shifts.find(
        (shift) =>
          shift.shiftId === selectedShiftId
      ) ?? null;

    return (
      <View style={styles.root}>
        <View style={styles.successView}>
          <View style={styles.successRing}>
            <MaterialCommunityIcons
              name="check-bold"
              size={44}
              color="#FFF"
            />
          </View>

          <Text style={styles.successTitle}>
            Member Added!
          </Text>

          <Text style={styles.successSub}>
            A welcome email containing the
            employee's login credentials has
            been sent successfully.
          </Text>

          <View style={styles.credCard}>
            <Text style={styles.credLabel}>
              Email
            </Text>

            <Text style={styles.credValue}>
              {form.email
                .trim()
                .toLowerCase()}
            </Text>

            <View style={styles.credSep} />

            <Text style={styles.credLabel}>
              Username
            </Text>

            <Text style={styles.credValue}>
              {form.username.trim()}
            </Text>

            <View style={styles.credSep} />

            <Text style={styles.credLabel}>
              Assigned Shift
            </Text>

            <Text style={styles.credValue}>
              {selectedShift?.shiftName ||
                `Shift ${selectedShiftId}`}
            </Text>

            <Text style={styles.credNote}>
              The employee will be prompted
              to change their password during
              their first login.
            </Text>
          </View>

          <Pressable
            style={styles.doneBtn}
            onPress={() =>
              router.replace(
                '/(organization)/(tabs)/members'
              )
            }
          >
            <Text style={styles.doneBtnText}>
              Go to Members
            </Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <PageHeader
        title="Add Member"
        subtitle="Create a new employee account"
      />

      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Account Type */}
        <Text style={styles.sectionTitle}>
          Account Type
        </Text>

        <View style={styles.accountTypeCard}>
          <View style={styles.accountTypeIcon}>
            <MaterialCommunityIcons
              name="account-outline"
              size={18}
              color={T.purpleIcon}
            />
          </View>

          <View style={styles.accountTypeInfo}>
            <Text style={styles.accountTypeTitle}>
              Employee
            </Text>

            <Text style={styles.accountTypeSub}>
              A login account and linked
              employee profile will be created.
            </Text>
          </View>

          <MaterialCommunityIcons
            name="check-circle"
            size={20}
            color={T.purpleIcon}
          />
        </View>

        {/* Personal Information */}
        <Text style={styles.sectionTitle}>
          Personal Information
        </Text>

        <InputField
          label="Full Name *"
          icon="account-outline"
          placeholder="e.g. Priya Sharma"
          value={form.employeeName}
          onChangeText={(value) =>
            setForm((current) => ({
              ...current,
              employeeName: value,
            }))
          }
          autoCapitalize="words"
        />

        <InputField
          label="Username *"
          icon="account-key-outline"
          placeholder="e.g. priya.sharma"
          value={form.username}
          onChangeText={(value) =>
            setForm((current) => ({
              ...current,
              username: value,
            }))
          }
          autoCapitalize="none"
        />

        <InputField
          label="Email Address *"
          icon="email-outline"
          placeholder="priya@company.com"
          value={form.email}
          onChangeText={(value) =>
            setForm((current) => ({
              ...current,
              email: value,
            }))
          }
          keyboardType="email-address"
          autoCapitalize="none"
        />

        <InputField
          label="Date of Joining"
          icon="calendar-outline"
          placeholder="YYYY-MM-DD"
          value={form.dateOfJoining}
          onChangeText={(value) =>
            setForm((current) => ({
              ...current,
              dateOfJoining: value,
            }))
          }
          autoCapitalize="none"
        />

        {/* Shift Assignment */}
        <Text style={styles.sectionTitle}>
          Assign Shift
        </Text>

        {loadingShifts ? (
          <View style={styles.shiftLoadingCard}>
            <ActivityIndicator
              size="small"
              color={T.purpleIcon}
            />

            <Text style={styles.shiftLoadingText}>
              Loading available shifts...
            </Text>
          </View>
        ) : shiftError ? (
          <View style={styles.errorBox}>
            <MaterialCommunityIcons
              name="alert-circle-outline"
              size={14}
              color="#B23A48"
            />

            <Text style={styles.errorText}>
              {shiftError}
            </Text>
          </View>
        ) : shifts.length === 0 ? (
          <View style={styles.noShiftCard}>
            <MaterialCommunityIcons
              name="calendar-clock-outline"
              size={26}
              color={T.textMuted}
            />

            <View style={styles.noShiftInfo}>
              <Text style={styles.noShiftTitle}>
                No shifts available
              </Text>

              <Text style={styles.noShiftSub}>
                Create a shift before adding
                an employee.
              </Text>
            </View>
          </View>
        ) : (
          <View style={styles.shiftList}>
            {shifts.map((shift) => {
              const selected =
                selectedShiftId ===
                shift.shiftId;

              return (
                <Pressable
                  key={shift.shiftId}
                  style={[
                    styles.shiftCard,
                    selected &&
                      styles.shiftCardSelected,
                  ]}
                  onPress={() => {
                    setSelectedShiftId(
                      shift.shiftId
                    );

                    setError('');
                  }}
                >
                  <View
                    style={[
                      styles.shiftIconWrap,
                      selected &&
                        styles.shiftIconWrapSelected,
                    ]}
                  >
                    <MaterialCommunityIcons
                      name="clock-time-four-outline"
                      size={20}
                      color={
                        selected
                          ? '#FFF'
                          : T.purpleIcon
                      }
                    />
                  </View>

                  <View style={styles.shiftInfo}>
                    <Text
                      style={[
                        styles.shiftName,
                        selected &&
                          styles.shiftNameSelected,
                      ]}
                    >
                      {shift.shiftName}
                    </Text>

                    <Text style={styles.shiftTime}>
                      {formatTime(
                        shift.startTime
                      )}
                      {'  →  '}
                      {formatTime(
                        shift.endTime
                      )}
                    </Text>

                    <Text style={styles.shiftMeta}>
                      Late allowance:{' '}
                      {shift.allowedLateMinutes ??
                        0}{' '}
                      min
                    </Text>
                  </View>

                  <MaterialCommunityIcons
                    name={
                      selected
                        ? 'check-circle'
                        : 'circle-outline'
                    }
                    size={21}
                    color={
                      selected
                        ? T.purpleIcon
                        : T.textMuted
                    }
                  />
                </Pressable>
              );
            })}
          </View>
        )}

        {/* Info Note */}
        <View style={styles.infoBox}>
          <MaterialCommunityIcons
            name="information-outline"
            size={14}
            color={T.purpleIcon}
          />

          <Text style={styles.infoText}>
            A welcome email containing login
            credentials will automatically
            be sent to the employee after
            the account is created. The
            selected shift will be assigned
            immediately.
          </Text>
        </View>

        {/* Error */}
        {error ? (
          <View style={styles.errorBox}>
            <MaterialCommunityIcons
              name="alert-circle-outline"
              size={14}
              color="#B23A48"
            />

            <Text style={styles.errorText}>
              {error}
            </Text>
          </View>
        ) : null}

        {/* Submit */}
        <Pressable
          style={[
            styles.createBtn,
            (
              loading ||
              loadingShifts ||
              shifts.length === 0
            ) &&
              styles.createBtnDisabled,
          ]}
          onPress={handleCreate}
          disabled={
            loading ||
            loadingShifts ||
            shifts.length === 0
          }
        >
          {loading ? (
            <ActivityIndicator color="#FFF" />
          ) : (
            <>
              <MaterialCommunityIcons
                name="account-plus"
                size={18}
                color="#FFF"
              />

              <Text style={styles.createBtnText}>
                Create Employee
              </Text>
            </>
          )}
        </Pressable>

        <View style={styles.bottomSpacer} />
      </ScrollView>
    </View>
  );
}

function InputField({
  label,
  icon,
  placeholder,
  value,
  onChangeText,
  keyboardType,
  autoCapitalize = 'none',
}: {
  label: string;
  icon: any;
  placeholder: string;
  value: string;
  onChangeText: (value: string) => void;
  keyboardType?: any;
  autoCapitalize?:
    | 'none'
    | 'sentences'
    | 'words'
    | 'characters';
}) {
  return (
    <>
      <Text style={styles.label}>
        {label}
      </Text>

      <View style={styles.inputWrap}>
        <MaterialCommunityIcons
          name={icon}
          size={16}
          color={T.textMuted}
        />

        <TextInput
          style={styles.input}
          placeholder={placeholder}
          placeholderTextColor={T.textMuted}
          value={value}
          onChangeText={onChangeText}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          autoCorrect={false}
        />
      </View>
    </>
  );
}

function formatTime(value: string) {
  return value?.slice(0, 5) || '--:--';
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: T.screenBg,
  },

  scroll: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },

  sectionTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: T.purpleDark,
    marginTop: 16,
    marginBottom: 10,
    letterSpacing: 0.5,
  },

  accountTypeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#FFF',
    borderRadius: 14,
    padding: 14,
    borderWidth: 1.5,
    borderColor: T.purpleIcon,
    marginBottom: 6,
  },

  accountTypeIcon: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: T.purpleLight,
  },

  accountTypeInfo: {
    flex: 1,
  },

  accountTypeTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: T.purpleDark,
  },

  accountTypeSub: {
    marginTop: 3,
    fontSize: 11,
    lineHeight: 15,
    color: T.textMuted,
  },

  label: {
    fontSize: 12,
    fontWeight: '600',
    color: T.purpleDark,
    marginBottom: 6,
    marginTop: 14,
  },

  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: '#FFF',
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 48,
    borderWidth: 1,
    borderColor: '#E8E4EC',
  },

  input: {
    flex: 1,
    fontSize: 14,
    color: T.purpleDark,
  },

  shiftLoadingCard: {
    minHeight: 76,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: '#FFF',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E8E4EC',
    padding: 16,
  },

  shiftLoadingText: {
    fontSize: 12,
    color: T.textMuted,
  },

  shiftList: {
    gap: 10,
  },

  shiftCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#FFF',
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: '#E8E4EC',
  },

  shiftCardSelected: {
    borderWidth: 1.5,
    borderColor: T.purpleIcon,
    backgroundColor: T.purpleLight,
  },

  shiftIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: T.purpleLight,
  },

  shiftIconWrapSelected: {
    backgroundColor: T.purpleIcon,
  },

  shiftInfo: {
    flex: 1,
  },

  shiftName: {
    fontSize: 13,
    fontWeight: '700',
    color: T.purpleDark,
  },

  shiftNameSelected: {
    color: T.purpleIcon,
  },

  shiftTime: {
    marginTop: 3,
    fontSize: 11,
    color: T.textMuted,
    fontFamily: 'monospace',
  },

  shiftMeta: {
    marginTop: 3,
    fontSize: 10,
    color: T.textMuted,
  },

  noShiftCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#FFF',
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: '#E8E4EC',
  },

  noShiftInfo: {
    flex: 1,
  },

  noShiftTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: T.purpleDark,
  },

  noShiftSub: {
    marginTop: 3,
    fontSize: 11,
    color: T.textMuted,
  },

  infoBox: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'flex-start',
    backgroundColor: T.purpleLight,
    borderRadius: 10,
    padding: 12,
    marginTop: 18,
  },

  infoText: {
    flex: 1,
    fontSize: 12,
    color: T.purpleIcon,
    lineHeight: 16,
  },

  errorBox: {
    flexDirection: 'row',
    gap: 6,
    alignItems: 'center',
    backgroundColor: '#FFF1F3',
    borderRadius: 8,
    padding: 10,
    marginTop: 12,
  },

  errorText: {
    flex: 1,
    fontSize: 12,
    color: '#B23A48',
  },

  createBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: T.purpleIcon,
    borderRadius: 14,
    height: 54,
    marginTop: 24,
  },

  createBtnDisabled: {
    opacity: 0.6,
  },

  createBtnText: {
    color: '#FFF',
    fontSize: 15,
    fontWeight: '700',
  },

  bottomSpacer: {
    height: 40,
  },

  successView: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },

  successRing: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },

  successTitle: {
    fontSize: 26,
    fontWeight: '800',
    color: T.purpleDark,
    marginBottom: 8,
  },

  successSub: {
    fontSize: 14,
    color: T.textMuted,
    textAlign: 'center',
    marginBottom: 24,
  },

  credCard: {
    width: '100%',
    backgroundColor: '#FFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 3,
  },

  credLabel: {
    fontSize: 11,
    color: T.textMuted,
    fontWeight: '600',
    marginBottom: 2,
  },

  credValue: {
    fontSize: 15,
    fontWeight: '700',
    color: T.purpleDark,
    fontFamily: 'monospace',
    marginBottom: 4,
  },

  credSep: {
    height: 1,
    backgroundColor: '#F5F3F8',
    marginVertical: 10,
  },

  credNote: {
    fontSize: 11,
    color: T.textMuted,
    marginTop: 10,
    fontStyle: 'italic',
  },

  doneBtn: {
    width: '100%',
    backgroundColor: T.purpleIcon,
    borderRadius: 14,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
  },

  doneBtnText: {
    color: '#FFF',
    fontSize: 15,
    fontWeight: '700',
  },
});