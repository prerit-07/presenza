// app/(organization)/create-admin.tsx

import { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
} from 'react-native';

import Ionicons from '@expo/vector-icons/Ionicons';
import { useRouter } from 'expo-router';

import { sendOtp } from '@/services/auth.service';

import { AuthTheme } from '@/constants/auth-theme';
import AuthLayout from '@/components/AuthLayout';
import { useOnboardingStore } from '@/store/onboarding.store';

const C = AuthTheme.dark;

const STEPS = [
  { id: 1, label: 'Organization' },
  { id: 2, label: 'Admin' },
  { id: 3, label: 'Verify' },
  { id: 4, label: 'Plan' },
  { id: 5, label: 'Review' },
];

function createUsername(
  fullName: string
): string {
  return fullName
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .replace(/\s+/g, '.');
}

export default function CreateAdminScreen() {
  const router = useRouter();
  const currentStep = 2;

  const storedFullName = useOnboardingStore(
    (state) => state.fullName
  );

  const storedEmail = useOnboardingStore(
    (state) => state.email
  );

  const storedPhone = useOnboardingStore(
    (state) => state.phone
  );

  const storedPassword = useOnboardingStore(
    (state) => state.password
  );

  const setAdminDetails = useOnboardingStore(
    (state) => state.setAdminDetails
  );

  const [fullName, setFullName] = useState(
    storedFullName
  );

  const [email, setEmail] = useState(
    storedEmail
  );

  const [phone, setPhone] = useState(
    storedPhone
  );

  const [password, setPassword] = useState(
    storedPassword
  );

  const [
    confirmPassword,
    setConfirmPassword,
  ] = useState(storedPassword);

  const [
    showPassword,
    setShowPassword,
  ] = useState(false);

  const [
    showConfirmPassword,
    setShowConfirmPassword,
  ] = useState(false);

  const [error, setError] = useState('');

  const [loading, setLoading] =
    useState(false);

  const isFormValid =
    Boolean(fullName.trim()) &&
    Boolean(email.trim()) &&
    Boolean(phone.trim()) &&
    password.length >= 8 &&
    password === confirmPassword;

  const handleContinue = async () => {

  setError('');

  const trimmedFullName =
    fullName.trim();

  const trimmedEmail =
    email.trim().toLowerCase();

  const trimmedPhone =
    phone.trim();

  if (
    !trimmedFullName ||
    !trimmedEmail ||
    !trimmedPhone ||
    !password
  ) {
    setError('Please fill in all fields');
    return;
  }

  if (password.length < 8) {
    setError(
      'Password must be at least 8 characters'
    );
    return;
  }

  if (password.length > 100) {
    setError(
      'Password must be at most 100 characters'
    );
    return;
  }

  if (password !== confirmPassword) {
    setError('Passwords do not match');
    return;
  }

  const username =
    createUsername(trimmedFullName);

  if (!username) {
    setError(
      'Please enter a valid full name'
    );
    return;
  }

  if (username.length > 100) {
    setError(
      'Generated username is too long'
    );
    return;
  }

  if (trimmedEmail.length > 150) {
    setError(
      'Email address is too long'
    );
    return;
  }

  try {

    setLoading(true);

    await sendOtp({

      email: trimmedEmail,

      purpose: 'REGISTRATION',

    });

    setAdminDetails({

      fullName: trimmedFullName,

      username,

      email: trimmedEmail,

      phone: trimmedPhone,

      password,

    });

    router.push(
      '/(auth)/otp-verification?flow=admin'
    );

  } catch (error) {

    setError(

      error instanceof Error
        ? error.message
        : 'Failed to send OTP.'

    );

  } finally {

    setLoading(false);

  }

};

  return (
    <AuthLayout
      variant="dark"
      title="Create admin account"
      subtitle="Set up the primary admin for your organization"
    >
      {/* Step indicator */}
      <View style={styles.stepsContainer}>
        <View style={styles.stepsRow}>
          {STEPS.map((step, index) => {
            const isActive =
              step.id === currentStep;

            const isCompleted =
              step.id < currentStep;

            const isLast =
              index === STEPS.length - 1;

            return (
              <View
                key={step.id}
                style={styles.stepSlot}
              >
                {!isLast && (
                  <View
                    style={[
                      styles.stepConnector,
                      {
                        backgroundColor:
                          isCompleted
                            ? C.progressCircleActive
                            : C.progressLine,
                      },
                    ]}
                  />
                )}

                <View
                  style={styles.stepColumn}
                >
                  <View
                    style={[
                      styles.stepCircle,
                      {
                        backgroundColor:
                          isActive ||
                          isCompleted
                            ? C.progressCircleActive
                            : C.progressCircleInactive,
                      },
                    ]}
                  >
                    {isCompleted ? (
                      <Ionicons
                        name="checkmark"
                        size={16}
                        color="#FFFFFF"
                      />
                    ) : (
                      <Text
                        style={[
                          styles.stepNumber,
                          {
                            color: isActive
                              ? C.progressTextActive
                              : C.progressTextInactive,
                          },
                        ]}
                      >
                        {step.id}
                      </Text>
                    )}
                  </View>

                  <Text
                    style={styles.stepLabel}
                    numberOfLines={1}
                  >
                    {step.label}
                  </Text>
                </View>
              </View>
            );
          })}
        </View>
      </View>

      <Text style={styles.sectionTitle}>
        Admin details
      </Text>

      <Text style={styles.fieldLabel}>
        Full Name
      </Text>

      <View style={styles.inputWrapper}>
        <Ionicons
          name="person-outline"
          size={18}
          color={C.inputPlaceholder}
        />

        <TextInput
          style={styles.input}
          placeholder="Enter full name"
          placeholderTextColor={
            C.inputPlaceholder
          }
          value={fullName}
          onChangeText={setFullName}
          autoCapitalize="words"
        />
      </View>

      <Text style={styles.fieldLabel}>
        Email Address
      </Text>

      <View style={styles.inputWrapper}>
        <Ionicons
          name="mail-outline"
          size={18}
          color={C.inputPlaceholder}
        />

        <TextInput
          style={styles.input}
          placeholder="admin@company.com"
          placeholderTextColor={
            C.inputPlaceholder
          }
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
        />
      </View>

      <Text style={styles.fieldLabel}>
        Phone Number
      </Text>

      <View style={styles.inputWrapper}>
        <Ionicons
          name="call-outline"
          size={18}
          color={C.inputPlaceholder}
        />

        <TextInput
          style={styles.input}
          placeholder="+91 98765 43210"
          placeholderTextColor={
            C.inputPlaceholder
          }
          value={phone}
          onChangeText={setPhone}
          keyboardType="phone-pad"
        />
      </View>

      <Text style={styles.fieldLabel}>
        Password
      </Text>

      <View style={styles.inputWrapper}>
        <Ionicons
          name="lock-closed-outline"
          size={18}
          color={C.inputPlaceholder}
        />

        <TextInput
          style={styles.input}
          placeholder="Minimum 8 characters"
          placeholderTextColor={
            C.inputPlaceholder
          }
          value={password}
          onChangeText={setPassword}
          secureTextEntry={!showPassword}
          autoCapitalize="none"
          autoCorrect={false}
        />

        <Pressable
          onPress={() =>
            setShowPassword(
              (previous) => !previous
            )
          }
        >
          <Ionicons
            name={
              showPassword
                ? 'eye-off-outline'
                : 'eye-outline'
            }
            size={18}
            color={C.inputPlaceholder}
          />
        </Pressable>
      </View>

      <Text style={styles.fieldLabel}>
        Confirm Password
      </Text>

      <View style={styles.inputWrapper}>
        <Ionicons
          name="lock-closed-outline"
          size={18}
          color={C.inputPlaceholder}
        />

        <TextInput
          style={styles.input}
          placeholder="Re-enter password"
          placeholderTextColor={
            C.inputPlaceholder
          }
          value={confirmPassword}
          onChangeText={
            setConfirmPassword
          }
          secureTextEntry={
            !showConfirmPassword
          }
          autoCapitalize="none"
          autoCorrect={false}
        />

        <Pressable
          onPress={() =>
            setShowConfirmPassword(
              (previous) => !previous
            )
          }
        >
          <Ionicons
            name={
              showConfirmPassword
                ? 'eye-off-outline'
                : 'eye-outline'
            }
            size={18}
            color={C.inputPlaceholder}
          />
        </Pressable>
      </View>

      {error ? (
        <Text style={styles.errorText}>
          {error}
        </Text>
      ) : null}

      <Pressable
        style={[
          styles.continueButton,
          !isFormValid &&
            styles.continueButtonDisabled,
        ]}
        onPress={handleContinue}
        disabled={
          !isFormValid ||
          loading
        }
      >
        <Text style={styles.continueButtonText}>
          {loading
            ? 'Sending OTP...'
            : 'Continue'}
        </Text>
      </Pressable>
    </AuthLayout>
  );
}

const styles = StyleSheet.create({
  stepsContainer: {
    width: '100%',
    marginBottom: 8,
  },

  stepsRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    width: '100%',
  },

  stepSlot: {
    flex: 1,
    position: 'relative',
    alignItems: 'center',
  },

  stepColumn: {
    width: '100%',
    alignItems: 'center',
    zIndex: 2,
  },

  stepCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },

  stepNumber: {
    fontSize: 14,
    fontWeight: '700',
  },

  stepLabel: {
    width: '100%',
    fontSize: 11,
    color: C.title,
    marginTop: 4,
    textAlign: 'center',
  },

  stepConnector: {
    position: 'absolute',
    top: 15,
    left: '50%',
    width: '100%',
    height: 2,
    zIndex: 1,
  },

  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: C.title,
    marginTop: 24,
    marginBottom: 16,
  },

  fieldLabel: {
    fontSize: 13,
    color: C.label,
    marginBottom: 6,
    fontWeight: '600',
  },

  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: C.inputBackground,
    borderRadius: 14,
    paddingHorizontal: 14,
    height: 52,
    marginBottom: 18,
    gap: 10,
  },

  input: {
    flex: 1,
    fontSize: 14,
    color: C.inputText,
  },

  errorText: {
    color: '#B23A48',
    fontSize: 12,
    marginBottom: 12,
    marginTop: -6,
  },

  continueButton: {
    backgroundColor: C.buttonBackground,
    borderRadius: 16,
    height: 54,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 12,
  },

  continueButtonDisabled: {
    opacity: 0.5,
  },

  continueButtonText: {
    color: C.buttonText,
    fontSize: 15,
    fontWeight: '600',
  },
});