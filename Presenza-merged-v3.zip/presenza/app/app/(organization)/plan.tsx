// app/(organization)/plan.tsx

import { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  StyleSheet,
} from 'react-native';

import Ionicons from '@expo/vector-icons/Ionicons';
import { useRouter } from 'expo-router';

import { AuthTheme } from '@/constants/auth-theme';
import AuthLayout from '@/components/AuthLayout';
import { useOnboardingStore } from '@/store/onboarding.store';

const C = AuthTheme.dark;

const STEPS = [
  { id: 1, label: 'Organization' },
  { id: 2, label: 'Admin' },
  { id: 3, label: 'Verify' },
  { id: 4, label: 'Plan' },
  { id: 5, label: 'Review' },
];

type Plan = {
  id: string;
  name: string;
  price: string;
  period: string;
  description: string;
  features: string[];
  badge?: string;
};

const PLANS: Plan[] = [
  {
    id: 'starter',
    name: 'Starter',
    price: '₹0',
    period: '/month',
    description: 'For small teams getting started',
    features: [
      'Up to 10 employees',
      'GPS attendance tracking',
      'Basic reports',
    ],
  },
  {
    id: 'growth',
    name: 'Growth',
    price: '₹1,499',
    period: '/month',
    description: 'For growing teams that need more',
    features: [
      'Up to 100 employees',
      'Geofencing + Face recognition',
      'Team manager roles',
      'Priority support',
    ],
    badge: 'Most Popular',
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 'Custom',
    period: '',
    description: 'For large organizations',
    features: [
      'Unlimited employees',
      'Advanced analytics',
      'Dedicated account manager',
      'Custom integrations',
    ],
  },
];

export default function CreatePlanScreen() {
  const router = useRouter();
  const currentStep = 4;

  const storedSelectedPlan = useOnboardingStore(
    (state) => state.selectedPlan
  );

  const setStoredSelectedPlan = useOnboardingStore(
    (state) => state.setSelectedPlan
  );

  /*
   * Local UI state always uses plan IDs:
   *
   * starter
   * growth
   * enterprise
   *
   * Store/review state uses readable names:
   *
   * Starter
   * Growth
   * Enterprise
   */
  const [selectedPlanId, setSelectedPlanId] =
    useState<string>(() => {
      if (!storedSelectedPlan) {
        return 'growth';
      }

      const matchedPlan = PLANS.find(
        (plan) =>
          plan.id === storedSelectedPlan ||
          plan.name === storedSelectedPlan
      );

      return matchedPlan?.id ?? 'growth';
    });

  const handleContinue = () => {
    const selectedPlanData = PLANS.find(
      (plan) => plan.id === selectedPlanId
    );

    if (!selectedPlanData) {
      return;
    }

    // Save readable name for review screen.
    // Nothing here is sent as planId to backend.
    setStoredSelectedPlan(
      selectedPlanData.name
    );

    router.push('/(organization)/review');
  };

  return (
    <AuthLayout
      variant="dark"
      title="Choose your plan"
      subtitle="Pick what fits your organization best"
    >
      {/* Step indicator */}
      <View style={styles.stepsContainer}>
        <View style={styles.stepsRow}>
          {STEPS.map((step, index) => {
            const isActive =
              step.id === currentStep;

            const isCompleted =
              step.id < currentStep;

            const isLast =
              index === STEPS.length - 1;

            return (
              <View
                key={step.id}
                style={styles.stepSlot}
              >
                {!isLast && (
                  <View
                    style={[
                      styles.stepConnector,
                      {
                        backgroundColor:
                          isCompleted
                            ? C.progressCircleActive
                            : C.progressLine,
                      },
                    ]}
                  />
                )}

                <View
                  style={styles.stepColumn}
                >
                  <View
                    style={[
                      styles.stepCircle,
                      {
                        backgroundColor:
                          isActive ||
                          isCompleted
                            ? C.progressCircleActive
                            : C.progressCircleInactive,
                      },
                    ]}
                  >
                    {isCompleted ? (
                      <Ionicons
                        name="checkmark"
                        size={16}
                        color="#FFFFFF"
                      />
                    ) : (
                      <Text
                        style={[
                          styles.stepNumber,
                          {
                            color: isActive
                              ? C.progressTextActive
                              : C.progressTextInactive,
                          },
                        ]}
                      >
                        {step.id}
                      </Text>
                    )}
                  </View>

                  <Text
                    style={styles.stepLabel}
                    numberOfLines={1}
                  >
                    {step.label}
                  </Text>
                </View>
              </View>
            );
          })}
        </View>
      </View>

      {/* Plan cards */}
      <Text style={styles.sectionTitle}>
        Available plans
      </Text>

      {PLANS.map((plan) => {
        const isSelected =
          selectedPlanId === plan.id;

        return (
          <Pressable
            key={plan.id}
            style={[
              styles.planCard,
              {
                backgroundColor: isSelected
                  ? C.buttonBackground
                  : C.inputBackground,
              },
            ]}
            onPress={() =>
              setSelectedPlanId(plan.id)
            }
          >
            {plan.badge && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>
                  {plan.badge}
                </Text>
              </View>
            )}

            <View style={styles.planHeader}>
              <View style={styles.planHeaderLeft}>
                <Text
                  style={[
                    styles.planName,
                    {
                      color: isSelected
                        ? '#FFFFFF'
                        : C.title,
                    },
                  ]}
                >
                  {plan.name}
                </Text>

                <Text
                  style={[
                    styles.planDescription,
                    {
                      color: isSelected
                        ? '#C9B9D9'
                        : C.subtitle,
                    },
                  ]}
                >
                  {plan.description}
                </Text>
              </View>

              <View
                style={[
                  styles.radioOuter,
                  {
                    borderColor: isSelected
                      ? '#FFFFFF'
                      : C.subtitle,
                  },
                ]}
              >
                {isSelected && (
                  <View
                    style={styles.radioInner}
                  />
                )}
              </View>
            </View>

            <View style={styles.priceRow}>
              <Text
                style={[
                  styles.planPrice,
                  {
                    color: isSelected
                      ? '#FFFFFF'
                      : C.title,
                  },
                ]}
              >
                {plan.price}
              </Text>

              {plan.period ? (
                <Text
                  style={[
                    styles.planPeriod,
                    {
                      color: isSelected
                        ? '#C9B9D9'
                        : C.subtitle,
                    },
                  ]}
                >
                  {plan.period}
                </Text>
              ) : null}
            </View>

            <View style={styles.featuresList}>
              {plan.features.map((feature) => (
                <View
                  key={feature}
                  style={styles.featureRow}
                >
                  <Ionicons
                    name="checkmark-circle"
                    size={16}
                    color={
                      isSelected
                        ? '#FFFFFF'
                        : C.label
                    }
                  />

                  <Text
                    style={[
                      styles.featureText,
                      {
                        color: isSelected
                          ? '#E5DCF0'
                          : C.subtitle,
                      },
                    ]}
                  >
                    {feature}
                  </Text>
                </View>
              ))}
            </View>
          </Pressable>
        );
      })}

      <Pressable
        style={styles.continueButton}
        onPress={handleContinue}
      >
        <Text style={styles.continueButtonText}>
          Continue
        </Text>
      </Pressable>
    </AuthLayout>
  );
}

const styles = StyleSheet.create({
  /* =========================
     STEPPER
  ========================= */

  stepsContainer: {
    width: '100%',
    marginBottom: 8,
  },

  stepsRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    width: '100%',
  },

  stepSlot: {
    flex: 1,
    position: 'relative',
    alignItems: 'center',
  },

  stepColumn: {
    width: '100%',
    alignItems: 'center',
    zIndex: 2,
  },

  stepCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },

  stepNumber: {
    fontSize: 14,
    fontWeight: '700',
  },

  stepLabel: {
    width: '100%',
    fontSize: 11,
    color: C.title,
    marginTop: 4,
    textAlign: 'center',
  },

  stepConnector: {
    position: 'absolute',
    top: 15,
    left: '50%',
    width: '100%',
    height: 2,
    zIndex: 1,
  },

  /* =========================
     CONTENT
  ========================= */

  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: C.title,
    marginTop: 24,
    marginBottom: 16,
  },

  planCard: {
    borderRadius: 18,
    padding: 18,
    marginBottom: 16,
    position: 'relative',
  },

  badge: {
    position: 'absolute',
    top: -10,
    right: 16,
    backgroundColor: C.label,
    borderRadius: 10,
    paddingVertical: 3,
    paddingHorizontal: 10,
  },

  badgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '700',
  },

  planHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },

  planHeaderLeft: {
    flex: 1,
  },

  planName: {
    fontSize: 17,
    fontWeight: '700',
  },

  planDescription: {
    fontSize: 12,
    marginTop: 2,
  },

  radioOuter: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 12,
  },

  radioInner: {
    width: 11,
    height: 11,
    borderRadius: 6,
    backgroundColor: '#FFFFFF',
  },

  priceRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginTop: 14,
  },

  planPrice: {
    fontSize: 24,
    fontWeight: '800',
  },

  planPeriod: {
    fontSize: 13,
    marginLeft: 4,
    marginBottom: 3,
  },

  featuresList: {
    marginTop: 14,
    gap: 8,
  },

  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },

  featureText: {
    fontSize: 12.5,
  },

  continueButton: {
    backgroundColor: C.buttonBackground,
    borderRadius: 16,
    height: 54,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
  },

  continueButtonText: {
    color: C.buttonText,
    fontSize: 15,
    fontWeight: '600',
  },
});