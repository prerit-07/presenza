import React, {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react';

import {
  ActivityIndicator,
  FlatList,
  RefreshControl,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import {
  Ionicons,
  MaterialCommunityIcons,
} from '@expo/vector-icons';

import {
  router,
} from 'expo-router';

import {
  Header,
} from '@/components/Header';

import {
  Theme,
} from '@/constants/theme';

import {
  getOrganizationAttendance,
  type Attendance,
} from '@/services/attendance.service';

import {
  getEmployees,
  type Employee,
} from '@/services/employee.service';

type AttendanceRow = Attendance & {
  employeeName: string;
  employeeId: number | null;
};

export default function AttendanceScreen() {
  const [
    attendance,
    setAttendance,
  ] = useState<Attendance[]>([]);

  const [
    employees,
    setEmployees,
  ] = useState<Employee[]>([]);

  const [
    loading,
    setLoading,
  ] = useState(true);

  const [
    refreshing,
    setRefreshing,
  ] = useState(false);

  const [
    error,
    setError,
  ] = useState('');

  const [
    search,
    setSearch,
  ] = useState('');

  const loadData = useCallback(
    async (
      isRefresh = false
    ) => {
      if (isRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      setError('');

      try {
        const [
          attendanceResponse,
          employeeResponse,
        ] = await Promise.all([
          getOrganizationAttendance(),
          getEmployees(),
        ]);

        setAttendance(
          attendanceResponse
        );

        setEmployees(
          employeeResponse
        );
      } catch (loadError) {
        console.error(
          'Failed to load admin attendance:',
          loadError
        );

        setError(
          getErrorMessage(
            loadError,
            'Failed to load attendance records.'
          )
        );
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    []
  );

  useEffect(() => {
    loadData();
  }, [loadData]);

  const employeeByUserId =
    useMemo(() => {
      const map =
        new Map<number, Employee>();

      employees.forEach(
        (employee) => {
          map.set(
            employee.userId,
            employee
          );
        }
      );

      return map;
    }, [employees]);

  const rows =
    useMemo<AttendanceRow[]>(
      () =>
        attendance.map(
          (record) => {
            const employee =
              employeeByUserId.get(
                record.userId
              );

            return {
              ...record,
              employeeName:
                employee
                  ?.employeeName ??
                `User #${record.userId}`,
              employeeId:
                employee
                  ?.employeeId ??
                null,
            };
          }
        ),
      [
        attendance,
        employeeByUserId,
      ]
    );

  const filteredRows =
    useMemo(() => {
      const query =
        search
          .trim()
          .toLowerCase();

      if (!query) {
        return rows;
      }

      return rows.filter(
        (row) =>
          row.employeeName
            .toLowerCase()
            .includes(query) ||
          String(row.userId)
            .includes(query) ||
          String(
            row.employeeId ?? ''
          ).includes(query) ||
          row.status
            .toLowerCase()
            .includes(query)
      );
    }, [rows, search]);

  const summary =
    useMemo(() => {
      const today =
        new Date();

      const todayCount =
        rows.filter((row) =>
          isSameLocalDay(
            new Date(
              row.checkinTime
            ),
            today
          )
        ).length;

      const presentCount =
        rows.filter(
          (row) =>
            row.status ===
            'PRESENT'
        ).length;

      const pendingCount =
        rows.filter(
          (row) =>
            row.status ===
            'PENDING'
        ).length;

      return {
        total: rows.length,
        today: todayCount,
        present: presentCount,
        pending: pendingCount,
      };
    }, [rows]);

  const handleRefresh =
    useCallback(() => {
      loadData(true);
    }, [loadData]);

  if (loading) {
    return (
      <SafeAreaView
        style={styles.safeArea}
      >
        <Header
          title="Attendance"
          subtitle="Organization records"
          showBackButton
          onBackPress={() =>
            router.replace(
              '/(organization)/(tabs)/overview'
            )
          }
        />

        <View
          style={styles.centered}
        >
          <ActivityIndicator
            size="large"
            color={
              Theme.colors.primary
            }
          />

          <Text
            style={styles.loadingText}
          >
            Loading attendance...
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView
      style={styles.safeArea}
    >
      <Header
        title="Attendance"
        subtitle="Organization records"
        showBackButton
        onBackPress={() =>
          router.replace(
            '/(organization)/(tabs)/overview'
          )
        }
      />

      <FlatList
        data={filteredRows}
        keyExtractor={(item) =>
          String(
            item.attendanceId
          )
        }
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={
              handleRefresh
            }
            tintColor={
              Theme.colors.primary
            }
          />
        }
        contentContainerStyle={
          styles.listContent
        }
        showsVerticalScrollIndicator={
          false
        }
        ListHeaderComponent={
          <View>
            <View
              style={
                styles.summaryGrid
              }
            >
              <SummaryCard
                icon="calendar-today"
                label="Today"
                value={
                  summary.today
                }
              />

              <SummaryCard
                icon="check-circle-outline"
                label="Present"
                value={
                  summary.present
                }
              />

              <SummaryCard
                icon="clock-outline"
                label="Pending"
                value={
                  summary.pending
                }
              />

              <SummaryCard
                icon="format-list-bulleted"
                label="Total"
                value={
                  summary.total
                }
              />
            </View>

            <View
              style={
                styles.searchBox
              }
            >
              <Ionicons
                name="search-outline"
                size={18}
                color={
                  Theme.colors.subText
                }
              />

              <TextInput
                style={
                  styles.searchInput
                }
                value={search}
                onChangeText={
                  setSearch
                }
                placeholder="Search employee or status"
                placeholderTextColor={
                  Theme.colors.subText
                }
              />

              {search.length > 0 && (
                <TouchableOpacity
                  onPress={() =>
                    setSearch('')
                  }
                >
                  <Ionicons
                    name="close-circle"
                    size={18}
                    color={
                      Theme.colors
                        .subText
                    }
                  />
                </TouchableOpacity>
              )}
            </View>

            {error ? (
              <View
                style={
                  styles.errorBanner
                }
              >
                <Ionicons
                  name="alert-circle-outline"
                  size={18}
                  color="#D64545"
                />

                <Text
                  style={
                    styles.errorText
                  }
                >
                  {error}
                </Text>

                <TouchableOpacity
                  onPress={() =>
                    loadData()
                  }
                >
                  <Text
                    style={
                      styles.retryText
                    }
                  >
                    Retry
                  </Text>
                </TouchableOpacity>
              </View>
            ) : null}

            <View
              style={
                styles.sectionHeader
              }
            >
              <Text
                style={
                  styles.sectionTitle
                }
              >
                Attendance Records
              </Text>

              <Text
                style={
                  styles.resultCount
                }
              >
                {
                  filteredRows.length
                }{' '}
                record
                {
                  filteredRows.length ===
                  1
                    ? ''
                    : 's'
                }
              </Text>
            </View>
          </View>
        }
        renderItem={({ item }) => (
          <AttendanceRowCard
            item={item}
          />
        )}
        ListEmptyComponent={
          <View
            style={styles.emptyState}
          >
            <MaterialCommunityIcons
              name="calendar-remove-outline"
              size={48}
              color={
                Theme.colors.subText
              }
            />

            <Text
              style={styles.emptyTitle}
            >
              No attendance records
            </Text>

            <Text
              style={styles.emptyText}
            >
              {search.trim()
                ? 'No records match your search.'
                : 'Employee check-ins will appear here.'}
            </Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

function SummaryCard({
  icon,
  label,
  value,
}: {
  icon:
    | 'calendar-today'
    | 'check-circle-outline'
    | 'clock-outline'
    | 'format-list-bulleted';
  label: string;
  value: number;
}) {
  return (
    <View style={styles.summaryCard}>
      <View
        style={
          styles.summaryIconWrap
        }
      >
        <MaterialCommunityIcons
          name={icon}
          size={18}
          color={
            Theme.colors.primary
          }
        />
      </View>

      <Text
        style={styles.summaryValue}
      >
        {value}
      </Text>

      <Text
        style={styles.summaryLabel}
      >
        {label}
      </Text>
    </View>
  );
}

function AttendanceRowCard({
  item,
}: {
  item: AttendanceRow;
}) {
  const checkinDate =
    new Date(item.checkinTime);

  return (
    <View style={styles.recordCard}>
      <View style={styles.avatar}>
        <Text
          style={styles.avatarText}
        >
          {getInitials(
            item.employeeName
          )}
        </Text>
      </View>

      <View style={styles.recordMain}>
        <View
          style={styles.recordTopRow}
        >
          <Text
            style={
              styles.employeeName
            }
            numberOfLines={1}
          >
            {item.employeeName}
          </Text>

          <StatusBadge
            status={item.status}
          />
        </View>

        <View
          style={styles.detailRow}
        >
          <Ionicons
            name="calendar-outline"
            size={13}
            color={
              Theme.colors.subText
            }
          />

          <Text
            style={styles.detailText}
          >
            {formatDate(
              checkinDate
            )}
          </Text>
        </View>

        <View
          style={styles.detailRow}
        >
          <Ionicons
            name="time-outline"
            size={13}
            color={
              Theme.colors.subText
            }
          />

          <Text
            style={styles.detailText}
          >
            {formatTime(
              checkinDate
            )}
          </Text>

          <Text
            style={styles.dot}
          >
            ·
          </Text>

          <Text
            style={styles.detailText}
          >
            Shift #
            {item.shiftId ?? '--'}
          </Text>
        </View>

        <View
          style={styles.detailRow}
        >
          <Ionicons
            name={
              item.wifiVerified
                ? 'wifi'
                : 'location-outline'
            }
            size={13}
            color={
              Theme.colors.subText
            }
          />

          <Text
            style={styles.detailText}
          >
            {item.wifiVerified
              ? 'Wi-Fi verified'
              : 'GPS check-in'}
          </Text>

          {item.employeeId !=
            null && (
            <>
              <Text
                style={styles.dot}
              >
                ·
              </Text>

              <Text
                style={
                  styles.detailText
                }
              >
                Employee #
                {item.employeeId}
              </Text>
            </>
          )}
        </View>

        {item.remarks ? (
          <View
            style={styles.remarksBox}
          >
            <Text
              style={
                styles.remarksText
              }
            >
              {item.remarks}
            </Text>
          </View>
        ) : null}
      </View>
    </View>
  );
}

function StatusBadge({
  status,
}: {
  status: string;
}) {
  const config =
    getStatusConfig(status);

  return (
    <View
      style={[
        styles.statusBadge,
        {
          backgroundColor:
            config.background,
        },
      ]}
    >
      <View
        style={[
          styles.statusDot,
          {
            backgroundColor:
              config.foreground,
          },
        ]}
      />

      <Text
        style={[
          styles.statusText,
          {
            color:
              config.foreground,
          },
        ]}
      >
        {formatStatus(status)}
      </Text>
    </View>
  );
}

function getStatusConfig(
  status: string
) {
  switch (
    status.toUpperCase()
  ) {
    case 'PRESENT':
      return {
        background:
          'rgba(67, 196, 122, 0.12)',
        foreground: '#2E9E62',
      };

    case 'PENDING':
      return {
        background:
          'rgba(240, 173, 78, 0.14)',
        foreground: '#C7831D',
      };

    case 'REJECTED':
    case 'ABSENT':
      return {
        background:
          'rgba(214, 69, 69, 0.12)',
        foreground: '#D64545',
      };

    case 'LATE':
      return {
        background:
          'rgba(91, 61, 122, 0.12)',
        foreground:
          Theme.colors.primary,
      };

    default:
      return {
        background: '#F2F0F5',
        foreground:
          Theme.colors.subText,
      };
  }
}

function formatStatus(
  status: string
) {
  return status
    .replace(/_/g, ' ')
    .toLowerCase()
    .replace(
      /\b\w/g,
      (character) =>
        character.toUpperCase()
    );
}

function formatDate(
  date: Date
) {
  if (
    Number.isNaN(date.getTime())
  ) {
    return 'Unknown date';
  }

  return date.toLocaleDateString(
    undefined,
    {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    }
  );
}

function formatTime(
  date: Date
) {
  if (
    Number.isNaN(date.getTime())
  ) {
    return '--:--';
  }

  return date.toLocaleTimeString(
    undefined,
    {
      hour: '2-digit',
      minute: '2-digit',
    }
  );
}

function isSameLocalDay(
  first: Date,
  second: Date
) {
  return (
    first.getFullYear() ===
      second.getFullYear() &&
    first.getMonth() ===
      second.getMonth() &&
    first.getDate() ===
      second.getDate()
  );
}

function getInitials(
  name: string
) {
  const parts = name
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  if (parts.length === 0) {
    return '?';
  }

  return parts
    .slice(0, 2)
    .map((part) =>
      part.charAt(0).toUpperCase()
    )
    .join('');
}

function getErrorMessage(
  error: unknown,
  fallback: string
) {
  if (error instanceof Error) {
    return (
      error.message ||
      fallback
    );
  }

  return fallback;
}

const styles =
  StyleSheet.create({
    safeArea: {
      flex: 1,
      backgroundColor:
        Theme.colors.background,
    },

    centered: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      paddingHorizontal: 24,
    },

    loadingText: {
      marginTop: 10,
      fontSize: 13,
      color:
        Theme.colors.subText,
    },

    listContent: {
      paddingHorizontal: 20,
      paddingBottom: 40,
    },

    summaryGrid: {
      flexDirection: 'row',
      gap: 8,
      marginTop: 12,
      marginBottom: 16,
    },

    summaryCard: {
      flex: 1,
      minWidth: 0,
      backgroundColor: '#FFF',
      borderRadius: 12,
      paddingVertical: 12,
      paddingHorizontal: 8,
      alignItems: 'center',
      borderWidth: 1,
      borderColor: '#EEEAF3',
    },

    summaryIconWrap: {
      width: 30,
      height: 30,
      borderRadius: 15,
      backgroundColor:
        '#F2EDF8',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 6,
    },

    summaryValue: {
      fontSize: 18,
      fontWeight: '800',
      color: Theme.colors.text,
    },

    summaryLabel: {
      marginTop: 2,
      fontSize: 10,
      color:
        Theme.colors.subText,
    },

    searchBox: {
      height: 46,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      paddingHorizontal: 14,
      backgroundColor: '#FFF',
      borderRadius: 12,
      borderWidth: 1,
      borderColor: '#E9E4EF',
      marginBottom: 14,
    },

    searchInput: {
      flex: 1,
      fontSize: 14,
      color: Theme.colors.text,
    },

    errorBanner: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      backgroundColor: '#FFF2F2',
      borderRadius: 12,
      padding: 12,
      marginBottom: 14,
    },

    errorText: {
      flex: 1,
      fontSize: 12,
      color: '#D64545',
    },

    retryText: {
      fontSize: 12,
      fontWeight: '700',
      color:
        Theme.colors.primary,
    },

    sectionHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent:
        'space-between',
      marginBottom: 10,
    },

    sectionTitle: {
      fontSize: 16,
      fontWeight: '800',
      color: Theme.colors.text,
    },

    resultCount: {
      fontSize: 11,
      color:
        Theme.colors.subText,
    },

    recordCard: {
      flexDirection: 'row',
      backgroundColor: '#FFF',
      borderRadius: 14,
      padding: 14,
      marginBottom: 10,
      borderWidth: 1,
      borderColor: '#EEEAF3',
    },

    avatar: {
      width: 44,
      height: 44,
      borderRadius: 22,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor:
        '#EAE4F3',
      marginRight: 12,
    },

    avatarText: {
      fontSize: 14,
      fontWeight: '800',
      color:
        Theme.colors.primary,
    },

    recordMain: {
      flex: 1,
    },

    recordTopRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      marginBottom: 7,
    },

    employeeName: {
      flex: 1,
      fontSize: 14,
      fontWeight: '800',
      color: Theme.colors.text,
    },

    detailRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 4,
      gap: 5,
    },

    detailText: {
      fontSize: 11,
      color:
        Theme.colors.subText,
    },

    dot: {
      fontSize: 11,
      color:
        Theme.colors.subText,
      marginHorizontal: 2,
    },

    statusBadge: {
      flexDirection: 'row',
      alignItems: 'center',
      borderRadius: 10,
      paddingHorizontal: 8,
      paddingVertical: 4,
    },

    statusDot: {
      width: 5,
      height: 5,
      borderRadius: 3,
      marginRight: 5,
    },

    statusText: {
      fontSize: 9,
      fontWeight: '800',
    },

    remarksBox: {
      marginTop: 8,
      padding: 8,
      borderRadius: 8,
      backgroundColor: '#F8F6FA',
    },

    remarksText: {
      fontSize: 10,
      lineHeight: 15,
      color:
        Theme.colors.subText,
    },

    emptyState: {
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 60,
      paddingHorizontal: 24,
    },

    emptyTitle: {
      marginTop: 12,
      fontSize: 15,
      fontWeight: '800',
      color: Theme.colors.text,
    },

    emptyText: {
      marginTop: 5,
      fontSize: 12,
      lineHeight: 18,
      textAlign: 'center',
      color:
        Theme.colors.subText,
    },
  });