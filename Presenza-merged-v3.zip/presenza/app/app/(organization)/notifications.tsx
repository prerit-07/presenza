// app/notifications.tsx
// Role: All
// Opens from: Bell icon on all dashboards

import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, ActivityIndicator } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { PageHeader } from '@/components/PageHeader';
import { api } from '@/services/api';

type Notification = {
  notificationId: number;
  title: string;
  body: string;
  createdAt: string;
  isRead: boolean;
};

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function iconForTitle(title: string): { icon: keyof typeof MaterialCommunityIcons.glyphMap; color: string } {
  const t = title.toLowerCase();
  if (t.includes('leave')) return { icon: 'calendar-check-outline', color: '#F59E0B' };
  if (t.includes('device')) return { icon: 'cellphone-key', color: T.purpleIcon };
  if (t.includes('check-in') || t.includes('checkin') || t.includes('failed')) return { icon: 'map-marker-alert-outline', color: '#B23A48' };
  if (t.includes('member') || t.includes('employee') || t.includes('joined')) return { icon: 'account-plus-outline', color: '#4CAF50' };
  if (t.includes('wfh') || t.includes('work from home')) return { icon: 'home-account', color: '#6E4B8D' };
  return { icon: 'bell-outline', color: T.purpleIcon };
}

export default function NotificationsScreen() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchNotifications = useCallback(async () => {
    try {
      setError(null);
      const data = await api.get<Notification[]>('/api/notifications');
      setNotifications(data);
    } catch (e: any) {
      setError(e?.message ?? 'Failed to load notifications');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  const markAsRead = async (id: number) => {
    // Optimistically update UI
    setNotifications((ns) =>
      ns.map((n) => (n.notificationId === id ? { ...n, isRead: true } : n))
    );
    try {
      await api.put(`/api/notifications/${id}/read`);
    } catch {
      // Silently ignore mark-read failures
    }
  };

  const markAllRead = async () => {
    const unread = notifications.filter((n) => !n.isRead);
    setNotifications((ns) => ns.map((n) => ({ ...n, isRead: true })));
    for (const n of unread) {
      try {
        await api.put(`/api/notifications/${n.notificationId}/read`);
      } catch { /* ignore */ }
    }
  };

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  if (isLoading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color={T.purpleIcon} />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.root}>
        <PageHeader title="Notifications" />
        <View style={styles.centered}>
          <MaterialCommunityIcons name="bell-alert-outline" size={48} color={T.textMuted} />
          <Text style={styles.emptyText}>{error}</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <PageHeader
        title="Notifications"
        subtitle={unreadCount > 0 ? `${unreadCount} unread` : undefined}
        rightElement={
          unreadCount > 0 ? (
            <Pressable onPress={markAllRead}>
              <Text style={styles.markAllText}>Mark all read</Text>
            </Pressable>
          ) : undefined
        }
      />

      <FlatList
        data={notifications}
        keyExtractor={(n) => String(n.notificationId)}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => {
          const { icon, color } = iconForTitle(item.title);
          return (
            <Pressable
              style={[styles.notifCard, !item.isRead && styles.notifCardUnread]}
              onPress={() => markAsRead(item.notificationId)}
            >
              <View style={[styles.iconWrap, { backgroundColor: color + '18' }]}>
                <MaterialCommunityIcons name={icon} size={20} color={color} />
              </View>
              <View style={styles.notifInfo}>
                <Text style={styles.notifTitle}>{item.title}</Text>
                <Text style={styles.notifBody}>{item.body}</Text>
                <Text style={styles.notifTime}>{timeAgo(item.createdAt)}</Text>
              </View>
              {!item.isRead && <View style={styles.unreadDot} />}
            </Pressable>
          );
        }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons name="bell-check-outline" size={48} color={T.textMuted} />
            <Text style={styles.emptyText}>All caught up!</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: T.screenBg },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  list: { paddingHorizontal: 20, paddingBottom: 100 },
  notifCard: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF',
    borderRadius: 16, padding: 14, marginBottom: 10,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05, shadowRadius: 4, elevation: 2,
  },
  notifCardUnread: {
    borderLeftWidth: 3, borderLeftColor: T.purpleIcon,
  },
  iconWrap: { width: 42, height: 42, borderRadius: 21, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  notifInfo: { flex: 1 },
  notifTitle: { fontSize: 13, fontWeight: '700', color: T.purpleDark, marginBottom: 2 },
  notifBody: { fontSize: 12, color: T.textMuted, marginBottom: 4 },
  notifTime: { fontSize: 11, color: '#C8B4E0' },
  unreadDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: T.purpleIcon, marginLeft: 8 },
  markAllText: { fontSize: 12, fontWeight: '600', color: T.purpleIcon },
  empty: { alignItems: 'center', marginTop: 60, gap: 10 },
  emptyText: { fontSize: 14, color: T.textMuted },
});
