// app/(organization)/edit-profile.tsx
// Role: ORG_ADMIN
// Opens from: Profile tab → Edit Profile

import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Modal,
  ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppStore } from '@/store/useAppStore';
import { useAuthStore } from '@/store/auth.store';
import { api } from '@/services/api';
import { DashboardTheme as T } from '@/constants/dashboard-theme';

export default function EditProfileScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const user = useAppStore((s) => s.user);
  const setUser = useAppStore((s) => s.setUser);

  const [username, setUsername] = useState(user?.username ?? '');
  const [email] = useState(user?.email ?? ''); // read-only
  const [isSaving, setIsSaving] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
  };

  const handleSave = async () => {
    if (!username.trim()) {
      showToast('error', 'Name cannot be empty.');
      return;
    }

    setIsSaving(true);
    try {
      await api.patch('/auth/me', { username: username.trim() });
      
      if (user) {
        setUser({ ...user, username: username.trim(), name: username.trim() });
      }

      showToast('success', 'Your profile has been updated successfully!');
    } catch (e: any) {
      showToast('error', e?.message ?? 'Could not update profile. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <View style={styles.root}>
      {/* ── Dark Purple Header (same style as all other screens) ── */}
      <View style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <TouchableOpacity style={styles.backCircle} onPress={() => router.back()}>
          <Ionicons name="chevron-back" size={20} color="#5B3D7A" />
        </TouchableOpacity>

        <View style={styles.headerCenter} pointerEvents="none">
          <Text style={styles.headerTitle}>Edit Profile</Text>
          <Text style={styles.headerSubtitle}>Update your account details</Text>
        </View>

        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Avatar placeholder */}
        <View style={styles.avatarSection}>
          <View style={styles.avatarCircle}>
            <Text style={styles.avatarLetter}>
              {(username[0] ?? '?').toUpperCase()}
            </Text>
          </View>
          <Text style={styles.avatarHint}>Profile picture coming soon</Text>
        </View>

        {/* Fields */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>PERSONAL INFORMATION</Text>

          {/* Username */}
          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>Display Name</Text>
            <View style={styles.inputWrapper}>
              <MaterialCommunityIcons
                name="account-outline"
                size={18}
                color={T.purpleIcon}
                style={styles.inputIcon}
              />
              <TextInput
                style={styles.input}
                value={username}
                onChangeText={setUsername}
                placeholder="Enter your name"
                placeholderTextColor={T.textMuted}
                autoCapitalize="words"
                returnKeyType="done"
              />
            </View>
          </View>

          {/* Email — read only */}
          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>Email Address</Text>
            <View style={[styles.inputWrapper, styles.inputWrapperDisabled]}>
              <MaterialCommunityIcons
                name="email-outline"
                size={18}
                color={T.textMuted}
                style={styles.inputIcon}
              />
              <TextInput
                style={[styles.input, { color: T.textMuted }]}
                value={email}
                editable={false}
                placeholderTextColor={T.textMuted}
              />
              <MaterialCommunityIcons
                name="lock-outline"
                size={14}
                color={T.textMuted}
              />
            </View>
            <Text style={styles.fieldHint}>Email cannot be changed</Text>
          </View>

          {/* Role — read only */}
          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>Role</Text>
            <View style={[styles.inputWrapper, styles.inputWrapperDisabled]}>
              <MaterialCommunityIcons
                name="shield-account-outline"
                size={18}
                color={T.textMuted}
                style={styles.inputIcon}
              />
              <TextInput
                style={[styles.input, { color: T.textMuted }]}
                value={
                  user?.role === 'ORG_ADMIN'
                    ? 'Organization Admin'
                    : user?.role === 'MANAGER'
                    ? 'Manager'
                    : 'Employee'
                }
                editable={false}
              />
            </View>
          </View>
        </View>

        {/* Save Button */}
        <TouchableOpacity
          style={[styles.saveBtn, isSaving && styles.saveBtnDisabled]}
          onPress={handleSave}
          disabled={isSaving}
          activeOpacity={0.85}
        >
          {isSaving ? (
            <ActivityIndicator size="small" color="#FFF" />
          ) : (
            <>
              <Ionicons name="checkmark-circle-outline" size={20} color="#FFF" />
              <Text style={styles.saveBtnText}>Save Changes</Text>
            </>
          )}
        </TouchableOpacity>
      </ScrollView>

      {/* ── Themed Toast Modal ── */}
      <Modal visible={!!toast} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <View style={[
              styles.modalIconCircle,
              { backgroundColor: toast?.type === 'success' ? '#4CAF5020' : '#B23A4820' }
            ]}>
              <Ionicons
                name={toast?.type === 'success' ? 'checkmark-circle' : 'alert-circle'}
                size={36}
                color={toast?.type === 'success' ? '#4CAF50' : '#B23A48'}
              />
            </View>
            <Text style={styles.modalTitle}>
              {toast?.type === 'success' ? 'Profile Updated!' : 'Oops!'}
            </Text>
            <Text style={styles.modalMessage}>{toast?.message}</Text>
            <TouchableOpacity
              style={[
                styles.modalBtn,
                { backgroundColor: toast?.type === 'success' ? T.purpleIcon : '#B23A48' }
              ]}
              onPress={() => {
                if (toast?.type === 'success') {
                  setToast(null);
                  router.back();
                } else {
                  setToast(null);
                }
              }}
            >
              <Text style={styles.modalBtnText}>
                {toast?.type === 'success' ? 'Great!' : 'Try Again'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: T.screenBg },

  // ── Header ──
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#EDE8F5',
    paddingHorizontal: 16,
    paddingBottom: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  backCircle: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: '#CAA6EC',
    justifyContent: 'center', alignItems: 'center',
  },
  headerCenter: {
    position: 'absolute',
    left: 0, right: 0, bottom: 18,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 22, fontWeight: '700', color: '#29185c',
  },
  headerSubtitle: {
    fontSize: 12, color: '#6B4E8D', marginTop: 3,
  },

  // ── Content ──
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 60,
  },

  avatarSection: {
    alignItems: 'center',
    marginBottom: 28,
  },
  avatarCircle: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: '#EDE8F5',
    borderWidth: 3, borderColor: '#CAA6EC',
    justifyContent: 'center', alignItems: 'center',
    marginBottom: 10,
  },
  avatarLetter: {
    fontSize: 32, fontWeight: '700', color: T.purpleIcon,
  },
  avatarHint: {
    fontSize: 12, color: T.textMuted,
  },

  card: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 3,
  },
  cardTitle: {
    fontSize: 11, fontWeight: '700', color: '#9B78C0',
    letterSpacing: 1, marginBottom: 18,
  },

  fieldGroup: { marginBottom: 16 },
  fieldLabel: {
    fontSize: 12, fontWeight: '600', color: T.purpleDark, marginBottom: 8,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F1FA',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E0D7EE',
    paddingHorizontal: 12,
    paddingVertical: 12,
  },
  inputWrapperDisabled: {
    backgroundColor: '#F0EDF6',
    borderColor: '#E8E4EC',
  },
  inputIcon: { marginRight: 10 },
  input: {
    flex: 1,
    fontSize: 14,
    color: T.purpleDark,
    fontWeight: '500',
  },
  fieldHint: {
    fontSize: 11, color: T.textMuted, marginTop: 5, marginLeft: 4,
  },

  saveBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: T.purpleIcon,
    borderRadius: 16,
    paddingVertical: 16,
    shadowColor: T.purpleIcon,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  saveBtnDisabled: { opacity: 0.6 },
  saveBtnText: {
    fontSize: 16, fontWeight: '700', color: '#FFF',
  },

  // ── Modal ──
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(41, 24, 92, 0.55)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
  },
  modalBox: {
    backgroundColor: '#FFF',
    borderRadius: 24,
    padding: 28,
    alignItems: 'center',
    width: '100%',
    shadowColor: '#29185c',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.18,
    shadowRadius: 20,
    elevation: 10,
  },
  modalIconCircle: {
    width: 72, height: 72, borderRadius: 36,
    justifyContent: 'center', alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 20, fontWeight: '800', color: '#29185c',
    marginBottom: 8,
  },
  modalMessage: {
    fontSize: 14, color: '#6B4E8D',
    textAlign: 'center', lineHeight: 20,
    marginBottom: 24,
  },
  modalBtn: {
    borderRadius: 14,
    paddingVertical: 14, paddingHorizontal: 40,
  },
  modalBtnText: {
    fontSize: 15, fontWeight: '700', color: '#FFF',
  },
});
