// app/(organization)/shifts.tsx

import React, {
  useCallback,
  useEffect,
  useState,
} from 'react';

import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import {
  MaterialCommunityIcons,
} from '@expo/vector-icons';

import {
  PageHeader,
} from '@/components/PageHeader';

import {
  Modal,
} from '@/components/Modal';

import {
  DashboardTheme as T,
} from '@/constants/dashboard-theme';

import {
  createShift,
  getShifts,
  updateShift,
  type Shift,
} from '@/services/shift.service';

import {
  getGeofences,
  type Geofence,
} from '@/services/geofence.service';

import {
  getMyOrganization,
} from '@/services/organization.service';
import { useThemedAlert } from '@/components/ThemedAlertProvider';

type ModalMode =
  | 'create'
  | 'edit';

export default function ShiftsScreen() {
  const { showAlert } = useThemedAlert();
  const [shifts, setShifts] =
    useState<Shift[]>([]);

  const [geofences, setGeofences] =
    useState<Geofence[]>([]);

  const [orgId, setOrgId] =
    useState<number | null>(null);

  const [loading, setLoading] =
    useState(true);

  const [saving, setSaving] =
    useState(false);

  const [showModal, setShowModal] =
    useState(false);

  const [modalMode, setModalMode] =
    useState<ModalMode>('create');

  const [
    editingShiftId,
    setEditingShiftId,
  ] = useState<number | null>(null);

  const [shiftName, setShiftName] =
    useState('');

  const [startTime, setStartTime] =
    useState('09:00');

  const [endTime, setEndTime] =
    useState('18:00');

  const [
    allowedLateMinutes,
    setAllowedLateMinutes,
  ] = useState('15');

  const [
    selectedGeofenceId,
    setSelectedGeofenceId,
  ] = useState<number | null>(null);

  const loadData = useCallback(
    async () => {
      setLoading(true);

      try {
        const [
          organization,
          shiftList,
          geofenceList,
        ] = await Promise.all([
          getMyOrganization(),
          getShifts(),
          getGeofences(),
        ]);

        setOrgId(organization.orgId);
        setShifts(shiftList);
        setGeofences(geofenceList);

        setSelectedGeofenceId(
          (current) =>
            current ??
            geofenceList[0]
              ?.geofenceId ??
            null
        );
      } catch (error) {
        console.error(
          'Failed to load shifts:',
          error
        );

        showAlert({
          type: 'error',
          title: 'Error',
          message: error instanceof Error
            ? error.message
            : 'Failed to load shifts.'
        });
      } finally {
        setLoading(false);
      }
    },
    []
  );

  useEffect(() => {
    loadData();
  }, [loadData]);

  const resetForm = () => {
    setShiftName('');
    setStartTime('09:00');
    setEndTime('18:00');
    setAllowedLateMinutes('15');

    setSelectedGeofenceId(
      geofences[0]?.geofenceId ??
        null
    );

    setEditingShiftId(null);
    setModalMode('create');
  };

  const openCreateModal = () => {
    if (geofences.length === 0) {
      showAlert({
        type: 'info',
        title: 'Geofence Required',
        message: 'Create a geofence before creating a shift.'
      });
      return;
    }

    resetForm();
    setModalMode('create');
    setShowModal(true);
  };

  const openEditModal = (
    shift: Shift
  ) => {
    setModalMode('edit');

    setEditingShiftId(
      shift.shiftId
    );

    setShiftName(
      shift.shiftName
    );

    setStartTime(
      formatTime(shift.startTime)
    );

    setEndTime(
      formatTime(shift.endTime)
    );

    setAllowedLateMinutes(
      String(
        shift.allowedLateMinutes ??
          0
      )
    );

    setSelectedGeofenceId(
      shift.geofenceId ??
        geofences[0]
          ?.geofenceId ??
        null
    );

    setShowModal(true);
  };

  const closeModal = () => {
    if (saving) {
      return;
    }

    setShowModal(false);
  };

  const handleSave = async () => {
    const name =
      shiftName.trim();

    const start =
      startTime.trim();

    const end =
      endTime.trim();

    if (!name) {
      showAlert({
        type: 'error',
        title: 'Error',
        message: 'Shift name is required.'
      });
      return;
    }

    if (!isValidTime(start)) {
      showAlert({
        type: 'error',
        title: 'Error',
        message: 'Start time must use HH:mm format.'
      });
      return;
    }

    if (!isValidTime(end)) {
      showAlert({
        type: 'error',
        title: 'Error',
        message: 'End time must use HH:mm format.'
      });
      return;
    }

    const lateText =
      allowedLateMinutes.trim();

    const lateMinutes =
      lateText.length > 0
        ? Number(lateText)
        : null;

    if (
      lateMinutes !== null &&
      (
        !Number.isInteger(
          lateMinutes
        ) ||
        lateMinutes < 0
      )
    ) {
      showAlert({
        type: 'error',
        title: 'Error',
        message: 'Allowed late minutes must be 0 or more.'
      });
      return;
    }

    if (orgId === null) {
      showAlert({
        type: 'error',
        title: 'Error',
        message: 'Organization is not loaded yet.'
      });
      return;
    }

    if (
      selectedGeofenceId === null
    ) {
      showAlert({
        type: 'info',
        title: 'Geofence Required',
        message: 'Select a geofence for this shift.'
      });
      return;
    }

    setSaving(true);

    try {
      const payload = {
        orgId,
        shiftName: name,
        startTime:
          normalizeTime(start),
        endTime:
          normalizeTime(end),
        allowedLateMinutes:
          lateMinutes,
        geofenceId:
          selectedGeofenceId,
      };

      if (
        modalMode === 'edit'
      ) {
        if (
          editingShiftId === null
        ) {
          throw new Error(
            'Editing shift ID is missing.'
          );
        }

        const updated =
          await updateShift(
            editingShiftId,
            payload
          );

        setShifts((current) =>
          current.map((shift) =>
            shift.shiftId ===
            updated.shiftId
              ? updated
              : shift
          )
        );

        setShowModal(false);
        resetForm();

        showAlert({
          type: 'success',
          title: 'Success',
          message: 'Shift updated successfully.'
        });

        return;
      }

      const created =
        await createShift(payload);

      setShifts((current) => [
        ...current,
        created,
      ]);

      setShowModal(false);
      resetForm();

      showAlert({
        type: 'success',
        title: 'Success',
        message: 'Shift created successfully.'
      });
    } catch (error) {
      console.error(
        modalMode === 'edit'
          ? 'Failed to update shift:'
          : 'Failed to create shift:',
        error
      );

      showAlert({
        type: 'error',
        title: 'Error',
        message: error instanceof Error
          ? error.message
          : modalMode === 'edit'
            ? 'Failed to update shift.'
            : 'Failed to create shift.'
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.root}>
      <PageHeader
        title="Shifts"
        subtitle="Work Schedules"
      />

      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator
            size="large"
          />

          <Text
            style={styles.loadingText}
          >
            Loading shifts...
          </Text>
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={
            styles.scroll
          }
          showsVerticalScrollIndicator={
            false
          }
        >
          <View
            style={styles.infoBanner}
          >
            <MaterialCommunityIcons
              name="clock-outline"
              size={18}
              color={T.purpleIcon}
            />

            <Text
              style={
                styles.infoBannerText
              }
            >
              Employees can check in
              only during their assigned
              shift window and inside
              its geofence. Tap a shift
              to edit it.
            </Text>
          </View>

          {shifts.length === 0 ? (
            <View
              style={styles.emptyCard}
            >
              <MaterialCommunityIcons
                name="calendar-clock-outline"
                size={44}
                color={T.textMuted}
              />

              <Text
                style={styles.emptyTitle}
              >
                No shifts yet
              </Text>

              <Text
                style={styles.emptySub}
              >
                Create a shift and link
                it to an office
                geofence.
              </Text>
            </View>
          ) : (
            shifts.map((shift) => {
              const geofence =
                geofences.find(
                  (item) =>
                    item.geofenceId ===
                    shift.geofenceId
                );

              return (
                <Pressable
                  key={shift.shiftId}
                  style={
                    styles.shiftCard
                  }
                  onPress={() =>
                    openEditModal(shift)
                  }
                >
                  <View
                    style={
                      styles.shiftIcon
                    }
                  >
                    <MaterialCommunityIcons
                      name="clock-time-four-outline"
                      size={24}
                      color={
                        T.purpleIcon
                      }
                    />
                  </View>

                  <View
                    style={
                      styles.shiftContent
                    }
                  >
                    <View
                      style={
                        styles.nameRow
                      }
                    >
                      <Text
                        style={
                          styles.shiftName
                        }
                        numberOfLines={1}
                      >
                        {shift.shiftName}
                      </Text>

                      <View
                        style={
                          styles.editBadge
                        }
                      >
                        <MaterialCommunityIcons
                          name="pencil-outline"
                          size={12}
                          color={
                            T.purpleIcon
                          }
                        />

                        <Text
                          style={
                            styles.editBadgeText
                          }
                        >
                          Edit
                        </Text>
                      </View>
                    </View>

                    <Text
                      style={
                        styles.shiftTime
                      }
                    >
                      {formatTime(
                        shift.startTime
                      )}
                      {'  →  '}
                      {formatTime(
                        shift.endTime
                      )}
                    </Text>

                    <View
                      style={
                        styles.metaRow
                      }
                    >
                      <View
                        style={
                          styles.metaChip
                        }
                      >
                        <MaterialCommunityIcons
                          name="timer-outline"
                          size={12}
                          color={
                            T.purpleIcon
                          }
                        />

                        <Text
                          style={
                            styles.metaText
                          }
                        >
                          {shift
                            .allowedLateMinutes ??
                            0}
                          m late
                        </Text>
                      </View>

                      <View
                        style={
                          styles.metaChip
                        }
                      >
                        <MaterialCommunityIcons
                          name="map-marker-radius-outline"
                          size={12}
                          color={
                            T.purpleIcon
                          }
                        />

                        <Text
                          style={
                            styles.metaText
                          }
                          numberOfLines={1}
                        >
                          {geofence
                            ?.buildingName ||
                            (
                              shift.geofenceId !=
                              null
                                ? `Geofence ${shift.geofenceId}`
                                : 'No geofence'
                            )}
                        </Text>
                      </View>
                    </View>
                  </View>

                  <MaterialCommunityIcons
                    name="chevron-right"
                    size={20}
                    color={T.textMuted}
                  />
                </Pressable>
              );
            })
          )}

          <View
            style={styles.listSpacer}
          />
        </ScrollView>
      )}

      <TouchableOpacity
        style={styles.fab}
        activeOpacity={0.8}
        disabled={loading}
        onPress={openCreateModal}
      >
        <MaterialCommunityIcons
          name="plus"
          size={28}
          color="#FFF"
        />
      </TouchableOpacity>

      <Modal
        visible={showModal}
        onClose={closeModal}
        title={
          modalMode === 'edit'
            ? 'Edit Shift'
            : 'Create Shift'
        }
      >
        <ScrollView
          style={styles.modalScroll}
          showsVerticalScrollIndicator={
            false
          }
          keyboardShouldPersistTaps="handled"
        >
          <Text style={styles.label}>
            Shift Name
          </Text>

          <TextInput
            style={styles.input}
            value={shiftName}
            onChangeText={setShiftName}
            placeholder="e.g. General Shift"
            placeholderTextColor={
              T.textMuted
            }
          />

          <Text
            style={styles.sectionTitle}
          >
            Shift Timing
          </Text>

          <View style={styles.timeRow}>
            <View
              style={styles.timeField}
            >
              <Text style={styles.label}>
                Start Time
              </Text>

              <TextInput
                style={styles.input}
                value={startTime}
                onChangeText={
                  setStartTime
                }
                placeholder="09:00"
                placeholderTextColor={
                  T.textMuted
                }
                keyboardType="numbers-and-punctuation"
              />
            </View>

            <View
              style={styles.timeField}
            >
              <Text style={styles.label}>
                End Time
              </Text>

              <TextInput
                style={styles.input}
                value={endTime}
                onChangeText={
                  setEndTime
                }
                placeholder="18:00"
                placeholderTextColor={
                  T.textMuted
                }
                keyboardType="numbers-and-punctuation"
              />
            </View>
          </View>

          <Text style={styles.label}>
            Allowed Late Minutes
          </Text>

          <TextInput
            style={styles.input}
            value={
              allowedLateMinutes
            }
            onChangeText={
              setAllowedLateMinutes
            }
            placeholder="15"
            placeholderTextColor={
              T.textMuted
            }
            keyboardType="number-pad"
          />

          <Text
            style={styles.sectionTitle}
          >
            Office Geofence
          </Text>

          <View
            style={styles.geofenceList}
          >
            {geofences.map(
              (geofence) => {
                const selected =
                  selectedGeofenceId ===
                  geofence.geofenceId;

                return (
                  <Pressable
                    key={
                      geofence.geofenceId
                    }
                    style={[
                      styles.geofenceOption,
                      selected &&
                        styles.geofenceOptionActive,
                    ]}
                    onPress={() =>
                      setSelectedGeofenceId(
                        geofence.geofenceId
                      )
                    }
                  >
                    <View
                      style={[
                        styles.radioOuter,
                        selected &&
                          styles.radioOuterActive,
                      ]}
                    >
                      {selected ? (
                        <View
                          style={
                            styles.radioInner
                          }
                        />
                      ) : null}
                    </View>

                    <View
                      style={
                        styles.shiftContent
                      }
                    >
                      <Text
                        style={[
                          styles.geofenceName,
                          selected &&
                            styles.geofenceNameActive,
                        ]}
                      >
                        {geofence
                          .buildingName ||
                          `Geofence #${geofence.geofenceId}`}
                      </Text>

                      <Text
                        style={
                          styles.geofenceSub
                        }
                      >
                        {geofence.radius}m
                        radius
                        {' · '}
                        {geofence.latitude}
                        {', '}
                        {geofence.longitude}
                      </Text>
                    </View>

                    <MaterialCommunityIcons
                      name="map-marker-radius-outline"
                      size={20}
                      color={
                        selected
                          ? T.purpleIcon
                          : T.textMuted
                      }
                    />
                  </Pressable>
                );
              }
            )}
          </View>

          <View style={styles.linkInfo}>
            <MaterialCommunityIcons
              name="information-outline"
              size={16}
              color={T.purpleIcon}
            />

            <Text
              style={
                styles.linkInfoText
              }
            >
              This geofence will be used
              to validate employee GPS
              location during check-in.
            </Text>
          </View>

          <Pressable
            style={[
              styles.saveBtn,
              saving &&
                styles.saveBtnDisabled,
            ]}
            onPress={handleSave}
            disabled={saving}
          >
            {saving ? (
              <ActivityIndicator
                color="#FFF"
              />
            ) : (
              <>
                <MaterialCommunityIcons
                  name={
                    modalMode === 'edit'
                      ? 'content-save-outline'
                      : 'calendar-plus'
                  }
                  size={18}
                  color="#FFF"
                />

                <Text
                  style={
                    styles.saveBtnText
                  }
                >
                  {modalMode === 'edit'
                    ? 'Save Changes'
                    : 'Create Shift'}
                </Text>
              </>
            )}
          </Pressable>
        </ScrollView>
      </Modal>
    </View>
  );
}

function isValidTime(
  value: string
) {
  return /^([01]\d|2[0-3]):[0-5]\d$/.test(
    value
  );
}

function normalizeTime(
  value: string
) {
  return `${value}:00`;
}

function formatTime(
  value: string
) {
  return (
    value?.slice(0, 5) ||
    '--:--'
  );
}

const styles =
  StyleSheet.create({
    root: {
      flex: 1,
      backgroundColor:
        T.screenBg,
    },

    centered: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
    },

    loadingText: {
      marginTop: 10,
      fontSize: 13,
      color: T.textMuted,
    },

    scroll: {
      paddingHorizontal: 20,
    },

    infoBanner: {
      flexDirection: 'row',
      alignItems: 'flex-start',
      gap: 10,
      backgroundColor:
        T.purpleLight,
      borderRadius: 12,
      padding: 14,
      marginBottom: 16,
    },

    infoBannerText: {
      flex: 1,
      fontSize: 13,
      lineHeight: 18,
      color: T.purpleIcon,
    },

    emptyCard: {
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#FFF',
      borderRadius: 14,
      padding: 32,
    },

    emptyTitle: {
      marginTop: 10,
      fontSize: 15,
      fontWeight: '700',
      color: T.purpleDark,
    },

    emptySub: {
      marginTop: 5,
      fontSize: 12,
      color: T.textMuted,
      textAlign: 'center',
    },

    shiftCard: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 14,
      backgroundColor: '#FFF',
      borderRadius: 14,
      padding: 16,
      marginBottom: 12,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 1,
      },
      shadowOpacity: 0.04,
      shadowRadius: 4,
      elevation: 2,
    },

    shiftIcon: {
      width: 48,
      height: 48,
      borderRadius: 24,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor:
        T.purpleLight,
    },

    shiftContent: {
      flex: 1,
    },

    nameRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
    },

    shiftName: {
      flexShrink: 1,
      fontSize: 15,
      fontWeight: '700',
      color: T.purpleDark,
    },

    editBadge: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 3,
      borderRadius: 8,
      paddingHorizontal: 6,
      paddingVertical: 3,
      backgroundColor:
        T.purpleLight,
    },

    editBadgeText: {
      fontSize: 9,
      fontWeight: '700',
      color: T.purpleIcon,
    },

    shiftTime: {
      marginTop: 3,
      fontSize: 12,
      color: T.textMuted,
      fontFamily: 'monospace',
    },

    metaRow: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: 6,
      marginTop: 8,
    },

    metaChip: {
      maxWidth: 180,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 4,
      borderRadius: 8,
      paddingHorizontal: 7,
      paddingVertical: 4,
      backgroundColor:
        T.purpleLight,
    },

    metaText: {
      flexShrink: 1,
      fontSize: 10,
      fontWeight: '600',
      color: T.purpleDark,
    },

    listSpacer: {
      height: 100,
    },

    fab: {
      position: 'absolute',
      right: 20,
      bottom: 40,
      width: 56,
      height: 56,
      borderRadius: 28,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor:
        T.purpleIcon,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 4,
      },
      shadowOpacity: 0.3,
      shadowRadius: 4,
      elevation: 5,
    },

    modalScroll: {
      maxHeight: 560,
    },

    label: {
      fontSize: 12,
      fontWeight: '600',
      color: T.purpleDark,
      marginBottom: 6,
    },

    sectionTitle: {
      marginTop: 8,
      marginBottom: 10,
      fontSize: 13,
      fontWeight: '700',
      color: T.purpleDark,
      letterSpacing: 0.4,
    },

    input: {
      height: 44,
      marginBottom: 14,
      paddingHorizontal: 12,
      borderWidth: 1,
      borderColor: '#E8E4EC',
      borderRadius: 10,
      backgroundColor: '#FFF',
      fontSize: 14,
      color: T.purpleDark,
    },

    timeRow: {
      flexDirection: 'row',
      gap: 12,
    },

    timeField: {
      flex: 1,
    },

    geofenceList: {
      gap: 8,
    },

    geofenceOption: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
      padding: 12,
      borderWidth: 1,
      borderColor: '#E8E4EC',
      borderRadius: 12,
      backgroundColor: '#FFF',
    },

    geofenceOptionActive: {
      borderWidth: 1.5,
      borderColor:
        T.purpleIcon,
      backgroundColor:
        T.purpleLight,
    },

    radioOuter: {
      width: 18,
      height: 18,
      borderRadius: 9,
      borderWidth: 1.5,
      borderColor: T.textMuted,
      alignItems: 'center',
      justifyContent: 'center',
    },

    radioOuterActive: {
      borderColor:
        T.purpleIcon,
    },

    radioInner: {
      width: 9,
      height: 9,
      borderRadius: 5,
      backgroundColor:
        T.purpleIcon,
    },

    geofenceName: {
      fontSize: 13,
      fontWeight: '700',
      color: T.purpleDark,
    },

    geofenceNameActive: {
      color: T.purpleIcon,
    },

    geofenceSub: {
      marginTop: 3,
      fontSize: 10,
      color: T.textMuted,
    },

    linkInfo: {
      flexDirection: 'row',
      alignItems: 'flex-start',
      gap: 8,
      marginTop: 14,
      padding: 12,
      borderRadius: 10,
      backgroundColor:
        T.purpleLight,
    },

    linkInfoText: {
      flex: 1,
      fontSize: 11,
      lineHeight: 16,
      color: T.purpleIcon,
    },

    saveBtn: {
      height: 50,
      marginTop: 20,
      marginBottom: 10,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      borderRadius: 14,
      backgroundColor:
        T.purpleIcon,
    },

    saveBtnDisabled: {
      opacity: 0.6,
    },

    saveBtnText: {
      fontSize: 15,
      fontWeight: '700',
      color: '#FFF',
    },
  });