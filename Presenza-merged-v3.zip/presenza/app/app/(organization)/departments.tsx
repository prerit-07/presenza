// app/departments.tsx
// Role: Admin only
// Opens from: Organisation tab, Admin dashboard, Office Setup wizard

import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, Pressable,
  TextInput, Modal, ActivityIndicator, TouchableOpacity, Alert
} from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useAppStore } from '@/store/useAppStore';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { PageHeader } from '@/components/PageHeader';
import { departmentService, DepartmentResponse } from '@/services/department.service';
import { getMyOrganization } from '@/services/organization.service';
import { useThemedAlert } from '@/components/ThemedAlertProvider';

export default function DepartmentsScreen() {
  const router = useRouter();
  const members = useAppStore((s) => s.members);
  const [departments, setDepartments] = useState<DepartmentResponse[]>([]);
  // NOT the same as the logged-in user's userId — orgId identifies the
  // organization, userId identifies the person. This used to send
  // user.userId (falling back to a hardcoded 1) as the department's
  // orgId, which silently attached every new department to the wrong
  // organization. Fetch the real org the same way shifts.tsx and
  // geofence-setup.tsx already do.
  const [orgId, setOrgId] = useState<number | null>(null);
  const { showAlert } = useThemedAlert();

  useFocusEffect(
    useCallback(() => {
      let isActive = true;
      const fetchDepartments = async () => {
        try {
          const [data, organization] = await Promise.all([
            departmentService.getDepartments(),
            getMyOrganization(),
          ]);
          if (isActive) {
            setDepartments(data);
            setOrgId(organization.orgId);
          }
        } catch (error) {
          console.error('Failed to fetch departments:', error);
        }
      };
      fetchDepartments();
      return () => { isActive = false; };
    }, [])
  );

  const [showAdd, setShowAdd] = useState(false);
  const [newDept, setNewDept] = useState('');
  const [saving, setSaving] = useState(false);

  const handleAdd = async () => {
    if (!newDept.trim()) return;
    if (orgId == null) {
      showAlert({ type: 'error', title: 'Error', message: 'Could not determine your organization yet. Please try again in a moment.' });
      return;
    }
    setSaving(true);

    try {
      // 1. Save to the database
      const newDepartment = await departmentService.createDepartment({
        orgId,
        departmentName: newDept.trim()
      });
      
      // 2. Add it to our list immediately so the UI updates
      setDepartments((prev) => [...prev, newDepartment]);
      
      setNewDept('');
      setShowAdd(false);
    } catch (error) {
      console.error('Failed to create department:', error);
      showAlert({ type: 'error', title: 'Error', message: 'Failed to create department. Is your backend running?' });
    } finally {
      setSaving(false);
    }
  };

  const getDeptMemberCount = (name: string) =>
    members.filter((m) => m.department === name && m.isActive).length;

  return (
    <View style={styles.root}>
      <PageHeader
        title="Departments"
        subtitle="Manage Departments"
      />

      <FlatList
        data={departments}
        keyExtractor={(d) => String(d.departmentId)}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => {
          const count = getDeptMemberCount(item.departmentName);
          return (
            <View style={styles.deptCard}>
              <View style={styles.deptIconWrap}>
                <MaterialCommunityIcons name="office-building-outline" size={22} color={T.purpleIcon} />
              </View>
              <View style={styles.deptInfo}>
                <Text style={styles.deptName}>{item.departmentName}</Text>
                <Text style={styles.deptSub}>{count} member{count !== 1 ? 's' : ''}</Text>
              </View>
              <Pressable style={styles.addMemberBtn} onPress={() => router.push('/add-member')}>
                <MaterialCommunityIcons name="account-plus-outline" size={16} color={T.purpleIcon} />
              </Pressable>
            </View>
          );
        }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons name="office-building-outline" size={48} color={T.textMuted} />
            <Text style={styles.emptyText}>No departments yet</Text>
            <Pressable style={styles.emptyBtn} onPress={() => setShowAdd(true)}>
              <Text style={styles.emptyBtnText}>Add First Department</Text>
            </Pressable>
          </View>
        }
      />

      {/* Add Department Modal */}
      <Modal visible={showAdd} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>New Department</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="e.g. Engineering"
              placeholderTextColor={T.textMuted}
              value={newDept}
              onChangeText={setNewDept}
              autoFocus
            />
            <View style={styles.modalActions}>
              <Pressable style={styles.modalCancel} onPress={() => { setShowAdd(false); setNewDept(''); }}>
                <Text style={styles.modalCancelText}>Cancel</Text>
              </Pressable>
              <Pressable style={[styles.modalCreate, saving && { opacity: 0.6 }]} onPress={handleAdd} disabled={saving}>
                {saving ? <ActivityIndicator color="#FFF" size="small" /> :
                  <Text style={styles.modalCreateText}>Create</Text>}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      <TouchableOpacity
        style={styles.fab}
        onPress={() => setShowAdd(true)}
      >
        <MaterialCommunityIcons name="plus" size={28} color="#FFF" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: T.screenBg },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12 },
  backBtn: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: 17, fontWeight: '700', color: T.purpleDark },
  addBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: T.purpleIcon, alignItems: 'center', justifyContent: 'center' },
  list: { paddingHorizontal: 20, paddingBottom: 100 },
  deptCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', borderRadius: 14, padding: 14, marginBottom: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 4, elevation: 2 },
  deptIconWrap: { width: 44, height: 44, borderRadius: 22, backgroundColor: T.purpleLight, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  deptInfo: { flex: 1 },
  deptName: { fontSize: 15, fontWeight: '700', color: T.purpleDark },
  deptSub: { fontSize: 12, color: T.textMuted, marginTop: 2 },
  addMemberBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: T.purpleLight, alignItems: 'center', justifyContent: 'center' },
  empty: { alignItems: 'center', marginTop: 80, gap: 12 },
  emptyText: { fontSize: 14, color: T.textMuted },
  emptyBtn: { backgroundColor: T.purpleIcon, borderRadius: 12, paddingVertical: 10, paddingHorizontal: 20 },
  emptyBtnText: { color: '#FFF', fontWeight: '700', fontSize: 13 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center', padding: 30 },
  modalCard: { backgroundColor: '#FFF', borderRadius: 20, padding: 24, width: '100%' },
  modalTitle: { fontSize: 18, fontWeight: '700', color: T.purpleDark, marginBottom: 16 },
  modalInput: { backgroundColor: T.screenBg, borderRadius: 12, paddingHorizontal: 14, height: 48, fontSize: 15, color: T.purpleDark, borderWidth: 1, borderColor: '#E8E4EC', marginBottom: 16 },
  modalActions: { flexDirection: 'row', gap: 10 },
  modalCancel: { flex: 1, borderWidth: 1.5, borderColor: '#E8E4EC', borderRadius: 12, height: 46, alignItems: 'center', justifyContent: 'center' },
  modalCancelText: { fontSize: 14, fontWeight: '600', color: T.textMuted },
  modalCreate: { flex: 1, backgroundColor: T.purpleIcon, borderRadius: 12, height: 46, alignItems: 'center', justifyContent: 'center' },
  modalCreateText: { fontSize: 14, fontWeight: '700', color: '#FFF' },
  fab: {
    position: 'absolute', right: 20, bottom: 40, width: 56, height: 56, borderRadius: 28,
    backgroundColor: T.purpleIcon, justifyContent: 'center', alignItems: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3,
    shadowRadius: 4, elevation: 5
  },
});