// app/device-approvals.tsx
// Role: Manager + Admin
// Opens from: Manager/Admin dashboard, Team screen, Inbox

import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList,
  Pressable, Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useFocusEffect } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { deviceChangeService, type DeviceChangeRequestResponse } from '@/services/device.change.service';

const STATUS_COLOR: Record<string, string> = {
  PENDING: '#F59E0B',
  APPROVED: '#4CAF50',
  REJECTED: '#B23A48',
};

export default function DeviceApprovalsScreen() {
  const router = useRouter();
  const [filter, setFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('ALL');
  const [deviceRequests, setDeviceRequests] = useState<DeviceChangeRequestResponse[]>([]);

  // 1. Fetch from the actual API
  const fetchRequests = async () => {
    try {
      const data = await deviceChangeService.getPendingRequests();
      setDeviceRequests(data);
    } catch (error) {
      console.error('Failed to fetch device requests:', error);
    }
  };

  useFocusEffect(
    useCallback(() => {
      fetchRequests();
    }, [])
  );

  // 2. Handle Approve/Reject via API
  const handleReview = async (requestId: number, approved: boolean) => {
    try {
      await deviceChangeService.reviewRequest(requestId, approved);
      // Remove it from the local list since it's no longer pending
      setDeviceRequests((prev) => prev.filter(r => r.requestId !== requestId));
    } catch (error) {
      console.error('Failed to review request:', error);
    }
  };

  const filtered = deviceRequests.filter((d) => filter === 'ALL' || d.status === filter);

  const formatDate = (d: string) => {
    if (!d) return '';
    return new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <MaterialCommunityIcons name="chevron-left" size={28} color={T.purpleDark} />
        </Pressable>
        <Text style={styles.headerTitle}>Device Requests</Text>
        <View style={{ width: 40 }} />
      </View>

      {/* Filter */}
      <View style={styles.filterRow}>
        {(['ALL', 'PENDING', 'APPROVED', 'REJECTED'] as const).map((f) => (
          <Pressable
            key={f}
            style={[styles.filterPill, filter === f && styles.filterPillActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>
              {f === 'ALL' ? 'All' : f.charAt(0) + f.slice(1).toLowerCase()}
            </Text>
          </Pressable>
        ))}
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(d) => String(d.requestId)}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={styles.cardTop}>
              <Image
                source={{ uri: `https://i.pravatar.cc/150?u=${item.userId}` }}
                style={styles.avatar}
              />
              <View style={styles.empInfo}>
                <Text style={styles.empName}>User {item.userId}</Text>
                <Text style={styles.dateText}>{formatDate(item.requestedAt)}</Text>
              </View>
              <View style={[styles.statusBadge, { backgroundColor: STATUS_COLOR[item.status] + '18' }]}>
                <Text style={[styles.statusText, { color: STATUS_COLOR[item.status] }]}>
                  {item.status ? item.status.charAt(0) + item.status.slice(1).toLowerCase() : ''}
                </Text>
              </View>
            </View>

            <View style={styles.reasonBox}>
              <MaterialCommunityIcons name="cellphone-key" size={14} color={T.textMuted} />
              <Text style={styles.reasonText}>{item.reason}</Text>
            </View>

            {item.status === 'PENDING' && (
              <View style={styles.actionRow}>
                <Pressable
                  style={[styles.actionBtn, styles.rejectBtn]}
                  onPress={() => handleReview(item.requestId, false)}
                >
                  <MaterialCommunityIcons name="close" size={14} color="#B23A48" />
                  <Text style={[styles.actionBtnText, { color: '#B23A48' }]}>Reject</Text>
                </Pressable>
                <Pressable
                  style={[styles.actionBtn, styles.approveBtn]}
                  onPress={() => handleReview(item.requestId, true)}
                >
                  <MaterialCommunityIcons name="check" size={14} color="#FFF" />
                  <Text style={[styles.actionBtnText, { color: '#FFF' }]}>Approve</Text>
                </Pressable>
              </View>
            )}
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons name="cellphone-check" size={48} color={T.textMuted} />
            <Text style={styles.emptyText}>No device requests</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: T.screenBg },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 12 },
  backBtn: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: 17, fontWeight: '700', color: T.purpleDark },
  filterRow: { flexDirection: 'row', gap: 8, paddingHorizontal: 20, marginBottom: 12 },
  filterPill: { borderRadius: 20, paddingVertical: 6, paddingHorizontal: 12, backgroundColor: '#FFF', borderWidth: 1, borderColor: '#E8E4EC' },
  filterPillActive: { backgroundColor: T.purpleIcon, borderColor: T.purpleIcon },
  filterText: { fontSize: 12, fontWeight: '600', color: T.purpleIcon },
  filterTextActive: { color: '#FFF' },
  list: { paddingHorizontal: 20, paddingBottom: 100 },
  card: { backgroundColor: '#FFF', borderRadius: 16, padding: 16, marginBottom: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 6, elevation: 3 },
  cardTop: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  avatar: { width: 40, height: 40, borderRadius: 20, marginRight: 10 },
  empInfo: { flex: 1 },
  empName: { fontSize: 14, fontWeight: '700', color: T.purpleDark },
  dateText: { fontSize: 11, color: T.textMuted, marginTop: 2 },
  statusBadge: { borderRadius: 8, paddingVertical: 4, paddingHorizontal: 8 },
  statusText: { fontSize: 11, fontWeight: '700' },
  reasonBox: { flexDirection: 'row', gap: 6, alignItems: 'flex-start', backgroundColor: T.screenBg, borderRadius: 8, padding: 10, marginBottom: 12 },
  reasonText: { flex: 1, fontSize: 12, color: T.purpleDark, lineHeight: 18 },
  actionRow: { flexDirection: 'row', gap: 10 },
  actionBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, borderRadius: 10, paddingVertical: 10 },
  rejectBtn: { backgroundColor: '#FFF1F3', borderWidth: 1, borderColor: '#B23A48' },
  approveBtn: { backgroundColor: '#4CAF50' },
  actionBtnText: { fontSize: 13, fontWeight: '700' },
  empty: { alignItems: 'center', marginTop: 60, gap: 10 },
  emptyText: { fontSize: 14, color: T.textMuted },
});