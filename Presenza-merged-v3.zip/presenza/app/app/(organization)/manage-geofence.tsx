import React, { useState, useRef, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Switch,
  TextInput,
  Modal,
  Alert,
  ActivityIndicator,
  Dimensions,
  Platform,
} from 'react-native';
import MapView, { Polygon, Marker, Circle } from 'react-native-maps';
import { Tabs, useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons, Feather, MaterialCommunityIcons, MaterialIcons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import { geofenceService } from '@/services/geofence.service';
import { getMyOrganization } from '@/services/organization.service';
import { wifiService } from '@/services/wifi.service';
import { ThemedModal, ThemedModalType } from '@/components/ThemedModal';

const DEFAULT_LAT = 28.2493;
const DEFAULT_LON = 76.8163;

function getDistanceInMeters(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371e3; // Earth's radius in meters
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c; // in meters
}

interface RouterItem {
  id: string;
  name: string;
  mac: string;
  isActive: boolean;
}

export default function ManagerGeofenceScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const mapRef = useRef<MapView>(null);
  const [isInitializing, setIsInitializing] = useState(false);
  // NOT the same as the logged-in user's userId — orgId identifies the
  // organization, userId identifies the person. This used to send
  // user.userId (falling back to a hardcoded 1) as the geofence's
  // orgId, which silently attached every new/edited geofence to the
  // wrong organization. Fetch the real org the same way
  // geofence-setup.tsx and shifts.tsx already do.
  const [orgId, setOrgId] = useState<number | null>(null);

  useEffect(() => {
    getMyOrganization()
      .then((organization) => setOrgId(organization.orgId))
      .catch((error) => console.error('Failed to load organization:', error));
  }, []);

  // Modal State
  const [modalVisible, setModalVisible] = useState(false);
  const [modalConfig, setModalConfig] = useState<{
    type: ThemedModalType;
    title: string;
    message: string;
    primaryButtonText?: string;
    secondaryButtonText?: string;
    onPrimaryPress: () => void;
    onSecondaryPress?: () => void;
  }>({
    type: 'info',
    title: '',
    message: '',
    onPrimaryPress: () => setModalVisible(false),
  });

  const showAlert = (
    type: ThemedModalType,
    title: string,
    message: string,
    onPrimaryPress: () => void = () => setModalVisible(false),
    primaryButtonText?: string,
    secondaryButtonText?: string,
    onSecondaryPress?: () => void
  ) => {
    setModalConfig({
      type, title, message, onPrimaryPress, primaryButtonText, secondaryButtonText, onSecondaryPress
    });
    setModalVisible(true);
  };

  // Tab state: 'geofence' | 'router'
  const [activeTab, setActiveTab] = useState<'geofence' | 'router'>('geofence');

  // Drawing state
  const [radiusInput, setRadiusInput] = useState<string>('50'); // meters

  // Geofence Settings
  const [checkInAllowed, setCheckInAllowed] = useState<boolean>(true);
  const [checkOutAllowed, setCheckOutAllowed] = useState<boolean>(true);
  const [extraDistance, setExtraDistance] = useState<string>('20'); // meters
  const [minStayDuration, setMinStayDuration] = useState<string>('8 Hours');

  // Address State
  const [locationName, setLocationName] = useState<string>('');
  const [officeAddress, setOfficeAddress] = useState<string>('');
  const [isAddressModalVisible, setIsAddressModalVisible] = useState<boolean>(false);
  const [addressInput, setAddressInput] = useState<string>('');
  const [nameInput, setNameInput] = useState<string>('');

  // GPS Coordinates State
  const [gpsLat, setGpsLat] = useState<string>('28.2493');
  const [gpsLon, setGpsLon] = useState<string>('76.8163');
  const [latInput, setLatInput] = useState<string>(gpsLat);
  const [lonInput, setLonInput] = useState<string>(gpsLon);

  // Routers list state
  const [routers, setRouters] = useState<RouterItem[]>([]);

  // Router modal state
  const [isRouterModalVisible, setIsRouterModalVisible] = useState<boolean>(false);
  const [newRouterName, setNewRouterName] = useState<string>('');
  const [newRouterMac, setNewRouterMac] = useState<string>('');
  const [isFetchingWifi, setIsFetchingWifi] = useState<boolean>(false);

  // Router general settings
  const [restrictToRouter, setRestrictToRouter] = useState<boolean>(false);
  const [matchPublicIp, setMatchPublicIp] = useState<boolean>(true);
  const [publicIp, setPublicIp] = useState<string>('');

  // Loading state for Save
  const [isSaving, setIsSaving] = useState<boolean>(false);

  useEffect(() => {
    if (id && id !== 'new') {
      const loadGeofenceData = async () => {
        setIsInitializing(true);
        try {
          const geofence = await geofenceService.getGeofenceById(Number(id));
          setRadiusInput(geofence.radius.toString());
          setGpsLat(geofence.latitude.toString());
          setGpsLon(geofence.longitude.toString());
          setLocationName(geofence.buildingName || '');
          
          try {
            const geofenceRouters = await geofenceService.getGeofenceRouters(Number(id));
            setRouters(
              geofenceRouters.map((r: any) => ({
                id: r.wifiId.toString(),
                name: r.ssid,
                mac: r.bssid,
                isActive: true,
              }))
            );
          } catch (rErr) {
            console.error('Failed to load routers for geofence', rErr);
          }
        } catch (error) {
          showAlert('error', 'Error', 'Failed to load geofence details');
        } finally {
          setIsInitializing(false);
        }
      };
      loadGeofenceData();
    }
  }, [id]);

  // --- Dynamic Calculations based on radius ---
  const radius = parseFloat(radiusInput) || 0;
  const area = Math.round(Math.PI * radius * radius);
  const hectares = (area / 10000).toFixed(2);
  const centerLat = parseFloat(gpsLat) || DEFAULT_LAT;
  const centerLon = parseFloat(gpsLon) || DEFAULT_LON;

  // Center map on GPS location
  const centerOnGeofence = () => {
    mapRef.current?.animateToRegion(
      {
        latitude: centerLat,
        longitude: centerLon,
        latitudeDelta: 0.004,
        longitudeDelta: 0.004,
      },
      800
    );
  };

  // Address edit submission
  const handleSaveAddress = () => {
    setLocationName(nameInput);
    setOfficeAddress(addressInput);
    setGpsLat(latInput);
    setGpsLon(lonInput);
    setIsAddressModalVisible(false);
  };

  // Router actions
  const toggleRouterActive = (id: string) => {
    setRouters(
      routers.map((r) => (r.id === id ? { ...r, isActive: !r.isActive } : r))
    );
  };

  const deleteRouter = (id: string) => {
    showAlert(
      'warning',
      'Delete Router',
      'Are you sure you want to delete this Wi-Fi router?',
      async () => {
        try {
          // If the ID is a short numeric ID (from DB), delete it from backend
          if (id.length <= 10) {
            await geofenceService.deleteWifiNetwork(Number(id));
          }
          setRouters(routers.filter((r) => r.id !== id));
          setModalVisible(false);
        } catch (e) {
          showAlert('error', 'Error', 'Failed to delete router from server.');
        }
      },
      'Delete',
      'Cancel',
      () => setModalVisible(false)
    );
  };

  const handleAddRouter = () => {
    if (!newRouterName.trim() || !newRouterMac.trim()) {
      showAlert('error', 'Error', 'Please fill in all fields.');
      return;
    }
    const macRegex = /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/;
    if (!macRegex.test(newRouterMac)) {
      showAlert('error', 'Invalid MAC Address', 'Please enter a valid MAC address (e.g. AA:BB:CC:DD:EE:FF).');
      return;
    }

    const newRouter: RouterItem = {
      id: Date.now().toString(),
      name: newRouterName.trim(),
      mac: newRouterMac.trim().toUpperCase(),
      isActive: true,
    };

    setRouters([...routers, newRouter]);
    setNewRouterName('');
    setNewRouterMac('');
    setIsRouterModalVisible(false);
  };

  const handleFetchCurrentWifi = async () => {
    setIsFetchingWifi(true);
    try {
      const info = await wifiService.getCurrentWifi();
      if (info.error) {
        showAlert('error', 'Wi-Fi Error', info.error);
      } else if (info.ssid && info.bssid) {
        setNewRouterName(info.ssid);
        setNewRouterMac(info.bssid);
      } else {
        showAlert('warning', 'Not Connected', 'Could not detect a connected Wi-Fi network.');
      }
    } catch (err) {
      showAlert('error', 'Error', 'Failed to fetch Wi-Fi details.');
    } finally {
      setIsFetchingWifi(false);
    }
  };

  const handleUseGPS = async () => {
    try {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        showAlert('error', 'Permission Denied', 'Please allow location access to use this feature.');
        return;
      }

      // Check if the device's location services are actually enabled
      const providerStatus = await Location.getProviderStatusAsync();
      if (!providerStatus.locationServicesEnabled) {
        showAlert('error', 'GPS is Off', 'Please enable Location Services in your phone settings.');
        return;
      }

      let location;
      try {
        // Use Highest accuracy now that permissions are properly configured in app.json
        location = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Highest,
        });
      } catch (err) {
        // Ultimate fallback
        location = await Location.getLastKnownPositionAsync({});
        if (!location) throw err;
      }

      if (!location) {
        showAlert('error', 'Location Error', 'Could not load your current location. Please ensure your device GPS is turned on.');
        return;
      }

      setGpsLat(location.coords.latitude.toString());
      setGpsLon(location.coords.longitude.toString());
      
      mapRef.current?.animateToRegion({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        latitudeDelta: 0.004,
        longitudeDelta: 0.004,
      }, 800);
    } catch (e) {
      showAlert('error', 'Location Error', 'Could not load your current location. Please ensure your device GPS is turned on.');
    }
  };

  // Save full configuration
  const handleSaveConfiguration = async () => {
    if (orgId == null) {
      showAlert('error', 'Error', 'Could not determine your organization yet. Please try again in a moment.');
      return;
    }

    const payload = {
      orgId,
      latitude: parseFloat(gpsLat),
      longitude: parseFloat(gpsLon),
      radius: parseFloat(radiusInput) || 0,
      buildingName: locationName,
    };

    setIsSaving(true);
    
    try {
      let savedGeofence;
      if (id && id !== 'new') {
        savedGeofence = await geofenceService.updateGeofence(Number(id), payload);
      } else {
        savedGeofence = await geofenceService.createGeofence(payload);
      }

      const finalGeofenceId = savedGeofence.geofenceId;

      // Save routers that don't have a database ID yet
      // Routers from DB have IDs like "1", "2", etc. New ones have Date.now() timestamps.
      const newRouters = routers.filter(r => r.id.length > 10);

      for (const routerItem of newRouters) {
        await geofenceService.addWifiNetwork({
          geofenceId: finalGeofenceId,
          ssid: routerItem.name,
          bssid: routerItem.mac
        });
      }

      setIsSaving(false);
      showAlert('success', 'Configuration Saved', 'Office Location and Routers have been updated successfully.', () => {
        setModalVisible(false);
        router.back();
      });
    } catch (error) {
      console.error('Failed to save office:', error);
      setIsSaving(false);
      showAlert('error', 'Save Failed', 'Could not save the configuration to the database.');
    }
  };

  return (
    <View style={styles.container}>
      <Tabs.Screen options={{ headerShown: false }} />

      {/* 🟣 FIGMA HEADER BAR */}
      <View style={styles.headerContainer}>
        <TouchableOpacity style={styles.backButtonCircle} onPress={() => router.back()}>
          <Ionicons name="chevron-back" size={20} color="#29185c" />
        </TouchableOpacity>
        <View style={styles.headerTextWrapper}>
          <Text style={styles.headerTitle}>Office Location Setup</Text>
          <Text style={styles.headerSubtitle}>Configure geofence and router details</Text>
        </View>
      </View>

      {/* 🔄 TABS: GEOFENCE VS ROUTER DETAILS */}
      <View style={styles.tabBarWrapper}>
        <View style={styles.segmentedControl}>
          <TouchableOpacity
            style={[styles.tabButton, activeTab === 'geofence' && styles.activeTabButton]}
            onPress={() => setActiveTab('geofence')}
          >
            <Ionicons
              name="location"
              size={16}
              color={activeTab === 'geofence' ? '#FFFFFF' : '#6E4B8D'}
              style={{ marginRight: 6 }}
            />
            <Text style={[styles.tabButtonText, activeTab === 'geofence' && styles.activeTabButtonText]}>
              Geofence
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.tabButton, activeTab === 'router' && styles.activeTabButton]}
            onPress={() => setActiveTab('router')}
          >
            <Ionicons
              name="wifi"
              size={16}
              color={activeTab === 'router' ? '#FFFFFF' : '#6E4B8D'}
              style={{ marginRight: 6 }}
            />
            <Text style={[styles.tabButtonText, activeTab === 'router' && styles.activeTabButtonText]}>
              Router Details
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {activeTab === 'geofence' ? (
          /* ========================================================
             ================ GEOFENCE VIEW CONTENT =================
             ======================================================== */
          <View style={styles.tabContentContainer}>
            {/* OFFICE GEOFENCE MAP FRAME */}
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <View style={styles.cardTitleRow}>
                  <View style={styles.iconCircleWrapper}>
                    <Ionicons name="location-outline" size={18} color="#6E4B8D" />
                  </View>
                  <View>
                    <Text style={styles.cardTitle}>Office Geofence</Text>
                    <Text style={styles.cardSubtitle}>Define the allowed attendance area</Text>
                  </View>
                </View>
                <View style={styles.activeBadge}>
                  <View style={styles.activeDot} />
                  <Text style={styles.activeBadgeText}>Active</Text>
                </View>
              </View>

              {/* MAP FRAME */}
              <View style={styles.mapContainer}>
                <MapView
                  ref={mapRef}
                  style={StyleSheet.absoluteFillObject}
                  initialRegion={{
                    latitude: centerLat,
                    longitude: centerLon,
                    latitudeDelta: 0.004,
                    longitudeDelta: 0.004,
                  }}
                  showsUserLocation={true}
                  showsMyLocationButton={false}
                  showsCompass={false}
                  toolbarEnabled={false}
                  pitchEnabled={false}
                  zoomControlEnabled={false}
                >
                  {/* Circle Geofence */}
                  {radius > 0 && (
                    <Circle
                      center={{ latitude: centerLat, longitude: centerLon }}
                      radius={radius}
                      fillColor="rgba(110, 75, 141, 0.2)"
                      strokeColor="#6E4B8D"
                      strokeWidth={2}
                    />
                  )}

                  {/* Manual GPS Location Pin */}
                  {gpsLat && gpsLon && (
                    <Marker coordinate={{ latitude: centerLat, longitude: centerLon }}>
                      <View style={styles.centroidWrapper}>
                        <MaterialCommunityIcons name="crosshairs-gps" size={26} color="#EA5455" />
                      </View>
                    </Marker>
                  )}
                </MapView>

                {/* CONTROLS OVERLAYS */}
                <View style={styles.mapControlsOverlay}>
                  <TouchableOpacity
                    style={styles.mapActionButton}
                    onPress={handleUseGPS}
                  >
                    <Ionicons name="locate" size={14} color="#6E4B8D" />
                    <Text style={styles.mapActionText}>Use GPS</Text>
                  </TouchableOpacity>
                </View>

              </View>

              {/* AREA & RADIUS DISPLAY */}
              <View style={styles.metricsRow}>
                <View style={styles.metricCard}>
                  <View style={styles.metricIconBox}>
                    <Ionicons name="expand" size={18} color="#6E4B8D" />
                  </View>
                  <View style={{ marginLeft: 8, flex: 1 }}>
                    <Text style={styles.metricLabel}>Area</Text>
                    <Text style={styles.metricValue}>
                      {radius > 0 ? `${area.toLocaleString()} sq. mt.` : '0 sq. mt.'}
                    </Text>
                    <Text style={styles.metricSub}>{hectares} Hectares</Text>
                  </View>
                </View>

                <View style={styles.metricCard}>
                  <View style={styles.metricIconBox}>
                    <MaterialCommunityIcons name="radius-outline" size={18} color="#6E4B8D" />
                  </View>
                  <View style={{ marginLeft: 8, flex: 1, paddingVertical: 2 }}>
                    <Text style={styles.metricLabel}>Geofence Radius (m)</Text>
                    <TextInput
                      style={{ fontSize: 16, fontWeight: '700', color: '#29185c', padding: 0, marginTop: 4, marginBottom: 2 }}
                      value={radiusInput}
                      onChangeText={setRadiusInput}
                      keyboardType="numeric"
                      placeholder="e.g. 50"
                    />
                    <Text style={styles.metricSub}>From center point</Text>
                  </View>
                </View>
              </View>

              {/* ADDRESS DISPLAY CARD */}
              <View style={styles.addressContainer}>
                <View style={styles.addressTextWrapper}>
                  <View style={styles.addressIconWrapper}>
                    <Ionicons name="business" size={16} color="#6E4B8D" />
                  </View>
                  <View style={{ flex: 1, marginLeft: 10 }}>
                    <Text style={styles.addressLabel}>Location Name</Text>
                    <Text style={styles.addressContent}>{locationName}</Text>
                    <Text style={[styles.addressLabel, { marginTop: 8 }]}>Office Address</Text>
                    <Text style={styles.addressContent}>{officeAddress}</Text>
                    <Text style={[styles.addressLabel, { marginTop: 8 }]}>GPS Coordinates</Text>
                    <Text style={styles.addressContent}>Lat: {gpsLat}, Lon: {gpsLon}</Text>
                  </View>
                </View>
                <TouchableOpacity
                  style={styles.addressEditButton}
                  onPress={() => {
                    setNameInput(locationName);
                    setAddressInput(officeAddress);
                    setLatInput(gpsLat);
                    setLonInput(gpsLon);
                    setIsAddressModalVisible(true);
                  }}
                >
                  <Feather name="edit" size={12} color="#6E4B8D" style={{ marginRight: 4 }} />
                  <Text style={styles.addressEditText}>Edit</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* GEOFENCE SETTING CARD */}
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <View style={styles.cardTitleRow}>
                  <View style={styles.iconCircleWrapper}>
                    <Ionicons name="settings-outline" size={18} color="#6E4B8D" />
                  </View>
                  <View>
                    <Text style={styles.cardTitle}>Geofence Setting</Text>
                  </View>
                </View>
              </View>

              {/* Setting Switch 1 */}
              <View style={styles.settingRow}>
                <View style={styles.settingLabelWrapper}>
                  <Text style={styles.settingMainLabel}>Check-in Allowed</Text>
                  <Text style={styles.settingSubLabel}>Only within geofence</Text>
                </View>
                <Switch
                  value={checkInAllowed}
                  onValueChange={setCheckInAllowed}
                  trackColor={{ false: '#D0C8D9', true: '#aa80cf' }}
                  thumbColor={checkInAllowed ? '#6E4B8D' : '#F4F3F4'}
                />
              </View>

              <View style={styles.divider} />

              {/* Setting Switch 2 */}
              <View style={styles.settingRow}>
                <View style={styles.settingLabelWrapper}>
                  <Text style={styles.settingMainLabel}>Check-out Allowed</Text>
                  <Text style={styles.settingSubLabel}>Only within geofence</Text>
                </View>
                <Switch
                  value={checkOutAllowed}
                  onValueChange={setCheckOutAllowed}
                  trackColor={{ false: '#D0C8D9', true: '#aa80cf' }}
                  thumbColor={checkOutAllowed ? '#6E4B8D' : '#F4F3F4'}
                />
              </View>

              <View style={styles.divider} />

              {/* Setting Extra Distance Selection */}
              <View style={styles.settingVerticalRow}>
                <View style={styles.settingLabelWrapper}>
                  <Text style={styles.settingMainLabel}>Extra Allowed Boundary Distance</Text>
                  <Text style={styles.settingSubLabel}>
                    Allow check-in within this extra distance from boundary
                  </Text>
                </View>
                <View style={styles.pillSelectorsRow}>
                  {['0', '10', '20', '50'].map((dist) => (
                    <TouchableOpacity
                      key={`dist-${dist}`}
                      style={[
                        styles.pillSelectorButton,
                        extraDistance === dist && styles.activePillSelector,
                      ]}
                      onPress={() => setExtraDistance(dist)}
                    >
                      <Text
                        style={[
                          styles.pillSelectorText,
                          extraDistance === dist && styles.activePillSelectorText,
                        ]}
                      >
                        {dist === '0' ? 'Strict' : `+ ${dist}m`}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.divider} />

              {/* Setting Minimum stay time Selection */}
              <View style={styles.settingVerticalRow}>
                <View style={styles.settingLabelWrapper}>
                  <Text style={styles.settingMainLabel}>Minimum Stay Duration</Text>
                  <Text style={styles.settingSubLabel}>
                    Minimum time required on-site to mark attendance session
                  </Text>
                </View>
                <View style={styles.pillSelectorsRow}>
                  {['30 Mins', '4 Hours', '8 Hours', 'Flexible'].map((duration) => (
                    <TouchableOpacity
                      key={`duration-${duration}`}
                      style={[
                        styles.pillSelectorButton,
                        minStayDuration === duration && styles.activePillSelector,
                      ]}
                      onPress={() => setMinStayDuration(duration)}
                    >
                      <Text
                        style={[
                          styles.pillSelectorText,
                          minStayDuration === duration && styles.activePillSelectorText,
                        ]}
                      >
                        {duration}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            </View>
          </View>
        ) : (
          /* ========================================================
             ================ ROUTER VIEW CONTENT ===================
             ======================================================== */
          <View style={styles.tabContentContainer}>
            {/* ROUTERS LIST CARD */}
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <View style={styles.cardTitleRow}>
                  <View style={styles.iconCircleWrapper}>
                    <Ionicons name="wifi-outline" size={18} color="#6E4B8D" />
                  </View>
                  <View>
                    <Text style={styles.cardTitle}>Office Router Details</Text>
                    <Text style={styles.cardSubtitle}>Authorized Wi-Fi routers for check-in</Text>
                  </View>
                </View>
                <TouchableOpacity
                  style={styles.addRouterButton}
                  onPress={() => setIsRouterModalVisible(true)}
                >
                  <Ionicons name="add" size={16} color="#FFFFFF" style={{ marginRight: 2 }} />
                  <Text style={styles.addRouterText}>Add Router</Text>
                </TouchableOpacity>
              </View>

              {/* Router Items List */}
              <View style={styles.routerListContainer}>
                {routers.length === 0 ? (
                  <View style={styles.emptyStateContainer}>
                    <Ionicons name="wifi-outline" size={40} color="#caa6ec" />
                    <Text style={styles.emptyStateText}>No authorized routers set up</Text>
                  </View>
                ) : (
                  routers.map((routerItem) => (
                    <View key={routerItem.id} style={styles.routerItemCard}>
                      <View style={styles.routerInfo}>
                        <View style={styles.routerAvatar}>
                          <Ionicons
                            name={routerItem.isActive ? 'wifi' : 'wifi-outline'}
                            size={18}
                            color={routerItem.isActive ? '#6E4B8D' : '#828282'}
                          />
                        </View>
                        <View style={{ flex: 1, marginLeft: 10 }}>
                          <Text style={styles.routerName}>{routerItem.name}</Text>
                          <Text style={styles.routerMac}>{routerItem.mac}</Text>
                        </View>
                      </View>
                      <View style={styles.routerActions}>
                        <Switch
                          value={routerItem.isActive}
                          onValueChange={() => toggleRouterActive(routerItem.id)}
                          trackColor={{ false: '#D0C8D9', true: '#aa80cf' }}
                          thumbColor={routerItem.isActive ? '#6E4B8D' : '#F4F3F4'}
                        />
                        <TouchableOpacity
                          style={styles.deleteRouterButton}
                          onPress={() => deleteRouter(routerItem.id)}
                        >
                          <Ionicons name="trash-outline" size={16} color="#EA5455" />
                        </TouchableOpacity>
                      </View>
                    </View>
                  ))
                )}
              </View>
            </View>

            {/* ROUTER SECURITY POLICY */}
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <View style={styles.cardTitleRow}>
                  <View style={styles.iconCircleWrapper}>
                    <Ionicons name="shield-checkmark-outline" size={18} color="#6E4B8D" />
                  </View>
                  <View>
                    <Text style={styles.cardTitle}>Router Security Settings</Text>
                  </View>
                </View>
              </View>

              {/* Policy Switch 1 */}
              <View style={styles.settingRow}>
                <View style={styles.settingLabelWrapper}>
                  <Text style={styles.settingMainLabel}>Restrict to Wi-Fi Only</Text>
                  <Text style={styles.settingSubLabel}>
                    Force attendance check-ins only via authorized routers
                  </Text>
                </View>
                <Switch
                  value={restrictToRouter}
                  onValueChange={setRestrictToRouter}
                  trackColor={{ false: '#D0C8D9', true: '#aa80cf' }}
                  thumbColor={restrictToRouter ? '#6E4B8D' : '#F4F3F4'}
                />
              </View>

              <View style={styles.divider} />

              {/* Policy Switch 2 */}
              <View style={styles.settingRow}>
                <View style={styles.settingLabelWrapper}>
                  <Text style={styles.settingMainLabel}>Verify Gateway IP</Text>
                  <Text style={styles.settingSubLabel}>
                    Validate connected router public IP matches corporate IP
                  </Text>
                </View>
                <Switch
                  value={matchPublicIp}
                  onValueChange={setMatchPublicIp}
                  trackColor={{ false: '#D0C8D9', true: '#aa80cf' }}
                  thumbColor={matchPublicIp ? '#6E4B8D' : '#F4F3F4'}
                />
              </View>

              {matchPublicIp && (
                <View style={styles.ipInputContainer}>
                  <Text style={styles.ipInputLabel}>Office Public Gateway IP Address</Text>
                  <TextInput
                    style={styles.ipTextInput}
                    value={publicIp}
                    onChangeText={setPublicIp}
                    placeholder="e.g. 192.0.2.1"
                    keyboardType="numeric"
                  />
                </View>
              )}
            </View>
          </View>
        )}
      </ScrollView>

      {/* 💾 SOLID PRIMARY CTA SAVE CONFIGURATION BUTTON */}
      <View style={styles.bottomCtaContainer}>
        <TouchableOpacity
          style={[styles.saveButton, isSaving && styles.disabledButton]}
          onPress={handleSaveConfiguration}
          disabled={isSaving}
        >
          {isSaving ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <View style={styles.saveButtonContent}>
              <MaterialCommunityIcons name="content-save-outline" size={18} color="#FFFFFF" style={{ marginRight: 6 }} />
              <Text style={styles.saveButtonText}>Save Configuration</Text>
            </View>
          )}
        </TouchableOpacity>
      </View>

      {/* ========================================================
         ================ ADDRESS EDIT MODAL ====================
         ======================================================== */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={isAddressModalVisible}
        onRequestClose={() => setIsAddressModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Edit Office Address</Text>
              <TouchableOpacity onPress={() => setIsAddressModalVisible(false)}>
                <Ionicons name="close" size={24} color="#29185c" />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <Text style={styles.inputLabel}>Location Name</Text>
              <TextInput
                style={[styles.textAreaInput, { minHeight: 40, marginBottom: 12 }]}
                value={nameInput}
                onChangeText={setNameInput}
                placeholder="e.g. Plant A"
              />
              <Text style={styles.inputLabel}>Complete Address</Text>
              <TextInput
                style={styles.textAreaInput}
                value={addressInput}
                onChangeText={setAddressInput}
                multiline={true}
                numberOfLines={3}
                placeholder="Enter office address"
              />
              <View style={{ flexDirection: 'row', gap: 12, marginTop: 12 }}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.inputLabel}>Latitude</Text>
                  <TextInput
                    style={[styles.textAreaInput, { minHeight: 40 }]}
                    value={latInput}
                    onChangeText={setLatInput}
                    placeholder="e.g. 28.2493"
                    keyboardType="numeric"
                  />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.inputLabel}>Longitude</Text>
                  <TextInput
                    style={[styles.textAreaInput, { minHeight: 40 }]}
                    value={lonInput}
                    onChangeText={setLonInput}
                    placeholder="e.g. 76.8163"
                    keyboardType="numeric"
                  />
                </View>
              </View>
            </View>
            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={() => setIsAddressModalVisible(false)}
              >
                <Text style={styles.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalConfirmButton} onPress={handleSaveAddress}>
                <Text style={styles.modalConfirmText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* ========================================================
         ================ ADD ROUTER MODAL ======================
         ======================================================== */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={isRouterModalVisible}
        onRequestClose={() => setIsRouterModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Office Router</Text>
              <TouchableOpacity onPress={() => setIsRouterModalVisible(false)}>
                <Ionicons name="close" size={24} color="#29185c" />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <TouchableOpacity
                style={styles.fetchWifiButton}
                onPress={handleFetchCurrentWifi}
                disabled={isFetchingWifi}
              >
                {isFetchingWifi ? (
                  <ActivityIndicator size="small" color="#6E4B8D" />
                ) : (
                  <>
                    <Ionicons name="refresh" size={16} color="#6E4B8D" />
                    <Text style={styles.fetchWifiText}>Fetch Current Wi-Fi</Text>
                  </>
                )}
              </TouchableOpacity>

              <Text style={styles.inputLabel}>Wi-Fi SSID (Name)</Text>
              <TextInput
                style={styles.modalTextInput}
                value={newRouterName}
                onChangeText={setNewRouterName}
                placeholder="e.g. Office_Premium"
              />

              <Text style={[styles.inputLabel, { marginTop: 12 }]}>BSSID (MAC Address)</Text>
              <TextInput
                style={styles.modalTextInput}
                value={newRouterMac}
                onChangeText={setNewRouterMac}
                placeholder="e.g. AA:BB:CC:DD:EE:FF"
                autoCapitalize="characters"
              />
            </View>
            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={styles.modalCancelButton}
                onPress={() => setIsRouterModalVisible(false)}
              >
                <Text style={styles.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalConfirmButton} onPress={handleAddRouter}>
                <Text style={styles.modalConfirmText}>Add Router</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Reusable Themed Modal for Success/Error/Warning Alerts */}
      <ThemedModal
        visible={modalVisible}
        type={modalConfig.type}
        title={modalConfig.title}
        message={modalConfig.message}
        primaryButtonText={modalConfig.primaryButtonText}
        secondaryButtonText={modalConfig.secondaryButtonText}
        onPrimaryPress={modalConfig.onPrimaryPress}
        onSecondaryPress={modalConfig.onSecondaryPress}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F7F5FC', // Off-white light purple tinted background
  },

  // Header System
  headerContainer: {
    width: '100%',
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#e7ddff', // Very light purple
  },
  backButtonCircle: {
    width: 38,
    height: 38,
    backgroundColor: '#caa6ec', // Light purple back button background
    borderRadius: 19,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    left: 16,
    top: 56,
    zIndex: 5,
  },
  deleteButtonCircle: {
    width: 38,
    height: 38,
    backgroundColor: '#ffcdd2', // Light red for delete background
    borderRadius: 19,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    right: 16,
    top: 56,
    zIndex: 5,
  },
  headerTextWrapper: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#29185c', // Dark violet
  },
  headerSubtitle: {
    fontSize: 12,
    color: '#6E4B8D', // Primary purple
    marginTop: 2,
    textAlign: 'center',
  },

  // Tabs / Segmented Control
  tabBarWrapper: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EBE5F5',
  },
  segmentedControl: {
    flexDirection: 'row',
    backgroundColor: '#F3EFFF',
    borderRadius: 20,
    padding: 4,
    height: 44,
  },
  tabButton: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 16,
  },
  activeTabButton: {
    backgroundColor: '#6E4B8D', // Selected primary purple
  },
  tabButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6E4B8D',
  },
  activeTabButtonText: {
    color: '#FFFFFF',
  },

  // Main Scroll View Contents
  scrollContent: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 110, // buffer for sticky bottom CTA
  },
  tabContentContainer: {
    gap: 16,
  },

  // Custom Cards
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#6E4B8D',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  cardTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  iconCircleWrapper: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: '#F3EFFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#29185c',
  },
  cardSubtitle: {
    fontSize: 11,
    color: '#828282',
    marginTop: 1,
  },

  // Active Green Badge
  activeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E8F9EE',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  activeDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#28C76F',
    marginRight: 6,
  },
  activeBadgeText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#28C76F',
  },

  // Map Container
  mapContainer: {
    height: 250,
    width: '100%',
    borderRadius: 12,
    overflow: 'hidden',
    position: 'relative',
    borderWidth: 1.5,
    borderColor: '#EBE5F5',
  },
  vertexMarker: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#caa6ec',
    borderWidth: 1.5,
    borderColor: '#29185c',
    justifyContent: 'center',
    alignItems: 'center',
  },
  vertexIndexText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#29185c',
  },
  centroidWrapper: {
    width: 32,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapControlsOverlay: {
    position: 'absolute',
    top: 10,
    left: 10,
    flexDirection: 'row',
    gap: 8,
    zIndex: 10,
  },
  mapActionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  activeMapActionButton: {
    backgroundColor: '#6E4B8D',
  },
  mapActionText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6E4B8D',
    marginLeft: 4,
  },
  activeMapActionText: {
    color: '#FFFFFF',
  },
  mapFloatNavigation: {
    position: 'absolute',
    right: 10,
    bottom: 10,
    zIndex: 10,
  },
  smallRoundNavButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },

  // Metrics Display
  metricsRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  metricCard: {
    flex: 1,
    backgroundColor: '#F9F8FF',
    borderWidth: 1,
    borderColor: '#EBE5F5',
    borderRadius: 10,
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  metricIconBox: {
    width: 30,
    height: 30,
    borderRadius: 6,
    backgroundColor: '#EBE5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  metricLabel: {
    fontSize: 10,
    color: '#828282',
    fontWeight: '500',
  },
  metricValue: {
    fontSize: 13,
    fontWeight: '700',
    color: '#29185c',
    marginTop: 1,
  },
  metricSub: {
    fontSize: 9,
    color: '#6E4B8D',
    marginTop: 1,
  },

  // Address Bar
  addressContainer: {
    backgroundColor: '#F9F8FF',
    borderWidth: 1,
    borderColor: '#EBE5F5',
    borderRadius: 12,
    padding: 12,
    marginTop: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  addressTextWrapper: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  addressIconWrapper: {
    marginTop: 2,
  },
  addressLabel: {
    fontSize: 10,
    color: '#828282',
    fontWeight: '600',
  },
  addressContent: {
    fontSize: 12,
    fontWeight: '500',
    color: '#29185c',
    lineHeight: 16,
    marginTop: 2,
  },
  addressEditButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#caa6ec',
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginLeft: 10,
  },
  addressEditText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#6E4B8D',
  },

  // Geofence settings
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  settingLabelWrapper: {
    flex: 1,
    marginRight: 10,
  },
  settingMainLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#29185c',
  },
  settingSubLabel: {
    fontSize: 11,
    color: '#828282',
    marginTop: 2,
  },
  divider: {
    height: 1,
    backgroundColor: '#F3EFFF',
  },
  settingVerticalRow: {
    paddingVertical: 14,
  },
  pillSelectorsRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 10,
  },
  pillSelectorButton: {
    flex: 1,
    height: 36,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#EBE5F5',
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  activePillSelector: {
    backgroundColor: '#6E4B8D',
    borderColor: '#6E4B8D',
  },
  pillSelectorText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6E4B8D',
  },
  activePillSelectorText: {
    color: '#FFFFFF',
  },

  // Router Details Specific Styling
  addRouterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#6E4B8D',
    borderRadius: 16,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  addRouterText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  routerListContainer: {
    marginTop: 8,
    gap: 12,
  },
  emptyStateContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
    backgroundColor: '#F9F8FF',
    borderRadius: 12,
    borderStyle: 'dashed',
    borderWidth: 1.5,
    borderColor: '#caa6ec',
  },
  emptyStateText: {
    fontSize: 13,
    color: '#828282',
    marginTop: 8,
    fontWeight: '500',
  },
  routerItemCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#F9F8FF',
    borderWidth: 1,
    borderColor: '#EBE5F5',
    borderRadius: 12,
    padding: 12,
  },
  routerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  routerAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#EBE5F5',
  },
  routerName: {
    fontSize: 13,
    fontWeight: '600',
    color: '#29185c',
  },
  routerMac: {
    fontSize: 10,
    color: '#828282',
    marginTop: 2,
    fontFamily: Platform.select({ ios: 'CourierNewPSMT', android: 'monospace', web: 'monospace' }),
  },
  routerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  deleteRouterButton: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: '#FFF1F1',
    justifyContent: 'center',
    alignItems: 'center',
  },

  // IP Input Card details
  ipInputContainer: {
    marginTop: 12,
    padding: 12,
    backgroundColor: '#F9F8FF',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#EBE5F5',
  },
  ipInputLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: '#6E4B8D',
    marginBottom: 6,
  },
  ipTextInput: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#EBE5F5',
    borderRadius: 8,
    height: 38,
    paddingHorizontal: 10,
    fontSize: 13,
    color: '#29185c',
    fontFamily: Platform.select({ ios: 'CourierNewPSMT', android: 'monospace', web: 'monospace' }),
  },

  // Sticky Bottom CTA Area
  bottomCtaContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingBottom: Platform.OS === 'ios' ? 34 : 20,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#EBE5F5',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 10,
  },
  saveButton: {
    backgroundColor: '#6E4B8D',
    borderRadius: 12,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  disabledButton: {
    opacity: 0.6,
  },
  saveButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },

  // Modal Custom Styling
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(41, 24, 92, 0.4)', // Dark violet overlay
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    width: '100%',
    maxWidth: 340,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 10,
    elevation: 5,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#F3EFFF',
    paddingBottom: 10,
    marginBottom: 14,
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#29185c',
  },
  modalBody: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: '#828282',
    marginBottom: 6,
  },
  modalTextInput: {
    backgroundColor: '#F9F8FF',
    borderWidth: 1,
    borderColor: '#EBE5F5',
    borderRadius: 8,
    height: 40,
    paddingHorizontal: 10,
    fontSize: 14,
    color: '#29185c',
  },
  fetchWifiButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F3EFFF',
    borderWidth: 1,
    borderColor: '#caa6ec',
    borderRadius: 8,
    paddingVertical: 10,
    marginBottom: 16,
    gap: 8,
  },
  fetchWifiText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#6E4B8D',
  },
  textAreaInput: {
    backgroundColor: '#F9F8FF',
    borderWidth: 1,
    borderColor: '#EBE5F5',
    borderRadius: 8,
    padding: 10,
    fontSize: 13,
    color: '#29185c',
    textAlignVertical: 'top',
  },
  modalFooter: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 10,
  },
  modalCancelButton: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 8,
  },
  modalCancelText: {
    fontSize: 13,
    color: '#828282',
    fontWeight: '600',
  },
  modalConfirmButton: {
    backgroundColor: '#6E4B8D',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  modalConfirmText: {
    fontSize: 13,
    color: '#FFFFFF',
    fontWeight: '600',
  },
});
