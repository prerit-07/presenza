// app/(organization)/member-detail.tsx

import React, {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react';

import {
  ActivityIndicator,
  Alert,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import {
  SafeAreaView,
  useSafeAreaInsets,
} from 'react-native-safe-area-context';

import {
  useLocalSearchParams,
  useRouter,
} from 'expo-router';

import { MaterialCommunityIcons } from '@expo/vector-icons';

import {
  getEmployeeById,
  updateEmployee,
  type Employee,
} from '@/services/employee.service';

import {
  getShifts,
  type Shift,
} from '@/services/shift.service';

import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { useThemedAlert } from '@/components/ThemedAlertProvider';

export default function MemberDetailScreen() {
  const { showAlert } = useThemedAlert();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const params =
    useLocalSearchParams<{ id?: string }>();

  const employeeId = useMemo(() => {
    const rawId = Array.isArray(params.id)
      ? params.id[0]
      : params.id;

    if (!rawId) {
      return null;
    }

    const parsed = Number(rawId);

    if (
      !Number.isInteger(parsed) ||
      parsed <= 0
    ) {
      return null;
    }

    return parsed;
  }, [params.id]);

  const [employee, setEmployee] =
    useState<Employee | null>(null);

  const [shifts, setShifts] =
    useState<Shift[]>([]);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState('');

  const [
    shiftModalVisible,
    setShiftModalVisible,
  ] = useState(false);

  const [
    selectedShiftId,
    setSelectedShiftId,
  ] = useState<number | null>(null);

  const [savingShift, setSavingShift] =
    useState(false);

  const loadData = useCallback(async () => {
    if (employeeId === null) {
      setEmployee(null);
      setError(
        'Invalid employee ID in route.'
      );
      setLoading(false);
      return;
    }

    setLoading(true);
    setError('');

    try {
      const [
        employeeResponse,
        shiftResponse,
      ] = await Promise.all([
        getEmployeeById(employeeId),
        getShifts(),
      ]);

      setEmployee(employeeResponse);
      setShifts(shiftResponse);

      setSelectedShiftId(
        employeeResponse.shiftId
      );
    } catch (err) {
      console.error(
        'Failed to load employee detail:',
        err
      );

      setEmployee(null);

      setError(
        err instanceof Error
          ? err.message
          : 'Failed to load employee.'
      );
    } finally {
      setLoading(false);
    }
  }, [employeeId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const currentShift = useMemo(() => {
    if (!employee) {
      return null;
    }

    return (
      shifts.find(
        (shift) =>
          shift.shiftId === employee.shiftId
      ) ?? null
    );
  }, [employee, shifts]);

  const selectedShift = useMemo(() => {
    return (
      shifts.find(
        (shift) =>
          shift.shiftId === selectedShiftId
      ) ?? null
    );
  }, [shifts, selectedShiftId]);

  const openShiftModal = () => {
    if (!employee) {
      return;
    }

    if (shifts.length === 0) {
      showAlert({
        type: 'info',
        title: 'No Shifts Available',
        message: 'Create a shift before assigning one.'
      });
      return;
    }

    setSelectedShiftId(employee.shiftId);
    setShiftModalVisible(true);
  };

  const closeShiftModal = () => {
    if (savingShift) {
      return;
    }

    setShiftModalVisible(false);
  };

  const handleSaveShift = async () => {
    if (!employee) {
      return;
    }

    if (selectedShiftId === null) {
      showAlert({
        type: 'info',
        title: 'Select Shift',
        message: 'Please select a shift first.'
      });
      return;
    }

    setSavingShift(true);

    try {
      const updated =
        await updateEmployee(
          employee.employeeId,
          {
            orgId: employee.orgId,
            userId: employee.userId,
            employeeName:
              employee.employeeName,
            dateOfJoining:
              employee.dateOfJoining,
            departmentId:
              employee.departmentId,
            shiftId: selectedShiftId,
            teamId: employee.teamId,
          }
        );

      setEmployee(updated);
      setSelectedShiftId(updated.shiftId);
      setShiftModalVisible(false);

      const updatedShift =
        shifts.find(
          (shift) =>
            shift.shiftId === updated.shiftId
        ) ?? selectedShift;

      showAlert({
        type: 'success',
        title: 'Shift Updated',
        message: `${updated.employeeName} is now assigned to ${
          updatedShift?.shiftName ??
          `Shift ${updated.shiftId}`
        }.`
      });
    } catch (err) {
      console.error(
        'Failed to update shift:',
        err
      );

      showAlert({
        type: 'error',
        title: 'Update Failed',
        message: err instanceof Error
          ? err.message
          : 'Failed to update employee shift.'
      });
    } finally {
      setSavingShift(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView
        style={styles.root}
        edges={['top']}
      >
        <Header
          title="Member Detail"
          onBack={() => router.back()}
        />

        <View style={styles.centered}>
          <ActivityIndicator
            size="large"
            color={T.purpleIcon}
          />

          <Text style={styles.loadingText}>
            Loading employee...
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  if (error || !employee) {
    return (
      <SafeAreaView
        style={styles.root}
        edges={['top']}
      >
        <Header
          title="Member Detail"
          onBack={() => router.back()}
        />

        <View style={styles.centered}>
          <MaterialCommunityIcons
            name="account-alert-outline"
            size={50}
            color="#B23A48"
          />

          <Text style={styles.errorTitle}>
            Could not load member
          </Text>

          <Text style={styles.errorMessage}>
            {error ||
              'Employee record not found.'}
          </Text>

          <Pressable
            style={styles.retryButton}
            onPress={loadData}
          >
            <MaterialCommunityIcons
              name="refresh"
              size={18}
              color="#FFF"
            />

            <Text style={styles.retryButtonText}>
              Retry
            </Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView
      style={styles.root}
      edges={['top']}
    >
      <Header
        title="Member Detail"
        onBack={() => router.back()}
      />

      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile */}
        <View style={styles.profileCard}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {getInitials(
                employee.employeeName
              )}
            </Text>
          </View>

          <Text style={styles.employeeName}>
            {employee.employeeName}
          </Text>

          <View style={styles.employeeBadge}>
            <MaterialCommunityIcons
              name="badge-account-outline"
              size={14}
              color={T.purpleIcon}
            />

            <Text style={styles.employeeBadgeText}>
              Employee #{employee.employeeId}
            </Text>
          </View>

          <Text style={styles.userIdText}>
            User ID: {employee.userId}
          </Text>
        </View>

        {/* Employee Information */}
        <Text style={styles.sectionTitle}>
          Employee Information
        </Text>

        <View style={styles.infoCard}>
          <DetailRow
            icon="identifier"
            label="Employee ID"
            value={String(
              employee.employeeId
            )}
          />

          <Separator />

          <DetailRow
            icon="account-outline"
            label="User ID"
            value={String(employee.userId)}
          />

          <Separator />

          <DetailRow
            icon="office-building-outline"
            label="Organization ID"
            value={String(employee.orgId)}
          />

          <Separator />

          <DetailRow
            icon="calendar-outline"
            label="Date of Joining"
            value={
              employee.dateOfJoining ??
              'Not set'
            }
          />

          <Separator />

          <DetailRow
            icon="domain"
            label="Department"
            value={
              employee.departmentId != null
                ? `Department ${employee.departmentId}`
                : 'Not assigned'
            }
          />

          <Separator />

          <DetailRow
            icon="account-group-outline"
            label="Team"
            value={
              employee.teamId != null
                ? `Team ${employee.teamId}`
                : 'Not assigned'
            }
          />
        </View>

        {/* Shift */}
        <Text style={styles.sectionTitle}>
          Work Shift
        </Text>

        <View style={styles.shiftCard}>
          <View style={styles.shiftIcon}>
            <MaterialCommunityIcons
              name="calendar-clock-outline"
              size={25}
              color={T.purpleIcon}
            />
          </View>

          <View style={styles.shiftInfo}>
            <Text style={styles.shiftLabel}>
              Current Shift
            </Text>

            <Text style={styles.shiftName}>
              {currentShift?.shiftName ??
                'No shift assigned'}
            </Text>

            {currentShift ? (
              <>
                <Text style={styles.shiftTime}>
                  {formatTime(
                    currentShift.startTime
                  )}
                  {'  →  '}
                  {formatTime(
                    currentShift.endTime
                  )}
                </Text>

                <Text style={styles.shiftMeta}>
                  Late allowance:{' '}
                  {currentShift.allowedLateMinutes ??
                    0}{' '}
                  min
                </Text>
              </>
            ) : (
              <Text style={styles.noShiftText}>
                Assign a shift to enable
                schedule-based attendance.
              </Text>
            )}
          </View>

          <Pressable
            style={styles.changeButton}
            onPress={openShiftModal}
          >
            <Text style={styles.changeButtonText}>
              {currentShift
                ? 'Change'
                : 'Assign'}
            </Text>
          </Pressable>
        </View>

        {/* Assignment Summary */}
        <Text style={styles.sectionTitle}>
          Assignment Summary
        </Text>

        <View style={styles.summaryGrid}>
          <SummaryCard
            icon="domain"
            label="Department"
            value={
              employee.departmentId != null
                ? `#${employee.departmentId}`
                : 'None'
            }
          />

          <SummaryCard
            icon="account-group-outline"
            label="Team"
            value={
              employee.teamId != null
                ? `#${employee.teamId}`
                : 'None'
            }
          />

          <SummaryCard
            icon="calendar-clock-outline"
            label="Shift"
            value={
              currentShift?.shiftName ??
              'None'
            }
          />
        </View>

        {/* Actions */}
        <Text style={styles.sectionTitle}>
          Actions
        </Text>

        <View style={styles.actionsCard}>
          <Pressable
            style={styles.actionRow}
            onPress={openShiftModal}
          >
            <View style={styles.actionIcon}>
              <MaterialCommunityIcons
                name="calendar-clock-outline"
                size={19}
                color={T.purpleIcon}
              />
            </View>

            <View style={styles.actionInfo}>
              <Text style={styles.actionTitle}>
                {currentShift
                  ? 'Change Shift'
                  : 'Assign Shift'}
              </Text>

              <Text style={styles.actionSub}>
                Update employee work schedule
              </Text>
            </View>

            <MaterialCommunityIcons
              name="chevron-right"
              size={20}
              color={T.textMuted}
            />
          </Pressable>
        </View>

        <View style={styles.bottomSpacer} />
      </ScrollView>

      {/* Shift Picker */}
      <Modal
        visible={shiftModalVisible}
        transparent
        animationType="slide"
        onRequestClose={closeShiftModal}
      >
        <View style={styles.modalOverlay}>
          <Pressable
            style={StyleSheet.absoluteFill}
            onPress={closeShiftModal}
          />

          <View
            style={[
              styles.modalSheet,
              {
                paddingBottom:
                  Math.max(
                    insets.bottom,
                    18
                  ) + 10,
              },
            ]}
          >
            <View style={styles.modalHandle} />

            <View style={styles.modalHeader}>
              <View style={styles.modalHeaderInfo}>
                <Text style={styles.modalTitle}>
                  {currentShift
                    ? 'Change Shift'
                    : 'Assign Shift'}
                </Text>

                <Text
                  style={styles.modalSubtitle}
                  numberOfLines={1}
                >
                  {employee.employeeName}
                </Text>
              </View>

              <Pressable
                style={styles.closeButton}
                onPress={closeShiftModal}
                disabled={savingShift}
              >
                <MaterialCommunityIcons
                  name="close"
                  size={22}
                  color={T.purpleDark}
                />
              </Pressable>
            </View>

            <ScrollView
              style={styles.shiftList}
              showsVerticalScrollIndicator={false}
            >
              {shifts.map((shift) => {
                const selected =
                  selectedShiftId ===
                  shift.shiftId;

                return (
                  <Pressable
                    key={shift.shiftId}
                    style={[
                      styles.shiftOption,
                      selected &&
                        styles.shiftOptionSelected,
                    ]}
                    disabled={savingShift}
                    onPress={() =>
                      setSelectedShiftId(
                        shift.shiftId
                      )
                    }
                  >
                    <View
                      style={[
                        styles.optionIcon,
                        selected &&
                          styles.optionIconSelected,
                      ]}
                    >
                      <MaterialCommunityIcons
                        name="clock-time-four-outline"
                        size={21}
                        color={
                          selected
                            ? '#FFF'
                            : T.purpleIcon
                        }
                      />
                    </View>

                    <View style={styles.optionInfo}>
                      <Text
                        style={[
                          styles.optionName,
                          selected &&
                            styles.optionNameSelected,
                        ]}
                      >
                        {shift.shiftName}
                      </Text>

                      <Text style={styles.optionTime}>
                        {formatTime(
                          shift.startTime
                        )}
                        {'  →  '}
                        {formatTime(
                          shift.endTime
                        )}
                      </Text>

                      <Text style={styles.optionMeta}>
                        Late allowance:{' '}
                        {shift.allowedLateMinutes ??
                          0}{' '}
                        min
                      </Text>
                    </View>

                    <MaterialCommunityIcons
                      name={
                        selected
                          ? 'check-circle'
                          : 'circle-outline'
                      }
                      size={22}
                      color={
                        selected
                          ? T.purpleIcon
                          : T.textMuted
                      }
                    />
                  </Pressable>
                );
              })}
            </ScrollView>

            <Pressable
              style={[
                styles.saveButton,
                (
                  savingShift ||
                  selectedShiftId === null
                ) &&
                  styles.saveButtonDisabled,
              ]}
              disabled={
                savingShift ||
                selectedShiftId === null
              }
              onPress={handleSaveShift}
            >
              {savingShift ? (
                <ActivityIndicator
                  color="#FFF"
                />
              ) : (
                <>
                  <MaterialCommunityIcons
                    name="content-save-check-outline"
                    size={19}
                    color="#FFF"
                  />

                  <Text style={styles.saveButtonText}>
                    Save Shift
                  </Text>
                </>
              )}
            </Pressable>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function Header({
  title,
  onBack,
}: {
  title: string;
  onBack: () => void;
}) {
  return (
    <View style={styles.header}>
      <Pressable
        style={styles.backButton}
        onPress={onBack}
      >
        <MaterialCommunityIcons
          name="chevron-left"
          size={28}
          color={T.purpleDark}
        />
      </Pressable>

      <Text style={styles.headerTitle}>
        {title}
      </Text>

      <View style={styles.headerSpacer} />
    </View>
  );
}

function DetailRow({
  icon,
  label,
  value,
}: {
  icon: any;
  label: string;
  value: string;
}) {
  return (
    <View style={styles.detailRow}>
      <View style={styles.detailIcon}>
        <MaterialCommunityIcons
          name={icon}
          size={18}
          color={T.purpleIcon}
        />
      </View>

      <View style={styles.detailInfo}>
        <Text style={styles.detailLabel}>
          {label}
        </Text>

        <Text style={styles.detailValue}>
          {value}
        </Text>
      </View>
    </View>
  );
}

function Separator() {
  return <View style={styles.separator} />;
}

function SummaryCard({
  icon,
  label,
  value,
}: {
  icon: any;
  label: string;
  value: string;
}) {
  return (
    <View style={styles.summaryCard}>
      <MaterialCommunityIcons
        name={icon}
        size={20}
        color={T.purpleIcon}
      />

      <Text
        style={styles.summaryValue}
        numberOfLines={1}
      >
        {value}
      </Text>

      <Text style={styles.summaryLabel}>
        {label}
      </Text>
    </View>
  );
}

function getInitials(name: string) {
  const parts = name
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  if (parts.length === 0) {
    return '?';
  }

  if (parts.length === 1) {
    return parts[0]
      .slice(0, 2)
      .toUpperCase();
  }

  return (
    parts[0][0] +
    parts[parts.length - 1][0]
  ).toUpperCase();
}

function formatTime(value: string) {
  return value?.slice(0, 5) || '--:--';
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: T.screenBg,
  },

  header: {
    height: 58,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
  },

  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
  },

  headerTitle: {
    fontSize: 17,
    fontWeight: '700',
    color: T.purpleDark,
  },

  headerSpacer: {
    width: 40,
  },

  scroll: {
    paddingHorizontal: 20,
  },

  centered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 30,
  },

  loadingText: {
    marginTop: 12,
    fontSize: 13,
    color: T.textMuted,
  },

  errorTitle: {
    marginTop: 14,
    fontSize: 18,
    fontWeight: '800',
    color: T.purpleDark,
  },

  errorMessage: {
    marginTop: 7,
    fontSize: 12,
    lineHeight: 18,
    textAlign: 'center',
    color: T.textMuted,
  },

  retryButton: {
    marginTop: 20,
    height: 44,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 7,
    paddingHorizontal: 20,
    borderRadius: 12,
    backgroundColor: T.purpleIcon,
  },

  retryButtonText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#FFF',
  },

  profileCard: {
    alignItems: 'center',
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 24,
    marginBottom: 18,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },

  avatar: {
    width: 82,
    height: 82,
    borderRadius: 41,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: T.purpleLight,
    marginBottom: 12,
  },

  avatarText: {
    fontSize: 26,
    fontWeight: '800',
    color: T.purpleIcon,
  },

  employeeName: {
    fontSize: 21,
    fontWeight: '800',
    color: T.purpleDark,
    textAlign: 'center',
  },

  employeeBadge: {
    marginTop: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    borderRadius: 14,
    paddingHorizontal: 10,
    paddingVertical: 5,
    backgroundColor: T.purpleLight,
  },

  employeeBadgeText: {
    fontSize: 11,
    fontWeight: '700',
    color: T.purpleIcon,
  },

  userIdText: {
    marginTop: 8,
    fontSize: 11,
    color: T.textMuted,
  },

  sectionTitle: {
    marginTop: 4,
    marginBottom: 10,
    fontSize: 14,
    fontWeight: '700',
    color: T.purpleDark,
  },

  infoCard: {
    backgroundColor: '#FFF',
    borderRadius: 16,
    paddingVertical: 4,
    marginBottom: 18,
  },

  detailRow: {
    minHeight: 64,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 15,
    paddingVertical: 10,
  },

  detailIcon: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: T.purpleLight,
  },

  detailInfo: {
    flex: 1,
  },

  detailLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: T.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 0.35,
  },

  detailValue: {
    marginTop: 3,
    fontSize: 13,
    fontWeight: '700',
    color: T.purpleDark,
  },

  separator: {
    height: 1,
    marginHorizontal: 15,
    backgroundColor: '#F2EFF5',
  },

  shiftCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#FFF',
    borderRadius: 16,
    padding: 15,
    marginBottom: 18,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 2,
  },

  shiftIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: T.purpleLight,
  },

  shiftInfo: {
    flex: 1,
  },

  shiftLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: T.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 0.35,
  },

  shiftName: {
    marginTop: 2,
    fontSize: 14,
    fontWeight: '800',
    color: T.purpleDark,
  },

  shiftTime: {
    marginTop: 3,
    fontSize: 11,
    color: T.textMuted,
    fontFamily: 'monospace',
  },

  shiftMeta: {
    marginTop: 3,
    fontSize: 10,
    color: T.textMuted,
  },

  noShiftText: {
    marginTop: 4,
    fontSize: 10,
    lineHeight: 14,
    color: T.textMuted,
  },

  changeButton: {
    borderWidth: 1,
    borderColor: T.purpleIcon,
    borderRadius: 18,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },

  changeButtonText: {
    fontSize: 11,
    fontWeight: '700',
    color: T.purpleIcon,
  },

  summaryGrid: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 18,
  },

  summaryCard: {
    flex: 1,
    minWidth: 0,
    alignItems: 'center',
    backgroundColor: '#FFF',
    borderRadius: 14,
    paddingHorizontal: 8,
    paddingVertical: 14,
  },

  summaryValue: {
    width: '100%',
    marginTop: 7,
    fontSize: 12,
    fontWeight: '800',
    color: T.purpleDark,
    textAlign: 'center',
  },

  summaryLabel: {
    marginTop: 3,
    fontSize: 9,
    color: T.textMuted,
    textAlign: 'center',
  },

  actionsCard: {
    backgroundColor: '#FFF',
    borderRadius: 16,
    overflow: 'hidden',
  },

  actionRow: {
    minHeight: 68,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 15,
  },

  actionIcon: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: T.purpleLight,
  },

  actionInfo: {
    flex: 1,
  },

  actionTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: T.purpleDark,
  },

  actionSub: {
    marginTop: 2,
    fontSize: 10,
    color: T.textMuted,
  },

  bottomSpacer: {
    height: 100,
  },

  modalOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(20, 12, 35, 0.42)',
  },

  modalSheet: {
    maxHeight: '78%',
    paddingHorizontal: 20,
    paddingTop: 10,
    backgroundColor: T.screenBg,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
  },

  modalHandle: {
    width: 42,
    height: 4,
    alignSelf: 'center',
    borderRadius: 2,
    backgroundColor: '#D8D1E2',
    marginBottom: 16,
  },

  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },

  modalHeaderInfo: {
    flex: 1,
    paddingRight: 12,
  },

  modalTitle: {
    fontSize: 19,
    fontWeight: '800',
    color: T.purpleDark,
  },

  modalSubtitle: {
    marginTop: 3,
    fontSize: 12,
    color: T.textMuted,
  },

  closeButton: {
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF',
  },

  shiftList: {
    maxHeight: 380,
  },

  shiftOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#E8E4EC',
    borderRadius: 14,
    backgroundColor: '#FFF',
  },

  shiftOptionSelected: {
    borderWidth: 1.5,
    borderColor: T.purpleIcon,
    backgroundColor: T.purpleLight,
  },

  optionIcon: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: T.purpleLight,
  },

  optionIconSelected: {
    backgroundColor: T.purpleIcon,
  },

  optionInfo: {
    flex: 1,
  },

  optionName: {
    fontSize: 13,
    fontWeight: '700',
    color: T.purpleDark,
  },

  optionNameSelected: {
    color: T.purpleIcon,
  },

  optionTime: {
    marginTop: 3,
    fontSize: 11,
    color: T.textMuted,
    fontFamily: 'monospace',
  },

  optionMeta: {
    marginTop: 3,
    fontSize: 10,
    color: T.textMuted,
  },

  saveButton: {
    height: 52,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 10,
    borderRadius: 14,
    backgroundColor: T.purpleIcon,
  },

  saveButtonDisabled: {
    opacity: 0.55,
  },

  saveButtonText: {
    fontSize: 15,
    fontWeight: '700',
    color: '#FFF',
  },
});