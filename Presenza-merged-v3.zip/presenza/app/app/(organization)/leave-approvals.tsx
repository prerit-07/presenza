// app/leave-approvals.tsx
// Role: Manager + Admin
// Opens from: Manager/Admin dashboard, Inbox
// Navigates to: back to dashboard

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList,
  Pressable, ActivityIndicator, Alert,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { DashboardTheme as T } from '@/constants/dashboard-theme';
import { PageHeader } from '@/components/PageHeader';
import { getPendingRequests, reviewRequest } from '@/services/request.service';
import { useThemedAlert } from '@/components/ThemedAlertProvider';

const STATUS_COLOR: Record<string, string> = {
  PENDING: '#F59E0B',
  APPROVED: '#4CAF50',
  REJECTED: '#B23A48',
};

type LeaveRequest = {
  requestId: number;
  employeeName: string;
  requestType: string;
  startDate: string;
  endDate: string;
  reason: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
};

export default function LeaveApprovalsScreen() {
  const { showAlert } = useThemedAlert();
  const [requests, setRequests] = useState<LeaveRequest[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('ALL');
  const [actionLoading, setActionLoading] = useState<number | null>(null);

  const fetchRequests = useCallback(async () => {
    try {
      const data = await getPendingRequests() as LeaveRequest[];
      setRequests(data);
    } catch (e: any) {
      showAlert({ type: 'error', title: 'Error', message: e?.message ?? 'Could not load leave requests' });
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRequests();
  }, [fetchRequests]);

  const handleReview = async (requestId: number, decision: 'APPROVED' | 'REJECTED') => {
    setActionLoading(requestId);
    try {
      await reviewRequest(requestId, { approved: decision === 'APPROVED', remarks: '' });
      // Update local state optimistically
      setRequests((prev) =>
        prev.map((r) =>
          r.requestId === requestId ? { ...r, status: decision } : r
        )
      );
    } catch (e: any) {
      showAlert({ type: 'error', title: 'Failed', message: e?.message ?? `Could not ${decision.toLowerCase()} request` });
    } finally {
      setActionLoading(null);
    }
  };

  const formatDate = (d: string) =>
    new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });

  const filtered = requests.filter(
    (l) => filter === 'ALL' || l.status === filter
  );

  if (isLoading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color={T.purpleIcon} />
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <PageHeader title="Leave Approvals" />

      {/* Filter Tabs */}
      <View style={styles.filterRow}>
        {(['ALL', 'PENDING', 'APPROVED', 'REJECTED'] as const).map((f) => (
          <Pressable
            key={f}
            style={[styles.filterPill, filter === f && styles.filterPillActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>
              {f === 'ALL' ? 'All' : f.charAt(0) + f.slice(1).toLowerCase()}
            </Text>
          </Pressable>
        ))}
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => String(item.requestId)}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={styles.card}>
            {/* Employee Info */}
            <View style={styles.cardTop}>
              <View style={styles.avatarCircle}>
                <Text style={styles.avatarLetter}>
                  {(item.employeeName ?? '?')[0].toUpperCase()}
                </Text>
              </View>
              <View style={styles.empInfo}>
                <Text style={styles.empName}>{item.employeeName ?? 'Unknown'}</Text>
                <Text style={styles.leaveType}>{item.requestType}</Text>
              </View>
              <View style={[styles.statusBadge, { backgroundColor: (STATUS_COLOR[item.status] ?? '#ccc') + '18' }]}>
                <Text style={[styles.statusText, { color: STATUS_COLOR[item.status] ?? '#ccc' }]}>
                  {item.status.charAt(0) + item.status.slice(1).toLowerCase()}
                </Text>
              </View>
            </View>

            {/* Date Range */}
            <View style={styles.dateRow}>
              <MaterialCommunityIcons name="calendar-range" size={14} color={T.textMuted} />
              <Text style={styles.dateText}>
                {formatDate(item.startDate)} – {formatDate(item.endDate)}
              </Text>
            </View>

            {/* Reason */}
            {item.reason ? (
              <Text style={styles.reason}>{item.reason}</Text>
            ) : null}

            {/* Actions — only show for PENDING */}
            {item.status === 'PENDING' && (
              <View style={styles.actionRow}>
                <Pressable
                  style={[styles.actionBtn, styles.rejectBtn]}
                  disabled={actionLoading === item.requestId}
                  onPress={() => handleReview(item.requestId, 'REJECTED')}
                >
                  <MaterialCommunityIcons name="close" size={14} color="#B23A48" />
                  <Text style={[styles.actionBtnText, { color: '#B23A48' }]}>Reject</Text>
                </Pressable>
                <Pressable
                  style={[styles.actionBtn, styles.approveBtn]}
                  disabled={actionLoading === item.requestId}
                  onPress={() => handleReview(item.requestId, 'APPROVED')}
                >
                  {actionLoading === item.requestId ? (
                    <ActivityIndicator size="small" color="#FFF" />
                  ) : (
                    <>
                      <MaterialCommunityIcons name="check" size={14} color="#FFF" />
                      <Text style={[styles.actionBtnText, { color: '#FFF' }]}>Approve</Text>
                    </>
                  )}
                </Pressable>
              </View>
            )}
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons name="calendar-check-outline" size={48} color={T.textMuted} />
            <Text style={styles.emptyText}>No leave requests</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: T.screenBg },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  filterRow: { flexDirection: 'row', gap: 8, paddingHorizontal: 20, marginBottom: 12 },
  filterPill: {
    borderRadius: 20, paddingVertical: 6, paddingHorizontal: 12,
    backgroundColor: '#FFF', borderWidth: 1, borderColor: '#E8E4EC',
  },
  filterPillActive: { backgroundColor: T.purpleIcon, borderColor: T.purpleIcon },
  filterText: { fontSize: 12, fontWeight: '600', color: T.purpleIcon },
  filterTextActive: { color: '#FFF' },
  list: { paddingHorizontal: 20, paddingBottom: 100 },
  card: {
    backgroundColor: '#FFF', borderRadius: 16, padding: 16, marginBottom: 12,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05, shadowRadius: 6, elevation: 3,
  },
  cardTop: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  avatarCircle: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: '#EDE8F5',
    justifyContent: 'center', alignItems: 'center', marginRight: 10,
  },
  avatarLetter: { fontSize: 16, fontWeight: '700', color: T.purpleIcon },
  empInfo: { flex: 1 },
  empName: { fontSize: 14, fontWeight: '700', color: T.purpleDark },
  leaveType: { fontSize: 11, color: T.textMuted, marginTop: 1 },
  statusBadge: { borderRadius: 8, paddingVertical: 4, paddingHorizontal: 8 },
  statusText: { fontSize: 11, fontWeight: '700' },
  dateRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
  dateText: { fontSize: 12, color: T.textMuted },
  reason: { fontSize: 12, color: T.purpleDark, fontStyle: 'italic', marginBottom: 14 },
  actionRow: { flexDirection: 'row', gap: 10 },
  actionBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 6, borderRadius: 10, paddingVertical: 10,
  },
  rejectBtn: { backgroundColor: '#FFF1F3', borderWidth: 1, borderColor: '#B23A48' },
  approveBtn: { backgroundColor: '#4CAF50' },
  actionBtnText: { fontSize: 13, fontWeight: '700' },
  empty: { alignItems: 'center', marginTop: 60, gap: 10 },
  emptyText: { fontSize: 14, color: T.textMuted },
});
