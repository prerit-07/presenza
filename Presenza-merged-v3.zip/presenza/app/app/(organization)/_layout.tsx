import { Stack } from 'expo-router';

export default function OrganizationLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="admin" />
      <Stack.Screen name="(tabs)" />

      <Stack.Screen name="register" />
      <Stack.Screen name="create-admin" />
      <Stack.Screen name="plan" />
      <Stack.Screen name="review" />

      <Stack.Screen name="add-member" />
      <Stack.Screen name="member-detail" />
      <Stack.Screen name="departments" />

      <Stack.Screen name="office-location-setup" />
      <Stack.Screen name="office-setup" />
      <Stack.Screen name="geofence-setup" />
      <Stack.Screen name="manage-geofence" />
      <Stack.Screen name="wifi-setup" />

      {/* Shift Management */}
      <Stack.Screen name="shifts" />

      <Stack.Screen name="attendance" />
      <Stack.Screen name="device-approvals" />
      <Stack.Screen name="leave-approvals" />
      <Stack.Screen name="help-desk" />
      <Stack.Screen name="notifications" />
    </Stack>
  );
}