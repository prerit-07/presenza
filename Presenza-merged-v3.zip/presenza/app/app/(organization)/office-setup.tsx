// app/office-setup.tsx
// Role: Admin — First login only
// Opens from: _layout.tsx (auto) on first login, or Organisation tab manually

import React, { useState } from 'react';
import {
  View, Text, StyleSheet, Pressable,
  ScrollView, Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { PageHeader } from '@/components/PageHeader';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { DashboardTheme as T } from '@/constants/dashboard-theme';

const { width } = Dimensions.get('window');

const STEPS = [
  {
    id: 1, icon: 'office-building-marker', title: 'Office Locations',
    desc: 'Set up your office geofences and register Wi-Fi routers for attendance tracking.',
    action: 'Manage Locations', route: '/office-locations',
  },
  {
    id: 2, icon: 'office-building-outline', title: 'Create Departments',
    desc: 'Add your organisation\'s departments to assign employees and managers.',
    action: 'Add Departments', route: '/departments',
  },
  {
    id: 3, icon: 'account-multiple-plus-outline', title: 'Add Employees',
    desc: 'Create accounts for your employees and managers. Their credentials will be generated automatically.',
    action: 'Add Members', route: '/add-member',
  },
  {
    id: 4, icon: 'check-circle-outline', title: 'All Done!',
    desc: 'Your organisation is ready. Attendance is now enabled for your team.',
    action: 'Go to Dashboard', route: '/(organization)/(tabs)/overview',
  },
];

export default function OfficeSetupScreen() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const step = STEPS[currentStep];
  const isLast = currentStep === STEPS.length - 1;

  const handleAction = () => {
    if (isLast) {
      router.replace('/(organization)/(tabs)/overview');
      return;
    }
    setCompletedSteps((prev) => [...prev, currentStep]);
    router.push(step.route as any);
  };

  return (
    <View style={styles.root}>
      <PageHeader title="Office Setup" subtitle="Configuration Wizard" />

      {/* Progress */}
      <View style={styles.progressRow}>
        {STEPS.map((s, i) => (
          <View
            key={s.id}
            style={[
              styles.progressDot,
              i === currentStep && styles.progressDotActive,
              completedSteps.includes(i) && styles.progressDotDone,
            ]}
          />
        ))}
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Step Indicator */}
        <Text style={styles.stepNum}>Step {step.id} of {STEPS.length}</Text>

        {/* Icon */}
        <View style={[styles.iconCircle, isLast && styles.iconCircleGreen]}>
          <MaterialCommunityIcons
            name={step.icon as any}
            size={56}
            color={isLast ? '#4CAF50' : T.purpleIcon}
          />
        </View>

        <Text style={styles.stepTitle}>{step.title}</Text>
        <Text style={styles.stepDesc}>{step.desc}</Text>

        {/* Steps overview */}
        <View style={styles.stepsOverview}>
          {STEPS.map((s, i) => (
            <Pressable
              key={s.id}
              style={[styles.overviewRow, i === currentStep && styles.overviewRowActive]}
              onPress={() => setCurrentStep(i)}
            >
              <View style={[
                styles.overviewDot,
                completedSteps.includes(i) && styles.overviewDotDone,
                i === currentStep && styles.overviewDotActive,
              ]}>
                {completedSteps.includes(i) ? (
                  <MaterialCommunityIcons name="check" size={12} color="#FFF" />
                ) : (
                  <Text style={styles.overviewDotText}>{s.id}</Text>
                )}
              </View>
              <Text style={[styles.overviewLabel, i === currentStep && styles.overviewLabelActive]}>
                {s.title}
              </Text>
            </Pressable>
          ))}
        </View>
      </ScrollView>

      {/* CTA */}
      <View style={styles.bottomBar}>
        <Pressable style={[styles.actionBtn, isLast && styles.actionBtnGreen]} onPress={handleAction}>
          <Text style={styles.actionBtnText}>{step.action}</Text>
          <MaterialCommunityIcons
            name={isLast ? 'check' : 'arrow-right'}
            size={18} color="#FFF"
          />
        </Pressable>
        {!isLast && currentStep < STEPS.length - 2 && (
          <Pressable style={styles.nextStepBtn} onPress={() => setCurrentStep((s) => s + 1)}>
            <Text style={styles.nextStepText}>Next Step →</Text>
          </Pressable>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: T.screenBg },
  progressRow: { flexDirection: 'row', gap: 6, justifyContent: 'center', paddingHorizontal: 20, marginBottom: 8 },
  progressDot: { flex: 1, height: 4, borderRadius: 2, backgroundColor: '#E8E4EC' },
  progressDotActive: { backgroundColor: T.purpleIcon },
  progressDotDone: { backgroundColor: '#4CAF50' },
  scroll: { paddingHorizontal: 24, paddingBottom: 20, alignItems: 'center' },
  stepNum: { fontSize: 12, fontWeight: '600', color: T.textMuted, marginTop: 8, marginBottom: 24, letterSpacing: 0.5 },
  iconCircle: { width: 120, height: 120, borderRadius: 60, backgroundColor: T.purpleLight, alignItems: 'center', justifyContent: 'center', marginBottom: 24 },
  iconCircleGreen: { backgroundColor: '#F0FFF4' },
  stepTitle: { fontSize: 22, fontWeight: '800', color: T.purpleDark, textAlign: 'center', marginBottom: 10 },
  stepDesc: { fontSize: 14, color: T.textMuted, textAlign: 'center', lineHeight: 21, marginBottom: 28 },
  stepsOverview: { width: '100%', backgroundColor: '#FFF', borderRadius: 16, padding: 16, gap: 4 },
  overviewRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 8, borderRadius: 10, paddingHorizontal: 8 },
  overviewRowActive: { backgroundColor: T.purpleLight },
  overviewDot: { width: 24, height: 24, borderRadius: 12, backgroundColor: '#E8E4EC', alignItems: 'center', justifyContent: 'center' },
  overviewDotActive: { backgroundColor: T.purpleIcon },
  overviewDotDone: { backgroundColor: '#4CAF50' },
  overviewDotText: { fontSize: 11, fontWeight: '700', color: T.textMuted },
  overviewLabel: { fontSize: 13, fontWeight: '500', color: T.textMuted, flex: 1 },
  overviewLabelActive: { fontWeight: '700', color: T.purpleDark },
  bottomBar: { paddingHorizontal: 20, paddingBottom: 24, gap: 10 },
  actionBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: T.purpleIcon, borderRadius: 14, height: 54 },
  actionBtnGreen: { backgroundColor: '#4CAF50' },
  actionBtnText: { color: '#FFF', fontSize: 15, fontWeight: '700' },
  nextStepBtn: { alignItems: 'center', paddingVertical: 8 },
  nextStepText: { fontSize: 13, fontWeight: '600', color: T.purpleIcon },
});


