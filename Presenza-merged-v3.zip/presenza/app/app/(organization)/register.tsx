// app/(organization)/register.tsx

import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
} from 'react-native';

import Ionicons from '@expo/vector-icons/Ionicons';
import { useRouter } from 'expo-router';

import { AuthTheme } from '@/constants/auth-theme';
import AuthLayout from '@/components/AuthLayout';

import {
  useOnboardingStore,
  type OrganizationType,
} from '@/store/onboarding.store';

const C = AuthTheme.dark;

const STEPS = [
  { id: 1, label: 'Organization' },
  { id: 2, label: 'Admin' },
  { id: 3, label: 'Verify' },
  { id: 4, label: 'Plan' },
  { id: 5, label: 'Review' },
];

const ORG_TYPES: OrganizationType[] = [
  'Corporate',
  'Educational',
];

export default function CreateOrganizationScreen() {
  const router = useRouter();

  const storedOrganizationName = useOnboardingStore(
    (state) => state.organizationName
  );

  const storedOrganizationType = useOnboardingStore(
    (state) => state.organizationType
  );

  const setOrganizationDetails = useOnboardingStore(
    (state) => state.setOrganizationDetails
  );

  const [orgName, setOrgName] = useState(
    storedOrganizationName
  );

  const [orgType, setOrgType] =
    useState<OrganizationType>(
      storedOrganizationType
    );

  const [showTypePicker, setShowTypePicker] =
    useState(false);

  const currentStep = 1;

  const handleContinue = () => {
    const trimmedOrgName = orgName.trim();

    if (!trimmedOrgName) {
      return;
    }

    setOrganizationDetails(
      trimmedOrgName,
      orgType
    );

    router.push(
      '/(organization)/create-admin'
    );
  };

  return (
    <AuthLayout
      variant="dark"
      title="Create your organization"
      subtitle="Set up your workspace in a few simple steps"
    >
      {/* Step indicator */}
      <View style={styles.stepsContainer}>
        {/* Line from center of first step to center of last step */}
        <View style={styles.progressLine} />

        <View style={styles.stepsRow}>
          {STEPS.map((step) => {
            const isActive =
              step.id === currentStep;

            return (
              <View
                key={step.id}
                style={styles.stepColumn}
              >
                <View
                  style={[
                    styles.stepCircle,
                    {
                      backgroundColor: isActive
                        ? C.progressCircleActive
                        : C.progressCircleInactive,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.stepNumber,
                      {
                        color: isActive
                          ? C.progressTextActive
                          : C.progressTextInactive,
                      },
                    ]}
                  >
                    {step.id}
                  </Text>
                </View>

                <Text
                  style={styles.stepLabel}
                  numberOfLines={1}
                >
                  {step.label}
                </Text>
              </View>
            );
          })}
        </View>
      </View>

      {/* Form */}
      <Text style={styles.sectionTitle}>
        Organization details
      </Text>

      <Text style={styles.fieldLabel}>
        Organization Name
      </Text>

      <View style={styles.inputWrapper}>
        <Ionicons
          name="business-outline"
          size={18}
          color={C.inputPlaceholder}
        />

        <TextInput
          style={styles.input}
          placeholder="Organization Name"
          placeholderTextColor={
            C.inputPlaceholder
          }
          value={orgName}
          onChangeText={setOrgName}
          autoCapitalize="words"
          returnKeyType="done"
        />
      </View>

      <Text style={styles.fieldLabel}>
        Organization Type
      </Text>

      <Pressable
        style={styles.inputWrapper}
        onPress={() => {
          setShowTypePicker(
            (previous) => !previous
          );
        }}
      >
        <Ionicons
          name="briefcase-outline"
          size={18}
          color={C.inputPlaceholder}
        />

        <Text style={styles.inputText}>
          {orgType}
        </Text>

        <Ionicons
          name={
            showTypePicker
              ? 'chevron-up'
              : 'chevron-down'
          }
          size={18}
          color={C.inputPlaceholder}
          style={styles.dropdownIcon}
        />
      </Pressable>

      {showTypePicker && (
        <View style={styles.dropdown}>
          {ORG_TYPES.map((type) => (
            <Pressable
              key={type}
              style={styles.dropdownItem}
              onPress={() => {
                setOrgType(type);
                setShowTypePicker(false);
              }}
            >
              <Text
                style={styles.dropdownItemText}
              >
                {type}
              </Text>
            </Pressable>
          ))}
        </View>
      )}

      <Pressable
        style={[
          styles.continueButton,
          !orgName.trim() &&
            styles.continueButtonDisabled,
        ]}
        onPress={handleContinue}
        disabled={!orgName.trim()}
      >
        <Text
          style={styles.continueButtonText}
        >
          Continue
        </Text>
      </Pressable>
    </AuthLayout>
  );
}

const styles = StyleSheet.create({
  // =========================================
  // STEPPER
  // =========================================

  stepsContainer: {
    position: 'relative',
    width: '100%',
    marginBottom: 8,
  },

  stepsRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    width: '100%',
  },

  progressLine: {
    position: 'absolute',

    // 32px circle => vertical center at 16px
    top: 15,

    // 4 equal columns:
    // each column = 25%
    // first center = 12.5%
    // last center = 87.5%
    left: '12.5%',
    right: '12.5%',

    height: 2,
    backgroundColor: C.progressLine,

    zIndex: 1,
  },

  stepColumn: {
    // Every step receives exactly 25% width
    flex: 1,

    alignItems: 'center',
    justifyContent: 'flex-start',

    zIndex: 2,
  },

  stepCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,

    alignItems: 'center',
    justifyContent: 'center',
  },

  stepNumber: {
    fontSize: 14,
    fontWeight: '700',
  },

  stepLabel: {
    width: '100%',

    fontSize: 11,
    color: C.title,

    marginTop: 4,

    textAlign: 'center',
  },

  // =========================================
  // FORM
  // =========================================

  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: C.title,

    marginTop: 24,
    marginBottom: 16,
  },

  fieldLabel: {
    fontSize: 13,
    color: C.label,

    marginBottom: 6,

    fontWeight: '600',
  },

  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',

    backgroundColor: C.inputBackground,

    borderRadius: 14,

    paddingHorizontal: 14,

    height: 52,

    marginBottom: 18,

    gap: 10,
  },

  input: {
    flex: 1,

    fontSize: 14,
    color: C.inputText,
  },

  inputText: {
    flex: 1,

    fontSize: 14,
    color: C.inputText,
  },

  dropdownIcon: {
    marginLeft: 'auto',
  },

  // =========================================
  // DROPDOWN
  // =========================================

  dropdown: {
    backgroundColor: C.inputBackground,

    borderRadius: 14,

    marginTop: -12,
    marginBottom: 18,

    paddingVertical: 4,

    overflow: 'hidden',
  },

  dropdownItem: {
    paddingVertical: 12,
    paddingHorizontal: 16,
  },

  dropdownItemText: {
    fontSize: 14,
    color: C.inputText,
  },

  // =========================================
  // BUTTON
  // =========================================

  continueButton: {
    backgroundColor: C.buttonBackground,

    borderRadius: 16,

    height: 54,

    alignItems: 'center',
    justifyContent: 'center',

    marginTop: 12,
  },

  continueButtonDisabled: {
    opacity: 0.5,
  },

  continueButtonText: {
    color: C.buttonText,

    fontSize: 15,
    fontWeight: '600',
  },
});