// app/(organization)/review.tsx

import { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  ActivityIndicator,
} from 'react-native';

import Ionicons from '@expo/vector-icons/Ionicons';
import { useRouter } from 'expo-router';

import { AuthTheme } from '@/constants/auth-theme';
import AuthLayout from '@/components/AuthLayout';

import {
  register,
  login,
} from '@/services/auth.service';

import { useOnboardingStore } from '@/store/onboarding.store';
import { useAuthStore } from '@/store/auth.store';

const C = AuthTheme.dark;

const STEPS = [
  { id: 1, label: 'Organization' },
  { id: 2, label: 'Admin' },
  { id: 3, label: 'Verify' },
  { id: 4, label: 'Plan' },
  { id: 5, label: 'Review' },
];

const PLAN_DETAILS: Record<
  string,
  {
    name: string;
    price: string;
    period: string;
  }
> = {
  starter: {
    name: 'Starter',
    price: '₹0',
    period: '/month',
  },

  growth: {
    name: 'Growth',
    price: '₹1,499',
    period: '/month',
  },

  enterprise: {
    name: 'Enterprise',
    price: 'Custom',
    period: '',
  },
};

export default function CreateReviewScreen() {
  const router = useRouter();
  const currentStep = 5;

  const organizationName = useOnboardingStore(
    (state) => state.organizationName
  );

  const organizationType = useOnboardingStore(
    (state) => state.organizationType
  );

  const fullName = useOnboardingStore(
    (state) => state.fullName
  );

  const username = useOnboardingStore(
    (state) => state.username
  );

  const email = useOnboardingStore(
    (state) => state.email
  );

  const phone = useOnboardingStore(
    (state) => state.phone
  );

  const password = useOnboardingStore(
    (state) => state.password
  );

  const selectedPlan = useOnboardingStore(
    (state) => state.selectedPlan
  );

  const resetOnboarding = useOnboardingStore(
    (state) => state.resetOnboarding
  );

  const setAuthenticatedUser = useAuthStore(
    (state) => state.setAuthenticatedUser
  );

  const [isSubmitting, setIsSubmitting] =
    useState(false);

  const [error, setError] = useState('');

  const selectedPlanKey =
    selectedPlan
      ?.trim()
      .toLowerCase();

  const selectedPlanDetails =
    selectedPlanKey
      ? PLAN_DETAILS[selectedPlanKey]
      : undefined;

  const handleEdit = (
    step: 'organization' | 'admin' | 'plan'
  ) => {
    if (step === 'organization') {
      router.push(
        '/(organization)/register'
      );
      return;
    }

    if (step === 'admin') {
      router.push(
        '/(organization)/create-admin'
      );
      return;
    }

    router.push(
      '/(organization)/plan'
    );
  };

  const handleSubmit = async () => {
    if (isSubmitting) {
      return;
    }

    setError('');

    if (
      !organizationName.trim() ||
      !username.trim() ||
      !email.trim() ||
      !password
    ) {
      setError(
        'Some onboarding details are missing. Please review the previous steps.'
      );
      return;
    }

    if (password.length < 8) {
      setError(
        'Password must be at least 8 characters.'
      );
      return;
    }

    setIsSubmitting(true);

    try {
      await register({
        organizationName:
          organizationName.trim(),

        username:
          username.trim(),

        email:
          email.trim().toLowerCase(),

        password,
      });

      const loginResult =
        await login({
          email:
            email.trim().toLowerCase(),

          password,
        });

      if (
        !loginResult.success ||
        !loginResult.user
      ) {
        setError(
          loginResult.error ??
            'Organization created, but automatic login failed. Please sign in manually.'
        );
        return;
      }

      setAuthenticatedUser(
        loginResult.user
      );

      resetOnboarding();

      router.replace(
        '/(organization)/(tabs)/overview'
      );
    } catch (err) {
      console.error(
        'Organization registration failed:',
        err
      );

      setError(
        err instanceof Error
          ? err.message
          : 'Unable to create organization. Please try again.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AuthLayout
      variant="dark"
      title="Review & confirm"
      subtitle="Check your details before finishing setup"
    >
      <View style={styles.stepsContainer}>
        <View style={styles.stepsRow}>
          {STEPS.map((step, index) => {
            const isActive =
              step.id === currentStep;

            const isCompleted =
              step.id < currentStep;

            const isLast =
              index === STEPS.length - 1;

            return (
              <View
                key={step.id}
                style={styles.stepSlot}
              >
                {!isLast && (
                  <View
                    style={[
                      styles.stepConnector,
                      {
                        backgroundColor:
                          isCompleted
                            ? C.progressCircleActive
                            : C.progressLine,
                      },
                    ]}
                  />
                )}

                <View
                  style={styles.stepColumn}
                >
                  <View
                    style={[
                      styles.stepCircle,
                      {
                        backgroundColor:
                          isActive ||
                          isCompleted
                            ? C.progressCircleActive
                            : C.progressCircleInactive,
                      },
                    ]}
                  >
                    {isCompleted ? (
                      <Ionicons
                        name="checkmark"
                        size={16}
                        color="#FFFFFF"
                      />
                    ) : (
                      <Text
                        style={[
                          styles.stepNumber,
                          {
                            color: isActive
                              ? C.progressTextActive
                              : C.progressTextInactive,
                          },
                        ]}
                      >
                        {step.id}
                      </Text>
                    )}
                  </View>

                  <Text
                    style={styles.stepLabel}
                    numberOfLines={1}
                  >
                    {step.label}
                  </Text>
                </View>
              </View>
            );
          })}
        </View>
      </View>

      <View style={styles.sectionCard}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            Organization
          </Text>

          <Pressable
            onPress={() =>
              handleEdit('organization')
            }
            disabled={isSubmitting}
          >
            <Text style={styles.editText}>
              Edit
            </Text>
          </Pressable>
        </View>

        <View style={styles.row}>
          <Text style={styles.rowLabel}>
            Name
          </Text>

          <Text style={styles.rowValue}>
            {organizationName || '—'}
          </Text>
        </View>

        <View style={styles.row}>
          <Text style={styles.rowLabel}>
            Type
          </Text>

          <Text style={styles.rowValue}>
            {organizationType || '—'}
          </Text>
        </View>
      </View>

      <View style={styles.sectionCard}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            Admin
          </Text>

          <Pressable
            onPress={() =>
              handleEdit('admin')
            }
            disabled={isSubmitting}
          >
            <Text style={styles.editText}>
              Edit
            </Text>
          </Pressable>
        </View>

        <View style={styles.row}>
          <Text style={styles.rowLabel}>
            Full name
          </Text>

          <Text style={styles.rowValue}>
            {fullName || '—'}
          </Text>
        </View>

        <View style={styles.row}>
          <Text style={styles.rowLabel}>
            Email
          </Text>

          <Text style={styles.rowValue}>
            {email || '—'}
          </Text>
        </View>

        <View style={styles.row}>
          <Text style={styles.rowLabel}>
            Phone
          </Text>

          <Text style={styles.rowValue}>
            {phone || '—'}
          </Text>
        </View>
      </View>

      <View style={styles.sectionCard}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            Plan
          </Text>

          <Pressable
            onPress={() =>
              handleEdit('plan')
            }
            disabled={isSubmitting}
          >
            <Text style={styles.editText}>
              Edit
            </Text>
          </Pressable>
        </View>

        <View style={styles.row}>
          <Text style={styles.rowLabel}>
            Selected plan
          </Text>

          <Text style={styles.rowValue}>
            {selectedPlanDetails?.name ??
              '—'}
          </Text>
        </View>

        <View style={styles.row}>
          <Text style={styles.rowLabel}>
            Price
          </Text>

          <Text style={styles.rowValue}>
            {selectedPlanDetails
              ? `${selectedPlanDetails.price}${selectedPlanDetails.period}`
              : '—'}
          </Text>
        </View>
      </View>

      {error ? (
        <View style={styles.errorBox}>
          <Ionicons
            name="alert-circle-outline"
            size={16}
            color="#B23A48"
          />

          <Text style={styles.errorText}>
            {error}
          </Text>
        </View>
      ) : null}

      <Pressable
        style={[
          styles.continueButton,
          isSubmitting &&
            styles.continueButtonDisabled,
        ]}
        onPress={handleSubmit}
        disabled={isSubmitting}
      >
        {isSubmitting ? (
          <ActivityIndicator
            color="#FFFFFF"
          />
        ) : (
          <Text
            style={styles.continueButtonText}
          >
            Confirm & Finish
          </Text>
        )}
      </Pressable>
    </AuthLayout>
  );
}

const styles = StyleSheet.create({
  stepsContainer: {
    width: '100%',
    marginBottom: 16,
  },

  stepsRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    width: '100%',
  },

  stepSlot: {
    flex: 1,
    position: 'relative',
    alignItems: 'center',
  },

  stepColumn: {
    width: '100%',
    alignItems: 'center',
    zIndex: 2,
  },

  stepCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },

  stepNumber: {
    fontSize: 14,
    fontWeight: '700',
  },

  stepLabel: {
    width: '100%',
    fontSize: 11,
    color: C.title,
    marginTop: 4,
    textAlign: 'center',
  },

  stepConnector: {
    position: 'absolute',
    top: 15,
    left: '50%',
    width: '100%',
    height: 2,
    zIndex: 1,
  },

  sectionCard: {
    backgroundColor: C.inputBackground,
    borderRadius: 18,
    padding: 18,
    marginTop: 20,
  },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },

  sectionTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: C.title,
  },

  editText: {
    fontSize: 13,
    fontWeight: '600',
    color: C.label,
  },

  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
    gap: 16,
  },

  rowLabel: {
    fontSize: 13,
    color: C.subtitle,
  },

  rowValue: {
    flexShrink: 1,
    fontSize: 13,
    fontWeight: '600',
    color: C.title,
    textAlign: 'right',
  },

  errorBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    backgroundColor: '#FFF1F3',
    borderRadius: 12,
    padding: 12,
    marginTop: 16,
  },

  errorText: {
    flex: 1,
    color: '#B23A48',
    fontSize: 12,
    lineHeight: 17,
  },

  continueButton: {
    backgroundColor: C.buttonBackground,
    borderRadius: 16,
    height: 54,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 28,
  },

  continueButtonDisabled: {
    opacity: 0.7,
  },

  continueButtonText: {
    color: C.buttonText,
    fontSize: 15,
    fontWeight: '600',
  },
});
