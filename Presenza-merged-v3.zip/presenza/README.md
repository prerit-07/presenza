# Presenza — merged repo

This repo combines the two previously-separate projects into one:

- `presenza/backend` — Spring Boot REST API. UI/behavior is unchanged; internal
  logic bugs found in this round of auditing are fixed (see below). Now includes
  a real database schema — see "Database setup" below.
- `presenza/app` — Expo / React Native mobile app (fixed — see below). UI was
  left untouched throughout; only data-wiring/logic bugs were fixed.

The app currently still points at the old shared deployment
(`https://presenza-backend-sumit-hugqdzfwfxeybngu.centralindia-01.azurewebsites.net`)
in `app/services/api.ts` — update `API_BASE_URL` there once you deploy your own
backend (see "Deploying" below).

## Database setup (new)

The backend source as originally provided had NO baseline database schema —
only 4 incremental patch files, assuming a schema that was never included.
This is now fixed: `backend/src/main/resources/db/migration/` contains a
complete Flyway migration set:

- `V1__baseline_schema.sql` — full baseline, reverse-engineered from every
  JPA `@Entity` class (27 tables, correct FK order, circular team/employee
  reference handled via a trailing `ALTER TABLE`).
- `V2`-`V5` — the original 4 patch files, renamed into proper Flyway order.

To use your own PostgreSQL:

1. Create an empty database (e.g. `createdb presenza`).
2. Copy `backend/.env.example` to `backend/.env` (or set these as real env
   vars / platform "Environment" settings) and fill in `DB_URL`,
   `DB_USERNAME`, `DB_PASSWORD`, `MAIL_USERNAME`, `MAIL_PASSWORD`.
3. Run `./gradlew bootRun` (or build a jar with `./gradlew build` and run
   `java -jar build/libs/*.jar`). Flyway runs all 5 migrations automatically
   on startup — no manual SQL needed.

## Backend logic fixes (this round)

1. **Geofence write endpoints had no role check.** `GeofenceService`
   (create/update/delete) only checked the caller's org, not their role —
   any authenticated employee could create, move, or delete their org's
   geofences, undermining the GPS check-in validation. Added the same
   `ORG_ADMIN`/`MANAGER` gate every other management service already has.
2. **Deactivated-account login returned a 500 instead of a 403.**
   `AuthService.login` threw a plain `IllegalStateException` with no
   handler, falling through to a generic 500. Now throws `ForbiddenException`
   (mapped to 403) with the real message.
3. **OTP verification had no attempt limit.** A caller could brute-force a
   6-digit OTP with unlimited guesses inside its 5-minute window. Added an
   `attempt_count` column and a 5-attempt cap; the OTP is invalidated after
   too many wrong guesses.
4. **Check-in race condition.** The duplicate-check-in guard was a
   check-then-insert with no DB-level constraint, so two concurrent
   check-in requests could both pass validation. Added a unique index on
   `(user_id, shift_id, day)` plus a matching catch so a genuine race now
   fails the second request cleanly instead of creating duplicate rows.
5. **Employee creation was rolled back by a transient email failure.**
   `EmployeeService.createEmployee` rethrew any welcome-email send error,
   rolling back the whole employee/user/role creation over an SMTP hiccup.
   Now logs a warning and continues — the employee record is the source of
   truth, the email is best-effort.

## Bugs found and fixed in `presenza/app` (checked against the real backend DTOs/controllers)

1. **Employee check-in never retried device registration.** Device registration at
   login/session-restore silently swallows its own errors. Check-in had no fallback, so a
   single failed registration meant permanent "Device not found" until the app was killed
   and reopened. Added a retry in `app/(employee)/remote-checkin.tsx`.

2. **Manager check-in sent the wrong Wi-Fi field names** (`wifiSsid`/`wifiBssid` instead of
   `connectedSsid`/`connectedBssid`) and never read the device's Wi-Fi at all — managers
   could never get `PRESENT` status, always `PENDING`. Fixed in
   `app/(manager)/remote-checkin.tsx` to match the employee screen's correct
   implementation, plus the same device-registration retry.

3. **Departments screen sent the wrong ID as `orgId`.** It used `user.userId` (the logged-in
   person's ID) with a hardcoded `|| 1` fallback, silently attaching new departments to the
   wrong organization. Fixed in `app/(organization)/departments.tsx` to fetch the real org
   via `getMyOrganization()`.

4. **Same exact bug in the geofence editor** (`app/(organization)/manage-geofence.tsx`) —
   identical fix applied.

5. **Ticket comments always failed backend validation.** Sent `{ comment }` but the backend's
   `AddTicketCommentRequest` requires a field literally named `message`
   (`@NotBlank(message = "Comment message is required")`) — every comment attempt was
   rejected with a 400. Fixed in `services/ticket.service.ts`.

6. **Manager's Leave Approvals screen never touched the backend.** It read/wrote a
   hardcoded local mock store (`store/useAppStore.ts`, seeded with 2 fake leave requests).
   Approving/rejecting only updated local state — the real `attendance_request` row on the
   server stayed `PENDING` forever no matter what a manager did. Rewired
   `app/(manager)/leave-approvals.tsx` to fetch `GET /attendance-requests` and call the
   real `PATCH /attendance-requests/{id}/review`.

7. **WFH Approvals screen was 100% fake** — a literal hardcoded array baked into the
   component (two made-up employees), no network calls at all. Same fix applied to
   `app/(manager)/wfh-approvals.tsx`.

8. **Device Approvals screen had the same problem** — approving/rejecting a device change
   never called the backend, so an employee's actual device swap was never applied
   server-side. Rewired `app/(manager)/device-approvals.tsx` to use the already-correct
   (but previously unused) `deviceChangeService`.

### Verified clean (no bug found)

- Auth (`login`/`logout`/`register`/OTP flows) — `services/auth.service.ts`,
  `app/(auth)/*`, `app/(organization)/create-admin.tsx`, `review.tsx` — all match the
  backend's `LoginRequest`/`RegisterRequest`/`SendOtpRequest` DTOs exactly.
- `services/shift.service.ts`, `services/geofence.service.ts`, `services/employee.service.ts`,
  `services/device.change.service.ts`, `services/request.service.ts` (leave/WFH
  *submission* — `apply-leave.tsx` / `apply-wfh.tsx` were always correct; only the
  *approval* screens were broken).
- Import/export consistency across the whole codebase (checked with a custom static
  analysis pass — every `import { X } from '...'` resolves to a real export).

### Known, deliberately unfixed items

- `app/(auth)/sign-up.tsx` is dead code — registered in the router but nothing navigates to
  it. The real self-registration flow is `register.tsx` → `create-admin.tsx` →
  `company-verification.tsx` → `plan.tsx` → `review.tsx`.
- The "My Team" tab's roster (`app/(employee|manager)/(tabs)/teamState.ts`) is a
  self-contained mock/demo feature with no matching backend endpoint to wire it to — left
  as a known placeholder rather than inventing new backend behavior.
- `tsc-errors*.txt` files bundled in the original app zip were stale snapshots from an
  earlier broken state of the code, not current bugs — confirmed by re-checking every
  import/export they flagged against the current source.

## Also fixed earlier in the same session (website, `gps_fr` repo — not part of this zip)

The companion website repo (separate project, already pushed to its own GitHub remote)
had the same class of bugs: missing `orgId` on shift/department/team create+update, a
site-wide login bug where every page forced a dead shared demo account instead of the
logged-in user's own session, and a missing device-registration step before check-in.
Those are already fixed and pushed there — see that repo's own git history.
